package u.aly;

public class db {
    public final String a;
    public final byte b;
    public final short c;

    public db() {
        this("", (byte) 0, 0);
    }

    public db(String str, byte b2, short s) {
        this.a = str;
        this.b = b2;
        this.c = s;
    }

    public boolean a(db dbVar) {
        return this.b == dbVar.b && this.c == dbVar.c;
    }

    public String toString() {
        return "<TField name:'" + this.a + "' type:" + ((int) this.b) + " field-id:" + ((int) this.c) + ">";
    }
}
