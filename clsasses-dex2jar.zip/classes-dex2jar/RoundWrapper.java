package com.keyboard.common.uimodule;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Region;
import android.util.AttributeSet;
import android.widget.FrameLayout;

public class RoundWrapper extends FrameLayout {
    private static final float DEFAULT_RADIUS_X = 20.0f;
    private static final float DEFAULT_RADIUS_Y = 20.0f;
    private Paint mPaint;
    private Path mPath;
    private float mRadiusX;
    private float mRadiusY;
    private RectF mRect;

    public RoundWrapper(Context context) {
        super(context);
        init(context, null);
    }

    public RoundWrapper(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public RoundWrapper(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        init(context, attributeSet);
    }

    private void init(Context context, AttributeSet attributeSet) {
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R.styleable.RoundWrapper, 0, 0);
            this.mRadiusX = obtainStyledAttributes.getDimension(R.styleable.RoundWrapper_radiusX, 20.0f);
            this.mRadiusY = obtainStyledAttributes.getDimension(R.styleable.RoundWrapper_radiusY, 20.0f);
            obtainStyledAttributes.recycle();
        } else {
            this.mRadiusX = 20.0f;
            this.mRadiusY = 20.0f;
        }
        this.mPaint = new Paint();
        this.mPaint.setColor(-2130771968);
        this.mPaint.setDither(true);
        this.mPaint.setAntiAlias(true);
        this.mPath = new Path();
        this.mRect = new RectF();
        setLayerType(1, null);
    }

    /* access modifiers changed from: protected */
    public void dispatchDraw(Canvas canvas) {
        canvas.save();
        canvas.clipPath(this.mPath, Region.Op.REPLACE);
        super.dispatchDraw(canvas);
        canvas.restore();
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        if (z) {
            this.mPath.reset();
            this.mRect.set((float) getPaddingLeft(), (float) getPaddingTop(), (float) ((i3 - i) - getPaddingRight()), (float) ((i4 - i2) - getPaddingBottom()));
            this.mPath.addRoundRect(this.mRect, this.mRadiusX, this.mRadiusY, Path.Direction.CW);
        }
    }

    public void setRadiusX(float f) {
        this.mRadiusX = f;
        requestLayout();
        invalidate();
    }

    public void setRadiusY(float f) {
        this.mRadiusX = f;
        requestLayout();
        invalidate();
    }
}
