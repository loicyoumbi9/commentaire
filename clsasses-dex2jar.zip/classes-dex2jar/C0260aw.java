package com.ironsource.mobilcore;

import android.content.Context;
import android.text.TextUtils;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import org.json.JSONObject;

/* renamed from: com.ironsource.mobilcore.aw  reason: case insensitive filesystem */
final class C0260aw extends I {
    private final int a = 48;

    public C0260aw(Context context, C0261ax axVar) {
        super(context, axVar);
    }

    @Override // com.ironsource.mobilcore.H
    public final String a() {
        return "sliderHeader";
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: com.ironsource.mobilcore.I.a(org.json.JSONObject, boolean):void
     arg types: [org.json.JSONObject, int]
     candidates:
      com.ironsource.mobilcore.I.a(com.ironsource.mobilcore.MCEWidgetTextProperties, java.lang.String):void
      com.ironsource.mobilcore.I.a(org.json.JSONObject, boolean):void */
    @Override // com.ironsource.mobilcore.H
    public final void a(JSONObject jSONObject) {
        super.a(jSONObject, true);
    }

    /* access modifiers changed from: protected */
    @Override // com.ironsource.mobilcore.H
    public final void c() {
        this.h = new RelativeLayout(this.c);
        this.h.setPadding(this.d.h(), this.d.j(), this.d.h(), this.d.j());
        this.h.setEnabled(false);
    }

    /* access modifiers changed from: protected */
    @Override // com.ironsource.mobilcore.H
    public final void d() {
        ViewGroup viewGroup = (ViewGroup) this.h;
        this.s = new ImageView(this.c);
        this.s.setId(j());
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(C.b(this.c, 48.0f), C.b(this.c, 48.0f));
        layoutParams.addRule(15);
        layoutParams.rightMargin = C.b(this.c, 9.0f);
        this.s.setLayoutParams(layoutParams);
        viewGroup.addView(this.s);
        this.p = new TextView(this.c);
        this.p.setBackgroundColor(0);
        RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams2.addRule(1, this.s.getId());
        layoutParams2.addRule(15);
        this.p.setLayoutParams(layoutParams2);
        this.p.setId(j());
        this.p.setSingleLine();
        this.p.setEllipsize(TextUtils.TruncateAt.END);
        this.p.setTypeface(null, 1);
        C.a(this.p, 18.0f);
        viewGroup.addView(this.p);
        this.d.a(true, this.d.b(), this.p);
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Removed duplicated region for block: B:14:? A[RETURN, SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:6:0x0022  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0029  */
    @Override // com.ironsource.mobilcore.H
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void e() {
        /*
            r5 = this;
            r2 = 0
            android.content.Context r0 = r5.c
            android.content.Context r0 = r0.getApplicationContext()
            android.content.pm.PackageManager r3 = r0.getPackageManager()
            android.content.Context r0 = r5.c     // Catch:{ NameNotFoundException -> 0x003d }
            java.lang.String r0 = r0.getPackageName()     // Catch:{ NameNotFoundException -> 0x003d }
            android.graphics.drawable.Drawable r1 = r3.getApplicationIcon(r0)     // Catch:{ NameNotFoundException -> 0x003d }
            android.content.Context r0 = r5.c     // Catch:{ NameNotFoundException -> 0x0043 }
            java.lang.String r0 = r0.getPackageName()     // Catch:{ NameNotFoundException -> 0x0043 }
            r4 = 0
            android.content.pm.ApplicationInfo r2 = r3.getApplicationInfo(r0, r4)     // Catch:{ NameNotFoundException -> 0x0043 }
        L_0x0020:
            if (r1 == 0) goto L_0x0027
            android.widget.ImageView r0 = r5.s
            r0.setImageDrawable(r1)
        L_0x0027:
            if (r2 == 0) goto L_0x003c
            java.lang.CharSequence r0 = r3.getApplicationLabel(r2)
            java.lang.String r0 = (java.lang.String) r0
            java.lang.String r0 = r0.toUpperCase()
            android.widget.TextView r1 = r5.p
            java.lang.String r0 = r0.toUpperCase()
            r1.setText(r0)
        L_0x003c:
            return
        L_0x003d:
            r0 = move-exception
            r1 = r2
        L_0x003f:
            r0.printStackTrace()
            goto L_0x0020
        L_0x0043:
            r0 = move-exception
            goto L_0x003f
        */
        throw new UnsupportedOperationException("Method not decompiled: com.ironsource.mobilcore.C0260aw.e():void");
    }

    /* access modifiers changed from: protected */
    @Override // com.ironsource.mobilcore.I
    public final boolean f() {
        return true;
    }
}
