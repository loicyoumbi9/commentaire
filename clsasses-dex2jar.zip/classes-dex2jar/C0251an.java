package com.ironsource.mobilcore;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.GradientDrawable;
import android.support.v4.view.ViewCompat;
import android.view.MotionEvent;

@SuppressLint({"NewApi"})
/* renamed from: com.ironsource.mobilcore.an  reason: case insensitive filesystem */
final class C0251an extends C0244ag {
    C0251an(Activity activity, int i) {
        super(activity, i);
    }

    private void f(int i) {
        if (this.n && this.A != 0) {
            int i2 = this.A;
            float f = (((float) i2) + ((float) i)) / ((float) i2);
            if (!p) {
                this.y.offsetLeftAndRight((((int) ((((float) i2) * f) * 0.25f)) + getWidth()) - this.y.getRight());
                this.y.setVisibility(i == 0 ? 4 : 0);
            } else if (i != 0) {
                this.y.setTranslationX((float) ((int) (((float) i2) * f * 0.25f)));
            } else {
                this.y.setTranslationX((float) (-i2));
            }
        }
    }

    /* access modifiers changed from: protected */
    @Override // com.ironsource.mobilcore.C0243af
    public final void a() {
        this.k.a(0, 0, (-this.A) / 3, 0, 1000);
    }

    @Override // com.ironsource.mobilcore.C0247aj
    public final void a(int i) {
        this.s = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{ViewCompat.MEASURED_STATE_MASK, 0});
        invalidate();
    }

    /* access modifiers changed from: protected */
    @Override // com.ironsource.mobilcore.C0243af
    public final void a(Canvas canvas, int i) {
        int height = getHeight();
        int width = getWidth() + i;
        this.s.setBounds(width, 0, this.t + width, height);
        this.s.draw(canvas);
    }

    @Override // com.ironsource.mobilcore.C0247aj
    public final void a(boolean z) {
        a(-this.A, 0, z);
    }

    /* access modifiers changed from: protected */
    @Override // com.ironsource.mobilcore.C0243af
    public final boolean a(float f) {
        int width = getWidth();
        int i = (int) this.f;
        return (!this.C && i >= width - this.F && f < 0.0f) || (this.C && ((float) i) <= ((float) width) + this.d);
    }

    /* access modifiers changed from: protected */
    @Override // com.ironsource.mobilcore.C0243af
    public final boolean a(MotionEvent motionEvent) {
        return motionEvent.getX() < ((float) getWidth()) + this.d;
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: ClspMth{java.lang.Math.min(float, float):float}
     arg types: [float, int]
     candidates:
      ClspMth{java.lang.Math.min(double, double):double}
      ClspMth{java.lang.Math.min(long, long):long}
      ClspMth{java.lang.Math.min(int, int):int}
      ClspMth{java.lang.Math.min(float, float):float} */
    /* access modifiers changed from: protected */
    @Override // com.ironsource.mobilcore.C0243af
    public final void b(float f) {
        c(Math.max(Math.min(this.d + f, 0.0f), (float) (-this.A)));
    }

    /* access modifiers changed from: protected */
    @Override // com.ironsource.mobilcore.C0243af
    public final void b(int i) {
        if (p) {
            this.z.setTranslationX((float) i);
            f(i);
            invalidate();
            return;
        }
        this.z.offsetLeftAndRight(i - this.z.getLeft());
        f(i);
        invalidate();
    }

    /* access modifiers changed from: protected */
    @Override // com.ironsource.mobilcore.C0243af
    public final void b(Canvas canvas, int i) {
        int height = getHeight();
        int width = getWidth();
        float abs = ((float) Math.abs(i)) / ((float) this.A);
        this.q.setBounds(width + i, 0, width, height);
        this.q.setAlpha((int) (185.0f * (1.0f - abs)));
        this.q.draw(canvas);
    }

    /* access modifiers changed from: protected */
    @Override // com.ironsource.mobilcore.C0243af
    public final void b(MotionEvent motionEvent) {
        int i = (int) this.d;
        int width = getWidth();
        if (this.e) {
            this.l.computeCurrentVelocity(1000, (float) this.m);
            int xVelocity = (int) this.l.getXVelocity();
            this.h = motionEvent.getX();
            a(this.l.getXVelocity() > 0.0f ? 0 : -this.A, xVelocity, true);
        } else if (this.C && motionEvent.getX() < ((float) (i + width))) {
            b(true);
        }
    }

    @Override // com.ironsource.mobilcore.C0247aj
    public final void b(boolean z) {
        a(0, 0, z);
    }

    /* access modifiers changed from: protected */
    @Override // com.ironsource.mobilcore.C0243af
    public final boolean b() {
        int width = getWidth();
        int i = (int) this.f;
        return (!this.C && i >= width - this.F) || (this.C && ((float) i) <= ((float) width) + this.d);
    }

    /* access modifiers changed from: protected */
    @Override // com.ironsource.mobilcore.C0243af
    public final void c(Canvas canvas, int i) {
        if (this.v != null && this.v.getParent() != null && this.w == 0) {
            int width = getWidth();
            int i2 = this.A;
            int width2 = this.f6u.getWidth();
            int i3 = width + i;
            float abs = ((float) Math.abs(i)) / ((float) i2);
            this.v.getDrawingRect(this.x);
            offsetDescendantRectToMyCoords(this.v, this.x);
            int interpolation = ((int) ((1.0f - a.getInterpolation(1.0f - abs)) * ((float) width2))) + i3;
            canvas.save();
            canvas.clipRect(i3, 0, interpolation, getHeight());
            canvas.drawBitmap(this.f6u, (float) (interpolation - width2), (float) (this.x.top + ((this.x.height() - this.f6u.getHeight()) / 2)), (Paint) null);
            canvas.restore();
        }
    }

    /* access modifiers changed from: protected */
    public final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int i5 = i3 - i;
        int i6 = i4 - i2;
        int i7 = (int) this.d;
        this.y.layout(i5 - this.A, 0, i5, i6);
        f(i7);
        if (p) {
            this.z.layout(0, 0, i5, i6);
        } else {
            this.z.layout(i7, 0, i5 + i7, i6);
        }
    }
}
