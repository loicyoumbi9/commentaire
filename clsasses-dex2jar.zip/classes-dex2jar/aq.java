package u.aly;

import com.alimama.mobile.csdk.umupdate.a.f;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.BitSet;
import java.util.Collections;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class aq implements Serializable, Cloneable, ch<aq, e> {
    public static final Map<e, ct> b;
    /* access modifiers changed from: private */
    public static final dl c = new dl("ControlPolicy");
    /* access modifiers changed from: private */
    public static final db d = new db("latent", (byte) 12, 1);
    private static final Map<Class<? extends Cdo>, dp> e = new HashMap();
    public bd a;
    private e[] f = {e.LATENT};

    private static class a extends dq<aq> {
        private a() {
        }

        /* renamed from: a */
        public void b(dg dgVar, aq aqVar) throws cn {
            dgVar.j();
            while (true) {
                db l = dgVar.l();
                if (l.b == 0) {
                    dgVar.k();
                    aqVar.f();
                    return;
                }
                switch (l.c) {
                    case 1:
                        if (l.b != 12) {
                            dj.a(dgVar, l.b);
                            break;
                        } else {
                            aqVar.a = new bd();
                            aqVar.a.a(dgVar);
                            aqVar.a(true);
                            break;
                        }
                    default:
                        dj.a(dgVar, l.b);
                        break;
                }
                dgVar.m();
            }
        }

        /* renamed from: b */
        public void a(dg dgVar, aq aqVar) throws cn {
            aqVar.f();
            dgVar.a(aq.c);
            if (aqVar.a != null && aqVar.e()) {
                dgVar.a(aq.d);
                aqVar.a.b(dgVar);
                dgVar.c();
            }
            dgVar.d();
            dgVar.b();
        }
    }

    private static class b implements dp {
        private b() {
        }

        /* renamed from: a */
        public a b() {
            return new a();
        }
    }

    private static class c extends dr<aq> {
        private c() {
        }

        public void a(dg dgVar, aq aqVar) throws cn {
            dm dmVar = (dm) dgVar;
            BitSet bitSet = new BitSet();
            if (aqVar.e()) {
                bitSet.set(0);
            }
            dmVar.a(bitSet, 1);
            if (aqVar.e()) {
                aqVar.a.b(dmVar);
            }
        }

        public void b(dg dgVar, aq aqVar) throws cn {
            dm dmVar = (dm) dgVar;
            if (dmVar.b(1).get(0)) {
                aqVar.a = new bd();
                aqVar.a.a(dmVar);
                aqVar.a(true);
            }
        }
    }

    private static class d implements dp {
        private d() {
        }

        /* renamed from: a */
        public c b() {
            return new c();
        }
    }

    public enum e implements co {
        LATENT(1, "latent");
        
        private static final Map<String, e> b = new HashMap();
        private final short c;
        private final String d;

        static {
            Iterator it = EnumSet.allOf(e.class).iterator();
            while (it.hasNext()) {
                e eVar = (e) it.next();
                b.put(eVar.b(), eVar);
            }
        }

        private e(short s, String str) {
            this.c = s;
            this.d = str;
        }

        public static e a(int i) {
            switch (i) {
                case 1:
                    return LATENT;
                default:
                    return null;
            }
        }

        public static e a(String str) {
            return b.get(str);
        }

        public static e b(int i) {
            e a = a(i);
            if (a != null) {
                return a;
            }
            throw new IllegalArgumentException("Field " + i + " doesn't exist!");
        }

        @Override // u.aly.co
        public short a() {
            return this.c;
        }

        @Override // u.aly.co
        public String b() {
            return this.d;
        }
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: MutableMD:(java.lang.Object, java.lang.Object):java.lang.Object
     arg types: [u.aly.aq$e, u.aly.ct]
     candidates:
      MutableMD:(java.lang.Enum, java.lang.Object):java.lang.Object
      MutableMD:(java.lang.Object, java.lang.Object):java.lang.Object */
    static {
        e.put(dq.class, new b());
        e.put(dr.class, new d());
        EnumMap enumMap = new EnumMap(e.class);
        enumMap.put((Object) e.LATENT, (Object) new ct("latent", (byte) 2, new cy((byte) 12, bd.class)));
        b = Collections.unmodifiableMap(enumMap);
        ct.a(aq.class, b);
    }

    public aq() {
    }

    public aq(aq aqVar) {
        if (aqVar.e()) {
            this.a = new bd(aqVar.a);
        }
    }

    private void a(ObjectInputStream objectInputStream) throws IOException, ClassNotFoundException {
        try {
            a(new da(new ds(objectInputStream)));
        } catch (cn e2) {
            throw new IOException(e2.getMessage());
        }
    }

    private void a(ObjectOutputStream objectOutputStream) throws IOException {
        try {
            b(new da(new ds(objectOutputStream)));
        } catch (cn e2) {
            throw new IOException(e2.getMessage());
        }
    }

    /* renamed from: a */
    public e b(int i) {
        return e.a(i);
    }

    /* renamed from: a */
    public aq g() {
        return new aq(this);
    }

    public aq a(bd bdVar) {
        this.a = bdVar;
        return this;
    }

    @Override // u.aly.ch
    public void a(dg dgVar) throws cn {
        e.get(dgVar.D()).b().b(dgVar, this);
    }

    public void a(boolean z) {
        if (!z) {
            this.a = null;
        }
    }

    @Override // u.aly.ch
    public void b() {
        this.a = null;
    }

    @Override // u.aly.ch
    public void b(dg dgVar) throws cn {
        e.get(dgVar.D()).b().a(dgVar, this);
    }

    public bd c() {
        return this.a;
    }

    public void d() {
        this.a = null;
    }

    public boolean e() {
        return this.a != null;
    }

    public void f() throws cn {
        if (this.a != null) {
            this.a.j();
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("ControlPolicy(");
        if (e()) {
            sb.append("latent:");
            if (this.a == null) {
                sb.append(f.b);
            } else {
                sb.append(this.a);
            }
        }
        sb.append(")");
        return sb.toString();
    }
}
