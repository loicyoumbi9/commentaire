package u.aly;

public interface cl {
    int a();
}
