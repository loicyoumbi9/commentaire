package com.ironsource.mobilcore;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;
import android.view.View;
import org.json.JSONObject;

final class K extends R {
    private String a;
    private String b;

    public K(Context context, C0261ax axVar) {
        super(context, axVar);
    }

    @Override // com.ironsource.mobilcore.H
    public final String a() {
        return "ironsourceFeedback";
    }

    /* access modifiers changed from: protected */
    @Override // com.ironsource.mobilcore.H, com.ironsource.mobilcore.I
    public final void a(View view) {
        super.a(view);
        if (!TextUtils.isEmpty(this.a) && !TextUtils.isEmpty(this.b)) {
            Intent intent = new Intent("android.intent.action.SENDTO");
            intent.setData(Uri.parse("mailto:" + Uri.encode(this.a) + "?subject=" + Uri.encode(this.b)));
            this.e.startActivity(Intent.createChooser(intent, ""));
        }
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: com.ironsource.mobilcore.I.a(org.json.JSONObject, boolean):void
     arg types: [org.json.JSONObject, int]
     candidates:
      com.ironsource.mobilcore.I.a(com.ironsource.mobilcore.MCEWidgetTextProperties, java.lang.String):void
      com.ironsource.mobilcore.I.a(org.json.JSONObject, boolean):void */
    @Override // com.ironsource.mobilcore.R, com.ironsource.mobilcore.H
    public final void a(JSONObject jSONObject) {
        this.a = jSONObject.optString("mailRecipient", "");
        this.b = jSONObject.optString("mailSubject", "");
        super.a(jSONObject, true);
    }
}
