package com.ironsource.mobilcore;

import android.content.Context;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

abstract class E extends I {
    public E(Context context, C0261ax axVar) {
        super(context, axVar);
    }

    /* access modifiers changed from: protected */
    @Override // com.ironsource.mobilcore.H
    public final void c() {
        this.h = new RelativeLayout(this.c);
    }

    /* access modifiers changed from: protected */
    @Override // com.ironsource.mobilcore.H
    public final void d() {
        this.s = new ImageView(this.c);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
        layoutParams.gravity = 1;
        layoutParams.bottomMargin = C.b(this.c, 15.0f);
        this.s.setLayoutParams(layoutParams);
        this.p = new TextView(this.c);
        this.p.setBackgroundColor(0);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams2.gravity = 1;
        this.p.setLayoutParams(layoutParams2);
        this.p.setGravity(1);
        this.p.setTypeface(null, 1);
        this.p.setTextColor(this.d.b().a(true));
        this.p.setSingleLine();
        this.p.setEllipsize(TextUtils.TruncateAt.END);
        C.a(this.p, 16.0f);
        LinearLayout linearLayout = new LinearLayout(this.c);
        linearLayout.setId(j());
        linearLayout.setOrientation(1);
        RelativeLayout.LayoutParams layoutParams3 = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams3.addRule(13);
        linearLayout.setLayoutParams(layoutParams3);
        linearLayout.setPadding(this.d.h(), this.d.h(), this.d.h(), this.d.h());
        View view = new View(this.c);
        RelativeLayout.LayoutParams layoutParams4 = new RelativeLayout.LayoutParams(C.b(this.c, (float) this.d.g()), -2);
        layoutParams4.addRule(11);
        layoutParams4.addRule(6, linearLayout.getId());
        layoutParams4.addRule(8, linearLayout.getId());
        view.setLayoutParams(layoutParams4);
        view.setBackgroundColor(this.d.e());
        ViewGroup viewGroup = (ViewGroup) this.h;
        viewGroup.setClickable(true);
        viewGroup.setFocusable(true);
        viewGroup.addView(linearLayout);
        viewGroup.addView(view);
        linearLayout.addView(this.s);
        linearLayout.addView(this.p);
        a(this.d.o(), this.d.b(), this.p);
    }

    /* access modifiers changed from: protected */
    @Override // com.ironsource.mobilcore.H
    public final void e() {
        this.p.setText(this.l);
        if (!TextUtils.isEmpty(this.o)) {
            this.s.setImageBitmap(C.b(this.c, this.o));
        }
    }
}
