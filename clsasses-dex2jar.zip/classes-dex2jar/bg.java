package com.ironsource.mobilcore;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Point;
import android.os.Build;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.ironsource.mobilcore.aS;
import com.ironsource.mobilcore.aX;
import com.ironsource.mobilcore.bc;
import org.json.JSONObject;

final class bg extends RelativeLayout implements View.OnTouchListener {
    private static Bitmap e;
    private int a;
    /* access modifiers changed from: private */
    public aX.b b;
    private bc.a c;
    private LinearLayout d;

    public bg(Context context, bc.a aVar, aX.b bVar) {
        super(context);
        try {
            this.c = aVar;
            if (e == null) {
                e = C.b("iVBORw0KGgoAAAANSUhEUgAAAEYAAABGCAMAAABG8BK2AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA2RpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMC1jMDYwIDYxLjEzNDc3NywgMjAxMC8wMi8xMi0xNzozMjowMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDo1RDVCOTE2MjkyNURFMzExOEUxRUI5ODgyM0IyQjAxQyIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDoyNjFENDM2NzVEOUYxMUUzQkY2N0I5QTU1MzNBQUZDRSIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDoyNjFENDM2NjVEOUYxMUUzQkY2N0I5QTU1MzNBQUZDRSIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ1M1IFdpbmRvd3MiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo1RTVCOTE2MjkyNURFMzExOEUxRUI5ODgyM0IyQjAxQyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo1RDVCOTE2MjkyNURFMzExOEUxRUI5ODgyM0IyQjAxQyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PusLT/cAAAE+UExURf///2ZmZmVlZVxcXGRkZGFhYWNjY11dXYKCgmdnZ3BwcPv7+2BgYNjY2F5eXv7+/vz8/Gtra6SkpGpqaqGhoWJiYubm5pycnK2trZWVlf39/V9fX/j4+GhoaH9/f46Ojs/Pz8XFxW9vb+np6ff394yMjIGBgbi4uKWlpZ2dnVtbW9zc3Ovr6/Ly8tDQ0PX19ZiYmJ+fn+rq6vb29tnZ2XZ2duDg4OLi4u7u7nR0dOTk5KamppaWlufn55mZmfPz87S0tImJiaenp6ysrM7OzmlpadHR0ZeXl3V1ddvb27Ozs6CgoKKiotLS0m1tbW5ublpaWtXV1fn5+VlZWWxsbPHx8cvLy9TU1H5+foeHh9fX1/T09JqampCQkPDw8HFxcXd3d3Nzc/r6+pubm9PT08rKyqurq4uLi5GRkf///2B65lQAAABqdFJOU////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////wC85NzjAAADMUlEQVR42uyXZ3/aMBCHdR7yBFNDGA57EzIge7XZu83u3rv9/l+gsg3ENl751S+5N2AkPZxO+t+d0d8wJqVb+zl+RRRX+Nx+Ky2NTUAhIJvZZhIslmxmNx+NiW0bDIrBrCyzmKEM0nbsUZinHYGsYmQaH4l8o8GLR5iWGfKT0HkaHlPZICswJ/C7h7UlSVGkpdrhLi9wmPy8UQmJyad0T7iquppAFkusqlVO9yiVD4OZK5Gp06DOojGbVckAQGkuGLOzRwJLF5eRqy0XaRLsvZ0gTJ74wsQzC8jDFjJxsrFSPgBD4kLFs8jHsnHiT8ofUwmkDDgVP8yiCEBnUIBlaABx0QeTIWdUrOtT5/qlrnP5ze92Xv+sF8l5ZbwxXQEYONNnfnp7R9/H7JRjgb77Y8T+jEwTup6YHADXNq7ax2sA9omNcwxTANffNf17mwPIeWHSBcDVdX3a0qV+722csk4B9uut/rBexVBIe2AOiDOqsUZLzYCdMy/oFGrml/moEncO3DFKEyhhzZz2rceZnMFtfmH4QsUvNPN5TaCgqbhi0kmQeW0oxBPa4s88ZVDo/tA5jZchmXbFtMidOR/FQnr2sK+yuSM6pYyGz8m/tFwxW0DhMrJwzH3dd28EVqdwKc0ScUzBFnI/bqZQsyaYE4MzdZU0fOH61uOvFRjIuWJ4wGLdlqh6RnwYxtjRhe0u1kUMvCvmFFjelu+Q9IEelAWKfq7YhhI8C6euGBHkhkNFUgebFNxWHEMNGcSwGFSeosw6E0NhMeObQuWC6Q3gSwfHe1NjIR4oAADGdOoTYueBEwWwBoF14XgfuOP6oXlTR5za4cY53tfPLgaiANY8aaQNdfEOhRCDTZokSw0UQE5a6jn98ZGmNVGYuW6kALve/ROFJW0N4zLSdKJnz2M+acuSRG+/TJtx0R70bvgTL0qBSfQhpedXZD3X9S0KMOMz/UYKTOmWAvOKYhmHphMnM4wsvA5RYCzl7ucVONUodZjPP8KUO2vxfenS3yy+D1d8I2oFompMomqTImraomoho2poo2qvI2v2o3r1iOxFKLLXshA2wUwwE8wEM8H8h/0TYACZQeeCp+VpcAAAAABJRU5ErkJggg==");
            }
            final JSONObject d2 = aVar.d();
            String string = d2.getString("title");
            String string2 = d2.getString("desc");
            String a2 = aT.a(C0282t.a().b(), d2.getString("img"));
            int applyDimension = (int) TypedValue.applyDimension(1, 5.0f, getResources().getDisplayMetrics());
            this.a = (int) TypedValue.applyDimension(1, 70.0f, getResources().getDisplayMetrics());
            setLayoutParams(new RelativeLayout.LayoutParams(-1, -2));
            setPadding(applyDimension, applyDimension, applyDimension, 0);
            setClipToPadding(false);
            this.d = new LinearLayout(context);
            this.d.setOrientation(0);
            int a3 = a(context);
            B.a("setupLayout() | pageWidth = " + a3, 55);
            this.d.setLayoutParams(new LinearLayout.LayoutParams(a3 - (applyDimension * 2), -2));
            C.a(this.d, this.c.b());
            this.d.setPadding(applyDimension, applyDimension, applyDimension, applyDimension);
            this.d.setClickable(true);
            this.d.setOnClickListener(new View.OnClickListener() {
                /* class com.ironsource.mobilcore.bg.AnonymousClass1 */

                public final void onClick(View view) {
                    if (bg.this.b != null) {
                        bg.this.b.a(d2);
                    }
                }
            });
            this.d.setId(1);
            bj bjVar = new bj(context);
            int i = this.a - (applyDimension * 2);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(i, i);
            layoutParams.setMargins(applyDimension, applyDimension, applyDimension, applyDimension);
            bjVar.setLayoutParams(layoutParams);
            bjVar.a(a2);
            ImageView imageView = new ImageView(context);
            LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(i, i);
            layoutParams2.setMargins(applyDimension, applyDimension, applyDimension, applyDimension);
            imageView.setLayoutParams(layoutParams2);
            C.a(imageView, this.c.c());
            LinearLayout linearLayout = new LinearLayout(context);
            linearLayout.setOrientation(1);
            linearLayout.setPadding(applyDimension, applyDimension, applyDimension, applyDimension);
            LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-1, -2);
            layoutParams3.weight = 1.0f;
            linearLayout.setLayoutParams(layoutParams3);
            TextView textView = new TextView(context);
            textView.setContentDescription("stickeez-banner-app-title");
            textView.setText(string);
            textView.setSingleLine();
            textView.setTypeface(null, 1);
            textView.setTextSize(14.0f);
            textView.setTextColor(Color.parseColor("#443E3E"));
            textView.setEllipsize(TextUtils.TruncateAt.END);
            TextView textView2 = new TextView(context);
            textView2.setContentDescription("stickeez-banner-app-description");
            textView2.setText(string2);
            textView2.setTextSize(14.0f);
            textView2.setMaxLines(2);
            textView2.setTextColor(Color.parseColor("#443E3E"));
            textView2.setEllipsize(TextUtils.TruncateAt.END);
            linearLayout.addView(textView);
            linearLayout.addView(textView2);
            ImageView imageView2 = new ImageView(context);
            imageView2.setContentDescription("stickeez-banner-x");
            int applyDimension2 = (int) TypedValue.applyDimension(1, 30.0f, getResources().getDisplayMetrics());
            imageView2.setClickable(true);
            imageView2.setImageBitmap(e);
            RelativeLayout.LayoutParams layoutParams4 = new RelativeLayout.LayoutParams(applyDimension2, applyDimension2);
            layoutParams4.addRule(11);
            layoutParams4.addRule(7, this.d.getId());
            layoutParams4.setMargins(applyDimension * 2, 0, 0, applyDimension * 2);
            imageView2.setLayoutParams(layoutParams4);
            imageView2.setOnClickListener(new View.OnClickListener() {
                /* class com.ironsource.mobilcore.bg.AnonymousClass2 */

                public final void onClick(View view) {
                    if (bg.this.b != null) {
                        bg.this.b.b();
                    }
                }
            });
            this.d.addView(bjVar);
            this.d.addView(linearLayout);
            this.d.addView(imageView);
            addView(this.d);
            addView(imageView2);
            this.b = bVar;
        } catch (Exception e2) {
            aK.a(aS.b.REPORT_TYPE_ERROR).a(e2).a();
        }
    }

    @SuppressLint({"NewApi"})
    private static int a(Context context) {
        try {
            Display defaultDisplay = ((WindowManager) context.getSystemService("window")).getDefaultDisplay();
            if (Build.VERSION.SDK_INT < 14) {
                return aF.e(context);
            }
            if (ViewConfiguration.get(context).hasPermanentMenuKey()) {
                return aF.e(context);
            }
            Point point = new Point();
            defaultDisplay.getSize(point);
            return point.x;
        } catch (Exception e2) {
            return aF.e(context);
        }
    }

    public final boolean onTouch(View view, MotionEvent motionEvent) {
        return true;
    }
}
