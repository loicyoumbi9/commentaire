package com.sms.common.thememodule.data;

import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONObject;

public class SmsRemoteDecoder {
    private static final String KEY_SMS_THEME_DOWNLOAD = "download";
    private static final String KEY_SMS_THEME_IMGURL = "smallpreview";
    private static final String KEY_SMS_THEME_LIST = "data";
    private static final String KEY_SMS_THEME_PKG = "pkg";
    private static final String KEY_SMS_THEME_PKG_NAME = "package";
    private static final String KEY_SMS_THEME_RATE = "rate";
    private static final String KEY_SMS_THEME_TITLE = "title";

    public static boolean decodeSmsThemeRaw(ArrayList<SmsThemeInfo> arrayList, JSONObject jSONObject) {
        JSONArray jSONArray;
        boolean z;
        int i;
        if (!(arrayList == null || jSONObject == null)) {
            try {
                jSONArray = jSONObject.getJSONArray(KEY_SMS_THEME_LIST);
            } catch (Exception e) {
                e.printStackTrace();
                jSONArray = null;
            }
            if (jSONArray != null) {
                arrayList.clear();
                int length = jSONArray.length();
                z = true;
                for (i = 0; i < length; i++) {
                    try {
                        JSONObject jSONObject2 = jSONArray.getJSONObject(i);
                        if (jSONObject2 != null) {
                            SmsThemeInfo smsThemeInfo = new SmsThemeInfo();
                            try {
                                smsThemeInfo.mTitle = jSONObject2.getString("title");
                                smsThemeInfo.mSmallPreview = jSONObject2.getString(KEY_SMS_THEME_IMGURL);
                                JSONObject jSONObject3 = new JSONObject(jSONObject2.getString("package"));
                                smsThemeInfo.mPkg = jSONObject3.getString(KEY_SMS_THEME_PKG);
                                smsThemeInfo.mDownload = jSONObject3.getString(KEY_SMS_THEME_DOWNLOAD);
                                smsThemeInfo.mRate = jSONObject3.getString(KEY_SMS_THEME_RATE);
                                arrayList.add(smsThemeInfo);
                            } catch (Exception e2) {
                                e = e2;
                            }
                        }
                    } catch (Exception e3) {
                        e = e3;
                    }
                }
                return z;
            }
        }
        return false;
        e.printStackTrace();
        z = false;
    }
}
