package com.google.gson.internal;

import java.io.ObjectInputStream;
import java.io.ObjectStreamClass;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public abstract class UnsafeAllocator {
    public static UnsafeAllocator create() {
        try {
            Class<?> cls = Class.forName("sun.misc.Unsafe");
            Field declaredField = cls.getDeclaredField("theUnsafe");
            declaredField.setAccessible(true);
            final Object obj = declaredField.get(null);
            final Method method = cls.getMethod("allocateInstance", Class.class);
            return new UnsafeAllocator() {
                /* class com.google.gson.internal.UnsafeAllocator.AnonymousClass1 */

                @Override // com.google.gson.internal.UnsafeAllocator
                public Object newInstance(Class cls) {
                    return method.invoke(obj, cls);
                }
            };
        } catch (Exception e) {
            try {
                final Method declaredMethod = ObjectInputStream.class.getDeclaredMethod("newInstance", Class.class, Class.class);
                declaredMethod.setAccessible(true);
                return new UnsafeAllocator() {
                    /* class com.google.gson.internal.UnsafeAllocator.AnonymousClass2 */

                    @Override // com.google.gson.internal.UnsafeAllocator
                    public Object newInstance(Class cls) {
                        return declaredMethod.invoke(null, cls, Object.class);
                    }
                };
            } catch (Exception e2) {
                try {
                    Method declaredMethod2 = ObjectStreamClass.class.getDeclaredMethod("getConstructorId", Class.class);
                    declaredMethod2.setAccessible(true);
                    final int intValue = ((Integer) declaredMethod2.invoke(null, Object.class)).intValue();
                    final Method declaredMethod3 = ObjectStreamClass.class.getDeclaredMethod("newInstance", Class.class, Integer.TYPE);
                    declaredMethod3.setAccessible(true);
                    return new UnsafeAllocator() {
                        /* class com.google.gson.internal.UnsafeAllocator.AnonymousClass3 */

                        @Override // com.google.gson.internal.UnsafeAllocator
                        public Object newInstance(Class cls) {
                            return declaredMethod3.invoke(null, cls, Integer.valueOf(intValue));
                        }
                    };
                } catch (Exception e3) {
                    return new UnsafeAllocator() {
                        /* class com.google.gson.internal.UnsafeAllocator.AnonymousClass4 */

                        @Override // com.google.gson.internal.UnsafeAllocator
                        public Object newInstance(Class cls) {
                            throw new UnsupportedOperationException("Cannot allocate " + cls);
                        }
                    };
                }
            }
        }
    }

    public abstract Object newInstance(Class cls);
}
