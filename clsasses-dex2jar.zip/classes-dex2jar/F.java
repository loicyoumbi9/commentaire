package com.ironsource.mobilcore;

import android.content.Context;
import android.view.View;
import org.json.JSONObject;

abstract class F extends I {
    protected String a;
    protected boolean b = true;
    /* access modifiers changed from: private */
    public JSONObject t;

    /* renamed from: u  reason: collision with root package name */
    private boolean f3u = false;
    /* access modifiers changed from: private */
    public a v;

    interface a {
        void a(JSONObject jSONObject);
    }

    public F(Context context, C0261ax axVar, a aVar) {
        super(context, axVar);
        this.v = aVar;
    }

    @Override // com.ironsource.mobilcore.H
    public final String a() {
        return null;
    }

    @Override // com.ironsource.mobilcore.H
    public final void a(JSONObject jSONObject) {
        if (!this.f3u) {
            this.f3u = true;
            d();
            this.h.setOnClickListener(new View.OnClickListener() {
                /* class com.ironsource.mobilcore.F.AnonymousClass1 */

                public final void onClick(View view) {
                    if (F.this.v != null && F.this.t != null) {
                        F.this.v.a(F.this.t);
                    }
                }
            });
        }
    }

    public final boolean b(JSONObject jSONObject) {
        this.b = true;
        c(jSONObject);
        e();
        return this.b;
    }

    /* access modifiers changed from: protected */
    public void c(JSONObject jSONObject) {
        this.t = jSONObject;
        this.l = jSONObject.optString("title");
    }

    /* access modifiers changed from: protected */
    @Override // com.ironsource.mobilcore.I
    public final boolean f() {
        return false;
    }

    public final boolean g() {
        return this.f3u;
    }
}
