package u.aly;

import u.aly.ch;

/* renamed from: u.aly.do  reason: invalid class name */
public interface Cdo<T extends ch> {
    void a(dg dgVar, T t) throws cn;

    void b(dg dgVar, T t) throws cn;
}
