package com.ironsource.mobilcore;

/* renamed from: com.ironsource.mobilcore.o  reason: case insensitive filesystem */
final class C0277o {

    /* renamed from: com.ironsource.mobilcore.o$a */
    protected enum a {
        OFFER_TYPE_MARKET("Market"),
        OFFER_TYPE_APK_DOWNLOAD("ApkDownload"),
        OFFER_TYPE_CPC("CPC");
        
        private String d;

        private a(String str) {
            this.d = str;
        }

        public static a a(String str) {
            if (str == null) {
                throw new IllegalArgumentException();
            }
            a[] values = values();
            for (a aVar : values) {
                if (str.equalsIgnoreCase(aVar.d)) {
                    return aVar;
                }
            }
            throw new IllegalArgumentException();
        }
    }

    /* renamed from: com.ironsource.mobilcore.o$b */
    protected enum b {
        SERVICE_TYPE_REPORT,
        SERVICE_TYPE_APK_DOWNLOAD
    }
}
