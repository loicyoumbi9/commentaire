package com.ironsource.mobilcore;

import android.app.Activity;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;

/* renamed from: com.ironsource.mobilcore.av  reason: case insensitive filesystem */
abstract class C0259av extends C0243af {
    C0259av(Activity activity, int i) {
        super(activity, i);
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        int action = motionEvent.getAction() & 255;
        if (action == 0 && this.C && j()) {
            c(0.0f);
            g();
            i();
            e(0);
        }
        if (this.C && a(motionEvent)) {
            return true;
        }
        if (this.G == 0) {
            return false;
        }
        if (action != 0 && this.e) {
            return true;
        }
        switch (action) {
            case 0:
                float x = motionEvent.getX();
                this.f = x;
                this.h = x;
                float y = motionEvent.getY();
                this.g = y;
                this.i = y;
                if (b()) {
                    e(this.C ? 8 : 0);
                    g();
                    i();
                    this.e = false;
                    break;
                }
                break;
            case 1:
            case 3:
                if (Math.abs(this.d) <= ((float) (this.A / 2))) {
                    b(true);
                    break;
                } else {
                    a(true);
                    break;
                }
            case 2:
                float x2 = motionEvent.getX();
                float abs = Math.abs(x2 - this.h);
                float y2 = motionEvent.getY();
                float f = y2 - this.i;
                float abs2 = Math.abs(f);
                if (abs2 > ((float) this.b) && abs2 > abs && a(f)) {
                    e(2);
                    this.e = true;
                    this.h = x2;
                    this.i = y2;
                    break;
                }
        }
        if (this.l == null) {
            this.l = VelocityTracker.obtain();
        }
        this.l.addMovement(motionEvent);
        return this.e;
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        int mode = View.MeasureSpec.getMode(i);
        int mode2 = View.MeasureSpec.getMode(i2);
        if (mode == 1073741824 && mode2 == 1073741824) {
            int size = View.MeasureSpec.getSize(i);
            int size2 = View.MeasureSpec.getSize(i2);
            if (!this.B) {
                this.A = (int) (((float) size2) * 0.25f);
            }
            if (this.d == -1.0f) {
                c((float) this.A);
            }
            this.y.measure(getChildMeasureSpec(i, 0, size), getChildMeasureSpec(i, 0, this.A));
            this.z.measure(getChildMeasureSpec(i, 0, size), getChildMeasureSpec(i, 0, size2));
            setMeasuredDimension(size, size2);
            f();
            return;
        }
        throw new IllegalStateException("Must measure with an exact size");
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (!this.C && this.G == 0) {
            return false;
        }
        int action = motionEvent.getAction();
        if (this.l == null) {
            this.l = VelocityTracker.obtain();
        }
        this.l.addMovement(motionEvent);
        switch (action & 255) {
            case 0:
                float x = motionEvent.getX();
                this.f = x;
                this.h = x;
                float y = motionEvent.getY();
                this.g = y;
                this.i = y;
                if (b()) {
                    g();
                    i();
                    e();
                    break;
                }
                break;
            case 1:
            case 3:
                b(motionEvent);
                break;
            case 2:
                if (!this.e) {
                    float abs = Math.abs(motionEvent.getX() - this.h);
                    float y2 = motionEvent.getY();
                    float f = y2 - this.i;
                    float abs2 = Math.abs(f);
                    if (abs2 > ((float) this.b) && abs2 > abs && a(f)) {
                        e(2);
                        this.e = true;
                        this.i = y2 - this.g > 0.0f ? this.g + ((float) this.b) : this.g - ((float) this.b);
                    }
                }
                if (this.e) {
                    e();
                    float y3 = motionEvent.getY();
                    float f2 = this.i;
                    this.i = y3;
                    b(y3 - f2);
                    break;
                }
                break;
        }
        return true;
    }
}
