package com.umeng.update;

import android.app.Activity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;
import com.alimama.mobile.MMAdView;
import java.io.File;
import u.upd.a;
import u.upd.c;

public class UpdateDialogActivity extends Activity {
    int a = 6;
    UpdateResponse b;
    boolean c = false;
    File d = null;
    ViewGroup e;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        boolean z = true;
        super.onCreate(bundle);
        requestWindowFeature(1);
        setContentView(c.a(this).d("umeng_update_dialog"));
        this.b = (UpdateResponse) getIntent().getExtras().getSerializable("response");
        String string = getIntent().getExtras().getString("file");
        boolean z2 = getIntent().getExtras().getBoolean("force");
        if (string == null) {
            z = false;
        }
        if (z) {
            this.d = new File(string);
        }
        int b2 = c.a(this).b("umeng_update_content");
        int b3 = c.a(this).b("umeng_update_wifi_indicator");
        final int b4 = c.a(this).b("umeng_update_id_ok");
        int b5 = c.a(this).b("umeng_update_id_cancel");
        final int b6 = c.a(this).b("umeng_update_id_ignore");
        int b7 = c.a(this).b("umeng_update_id_close");
        int b8 = c.a(this).b("umeng_update_id_check");
        this.e = (ViewGroup) findViewById(c.a(this).b("umeng_update_frame"));
        if (this.e != null && this.b.display_ads) {
            if (!TextUtils.isEmpty(UpdateConfig.getSlotId())) {
                this.f = new MMAdView(this);
                MMAdView mMAdView = this.f;
                throw new RuntimeException("d2j: wrong position of move-result");
            }
            Log.w(UpdateConfig.a, "尚未设置推广位id,无法展示推广内容。");
        }
        AnonymousClass1 r12 = new View.OnClickListener() {
            /* class com.umeng.update.UpdateDialogActivity.AnonymousClass1 */

            public void onClick(View view) {
                if (b4 == view.getId()) {
                    UpdateDialogActivity.this.a = 5;
                } else if (b6 == view.getId()) {
                    UpdateDialogActivity.this.a = 7;
                } else if (UpdateDialogActivity.this.c) {
                    UpdateDialogActivity.this.a = 7;
                }
                UpdateDialogActivity.this.finish();
            }
        };
        AnonymousClass2 r13 = new CompoundButton.OnCheckedChangeListener() {
            /* class com.umeng.update.UpdateDialogActivity.AnonymousClass2 */

            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                UpdateDialogActivity.this.c = z;
            }
        };
        if (b3 > 0) {
            findViewById(b3).setVisibility(a.k(this) ? 8 : 0);
        }
        if (z2) {
            findViewById(b8).setVisibility(8);
        }
        findViewById(b4).setOnClickListener(r12);
        findViewById(b5).setOnClickListener(r12);
        findViewById(b6).setOnClickListener(r12);
        findViewById(b7).setOnClickListener(r12);
        ((CheckBox) findViewById(b8)).setOnCheckedChangeListener(r13);
        String a2 = this.b.a(this, z);
        TextView textView = (TextView) findViewById(b2);
        textView.requestFocus();
        textView.setText(a2);
    }

    /* access modifiers changed from: protected */
    public void onDestroy() {
        super.onDestroy();
        UmengUpdateAgent.a(this.a, this, this.b, this.d);
        if (this.f != null) {
        }
    }
}
