package com.ironsource.mobilcore;

import android.content.Context;
import android.text.TextUtils;
import org.json.JSONObject;

final class aI {
    private Context a;

    public aI(Context context) {
        this.a = context;
    }

    public final H a(JSONObject jSONObject, C0261ax axVar) {
        String string = jSONObject.getString("type");
        if (!TextUtils.isEmpty(string)) {
            H s = string.equals("lineButton") ? new S(this.a, axVar) : string.equals("widgetButton") ? new aH(this.a, axVar) : string.equals("sliderHeader") ? new C0260aw(this.a, axVar) : string.equals("groupHeader") ? new L(this.a, axVar) : string.equals("separator") ? new Y(this.a, axVar) : string.equals("ironsourceRateUs") ? new U(this.a, axVar) : string.equals("ironsourceShare") ? new Z(this.a, axVar) : string.equals("ironsourceSearch") ? new X(this.a, axVar) : string.equals("ironsourceOfferWallOpener") ? new Q(this.a, axVar) : string.equals("ironsourceFeedback") ? new K(this.a, axVar) : string.equals("ironsourceInlineApps") ? new D(this.a, axVar) : string.equals("ironsourceSocialWidget") ? new aC(this.a, axVar) : string.equals("ironsourceUrl") ? new aE(this.a, axVar) : null;
            if (s != null) {
                s.a(jSONObject);
                return s;
            }
        }
        return null;
    }
}
