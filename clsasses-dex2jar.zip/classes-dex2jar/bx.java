package u.aly;

import org.json.JSONObject;

public abstract class bx {
    protected static String b = "POST";
    protected static String c = "GET";
    protected String d;

    public bx(String str) {
        this.d = str;
    }

    public abstract JSONObject a();

    public void a(String str) {
        this.d = str;
    }

    public abstract String b();

    /* access modifiers changed from: protected */
    public String c() {
        return b;
    }

    public String d() {
        return this.d;
    }
}
