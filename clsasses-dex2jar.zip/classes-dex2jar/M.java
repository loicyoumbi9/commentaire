package com.ironsource.mobilcore;

public interface M {
    void g();
}
