package u.aly;

import java.io.ByteArrayOutputStream;
import java.io.UnsupportedEncodingException;
import u.aly.da;

public class cq {
    private final ByteArrayOutputStream a;
    private final ds b;
    private dg c;

    public cq() {
        this(new da.a());
    }

    public cq(di diVar) {
        this.a = new ByteArrayOutputStream();
        this.b = new ds(this.a);
        this.c = diVar.a(this.b);
    }

    public String a(ch chVar, String str) throws cn {
        try {
            return new String(a(chVar), str);
        } catch (UnsupportedEncodingException e) {
            throw new cn("JVM DOES NOT SUPPORT ENCODING: " + str);
        }
    }

    public byte[] a(ch chVar) throws cn {
        this.a.reset();
        chVar.b(this.c);
        return this.a.toByteArray();
    }

    public String b(ch chVar) throws cn {
        return new String(a(chVar));
    }
}
