package u.upd;

import android.os.AsyncTask;
import u.upd.f;

public class d extends g {
    private static final String TAG = d.class.getName();

    public interface a {
        void a();

        void a(f.a aVar);
    }

    private class b extends AsyncTask<Integer, Integer, f.a> {
        private e b;
        private a c;

        public b(e eVar, a aVar) {
            this.b = eVar;
            this.c = aVar;
        }

        /* access modifiers changed from: protected */
        /* renamed from: a */
        public f.a doInBackground(Integer... numArr) {
            return d.this.send(this.b);
        }

        /* access modifiers changed from: protected */
        /* renamed from: a */
        public void onPostExecute(f.a aVar) {
            if (this.c != null) {
                this.c.a(aVar);
            }
        }

        /* access modifiers changed from: protected */
        public void onPreExecute() {
            if (this.c != null) {
                this.c.a();
            }
        }
    }

    public f.a send(e eVar) {
        f fVar = (f) execute(eVar, f.class);
        return fVar == null ? f.a.FAIL : fVar.a;
    }

    public void sendAsync(e eVar, a aVar) {
        try {
            new b(eVar, aVar).execute(new Integer[0]);
        } catch (Exception e) {
            b.b(TAG, "", e);
            if (aVar != null) {
                aVar.a(f.a.FAIL);
            }
        }
    }
}
