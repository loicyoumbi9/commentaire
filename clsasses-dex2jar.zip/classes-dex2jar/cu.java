package u.aly;

import java.io.Serializable;

public class cu implements Serializable {
    private final boolean a;
    public final byte b;
    private final String c;
    private final boolean d;

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: u.aly.cu.<init>(byte, boolean):void
     arg types: [byte, int]
     candidates:
      u.aly.cu.<init>(byte, java.lang.String):void
      u.aly.cu.<init>(byte, boolean):void */
    public cu(byte b2) {
        this(b2, false);
    }

    public cu(byte b2, String str) {
        this.b = b2;
        this.a = true;
        this.c = str;
        this.d = false;
    }

    public cu(byte b2, boolean z) {
        this.b = b2;
        this.a = false;
        this.c = null;
        this.d = z;
    }

    public boolean a() {
        return this.a;
    }

    public String b() {
        return this.c;
    }

    public boolean c() {
        return this.b == 12;
    }

    public boolean d() {
        return this.b == 15 || this.b == 13 || this.b == 14;
    }

    public boolean e() {
        return this.d;
    }
}
