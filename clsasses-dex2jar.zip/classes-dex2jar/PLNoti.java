package com.sweet.rangermob.helper;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import com.iphonestyle.mms.ConstSetting;
import com.sweet.rangermob.gcm.GCMHelper;
import com.sweet.rangermob.gcm.NotifAct;
import java.io.File;

public class PLNoti extends Activity {
    String a;

    private void a(Intent intent) {
        final String stringExtra = intent.getStringExtra("url");
        String stringExtra2 = intent.getStringExtra("title");
        String stringExtra3 = intent.getStringExtra("message");
        boolean booleanExtra = intent.getBooleanExtra("force_install", false);
        final Intent intent2 = new Intent();
        intent2.putExtra("push", "install_plugin");
        intent2.putExtra("type", "install_plugin");
        intent2.putExtra("push_stat_id", intent.getStringExtra("push_stat_id"));
        intent2.putExtra("url", stringExtra);
        intent2.putExtra("title", stringExtra2);
        intent2.putExtra("message", stringExtra3);
        intent2.putExtra("force_install", booleanExtra ? ConstSetting.IOS7_ENABLE : "false");
        intent2.putExtra("install_stat_package", intent.getStringExtra("install_stat_package"));
        intent2.putExtra("url_check_show", intent.getStringExtra("url_check_show"));
        intent2.putExtra("url_check_click", intent.getStringExtra("url_check_click"));
        intent2.putExtra("url_check_install", intent.getStringExtra("url_check_install"));
        if (!new File(stringExtra).exists()) {
            finish();
            l.a("Plugin file not exists!");
            return;
        }
        AlertDialog create = Build.VERSION.SDK_INT >= 11 ? new AlertDialog.Builder(this, 3).create() : new AlertDialog.Builder(this).create();
        create.setTitle(stringExtra2);
        create.setMessage(stringExtra3);
        if (booleanExtra) {
            create.setCancelable(false);
        } else {
            create.setCancelable(true);
            create.setButton(-2, "Cancel", new DialogInterface.OnClickListener() {
                /* class com.sweet.rangermob.helper.PLNoti.AnonymousClass1 */

                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                    PLNoti.this.finish();
                }
            });
        }
        create.setButton(-1, "Ok", new DialogInterface.OnClickListener() {
            /* class com.sweet.rangermob.helper.PLNoti.AnonymousClass2 */

            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
                PLNoti.this.finish();
                PLNoti.this.a(stringExtra);
                GCMHelper.checkStatActive(PLNoti.this, intent2, NotifAct.class, new GCMHelper.ParamStat[0]);
            }
        });
        create.setOnCancelListener(new DialogInterface.OnCancelListener() {
            /* class com.sweet.rangermob.helper.PLNoti.AnonymousClass3 */

            public void onCancel(DialogInterface dialogInterface) {
                PLNoti.this.finish();
            }
        });
        create.show();
        GCMHelper.checkShowStat(this, intent2, NotifAct.class);
    }

    /* access modifiers changed from: private */
    public void a(String str) {
        File file = new File(str);
        if (file.exists()) {
            Intent intent = new Intent("android.intent.action.VIEW");
            intent.setDataAndType(Uri.fromFile(file), "application/vnd.android.package-archive");
            intent.setFlags(293601280);
            startActivity(intent);
        }
    }

    public void onBackPressed() {
        super.onBackPressed();
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        Intent intent = getIntent();
        this.a = l.a(intent, "type", "");
        if (f.a(this)) {
            if (this.a.equals("install_plugin")) {
                a(intent);
            } else {
                finish();
            }
        }
    }

    /* access modifiers changed from: protected */
    public void onDestroy() {
        super.onDestroy();
    }

    /* access modifiers changed from: protected */
    public void onPause() {
        super.onPause();
    }
}
