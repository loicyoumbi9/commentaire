package u.aly;

import com.alimama.mobile.csdk.umupdate.a.f;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.Collections;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class az implements Serializable, Cloneable, ch<az, e> {
    public static final Map<e, ct> d;
    /* access modifiers changed from: private */
    public static final dl e = new dl("IdTracking");
    /* access modifiers changed from: private */
    public static final db f = new db("snapshots", dn.k, 1);
    /* access modifiers changed from: private */
    public static final db g = new db("journals", dn.m, 2);
    /* access modifiers changed from: private */
    public static final db h = new db("checksum", (byte) 11, 3);
    private static final Map<Class<? extends Cdo>, dp> i = new HashMap();
    public Map<String, ay> a;
    public List<ax> b;
    public String c;
    private e[] j;

    private static class a extends dq<az> {
        private a() {
        }

        /* renamed from: a */
        public void b(dg dgVar, az azVar) throws cn {
            dgVar.j();
            while (true) {
                db l = dgVar.l();
                if (l.b == 0) {
                    dgVar.k();
                    azVar.p();
                    return;
                }
                switch (l.c) {
                    case 1:
                        if (l.b != 13) {
                            dj.a(dgVar, l.b);
                            break;
                        } else {
                            dd n = dgVar.n();
                            azVar.a = new HashMap(n.c * 2);
                            for (int i = 0; i < n.c; i++) {
                                String z = dgVar.z();
                                ay ayVar = new ay();
                                ayVar.a(dgVar);
                                azVar.a.put(z, ayVar);
                            }
                            dgVar.o();
                            azVar.a(true);
                            break;
                        }
                    case 2:
                        if (l.b != 15) {
                            dj.a(dgVar, l.b);
                            break;
                        } else {
                            dc p = dgVar.p();
                            azVar.b = new ArrayList(p.b);
                            for (int i2 = 0; i2 < p.b; i2++) {
                                ax axVar = new ax();
                                axVar.a(dgVar);
                                azVar.b.add(axVar);
                            }
                            dgVar.q();
                            azVar.b(true);
                            break;
                        }
                    case 3:
                        if (l.b != 11) {
                            dj.a(dgVar, l.b);
                            break;
                        } else {
                            azVar.c = dgVar.z();
                            azVar.c(true);
                            break;
                        }
                    default:
                        dj.a(dgVar, l.b);
                        break;
                }
                dgVar.m();
            }
        }

        /* renamed from: b */
        public void a(dg dgVar, az azVar) throws cn {
            azVar.p();
            dgVar.a(az.e);
            if (azVar.a != null) {
                dgVar.a(az.f);
                dgVar.a(new dd((byte) 11, (byte) 12, azVar.a.size()));
                for (Map.Entry<String, ay> entry : azVar.a.entrySet()) {
                    dgVar.a(entry.getKey());
                    entry.getValue().b(dgVar);
                }
                dgVar.e();
                dgVar.c();
            }
            if (azVar.b != null && azVar.l()) {
                dgVar.a(az.g);
                dgVar.a(new dc((byte) 12, azVar.b.size()));
                for (ax axVar : azVar.b) {
                    axVar.b(dgVar);
                }
                dgVar.f();
                dgVar.c();
            }
            if (azVar.c != null && azVar.o()) {
                dgVar.a(az.h);
                dgVar.a(azVar.c);
                dgVar.c();
            }
            dgVar.d();
            dgVar.b();
        }
    }

    private static class b implements dp {
        private b() {
        }

        /* renamed from: a */
        public a b() {
            return new a();
        }
    }

    private static class c extends dr<az> {
        private c() {
        }

        public void a(dg dgVar, az azVar) throws cn {
            dm dmVar = (dm) dgVar;
            dmVar.a(azVar.a.size());
            for (Map.Entry<String, ay> entry : azVar.a.entrySet()) {
                dmVar.a(entry.getKey());
                entry.getValue().b(dmVar);
            }
            BitSet bitSet = new BitSet();
            if (azVar.l()) {
                bitSet.set(0);
            }
            if (azVar.o()) {
                bitSet.set(1);
            }
            dmVar.a(bitSet, 2);
            if (azVar.l()) {
                dmVar.a(azVar.b.size());
                for (ax axVar : azVar.b) {
                    axVar.b(dmVar);
                }
            }
            if (azVar.o()) {
                dmVar.a(azVar.c);
            }
        }

        public void b(dg dgVar, az azVar) throws cn {
            dm dmVar = (dm) dgVar;
            dd ddVar = new dd((byte) 11, (byte) 12, dmVar.w());
            azVar.a = new HashMap(ddVar.c * 2);
            for (int i = 0; i < ddVar.c; i++) {
                String z = dmVar.z();
                ay ayVar = new ay();
                ayVar.a(dmVar);
                azVar.a.put(z, ayVar);
            }
            azVar.a(true);
            BitSet b = dmVar.b(2);
            if (b.get(0)) {
                dc dcVar = new dc((byte) 12, dmVar.w());
                azVar.b = new ArrayList(dcVar.b);
                for (int i2 = 0; i2 < dcVar.b; i2++) {
                    ax axVar = new ax();
                    axVar.a(dmVar);
                    azVar.b.add(axVar);
                }
                azVar.b(true);
            }
            if (b.get(1)) {
                azVar.c = dmVar.z();
                azVar.c(true);
            }
        }
    }

    private static class d implements dp {
        private d() {
        }

        /* renamed from: a */
        public c b() {
            return new c();
        }
    }

    public enum e implements co {
        SNAPSHOTS(1, "snapshots"),
        JOURNALS(2, "journals"),
        CHECKSUM(3, "checksum");
        
        private static final Map<String, e> d = new HashMap();
        private final short e;
        private final String f;

        static {
            Iterator it = EnumSet.allOf(e.class).iterator();
            while (it.hasNext()) {
                e eVar = (e) it.next();
                d.put(eVar.b(), eVar);
            }
        }

        private e(short s, String str) {
            this.e = s;
            this.f = str;
        }

        public static e a(int i) {
            switch (i) {
                case 1:
                    return SNAPSHOTS;
                case 2:
                    return JOURNALS;
                case 3:
                    return CHECKSUM;
                default:
                    return null;
            }
        }

        public static e a(String str) {
            return d.get(str);
        }

        public static e b(int i) {
            e a = a(i);
            if (a != null) {
                return a;
            }
            throw new IllegalArgumentException("Field " + i + " doesn't exist!");
        }

        @Override // u.aly.co
        public short a() {
            return this.e;
        }

        @Override // u.aly.co
        public String b() {
            return this.f;
        }
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: MutableMD:(java.lang.Object, java.lang.Object):java.lang.Object
     arg types: [u.aly.az$e, u.aly.ct]
     candidates:
      MutableMD:(java.lang.Enum, java.lang.Object):java.lang.Object
      MutableMD:(java.lang.Object, java.lang.Object):java.lang.Object */
    static {
        i.put(dq.class, new b());
        i.put(dr.class, new d());
        EnumMap enumMap = new EnumMap(e.class);
        enumMap.put((Object) e.SNAPSHOTS, (Object) new ct("snapshots", (byte) 1, new cw(dn.k, new cu((byte) 11), new cy((byte) 12, ay.class))));
        enumMap.put((Object) e.JOURNALS, (Object) new ct("journals", (byte) 2, new cv(dn.m, new cy((byte) 12, ax.class))));
        enumMap.put((Object) e.CHECKSUM, (Object) new ct("checksum", (byte) 2, new cu((byte) 11)));
        d = Collections.unmodifiableMap(enumMap);
        ct.a(az.class, d);
    }

    public az() {
        this.j = new e[]{e.JOURNALS, e.CHECKSUM};
    }

    public az(Map<String, ay> map) {
        this();
        this.a = map;
    }

    public az(az azVar) {
        this.j = new e[]{e.JOURNALS, e.CHECKSUM};
        if (azVar.f()) {
            HashMap hashMap = new HashMap();
            for (Map.Entry<String, ay> entry : azVar.a.entrySet()) {
                hashMap.put(entry.getKey(), new ay(entry.getValue()));
            }
            this.a = hashMap;
        }
        if (azVar.l()) {
            ArrayList arrayList = new ArrayList();
            for (ax axVar : azVar.b) {
                arrayList.add(new ax(axVar));
            }
            this.b = arrayList;
        }
        if (azVar.o()) {
            this.c = azVar.c;
        }
    }

    private void a(ObjectInputStream objectInputStream) throws IOException, ClassNotFoundException {
        try {
            a(new da(new ds(objectInputStream)));
        } catch (cn e2) {
            throw new IOException(e2.getMessage());
        }
    }

    private void a(ObjectOutputStream objectOutputStream) throws IOException {
        try {
            b(new da(new ds(objectOutputStream)));
        } catch (cn e2) {
            throw new IOException(e2.getMessage());
        }
    }

    /* renamed from: a */
    public e b(int i2) {
        return e.a(i2);
    }

    /* renamed from: a */
    public az g() {
        return new az(this);
    }

    public az a(String str) {
        this.c = str;
        return this;
    }

    public az a(List<ax> list) {
        this.b = list;
        return this;
    }

    public az a(Map<String, ay> map) {
        this.a = map;
        return this;
    }

    public void a(String str, ay ayVar) {
        if (this.a == null) {
            this.a = new HashMap();
        }
        this.a.put(str, ayVar);
    }

    public void a(ax axVar) {
        if (this.b == null) {
            this.b = new ArrayList();
        }
        this.b.add(axVar);
    }

    @Override // u.aly.ch
    public void a(dg dgVar) throws cn {
        i.get(dgVar.D()).b().b(dgVar, this);
    }

    public void a(boolean z) {
        if (!z) {
            this.a = null;
        }
    }

    @Override // u.aly.ch
    public void b() {
        this.a = null;
        this.b = null;
        this.c = null;
    }

    @Override // u.aly.ch
    public void b(dg dgVar) throws cn {
        i.get(dgVar.D()).b().a(dgVar, this);
    }

    public void b(boolean z) {
        if (!z) {
            this.b = null;
        }
    }

    public int c() {
        if (this.a == null) {
            return 0;
        }
        return this.a.size();
    }

    public void c(boolean z) {
        if (!z) {
            this.c = null;
        }
    }

    public Map<String, ay> d() {
        return this.a;
    }

    public void e() {
        this.a = null;
    }

    public boolean f() {
        return this.a != null;
    }

    public int h() {
        if (this.b == null) {
            return 0;
        }
        return this.b.size();
    }

    public Iterator<ax> i() {
        if (this.b == null) {
            return null;
        }
        return this.b.iterator();
    }

    public List<ax> j() {
        return this.b;
    }

    public void k() {
        this.b = null;
    }

    public boolean l() {
        return this.b != null;
    }

    public String m() {
        return this.c;
    }

    public void n() {
        this.c = null;
    }

    public boolean o() {
        return this.c != null;
    }

    public void p() throws cn {
        if (this.a == null) {
            throw new dh("Required field 'snapshots' was not present! Struct: " + toString());
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("IdTracking(");
        sb.append("snapshots:");
        if (this.a == null) {
            sb.append(f.b);
        } else {
            sb.append(this.a);
        }
        if (l()) {
            sb.append(", ");
            sb.append("journals:");
            if (this.b == null) {
                sb.append(f.b);
            } else {
                sb.append(this.b);
            }
        }
        if (o()) {
            sb.append(", ");
            sb.append("checksum:");
            if (this.c == null) {
                sb.append(f.b);
            } else {
                sb.append(this.c);
            }
        }
        sb.append(")");
        return sb.toString();
    }
}
