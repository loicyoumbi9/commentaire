package com.ironsource.mobilcore;

import com.ironsource.mobilcore.ba;

final class bi extends aW {
    public bi(ba.g gVar) {
        super(gVar);
        this.a = "StickeezWaitingForLayoutState";
    }

    @Override // com.ironsource.mobilcore.aW
    public final void a() {
        B.a("StickeezWaitingForLayoutState | setStateToInit | doing nothing", 55);
    }

    @Override // com.ironsource.mobilcore.aW
    public final void b() {
        B.a("StickeezWaitingForLayoutState | setStateToReadyToShow | doing nothing", 55);
    }

    @Override // com.ironsource.mobilcore.aW
    public final void c() {
        B.a("StickeezWaitingForLayoutState | setStateToShowingHandle | doing nothing", 55);
    }

    @Override // com.ironsource.mobilcore.aW
    public final void d() {
        B.a("StickeezWaitingForLayoutState | setStateToShowingOffers | doing nothing", 55);
    }

    @Override // com.ironsource.mobilcore.aW
    public final void e() {
        B.a("StickeezWaitingForLayoutState | setStateToHiding | doing nothing", 55);
    }

    @Override // com.ironsource.mobilcore.aW
    public final void f() {
        B.a("StickeezWaitingForLayoutState | setStateToSwitchingAnimations | switching to StickeezSwitchingAnimationsState", 55);
        bh bhVar = new bh(this.b);
        this.b.a(bhVar);
        bhVar.h();
    }

    @Override // com.ironsource.mobilcore.aW
    public final void g() {
        B.a("StickeezWaitingForLayoutState | setStateToWaitingForLayout | doing nothing", 55);
    }
}
