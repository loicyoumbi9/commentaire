package u.aly;

public class dv extends cn {
    public static final int a = 0;
    public static final int b = 1;
    public static final int c = 2;
    public static final int d = 3;
    public static final int e = 4;
    private static final long g = 1;
    protected int f = 0;

    public dv() {
    }

    public dv(int i) {
        this.f = i;
    }

    public dv(int i, String str) {
        super(str);
        this.f = i;
    }

    public dv(int i, String str, Throwable th) {
        super(str, th);
        this.f = i;
    }

    public dv(int i, Throwable th) {
        super(th);
        this.f = i;
    }

    public dv(String str) {
        super(str);
    }

    public dv(String str, Throwable th) {
        super(str, th);
    }

    public dv(Throwable th) {
        super(th);
    }

    public int a() {
        return this.f;
    }
}
