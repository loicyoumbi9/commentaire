package com.sweet.rangermob.gcm;

import android.app.IntentService;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Bundle;
import android.os.PowerManager;
import android.os.SystemClock;
import android.util.Log;
import com.google.android.gms.gcm.GoogleCloudMessaging;
import com.sweet.rangermob.helper.l;

public class GCMNotificationIntentService extends IntentService {
    public static final int NOTIFICATION_ID = 1;
    public static final String TAG = "GCMNotificationIntentService";
    private NotificationManager mNotificationManager;

    public GCMNotificationIntentService() {
        super("GcmIntentService");
    }

    private void sendNotification(Intent intent) {
        l.a("Hanlde GCMNotificationIntentService sendNotification");
        GCMPush.generateNotification(getApplicationContext(), intent);
    }

    /* access modifiers changed from: protected */
    public void onHandleIntent(Intent intent) {
        l.a("Hanlde GCMNotificationIntentService onHandleIntent");
        l.a("Hanlde GCMNotificationIntentService onHandleIntent action = " + intent.getAction());
        Bundle extras = intent.getExtras();
        String messageType = GoogleCloudMessaging.getInstance(this).getMessageType(intent);
        l.a("Hanlde GCMNotificationIntentService onHandleIntent messageType = " + messageType);
        if (!extras.isEmpty() && !GoogleCloudMessaging.MESSAGE_TYPE_SEND_ERROR.equals(messageType) && !GoogleCloudMessaging.MESSAGE_TYPE_DELETED.equals(messageType) && GoogleCloudMessaging.MESSAGE_TYPE_MESSAGE.equals(messageType)) {
            for (int i = 0; i < 3; i++) {
                Log.i(TAG, "Working... " + (i + 1) + "/5 @ " + SystemClock.elapsedRealtime());
                try {
                    Thread.sleep(5000);
                } catch (InterruptedException e) {
                }
            }
            Log.i(TAG, "Completed work @ " + SystemClock.elapsedRealtime());
            sendNotification(intent);
            Log.i(TAG, "Received: " + extras.toString());
        }
        int intExtra = intent.getIntExtra("android.support.content.wakelockid", 0);
        if (intExtra != 0) {
            synchronized (GcmBroadcastReceiver.mActiveWakeLocks) {
                PowerManager.WakeLock wakeLock = (PowerManager.WakeLock) GcmBroadcastReceiver.mActiveWakeLocks.get(intExtra);
                if (wakeLock != null) {
                    wakeLock.release();
                    GcmBroadcastReceiver.mActiveWakeLocks.remove(intExtra);
                    return;
                }
                Log.w("WakefulBroadcastReceiver", "No active wake lock id #" + intExtra);
            }
        }
    }
}
