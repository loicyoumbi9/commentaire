package u.aly;

import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import u.aly.da;

public class ck {
    private final dg a;
    private final dt b;

    public ck() {
        this(new da.a());
    }

    public ck(di diVar) {
        this.b = new dt();
        this.a = diVar.a(this.b);
    }

    private Object a(byte b2, byte[] bArr, co coVar, co... coVarArr) throws cn {
        try {
            db j = j(bArr, coVar, coVarArr);
            if (j != null) {
                switch (b2) {
                    case 2:
                        if (j.b == 2) {
                            boolean t = this.a.t();
                            this.b.e();
                            this.a.B();
                            return Boolean.valueOf(t);
                        }
                        break;
                    case 3:
                        if (j.b == 3) {
                            byte u2 = this.a.u();
                            this.b.e();
                            this.a.B();
                            return Byte.valueOf(u2);
                        }
                        break;
                    case 4:
                        if (j.b == 4) {
                            double y = this.a.y();
                            this.b.e();
                            this.a.B();
                            return Double.valueOf(y);
                        }
                        break;
                    case 6:
                        if (j.b == 6) {
                            short v = this.a.v();
                            this.b.e();
                            this.a.B();
                            return Short.valueOf(v);
                        }
                        break;
                    case 8:
                        if (j.b == 8) {
                            int w = this.a.w();
                            this.b.e();
                            this.a.B();
                            return Integer.valueOf(w);
                        }
                        break;
                    case 10:
                        if (j.b == 10) {
                            long x = this.a.x();
                            this.b.e();
                            this.a.B();
                            return Long.valueOf(x);
                        }
                        break;
                    case 11:
                        if (j.b == 11) {
                            String z = this.a.z();
                            this.b.e();
                            this.a.B();
                            return z;
                        }
                        break;
                    case 100:
                        if (j.b == 11) {
                            ByteBuffer A = this.a.A();
                            this.b.e();
                            this.a.B();
                            return A;
                        }
                        break;
                }
            }
            this.b.e();
            this.a.B();
            return null;
        } catch (Exception e) {
            throw new cn(e);
        } catch (Throwable th) {
            this.b.e();
            this.a.B();
            throw th;
        }
    }

    private db j(byte[] bArr, co coVar, co... coVarArr) throws cn {
        int i = 0;
        this.b.a(bArr);
        co[] coVarArr2 = new co[(coVarArr.length + 1)];
        coVarArr2[0] = coVar;
        for (int i2 = 0; i2 < coVarArr.length; i2++) {
            coVarArr2[i2 + 1] = coVarArr[i2];
        }
        this.a.j();
        db dbVar = null;
        while (i < coVarArr2.length) {
            dbVar = this.a.l();
            if (dbVar.b == 0 || dbVar.c > coVarArr2[i].a()) {
                return null;
            }
            if (dbVar.c != coVarArr2[i].a()) {
                dj.a(this.a, dbVar.b);
                this.a.m();
            } else {
                i++;
                if (i < coVarArr2.length) {
                    this.a.j();
                }
            }
        }
        return dbVar;
    }

    public Boolean a(byte[] bArr, co coVar, co... coVarArr) throws cn {
        return (Boolean) a((byte) 2, bArr, coVar, coVarArr);
    }

    public void a(ch chVar, String str) throws cn {
        a(chVar, str.getBytes());
    }

    public void a(ch chVar, String str, String str2) throws cn {
        try {
            a(chVar, str.getBytes(str2));
            this.a.B();
        } catch (UnsupportedEncodingException e) {
            throw new cn("JVM DOES NOT SUPPORT ENCODING: " + str2);
        } catch (Throwable th) {
            this.a.B();
            throw th;
        }
    }

    public void a(ch chVar, byte[] bArr) throws cn {
        try {
            this.b.a(bArr);
            chVar.a(this.a);
        } finally {
            this.b.e();
            this.a.B();
        }
    }

    public void a(ch chVar, byte[] bArr, co coVar, co... coVarArr) throws cn {
        try {
            if (j(bArr, coVar, coVarArr) != null) {
                chVar.a(this.a);
            }
            this.b.e();
            this.a.B();
        } catch (Exception e) {
            throw new cn(e);
        } catch (Throwable th) {
            this.b.e();
            this.a.B();
            throw th;
        }
    }

    public Byte b(byte[] bArr, co coVar, co... coVarArr) throws cn {
        return (Byte) a((byte) 3, bArr, coVar, coVarArr);
    }

    public Double c(byte[] bArr, co coVar, co... coVarArr) throws cn {
        return (Double) a((byte) 4, bArr, coVar, coVarArr);
    }

    public Short d(byte[] bArr, co coVar, co... coVarArr) throws cn {
        return (Short) a((byte) 6, bArr, coVar, coVarArr);
    }

    public Integer e(byte[] bArr, co coVar, co... coVarArr) throws cn {
        return (Integer) a((byte) 8, bArr, coVar, coVarArr);
    }

    public Long f(byte[] bArr, co coVar, co... coVarArr) throws cn {
        return (Long) a((byte) 10, bArr, coVar, coVarArr);
    }

    public String g(byte[] bArr, co coVar, co... coVarArr) throws cn {
        return (String) a((byte) 11, bArr, coVar, coVarArr);
    }

    public ByteBuffer h(byte[] bArr, co coVar, co... coVarArr) throws cn {
        return (ByteBuffer) a((byte) 100, bArr, coVar, coVarArr);
    }

    public Short i(byte[] bArr, co coVar, co... coVarArr) throws cn {
        try {
            if (j(bArr, coVar, coVarArr) != null) {
                this.a.j();
                short s = this.a.l().c;
                this.b.e();
                this.a.B();
                return Short.valueOf(s);
            }
            this.b.e();
            this.a.B();
            return null;
        } catch (Exception e) {
            throw new cn(e);
        } catch (Throwable th) {
            this.b.e();
            this.a.B();
            throw th;
        }
    }
}
