package u.aly;

import android.support.v4.media.TransportMediator;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;

public class da extends dg {
    private static final dl d = new dl("");
    private static final db e = new db("", (byte) 0, 0);
    private static final byte[] f = new byte[16];
    private static final byte h = -126;
    private static final byte i = 1;
    private static final byte j = 31;
    private static final byte k = -32;
    private static final int l = 5;
    byte[] a;
    byte[] b;
    byte[] c;
    private cf m;
    private short n;
    private db o;
    private Boolean p;
    private final long q;
    private byte[] r;

    public static class a implements di {
        private final long a;

        public a() {
            this.a = -1;
        }

        public a(int i) {
            this.a = (long) i;
        }

        @Override // u.aly.di
        public dg a(du duVar) {
            return new da(duVar, this.a);
        }
    }

    private static class b {
        public static final byte a = 1;
        public static final byte b = 2;
        public static final byte c = 3;
        public static final byte d = 4;
        public static final byte e = 5;
        public static final byte f = 6;
        public static final byte g = 7;
        public static final byte h = 8;
        public static final byte i = 9;
        public static final byte j = 10;
        public static final byte k = 11;
        public static final byte l = 12;

        private b() {
        }
    }

    static {
        f[0] = 0;
        f[2] = 1;
        f[3] = 3;
        f[6] = 4;
        f[8] = 5;
        f[10] = 6;
        f[4] = 7;
        f[11] = 8;
        f[15] = 9;
        f[14] = 10;
        f[13] = 11;
        f[12] = 12;
    }

    public da(du duVar) {
        this(duVar, -1);
    }

    public da(du duVar, long j2) {
        super(duVar);
        this.m = new cf(15);
        this.n = 0;
        this.o = null;
        this.p = null;
        this.a = new byte[5];
        this.b = new byte[10];
        this.r = new byte[1];
        this.c = new byte[1];
        this.q = j2;
    }

    /* JADX WARN: Type inference failed for: r1v8, types: [int] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private int E() throws u.aly.cn {
        /*
            r8 = this;
            r7 = 128(0x80, float:1.794E-43)
            r1 = 0
            u.aly.du r0 = r8.g
            int r0 = r0.h()
            r2 = 5
            if (r0 < r2) goto L_0x0046
            u.aly.du r0 = r8.g
            byte[] r4 = r0.f()
            u.aly.du r0 = r8.g
            int r5 = r0.g()
            r0 = r1
            r2 = r1
            r3 = r1
        L_0x001b:
            int r1 = r5 + r3
            byte r1 = r4[r1]
            r6 = r1 & 127(0x7f, float:1.78E-43)
            int r6 = r6 << r2
            r0 = r0 | r6
            r1 = r1 & 128(0x80, float:1.794E-43)
            if (r1 == r7) goto L_0x002f
            u.aly.du r1 = r8.g
            int r2 = r3 + 1
            r1.a(r2)
        L_0x002e:
            return r0
        L_0x002f:
            int r1 = r2 + 7
            int r3 = r3 + 1
            r2 = r1
            goto L_0x001b
        L_0x0035:
            int r2 = r2 + 7
            r0 = r1
        L_0x0038:
            byte r3 = r8.u()
            r1 = r3 & 127(0x7f, float:1.78E-43)
            int r1 = r1 << r2
            r1 = r1 | r0
            r0 = r3 & 128(0x80, float:1.794E-43)
            if (r0 == r7) goto L_0x0035
            r0 = r1
            goto L_0x002e
        L_0x0046:
            r0 = r1
            r2 = r1
            goto L_0x0038
        */
        throw new UnsupportedOperationException("Method not decompiled: u.aly.da.E():int");
    }

    private long F() throws cn {
        int i2;
        int i3 = 0;
        long j2 = 0;
        if (this.g.h() >= 10) {
            byte[] f2 = this.g.f();
            int g = this.g.g();
            int i4 = 0;
            while (true) {
                i2 = i3;
                byte b2 = f2[g + i2];
                j2 |= ((long) (b2 & Byte.MAX_VALUE)) << i4;
                if ((b2 & 128) != 128) {
                    break;
                }
                i4 += 7;
                i3 = i2 + 1;
            }
            this.g.a(i2 + 1);
        } else {
            while (true) {
                byte u2 = u();
                j2 |= ((long) (u2 & Byte.MAX_VALUE)) << i3;
                if ((u2 & 128) != 128) {
                    break;
                }
                i3 += 7;
            }
        }
        return j2;
    }

    private long a(byte[] bArr) {
        return ((((long) bArr[7]) & 255) << 56) | ((((long) bArr[6]) & 255) << 48) | ((((long) bArr[5]) & 255) << 40) | ((((long) bArr[4]) & 255) << 32) | ((((long) bArr[3]) & 255) << 24) | ((((long) bArr[2]) & 255) << 16) | ((((long) bArr[1]) & 255) << 8) | (((long) bArr[0]) & 255);
    }

    private void a(long j2, byte[] bArr, int i2) {
        bArr[i2 + 0] = (byte) ((int) (j2 & 255));
        bArr[i2 + 1] = (byte) ((int) ((j2 >> 8) & 255));
        bArr[i2 + 2] = (byte) ((int) ((j2 >> 16) & 255));
        bArr[i2 + 3] = (byte) ((int) ((j2 >> 24) & 255));
        bArr[i2 + 4] = (byte) ((int) ((j2 >> 32) & 255));
        bArr[i2 + 5] = (byte) ((int) ((j2 >> 40) & 255));
        bArr[i2 + 6] = (byte) ((int) ((j2 >> 48) & 255));
        bArr[i2 + 7] = (byte) ((int) ((j2 >> 56) & 255));
    }

    private void a(db dbVar, byte b2) throws cn {
        if (b2 == -1) {
            b2 = e(dbVar.b);
        }
        if (dbVar.c <= this.n || dbVar.c - this.n > 15) {
            b(b2);
            a(dbVar.c);
        } else {
            d((int) (((dbVar.c - this.n) << 4) | b2));
        }
        this.n = dbVar.c;
    }

    private void a(byte[] bArr, int i2, int i3) throws cn {
        b(i3);
        this.g.b(bArr, i2, i3);
    }

    private void b(byte b2) throws cn {
        this.r[0] = b2;
        this.g.b(this.r);
    }

    private void b(int i2) throws cn {
        int i3 = 0;
        while ((i2 & -128) != 0) {
            this.a[i3] = (byte) ((i2 & TransportMediator.KEYCODE_MEDIA_PAUSE) | 128);
            i2 >>>= 7;
            i3++;
        }
        this.a[i3] = (byte) i2;
        this.g.b(this.a, 0, i3 + 1);
    }

    private void b(long j2) throws cn {
        int i2 = 0;
        while ((-128 & j2) != 0) {
            this.b[i2] = (byte) ((int) ((127 & j2) | 128));
            j2 >>>= 7;
            i2++;
        }
        this.b[i2] = (byte) ((int) j2);
        this.g.b(this.b, 0, i2 + 1);
    }

    private int c(int i2) {
        return (i2 << 1) ^ (i2 >> 31);
    }

    private long c(long j2) {
        return (j2 << 1) ^ (j2 >> 63);
    }

    private boolean c(byte b2) {
        byte b3 = b2 & dn.m;
        return b3 == 1 || b3 == 2;
    }

    private byte d(byte b2) throws dh {
        switch ((byte) (b2 & dn.m)) {
            case 0:
                return 0;
            case 1:
            case 2:
                return 2;
            case 3:
                return 3;
            case 4:
                return 6;
            case 5:
                return 8;
            case 6:
                return 10;
            case 7:
                return 4;
            case 8:
                return 11;
            case 9:
                return dn.m;
            case 10:
                return dn.l;
            case 11:
                return dn.k;
            case 12:
                return 12;
            default:
                throw new dh("don't know what type: " + ((int) ((byte) (b2 & dn.m))));
        }
    }

    private long d(long j2) {
        return (j2 >>> 1) ^ (-(1 & j2));
    }

    private void d(int i2) throws cn {
        b((byte) i2);
    }

    private byte e(byte b2) {
        return f[b2];
    }

    private byte[] e(int i2) throws cn {
        if (i2 == 0) {
            return new byte[0];
        }
        byte[] bArr = new byte[i2];
        this.g.d(bArr, 0, i2);
        return bArr;
    }

    private void f(int i2) throws dh {
        if (i2 < 0) {
            throw new dh("Negative length: " + i2);
        } else if (this.q != -1 && ((long) i2) > this.q) {
            throw new dh("Length exceeded max allowed: " + i2);
        }
    }

    private int g(int i2) {
        return (i2 >>> 1) ^ (-(i2 & 1));
    }

    @Override // u.aly.dg
    public ByteBuffer A() throws cn {
        int E = E();
        f(E);
        if (E == 0) {
            return ByteBuffer.wrap(new byte[0]);
        }
        byte[] bArr = new byte[E];
        this.g.d(bArr, 0, E);
        return ByteBuffer.wrap(bArr);
    }

    @Override // u.aly.dg
    public void B() {
        this.m.c();
        this.n = 0;
    }

    @Override // u.aly.dg
    public void a() throws cn {
    }

    @Override // u.aly.dg
    public void a(byte b2) throws cn {
        b(b2);
    }

    /* access modifiers changed from: protected */
    public void a(byte b2, int i2) throws cn {
        if (i2 <= 14) {
            d((int) ((i2 << 4) | e(b2)));
            return;
        }
        d((int) (e(b2) | 240));
        b(i2);
    }

    @Override // u.aly.dg
    public void a(double d2) throws cn {
        byte[] bArr = {0, 0, 0, 0, 0, 0, 0, 0};
        a(Double.doubleToLongBits(d2), bArr, 0);
        this.g.b(bArr);
    }

    @Override // u.aly.dg
    public void a(int i2) throws cn {
        b(c(i2));
    }

    @Override // u.aly.dg
    public void a(long j2) throws cn {
        b(c(j2));
    }

    @Override // u.aly.dg
    public void a(String str) throws cn {
        try {
            byte[] bytes = str.getBytes("UTF-8");
            a(bytes, 0, bytes.length);
        } catch (UnsupportedEncodingException e2) {
            throw new cn("UTF-8 not supported!");
        }
    }

    @Override // u.aly.dg
    public void a(ByteBuffer byteBuffer) throws cn {
        a(byteBuffer.array(), byteBuffer.position() + byteBuffer.arrayOffset(), byteBuffer.limit() - byteBuffer.position());
    }

    @Override // u.aly.dg
    public void a(db dbVar) throws cn {
        if (dbVar.b == 2) {
            this.o = dbVar;
        } else {
            a(dbVar, (byte) -1);
        }
    }

    @Override // u.aly.dg
    public void a(dc dcVar) throws cn {
        a(dcVar.a, dcVar.b);
    }

    @Override // u.aly.dg
    public void a(dd ddVar) throws cn {
        if (ddVar.c == 0) {
            d(0);
            return;
        }
        b(ddVar.c);
        d((int) ((e(ddVar.a) << 4) | e(ddVar.b)));
    }

    @Override // u.aly.dg
    public void a(de deVar) throws cn {
        b((byte) h);
        d(((deVar.b << 5) & -32) | 1);
        b(deVar.c);
        a(deVar.a);
    }

    @Override // u.aly.dg
    public void a(dk dkVar) throws cn {
        a(dkVar.a, dkVar.b);
    }

    @Override // u.aly.dg
    public void a(dl dlVar) throws cn {
        this.m.a(this.n);
        this.n = 0;
    }

    @Override // u.aly.dg
    public void a(short s) throws cn {
        b(c((int) s));
    }

    @Override // u.aly.dg
    public void a(boolean z) throws cn {
        byte b2 = 2;
        byte b3 = 1;
        if (this.o != null) {
            db dbVar = this.o;
            if (z) {
                b2 = 1;
            }
            a(dbVar, b2);
            this.o = null;
            return;
        }
        if (!z) {
            b3 = 2;
        }
        b(b3);
    }

    @Override // u.aly.dg
    public void b() throws cn {
        this.n = this.m.a();
    }

    @Override // u.aly.dg
    public void c() throws cn {
    }

    @Override // u.aly.dg
    public void d() throws cn {
        b((byte) 0);
    }

    @Override // u.aly.dg
    public void e() throws cn {
    }

    @Override // u.aly.dg
    public void f() throws cn {
    }

    @Override // u.aly.dg
    public void g() throws cn {
    }

    @Override // u.aly.dg
    public de h() throws cn {
        byte u2 = u();
        if (u2 != -126) {
            throw new dh("Expected protocol id " + Integer.toHexString(-126) + " but got " + Integer.toHexString(u2));
        }
        byte u3 = u();
        byte b2 = (byte) (u3 & j);
        if (b2 != 1) {
            throw new dh("Expected version 1 but got " + ((int) b2));
        }
        int E = E();
        return new de(z(), (byte) ((u3 >> 5) & 3), E);
    }

    @Override // u.aly.dg
    public void i() throws cn {
    }

    @Override // u.aly.dg
    public dl j() throws cn {
        this.m.a(this.n);
        this.n = 0;
        return d;
    }

    @Override // u.aly.dg
    public void k() throws cn {
        this.n = this.m.a();
    }

    @Override // u.aly.dg
    public db l() throws cn {
        byte u2 = u();
        if (u2 == 0) {
            return e;
        }
        short s = (short) ((u2 & 240) >> 4);
        db dbVar = new db("", d((byte) (u2 & dn.m)), s == 0 ? v() : (short) (s + this.n));
        if (c(u2)) {
            this.p = ((byte) (u2 & dn.m)) == 1 ? Boolean.TRUE : Boolean.FALSE;
        }
        this.n = dbVar.c;
        return dbVar;
    }

    @Override // u.aly.dg
    public void m() throws cn {
    }

    @Override // u.aly.dg
    public dd n() throws cn {
        int E = E();
        byte u2 = E == 0 ? 0 : u();
        return new dd(d((byte) (u2 >> 4)), d((byte) (u2 & dn.m)), E);
    }

    @Override // u.aly.dg
    public void o() throws cn {
    }

    @Override // u.aly.dg
    public dc p() throws cn {
        byte u2 = u();
        int i2 = (u2 >> 4) & 15;
        if (i2 == 15) {
            i2 = E();
        }
        return new dc(d(u2), i2);
    }

    @Override // u.aly.dg
    public void q() throws cn {
    }

    @Override // u.aly.dg
    public dk r() throws cn {
        return new dk(p());
    }

    @Override // u.aly.dg
    public void s() throws cn {
    }

    @Override // u.aly.dg
    public boolean t() throws cn {
        if (this.p == null) {
            return u() == 1;
        }
        boolean booleanValue = this.p.booleanValue();
        this.p = null;
        return booleanValue;
    }

    @Override // u.aly.dg
    public byte u() throws cn {
        if (this.g.h() > 0) {
            byte b2 = this.g.f()[this.g.g()];
            this.g.a(1);
            return b2;
        }
        this.g.d(this.c, 0, 1);
        return this.c[0];
    }

    @Override // u.aly.dg
    public short v() throws cn {
        return (short) g(E());
    }

    @Override // u.aly.dg
    public int w() throws cn {
        return g(E());
    }

    @Override // u.aly.dg
    public long x() throws cn {
        return d(F());
    }

    @Override // u.aly.dg
    public double y() throws cn {
        byte[] bArr = new byte[8];
        this.g.d(bArr, 0, 8);
        return Double.longBitsToDouble(a(bArr));
    }

    @Override // u.aly.dg
    public String z() throws cn {
        int E = E();
        f(E);
        if (E == 0) {
            return "";
        }
        try {
            if (this.g.h() < E) {
                return new String(e(E), "UTF-8");
            }
            String str = new String(this.g.f(), this.g.g(), E, "UTF-8");
            this.g.a(E);
            return str;
        } catch (UnsupportedEncodingException e2) {
            throw new cn("UTF-8 not supported!");
        }
    }
}
