package com.keyboard.common.utilsmodule;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class ReflectUtils {
    public static final Object getFieldObject(Class<?> cls, Object obj, String str) {
        if (cls == null || obj == null || str == null) {
            return null;
        }
        try {
            Field declaredField = cls.getDeclaredField(str);
            declaredField.setAccessible(true);
            return declaredField.get(obj);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static final Object getStaticFieldObject(Class<?> cls, String str) {
        if (cls == null || str == null) {
            return null;
        }
        try {
            Field declaredField = cls.getDeclaredField(str);
            declaredField.setAccessible(true);
            return declaredField.get(null);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static final Object invokeMethod(Class<?> cls, Object obj, String str, Class<?>[] clsArr, Object... objArr) {
        if (cls == null || obj == null || str == null) {
            return null;
        }
        try {
            Method declaredMethod = cls.getDeclaredMethod(str, clsArr);
            declaredMethod.setAccessible(true);
            return declaredMethod.invoke(obj, objArr);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static final Object invokeStaticMethod(Class<?> cls, String str, Class<?>[] clsArr, Object... objArr) {
        if (cls == null || str == null) {
            return null;
        }
        try {
            Method declaredMethod = cls.getDeclaredMethod(str, clsArr);
            declaredMethod.setAccessible(true);
            return declaredMethod.invoke(null, objArr);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static final Object newObject(String str) {
        if (str == null) {
            return null;
        }
        try {
            return Class.forName(str).newInstance();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static final void setFieldObject(Class<?> cls, Object obj, String str, Object obj2) {
        if (cls != null && obj != null && str != null) {
            try {
                Field declaredField = cls.getDeclaredField(str);
                declaredField.setAccessible(true);
                declaredField.set(obj, obj2);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static final void setFinalStaticFieldObject(Class<?> cls, String str, Object obj) {
        if (cls != null && str != null) {
            try {
                Field declaredField = cls.getDeclaredField(str);
                declaredField.setAccessible(true);
                Field declaredField2 = Field.class.getDeclaredField("modifiers");
                declaredField2.setAccessible(true);
                declaredField2.setInt(declaredField, declaredField.getModifiers() & -17);
                declaredField.set(null, obj);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static final void setStaticFieldObject(Class<?> cls, String str, Object obj) {
        if (cls != null && str != null) {
            try {
                Field declaredField = cls.getDeclaredField(str);
                declaredField.setAccessible(true);
                declaredField.set(null, obj);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
