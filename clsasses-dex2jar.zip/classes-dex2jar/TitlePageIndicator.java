package com.keyboard.common.uimodule.viewpagerindicator;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.view.MotionEventCompat;
import android.support.v4.view.ViewConfigurationCompat;
import android.support.v4.view.ViewPager;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import com.keyboard.common.uimodule.R;
import java.util.ArrayList;

public class TitlePageIndicator extends View implements PageIndicator {
    private static final float BOLD_FADE_PERCENTAGE = 0.05f;
    private static final String EMPTY_TITLE = "";
    private static final int INVALID_POINTER = -1;
    private static final float SELECTION_FADE_PERCENTAGE = 0.25f;
    private int mActivePointerId;
    private boolean mBoldText;
    private final Rect mBounds;
    private OnCenterItemClickListener mCenterItemClickListener;
    private float mClipPadding;
    private int mColorSelected;
    private int mColorText;
    private int mCurrentPage;
    private float mFooterIndicatorHeight;
    private IndicatorStyle mFooterIndicatorStyle;
    private float mFooterIndicatorUnderlinePadding;
    private float mFooterLineHeight;
    private float mFooterPadding;
    private boolean mIsDragging;
    private float mLastMotionX;
    private LinePosition mLinePosition;
    private ViewPager.OnPageChangeListener mListener;
    private float mPageOffset;
    private final Paint mPaintFooterIndicator;
    private final Paint mPaintFooterLine;
    private final Paint mPaintText;
    private Path mPath;
    private int mScrollState;
    private float mTitlePadding;
    private float mTopPadding;
    private int mTouchSlop;
    private ViewPager mViewPager;

    public enum IndicatorStyle {
        None(0),
        Triangle(1),
        Underline(2);
        
        public final int value;

        private IndicatorStyle(int i) {
            this.value = i;
        }

        public static IndicatorStyle fromValue(int i) {
            IndicatorStyle[] values = values();
            for (IndicatorStyle indicatorStyle : values) {
                if (indicatorStyle.value == i) {
                    return indicatorStyle;
                }
            }
            return null;
        }
    }

    public enum LinePosition {
        Bottom(0),
        Top(1);
        
        public final int value;

        private LinePosition(int i) {
            this.value = i;
        }

        public static LinePosition fromValue(int i) {
            LinePosition[] values = values();
            for (LinePosition linePosition : values) {
                if (linePosition.value == i) {
                    return linePosition;
                }
            }
            return null;
        }
    }

    public interface OnCenterItemClickListener {
        void onCenterItemClick(int i);
    }

    static class SavedState extends View.BaseSavedState {
        public static final Parcelable.Creator<SavedState> CREATOR = new Parcelable.Creator<SavedState>() {
            /* class com.keyboard.common.uimodule.viewpagerindicator.TitlePageIndicator.SavedState.AnonymousClass1 */

            @Override // android.os.Parcelable.Creator
            public SavedState createFromParcel(Parcel parcel) {
                return new SavedState(parcel);
            }

            @Override // android.os.Parcelable.Creator
            public SavedState[] newArray(int i) {
                return new SavedState[i];
            }
        };
        int currentPage;

        private SavedState(Parcel parcel) {
            super(parcel);
            this.currentPage = parcel.readInt();
        }

        public SavedState(Parcelable parcelable) {
            super(parcelable);
        }

        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeInt(this.currentPage);
        }
    }

    public TitlePageIndicator(Context context) {
        this(context, null);
    }

    public TitlePageIndicator(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.vpiTitlePageIndicatorStyle);
    }

    public TitlePageIndicator(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.mCurrentPage = -1;
        this.mPaintText = new Paint();
        this.mPath = new Path();
        this.mBounds = new Rect();
        this.mPaintFooterLine = new Paint();
        this.mPaintFooterIndicator = new Paint();
        this.mLastMotionX = -1.0f;
        this.mActivePointerId = -1;
        if (!isInEditMode()) {
            Resources resources = getResources();
            int color = resources.getColor(R.color.default_title_indicator_footer_color);
            float dimension = resources.getDimension(R.dimen.default_title_indicator_footer_line_height);
            int integer = resources.getInteger(R.integer.default_title_indicator_footer_indicator_style);
            float dimension2 = resources.getDimension(R.dimen.default_title_indicator_footer_indicator_height);
            float dimension3 = resources.getDimension(R.dimen.default_title_indicator_footer_indicator_underline_padding);
            float dimension4 = resources.getDimension(R.dimen.default_title_indicator_footer_padding);
            int integer2 = resources.getInteger(R.integer.default_title_indicator_line_position);
            int color2 = resources.getColor(R.color.default_title_indicator_selected_color);
            boolean z = resources.getBoolean(R.bool.default_title_indicator_selected_bold);
            int color3 = resources.getColor(R.color.default_title_indicator_text_color);
            float dimension5 = resources.getDimension(R.dimen.default_title_indicator_text_size);
            float dimension6 = resources.getDimension(R.dimen.default_title_indicator_title_padding);
            float dimension7 = resources.getDimension(R.dimen.default_title_indicator_clip_padding);
            float dimension8 = resources.getDimension(R.dimen.default_title_indicator_top_padding);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R.styleable.TitlePageIndicator, i, 0);
            this.mFooterLineHeight = obtainStyledAttributes.getDimension(R.styleable.TitlePageIndicator_footerLineHeight, dimension);
            this.mFooterIndicatorStyle = IndicatorStyle.fromValue(obtainStyledAttributes.getInteger(R.styleable.TitlePageIndicator_footerIndicatorStyle, integer));
            this.mFooterIndicatorHeight = obtainStyledAttributes.getDimension(R.styleable.TitlePageIndicator_footerIndicatorHeight, dimension2);
            this.mFooterIndicatorUnderlinePadding = obtainStyledAttributes.getDimension(R.styleable.TitlePageIndicator_footerIndicatorUnderlinePadding, dimension3);
            this.mFooterPadding = obtainStyledAttributes.getDimension(R.styleable.TitlePageIndicator_footerPadding, dimension4);
            this.mLinePosition = LinePosition.fromValue(obtainStyledAttributes.getInteger(R.styleable.TitlePageIndicator_linePosition, integer2));
            this.mTopPadding = obtainStyledAttributes.getDimension(R.styleable.TitlePageIndicator_topPadding, dimension8);
            this.mTitlePadding = obtainStyledAttributes.getDimension(R.styleable.TitlePageIndicator_titlePadding, dimension6);
            this.mClipPadding = obtainStyledAttributes.getDimension(R.styleable.TitlePageIndicator_clipPadding, dimension7);
            this.mColorSelected = obtainStyledAttributes.getColor(R.styleable.TitlePageIndicator_selectedColor, color2);
            this.mColorText = obtainStyledAttributes.getColor(R.styleable.TitlePageIndicator_android_textColor, color3);
            this.mBoldText = obtainStyledAttributes.getBoolean(R.styleable.TitlePageIndicator_selectedBold, z);
            float dimension9 = obtainStyledAttributes.getDimension(R.styleable.TitlePageIndicator_android_textSize, dimension5);
            int color4 = obtainStyledAttributes.getColor(R.styleable.TitlePageIndicator_footerColor, color);
            this.mPaintText.setTextSize(dimension9);
            this.mPaintText.setAntiAlias(true);
            this.mPaintFooterLine.setStyle(Paint.Style.FILL_AND_STROKE);
            this.mPaintFooterLine.setStrokeWidth(this.mFooterLineHeight);
            this.mPaintFooterLine.setColor(color4);
            this.mPaintFooterIndicator.setStyle(Paint.Style.FILL_AND_STROKE);
            this.mPaintFooterIndicator.setColor(color4);
            Drawable drawable = obtainStyledAttributes.getDrawable(R.styleable.TitlePageIndicator_android_background);
            if (drawable != null) {
                setBackgroundDrawable(drawable);
            }
            obtainStyledAttributes.recycle();
            this.mTouchSlop = ViewConfigurationCompat.getScaledPagingTouchSlop(ViewConfiguration.get(context));
        }
    }

    private Rect calcBounds(int i, Paint paint) {
        Rect rect = new Rect();
        CharSequence title = getTitle(i);
        rect.right = (int) paint.measureText(title, 0, title.length());
        rect.bottom = (int) (paint.descent() - paint.ascent());
        return rect;
    }

    private ArrayList<Rect> calculateAllBounds(Paint paint) {
        ArrayList<Rect> arrayList = new ArrayList<>();
        int count = this.mViewPager.getAdapter().getCount();
        int width = getWidth();
        int i = width / 2;
        for (int i2 = 0; i2 < count; i2++) {
            Rect calcBounds = calcBounds(i2, paint);
            int i3 = calcBounds.right - calcBounds.left;
            int i4 = calcBounds.bottom;
            int i5 = calcBounds.top;
            calcBounds.left = (int) ((((float) i) - (((float) i3) / 2.0f)) + ((((float) (i2 - this.mCurrentPage)) - this.mPageOffset) * ((float) width)));
            calcBounds.right = i3 + calcBounds.left;
            calcBounds.top = 0;
            calcBounds.bottom = i4 - i5;
            arrayList.add(calcBounds);
        }
        return arrayList;
    }

    private void clipViewOnTheLeft(Rect rect, float f, int i) {
        rect.left = (int) (((float) i) + this.mClipPadding);
        rect.right = (int) (this.mClipPadding + f);
    }

    private void clipViewOnTheRight(Rect rect, float f, int i) {
        rect.right = (int) (((float) i) - this.mClipPadding);
        rect.left = (int) (((float) rect.right) - f);
    }

    private CharSequence getTitle(int i) {
        CharSequence pageTitle = this.mViewPager.getAdapter().getPageTitle(i);
        return pageTitle == null ? "" : pageTitle;
    }

    public float getClipPadding() {
        return this.mClipPadding;
    }

    public int getFooterColor() {
        return this.mPaintFooterLine.getColor();
    }

    public float getFooterIndicatorHeight() {
        return this.mFooterIndicatorHeight;
    }

    public float getFooterIndicatorPadding() {
        return this.mFooterPadding;
    }

    public IndicatorStyle getFooterIndicatorStyle() {
        return this.mFooterIndicatorStyle;
    }

    public float getFooterLineHeight() {
        return this.mFooterLineHeight;
    }

    public LinePosition getLinePosition() {
        return this.mLinePosition;
    }

    public int getSelectedColor() {
        return this.mColorSelected;
    }

    public int getTextColor() {
        return this.mColorText;
    }

    public float getTextSize() {
        return this.mPaintText.getTextSize();
    }

    public float getTitlePadding() {
        return this.mTitlePadding;
    }

    public float getTopPadding() {
        return this.mTopPadding;
    }

    public Typeface getTypeface() {
        return this.mPaintText.getTypeface();
    }

    public boolean isSelectedBold() {
        return this.mBoldText;
    }

    @Override // com.keyboard.common.uimodule.viewpagerindicator.PageIndicator
    public void notifyDataSetChanged() {
        invalidate();
    }

    /* access modifiers changed from: protected */
    public void onDraw(Canvas canvas) {
        int count;
        float f;
        int i;
        int i2;
        super.onDraw(canvas);
        if (this.mViewPager != null && (count = this.mViewPager.getAdapter().getCount()) != 0) {
            if (this.mCurrentPage == -1 && this.mViewPager != null) {
                this.mCurrentPage = this.mViewPager.getCurrentItem();
            }
            ArrayList<Rect> calculateAllBounds = calculateAllBounds(this.mPaintText);
            int size = calculateAllBounds.size();
            if (this.mCurrentPage >= size) {
                setCurrentItem(size - 1);
                return;
            }
            float width = ((float) getWidth()) / 2.0f;
            int left = getLeft();
            float f2 = ((float) left) + this.mClipPadding;
            int width2 = getWidth();
            int height = getHeight();
            int i3 = left + width2;
            float f3 = ((float) i3) - this.mClipPadding;
            int i4 = this.mCurrentPage;
            if (((double) this.mPageOffset) <= 0.5d) {
                f = this.mPageOffset;
                i = i4;
            } else {
                f = 1.0f - this.mPageOffset;
                i = i4 + 1;
            }
            boolean z = f <= SELECTION_FADE_PERCENTAGE;
            boolean z2 = f <= BOLD_FADE_PERCENTAGE;
            float f4 = (SELECTION_FADE_PERCENTAGE - f) / SELECTION_FADE_PERCENTAGE;
            Rect rect = calculateAllBounds.get(this.mCurrentPage);
            float f5 = (float) (rect.right - rect.left);
            if (((float) rect.left) < f2) {
                clipViewOnTheLeft(rect, f5, left);
            }
            if (((float) rect.right) > f3) {
                clipViewOnTheRight(rect, f5, i3);
            }
            if (this.mCurrentPage > 0) {
                for (int i5 = this.mCurrentPage - 1; i5 >= 0; i5--) {
                    Rect rect2 = calculateAllBounds.get(i5);
                    if (((float) rect2.left) < f2) {
                        int i6 = rect2.right - rect2.left;
                        clipViewOnTheLeft(rect2, (float) i6, left);
                        Rect rect3 = calculateAllBounds.get(i5 + 1);
                        if (((float) rect2.right) + this.mTitlePadding > ((float) rect3.left)) {
                            rect2.left = (int) (((float) (rect3.left - i6)) - this.mTitlePadding);
                            rect2.right = rect2.left + i6;
                        }
                    }
                }
            }
            if (this.mCurrentPage < count - 1) {
                int i7 = this.mCurrentPage + 1;
                while (true) {
                    int i8 = i7;
                    if (i8 >= count) {
                        break;
                    }
                    Rect rect4 = calculateAllBounds.get(i8);
                    if (((float) rect4.right) > f3) {
                        int i9 = rect4.right - rect4.left;
                        clipViewOnTheRight(rect4, (float) i9, i3);
                        Rect rect5 = calculateAllBounds.get(i8 - 1);
                        if (((float) rect4.left) - this.mTitlePadding < ((float) rect5.right)) {
                            rect4.left = (int) (((float) rect5.right) + this.mTitlePadding);
                            rect4.right = rect4.left + i9;
                        }
                    }
                    i7 = i8 + 1;
                }
            }
            int i10 = this.mColorText >>> 24;
            int i11 = 0;
            while (true) {
                int i12 = i11;
                if (i12 >= count) {
                    break;
                }
                Rect rect6 = calculateAllBounds.get(i12);
                if ((rect6.left > left && rect6.left < i3) || (rect6.right > left && rect6.right < i3)) {
                    boolean z3 = i12 == i;
                    CharSequence title = getTitle(i12);
                    this.mPaintText.setFakeBoldText(z3 && z2 && this.mBoldText);
                    this.mPaintText.setColor(this.mColorText);
                    if (z3 && z) {
                        this.mPaintText.setAlpha(i10 - ((int) (((float) i10) * f4)));
                    }
                    if (i12 < size - 1) {
                        Rect rect7 = calculateAllBounds.get(i12 + 1);
                        if (((float) rect6.right) + this.mTitlePadding > ((float) rect7.left)) {
                            int i13 = rect6.right - rect6.left;
                            rect6.left = (int) (((float) (rect7.left - i13)) - this.mTitlePadding);
                            rect6.right = rect6.left + i13;
                        }
                    }
                    canvas.drawText(title, 0, title.length(), (float) rect6.left, this.mTopPadding + ((float) rect6.bottom), this.mPaintText);
                    if (z3 && z) {
                        this.mPaintText.setColor(this.mColorSelected);
                        this.mPaintText.setAlpha((int) (((float) (this.mColorSelected >>> 24)) * f4));
                        canvas.drawText(title, 0, title.length(), (float) rect6.left, this.mTopPadding + ((float) rect6.bottom), this.mPaintText);
                    }
                }
                i11 = i12 + 1;
            }
            float f6 = this.mFooterLineHeight;
            float f7 = this.mFooterIndicatorHeight;
            if (this.mLinePosition == LinePosition.Top) {
                i2 = 0;
                f6 = -f6;
                f7 = -f7;
            } else {
                i2 = height;
            }
            this.mPath.reset();
            this.mPath.moveTo(0.0f, ((float) i2) - (f6 / 2.0f));
            this.mPath.lineTo((float) width2, ((float) i2) - (f6 / 2.0f));
            this.mPath.close();
            canvas.drawPath(this.mPath, this.mPaintFooterLine);
            float f8 = ((float) i2) - f6;
            switch (this.mFooterIndicatorStyle) {
                case Triangle:
                    this.mPath.reset();
                    this.mPath.moveTo(width, f8 - f7);
                    this.mPath.lineTo(width + f7, f8);
                    this.mPath.lineTo(width - f7, f8);
                    this.mPath.close();
                    canvas.drawPath(this.mPath, this.mPaintFooterIndicator);
                    return;
                case Underline:
                    if (z && i < size) {
                        Rect rect8 = calculateAllBounds.get(i);
                        float f9 = ((float) rect8.right) + this.mFooterIndicatorUnderlinePadding;
                        float f10 = ((float) rect8.left) - this.mFooterIndicatorUnderlinePadding;
                        float f11 = f8 - f7;
                        this.mPath.reset();
                        this.mPath.moveTo(f10, f8);
                        this.mPath.lineTo(f9, f8);
                        this.mPath.lineTo(f9, f11);
                        this.mPath.lineTo(f10, f11);
                        this.mPath.close();
                        this.mPaintFooterIndicator.setAlpha((int) (255.0f * f4));
                        canvas.drawPath(this.mPath, this.mPaintFooterIndicator);
                        this.mPaintFooterIndicator.setAlpha(255);
                        return;
                    }
                    return;
                default:
                    return;
            }
        }
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        float f;
        int size = View.MeasureSpec.getSize(i);
        if (View.MeasureSpec.getMode(i2) == 1073741824) {
            f = (float) View.MeasureSpec.getSize(i2);
        } else {
            this.mBounds.setEmpty();
            this.mBounds.bottom = (int) (this.mPaintText.descent() - this.mPaintText.ascent());
            f = ((float) (this.mBounds.bottom - this.mBounds.top)) + this.mFooterLineHeight + this.mFooterPadding + this.mTopPadding;
            if (this.mFooterIndicatorStyle != IndicatorStyle.None) {
                f += this.mFooterIndicatorHeight;
            }
        }
        setMeasuredDimension(size, (int) f);
    }

    @Override // android.support.v4.view.ViewPager.OnPageChangeListener
    public void onPageScrollStateChanged(int i) {
        this.mScrollState = i;
        if (this.mListener != null) {
            this.mListener.onPageScrollStateChanged(i);
        }
    }

    @Override // android.support.v4.view.ViewPager.OnPageChangeListener
    public void onPageScrolled(int i, float f, int i2) {
        this.mCurrentPage = i;
        this.mPageOffset = f;
        invalidate();
        if (this.mListener != null) {
            this.mListener.onPageScrolled(i, f, i2);
        }
    }

    @Override // android.support.v4.view.ViewPager.OnPageChangeListener
    public void onPageSelected(int i) {
        if (this.mScrollState == 0) {
            this.mCurrentPage = i;
            invalidate();
        }
        if (this.mListener != null) {
            this.mListener.onPageSelected(i);
        }
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        SavedState savedState = (SavedState) parcelable;
        super.onRestoreInstanceState(savedState.getSuperState());
        this.mCurrentPage = savedState.currentPage;
        requestLayout();
    }

    public Parcelable onSaveInstanceState() {
        SavedState savedState = new SavedState(super.onSaveInstanceState());
        savedState.currentPage = this.mCurrentPage;
        return savedState;
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        int i = 0;
        if (super.onTouchEvent(motionEvent)) {
            return true;
        }
        if (this.mViewPager == null || this.mViewPager.getAdapter().getCount() == 0) {
            return false;
        }
        int action = motionEvent.getAction() & 255;
        switch (action) {
            case 0:
                this.mActivePointerId = MotionEventCompat.getPointerId(motionEvent, 0);
                this.mLastMotionX = motionEvent.getX();
                return true;
            case 1:
            case 3:
                if (!this.mIsDragging) {
                    int count = this.mViewPager.getAdapter().getCount();
                    int width = getWidth();
                    float f = ((float) width) / 2.0f;
                    float f2 = ((float) width) / 6.0f;
                    float x = motionEvent.getX();
                    if (x < f - f2) {
                        if (this.mCurrentPage > 0) {
                            if (action == 3) {
                                return true;
                            }
                            this.mViewPager.setCurrentItem(this.mCurrentPage - 1);
                            return true;
                        }
                    } else if (x > f2 + f) {
                        if (this.mCurrentPage < count - 1) {
                            if (action == 3) {
                                return true;
                            }
                            this.mViewPager.setCurrentItem(this.mCurrentPage + 1);
                            return true;
                        }
                    } else if (!(this.mCenterItemClickListener == null || action == 3)) {
                        this.mCenterItemClickListener.onCenterItemClick(this.mCurrentPage);
                    }
                }
                this.mIsDragging = false;
                this.mActivePointerId = -1;
                if (!this.mViewPager.isFakeDragging()) {
                    return true;
                }
                this.mViewPager.endFakeDrag();
                return true;
            case 2:
                float x2 = MotionEventCompat.getX(motionEvent, MotionEventCompat.findPointerIndex(motionEvent, this.mActivePointerId));
                float f3 = x2 - this.mLastMotionX;
                if (!this.mIsDragging && Math.abs(f3) > ((float) this.mTouchSlop)) {
                    this.mIsDragging = true;
                }
                if (!this.mIsDragging) {
                    return true;
                }
                this.mLastMotionX = x2;
                if (!this.mViewPager.beginFakeDrag() && !this.mViewPager.isFakeDragging()) {
                    return true;
                }
                this.mViewPager.fakeDragBy(f3);
                return true;
            case 4:
            default:
                return true;
            case 5:
                int actionIndex = MotionEventCompat.getActionIndex(motionEvent);
                this.mLastMotionX = MotionEventCompat.getX(motionEvent, actionIndex);
                this.mActivePointerId = MotionEventCompat.getPointerId(motionEvent, actionIndex);
                return true;
            case 6:
                int actionIndex2 = MotionEventCompat.getActionIndex(motionEvent);
                if (MotionEventCompat.getPointerId(motionEvent, actionIndex2) == this.mActivePointerId) {
                    if (actionIndex2 == 0) {
                        i = 1;
                    }
                    this.mActivePointerId = MotionEventCompat.getPointerId(motionEvent, i);
                }
                this.mLastMotionX = MotionEventCompat.getX(motionEvent, MotionEventCompat.findPointerIndex(motionEvent, this.mActivePointerId));
                return true;
        }
    }

    public void setClipPadding(float f) {
        this.mClipPadding = f;
        invalidate();
    }

    @Override // com.keyboard.common.uimodule.viewpagerindicator.PageIndicator
    public void setCurrentItem(int i) {
        if (this.mViewPager == null) {
            throw new IllegalStateException("ViewPager has not been bound.");
        }
        this.mViewPager.setCurrentItem(i);
        this.mCurrentPage = i;
        invalidate();
    }

    public void setFooterColor(int i) {
        this.mPaintFooterLine.setColor(i);
        this.mPaintFooterIndicator.setColor(i);
        invalidate();
    }

    public void setFooterIndicatorHeight(float f) {
        this.mFooterIndicatorHeight = f;
        invalidate();
    }

    public void setFooterIndicatorPadding(float f) {
        this.mFooterPadding = f;
        invalidate();
    }

    public void setFooterIndicatorStyle(IndicatorStyle indicatorStyle) {
        this.mFooterIndicatorStyle = indicatorStyle;
        invalidate();
    }

    public void setFooterLineHeight(float f) {
        this.mFooterLineHeight = f;
        this.mPaintFooterLine.setStrokeWidth(this.mFooterLineHeight);
        invalidate();
    }

    public void setLinePosition(LinePosition linePosition) {
        this.mLinePosition = linePosition;
        invalidate();
    }

    public void setOnCenterItemClickListener(OnCenterItemClickListener onCenterItemClickListener) {
        this.mCenterItemClickListener = onCenterItemClickListener;
    }

    @Override // com.keyboard.common.uimodule.viewpagerindicator.PageIndicator
    public void setOnPageChangeListener(ViewPager.OnPageChangeListener onPageChangeListener) {
        this.mListener = onPageChangeListener;
    }

    public void setSelectedBold(boolean z) {
        this.mBoldText = z;
        invalidate();
    }

    public void setSelectedColor(int i) {
        this.mColorSelected = i;
        invalidate();
    }

    public void setTextColor(int i) {
        this.mPaintText.setColor(i);
        this.mColorText = i;
        invalidate();
    }

    public void setTextSize(float f) {
        this.mPaintText.setTextSize(f);
        invalidate();
    }

    public void setTitlePadding(float f) {
        this.mTitlePadding = f;
        invalidate();
    }

    public void setTopPadding(float f) {
        this.mTopPadding = f;
        invalidate();
    }

    public void setTypeface(Typeface typeface) {
        this.mPaintText.setTypeface(typeface);
        invalidate();
    }

    @Override // com.keyboard.common.uimodule.viewpagerindicator.PageIndicator
    public void setViewPager(ViewPager viewPager) {
        if (this.mViewPager != viewPager) {
            if (this.mViewPager != null) {
                this.mViewPager.setOnPageChangeListener(null);
            }
            if (viewPager.getAdapter() == null) {
                throw new IllegalStateException("ViewPager does not have adapter instance.");
            }
            this.mViewPager = viewPager;
            this.mViewPager.setOnPageChangeListener(this);
            invalidate();
        }
    }

    @Override // com.keyboard.common.uimodule.viewpagerindicator.PageIndicator
    public void setViewPager(ViewPager viewPager, int i) {
        setViewPager(viewPager);
        setCurrentItem(i);
    }
}
