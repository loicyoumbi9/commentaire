package org.w3c.dom.views;

public interface AbstractView {
    DocumentView getDocument();
}
