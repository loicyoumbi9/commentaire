package com.ironsource.mobilcore;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.widget.Toast;
import com.ironsource.mobilcore.MobileCore;
import com.ironsource.mobilcore.aS;
import com.umeng.update.UpdateConfig;
import java.math.BigInteger;
import java.util.Locale;

/* renamed from: com.ironsource.mobilcore.x  reason: case insensitive filesystem */
final class C0286x {
    private static C0286x a = null;
    private static final String[] b = {UpdateConfig.g};
    private static final String[] c = {"android.permission.ACCESS_WIFI_STATE", "android.permission.READ_PHONE_STATE", UpdateConfig.f};
    private boolean d;
    private Context e;
    private int f = -1;
    private int g = -1;

    /* renamed from: com.ironsource.mobilcore.x$a */
    private enum a {
        SOFT,
        HARD
    }

    C0286x() {
    }

    protected static C0286x a() {
        if (a == null) {
            a = new C0286x();
        }
        return a;
    }

    private void a(String str, a aVar) {
        if (aVar == a.SOFT) {
            B.a("Warning: " + str, 1);
            return;
        }
        B.a("Error: " + str, 2);
        try {
            Toast makeText = Toast.makeText(this.e, str, 1);
            makeText.setGravity(17, 0, 0);
            makeText.show();
        } catch (Exception e2) {
        }
    }

    private boolean e() {
        try {
            if (this.e.getPackageManager().getReceiverInfo(new ComponentName(this.e, InstallationTracker.class), 2).enabled) {
                return true;
            }
        } catch (PackageManager.NameNotFoundException e2) {
            B.a("ImpVerifier crashed: " + e2.getLocalizedMessage(), 55);
        }
        a("mobileCore's receiver is not declared in your manifest, see mobileCore documentation for more details.", a.HARD);
        return false;
    }

    /* access modifiers changed from: protected */
    public final void a(int i) {
        if (this.f == -1) {
            this.f = i;
        } else if (this.g == -1) {
            this.g = i;
            if (this.f == this.g - 1) {
                a("It is generally advised not to call mobileCore's showInterstitial directly after calling init", a.SOFT);
            }
        }
    }

    /* access modifiers changed from: protected */
    public final void a(Context context) {
        if (Build.VERSION.SDK_INT <= 10 && !aF.a(context, UpdateConfig.h)) {
            B.a("Error: mobileCore has detected a critical, missing permission: android.permission.INTERNET. Please add it to your manifest for mobileCore to work correctly.", 2);
            for (StackTraceElement stackTraceElement : Thread.currentThread().getStackTrace()) {
                B.a(stackTraceElement.toString(), 2);
            }
        }
    }

    /* access modifiers changed from: protected */
    public final void a(Context context, MobileCore.LOG_TYPE log_type) {
        this.d = log_type == MobileCore.LOG_TYPE.DEBUG;
        this.e = context;
    }

    /* access modifiers changed from: protected */
    public final void a(StackTraceElement[] stackTraceElementArr) {
        int i = 0;
        while (i < stackTraceElementArr.length) {
            try {
                if (!stackTraceElementArr[i].getMethodName().toLowerCase(Locale.US).contains("oncreate")) {
                    i++;
                } else if (stackTraceElementArr[i - 1] == null) {
                    return;
                } else {
                    if (stackTraceElementArr[i - 1].getMethodName().toLowerCase(Locale.US).contains("showInterstitial")) {
                        a("Calling mobileCore's showInterstitial command in the onCreate event is not optimal, more time will allow better offers to load.", a.SOFT);
                        return;
                    }
                    return;
                }
            } catch (Exception e2) {
                return;
            }
        }
    }

    /* access modifiers changed from: protected */
    public final boolean a(String str, Context context, SharedPreferences.Editor editor) {
        String bigInteger = new BigInteger(str, 36).toString(16);
        if (bigInteger.length() > 32) {
            String substring = bigInteger.substring(32);
            B.a("Account name in init. " + substring, 55);
            editor.putString("s#ge1%dms#ga1%dns#g_1%dt1%dn1%du1%dos#gcs#gcs#gas#g_1%dss#gfs#ge1%dr1%dp", C0285w.a(substring));
            return true;
        }
        a("The developer hash used is invalid(" + str + ")", a.HARD);
        aK.a(context, aS.b.REPORT_TYPE_ERROR).b("Can't extract affiliateAccount from the token passed").b("1%dns#ge1%dk1%do1%dt", str).a();
        return false;
    }

    /* access modifiers changed from: protected */
    public final boolean b() {
        boolean z = true;
        try {
            PackageManager packageManager = this.e.getPackageManager();
            boolean z2 = false;
            for (int i = 0; i < b.length; i++) {
                String str = b[i];
                if (packageManager.checkPermission(str, this.e.getPackageName()) != 0) {
                    a("mobileCore requires permission: " + str, a.HARD);
                    z2 = true;
                }
            }
            for (int i2 = 0; i2 < c.length; i2++) {
                String str2 = c[i2];
                if (packageManager.checkPermission(str2, this.e.getPackageName()) != 0) {
                    a("mobileCore can potentially work better with: " + str2, a.SOFT);
                }
            }
            if (z2) {
                z = false;
            }
            return e() & z;
        } catch (Exception e2) {
            B.a("ImpVerifier crashed: " + e2.getLocalizedMessage(), 55);
            return false;
        }
    }

    /* access modifiers changed from: protected */
    public final boolean c() {
        if (this.e.getPackageManager().queryIntentServices(new Intent(this.e, MobileCoreReport.class), 65536).size() > 0) {
            return true;
        }
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        B.a("Error: mobileCore's service not detected. Please register according to updated documentation.", 2);
        for (StackTraceElement stackTraceElement : stackTrace) {
            B.a(stackTraceElement.toString(), 2);
        }
        return false;
    }

    /* access modifiers changed from: protected */
    public final boolean d() {
        return this.d;
    }
}
