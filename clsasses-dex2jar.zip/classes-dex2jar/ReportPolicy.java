package com.umeng.analytics;

import android.content.Context;
import u.aly.aa;
import u.aly.ak;
import u.aly.bq;
import u.aly.s;

public class ReportPolicy {
    public static final int BATCH_AT_LAUNCH = 1;
    public static final int BATCH_BY_INTERVAL = 6;
    public static final int BATCH_BY_SIZE = 7;
    public static final int DAILY = 4;
    public static final int REALTIME = 0;
    public static final int WIFIONLY = 5;
    static final int a = 2;
    static final int b = 3;

    public static class a extends g {
        private ak a;
        private aa b;

        public a(aa aaVar, ak akVar) {
            this.b = aaVar;
            this.a = akVar;
        }

        @Override // com.umeng.analytics.ReportPolicy.g
        public boolean a() {
            return this.a.c();
        }

        @Override // com.umeng.analytics.ReportPolicy.g
        public boolean a(boolean z) {
            return System.currentTimeMillis() - this.b.c >= this.a.a();
        }
    }

    public static class b extends g {
        private long a;
        private long b = 0;

        public b(int i) {
            this.a = (long) i;
            this.b = System.currentTimeMillis();
        }

        @Override // com.umeng.analytics.ReportPolicy.g
        public boolean a() {
            return System.currentTimeMillis() - this.b < this.a;
        }

        @Override // com.umeng.analytics.ReportPolicy.g
        public boolean a(boolean z) {
            return System.currentTimeMillis() - this.b >= this.a;
        }
    }

    public static class c extends g {
        @Override // com.umeng.analytics.ReportPolicy.g
        public boolean a(boolean z) {
            return z;
        }
    }

    public static class d extends g {
        private long a = 90000;
        private long b;
        private aa c;

        public d(aa aaVar, long j) {
            this.c = aaVar;
            this.b = j < this.a ? this.a : j;
        }

        @Override // com.umeng.analytics.ReportPolicy.g
        public boolean a(boolean z) {
            return System.currentTimeMillis() - this.c.c >= this.b;
        }

        public long b() {
            return this.b;
        }
    }

    public static class e extends g {
        private final int a;
        private s b;

        public e(s sVar, int i) {
            this.a = i;
            this.b = sVar;
        }

        @Override // com.umeng.analytics.ReportPolicy.g
        public boolean a(boolean z) {
            return this.b.b() > this.a;
        }
    }

    public static class f extends g {
        private long a = 86400000;
        private aa b;

        public f(aa aaVar) {
            this.b = aaVar;
        }

        @Override // com.umeng.analytics.ReportPolicy.g
        public boolean a(boolean z) {
            return System.currentTimeMillis() - this.b.c >= this.a;
        }
    }

    public static class g {
        public boolean a() {
            return true;
        }

        public boolean a(boolean z) {
            return true;
        }
    }

    public static class h extends g {
        private Context a = null;

        public h(Context context) {
            this.a = context;
        }

        @Override // com.umeng.analytics.ReportPolicy.g
        public boolean a(boolean z) {
            return bq.k(this.a);
        }
    }
}
