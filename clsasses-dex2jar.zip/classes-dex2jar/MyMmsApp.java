package com.crazystudio.mms7.imessager;

import com.iphonestyle.mms.MmsApp;

public class MyMmsApp extends MmsApp {
    public static final String LOG_TAG = "Mms7";

    @Override // com.iphonestyle.mms.MmsApp
    public void onCreate() {
        super.onCreate();
    }
}
