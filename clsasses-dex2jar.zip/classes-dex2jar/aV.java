package com.ironsource.mobilcore;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.os.AsyncTask;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.OrientationEventListener;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import com.ironsource.mobilcore.C0247aj;
import com.ironsource.mobilcore.C0274l;
import com.ironsource.mobilcore.C0282t;
import com.ironsource.mobilcore.C0283u;
import com.ironsource.mobilcore.H;
import com.ironsource.mobilcore.MobileCore;
import com.ironsource.mobilcore.T;
import com.ironsource.mobilcore.aF;
import com.ironsource.mobilcore.aS;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

final class aV extends C0274l implements MCISliderAPI {
    private static aV z;
    private boolean A = false;
    private int B;
    /* access modifiers changed from: private */
    public ArrayList C;
    private long D;
    /* access modifiers changed from: private */
    public long E;
    /* access modifiers changed from: private */
    public Activity g;
    /* access modifiers changed from: private */
    public String h;
    private boolean i;
    private aI j;
    /* access modifiers changed from: private */
    public HashMap k;
    private C0238aa l;
    /* access modifiers changed from: private */
    public boolean m;
    /* access modifiers changed from: private */
    public String n;
    private ArrayList o;
    private OrientationEventListener p;
    /* access modifiers changed from: private */
    public int q = -1;
    private int[] r = {5000, 22000, 42000};
    private int s;
    private Runnable t;
    /* access modifiers changed from: private */

    /* renamed from: u  reason: collision with root package name */
    public C0247aj f4u;
    /* access modifiers changed from: private */
    public W v;
    /* access modifiers changed from: private */
    public T w;
    /* access modifiers changed from: private */
    public ImageView x;
    private ProgressBar y;

    private abstract class a {
        protected String a;

        public a(String str) {
            this.a = str;
        }

        public abstract void a();
    }

    protected enum b implements C0274l.d {
        INIT("init"),
        VISIBLE("visible");
        
        private String c;

        private b(String str) {
            this.c = str;
        }

        @Override // com.ironsource.mobilcore.C0274l.d
        public final String a() {
            return this.c;
        }
    }

    private final class c extends C0275m {
        public c() {
        }

        public final void init(String str, String str2) {
            aV.this.a("JSFlowBridge , init", "flow:" + str + " , flowName:" + str2);
            aV.this.c = str2;
            aV.this.b = str;
        }

        public final void processFeed(String str) {
            aV.this.a("JSFlowBridge , processFeed");
            C0282t.a().a("slider-feed", str);
            try {
                JSONObject jSONObject = new JSONObject(str);
                C0282t.a().a(jSONObject, new f(jSONObject), new String[0]);
            } catch (JSONException e) {
                aK.a(aS.b.REPORT_TYPE_ERROR).a(e).a();
            }
        }

        public final void reportFeedRequestError() {
        }

        public final void setMinTimeBetweenRefresh(int i) {
            long unused = aV.this.E = (long) i;
        }
    }

    private final class d extends a {
        protected int c;

        public d(String str, int i) {
            super(str);
            this.c = i;
        }

        /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
         method: com.ironsource.mobilcore.aV.a(com.ironsource.mobilcore.aV, java.lang.String, int, boolean):void
         arg types: [com.ironsource.mobilcore.aV, java.lang.String, int, int]
         candidates:
          com.ironsource.mobilcore.aV.a(java.lang.String, com.ironsource.mobilcore.MCEWidgetTextProperties, java.lang.String, boolean):void
          com.ironsource.mobilcore.l.a(android.app.Activity, org.json.JSONObject, java.lang.String, java.lang.String):void
          com.ironsource.mobilcore.aV.a(com.ironsource.mobilcore.aV, java.lang.String, int, boolean):void */
        @Override // com.ironsource.mobilcore.aV.a
        public final void a() {
            aV.this.a(this.a, this.c, false);
        }
    }

    private final class e extends a {
        private MCEWidgetTextProperties d;
        private String e;

        public e(String str, MCEWidgetTextProperties mCEWidgetTextProperties, String str2) {
            super(str);
            this.d = mCEWidgetTextProperties;
            this.e = str2;
        }

        /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
         method: com.ironsource.mobilcore.aV.a(com.ironsource.mobilcore.aV, java.lang.String, com.ironsource.mobilcore.MCEWidgetTextProperties, java.lang.String, boolean):void
         arg types: [com.ironsource.mobilcore.aV, java.lang.String, com.ironsource.mobilcore.MCEWidgetTextProperties, java.lang.String, int]
         candidates:
          com.ironsource.mobilcore.l.a(android.app.Activity, org.json.JSONObject, java.lang.String, java.lang.String, com.ironsource.mobilcore.l$c):void
          com.ironsource.mobilcore.aV.a(com.ironsource.mobilcore.aV, java.lang.String, com.ironsource.mobilcore.MCEWidgetTextProperties, java.lang.String, boolean):void */
        @Override // com.ironsource.mobilcore.aV.a
        public final void a() {
            aV.this.a(this.a, this.d, this.e, false);
        }
    }

    final class f extends aF.e {
        /* access modifiers changed from: private */
        public JSONObject b;

        public f(JSONObject jSONObject) {
            this.b = jSONObject;
        }

        @Override // com.ironsource.mobilcore.aF.d, com.ironsource.mobilcore.aF.e
        public final void a(boolean z) {
            if (z) {
                MobileCore.b().post(new Runnable() {
                    /* class com.ironsource.mobilcore.aV.f.AnonymousClass1 */

                    public final void run() {
                        Iterator it = aV.this.C.iterator();
                        while (it.hasNext()) {
                            ((C0282t.a) it.next()).a(f.this.b);
                        }
                    }
                });
            }
        }
    }

    private aV() {
    }

    private H a(ViewGroup viewGroup, String str) {
        if (!TextUtils.isEmpty(str) && this.k.containsKey(str)) {
            H h2 = (H) this.k.get(str);
            h2.a(this.g);
            if (h2 != null) {
                View i2 = h2.i();
                ViewParent parent = i2.getParent();
                if (parent != null && (parent instanceof ViewGroup)) {
                    ((ViewGroup) parent).removeView(i2);
                }
                viewGroup.addView(i2);
                return h2;
            }
        }
        return null;
    }

    /* access modifiers changed from: private */
    public String a(int i2) {
        String str = null;
        try {
            FileInputStream fileInputStream = new FileInputStream(this.d + "/sliderConfig.json");
            str = aF.a((InputStream) fileInputStream);
            fileInputStream.close();
        } catch (IOException e2) {
            B.a("Couldn't find sliderConfig.json. using fallback (should be the case on the first app run)", 55);
        }
        if (!TextUtils.isEmpty(str)) {
            return str;
        }
        if (-1 != i2) {
            try {
                str = aF.a(MobileCore.c().getResources().openRawResource(i2));
            } catch (Exception e3) {
                aK.a(aS.b.REPORT_TYPE_ERROR).a(e3).a();
            }
        }
        if (!TextUtils.isEmpty(str)) {
            return str;
        }
        try {
            InputStream resourceAsStream = MobileCore.class.getResourceAsStream("fallback/slider_fallback.json");
            str = aF.a(resourceAsStream);
            resourceAsStream.close();
            return str;
        } catch (Exception e4) {
            aK.a(aS.b.REPORT_TYPE_ERROR).a(e4).a();
            return str;
        }
    }

    private void a(LinearLayout linearLayout) {
        if (linearLayout != null) {
            linearLayout.removeAllViews();
            if (!this.i) {
                this.y = new ProgressBar(MobileCore.c());
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
                layoutParams.topMargin = 20;
                layoutParams.gravity = 1;
                this.y.setLayoutParams(layoutParams);
                linearLayout.addView(this.y);
                aK.a(aS.b.REPORT_TYPE_EVENT).a("slider", "slider_features", "progress_added").a();
            } else if (this.l != null) {
                C.a(this.v, this.l.d().m());
                if (this.x != null) {
                    if (this.l.a()) {
                        this.x.setVisibility(0);
                        this.x.setImageDrawable(this.l.d().k());
                    } else {
                        this.x.setVisibility(8);
                    }
                }
                JSONArray c2 = this.l.c();
                if (c2 != null) {
                    H h2 = null;
                    int i2 = 0;
                    while (i2 < c2.length()) {
                        JSONArray optJSONArray = c2.optJSONArray(i2);
                        if (optJSONArray != null) {
                            int length = optJSONArray.length();
                            if (length == 1) {
                                H a2 = a(linearLayout, optJSONArray.optString(0));
                                if (a2 != null) {
                                    a2.a(i2);
                                    if (!(a2 instanceof Y)) {
                                        h2 = a2;
                                    } else if (h2 != null) {
                                        h2.a((Y) a2);
                                    }
                                }
                            } else {
                                LinearLayout linearLayout2 = new LinearLayout(MobileCore.c());
                                linearLayout2.setOrientation(0);
                                for (int i3 = 0; i3 < length; i3++) {
                                    H a3 = a(linearLayout2, optJSONArray.optString(i3));
                                    if (a3 != null) {
                                        a3.a(i2);
                                        View i4 = a3.i();
                                        LinearLayout.LayoutParams layoutParams2 = (LinearLayout.LayoutParams) i4.getLayoutParams();
                                        layoutParams2.width = -1;
                                        layoutParams2.height = -1;
                                        layoutParams2.weight = 1.0f;
                                        i4.setLayoutParams(layoutParams2);
                                    }
                                }
                                linearLayout.addView(linearLayout2);
                            }
                        }
                        i2++;
                        h2 = h2;
                    }
                    if (!MobileCore.a(MobileCore.AD_UNITS.INTERSTITIAL)) {
                        for (H h3 : this.k.values()) {
                            if (h3.a() == "ironsourceOfferWallOpener") {
                                h3.a(false);
                            }
                        }
                    }
                }
            }
        }
    }

    static /* synthetic */ void a(aV aVVar, H.a aVar) {
        if (aF.d().getBoolean("sliderOpenedByUser", false)) {
            for (String str : aVVar.k.keySet()) {
                H h2 = (H) aVVar.k.get(str);
                if (h2 != null) {
                    h2.a(aVar);
                }
            }
        }
    }

    /* access modifiers changed from: private */
    public void a(String str, int i2, boolean z2) {
        H h2;
        if (z2) {
            this.o.add(new d(str, i2));
        }
        if (this.i && this.k.containsKey(str) && (h2 = (H) this.k.get(str)) != null && (h2 instanceof I)) {
            ((I) h2).b(i2);
        }
    }

    /* access modifiers changed from: private */
    public void a(String str, MCEWidgetTextProperties mCEWidgetTextProperties, String str2, boolean z2) {
        H h2;
        if (z2) {
            this.o.add(new e(str, mCEWidgetTextProperties, str2));
        }
        if (this.i && this.k.containsKey(str) && (h2 = (H) this.k.get(str)) != null && (h2 instanceof I)) {
            ((I) h2).a(mCEWidgetTextProperties, str2);
        }
    }

    /* access modifiers changed from: private */
    public void b(String str) {
        synchronized (this) {
            try {
                JSONObject jSONObject = new JSONObject(str).getJSONObject("slider");
                for (String str2 : this.k.keySet()) {
                    this.k.get(str2);
                }
                this.k.clear();
                this.l = new C0238aa(MobileCore.c(), jSONObject);
                JSONArray jSONArray = jSONObject.getJSONArray("widgets");
                for (int i2 = 0; i2 < jSONArray.length(); i2++) {
                    H a2 = this.j.a(jSONArray.getJSONObject(i2), this.l.d());
                    if (a2 != null) {
                        String h2 = a2.h();
                        if (h2 != "") {
                            if (!this.k.containsKey(h2)) {
                                this.k.put(h2, a2);
                            }
                        }
                    }
                }
                this.i = true;
                Iterator it = this.o.iterator();
                while (it.hasNext()) {
                    ((a) it.next()).a();
                }
                a(this.w);
                if (this.f4u != null) {
                    this.f4u.removeCallbacks(this.t);
                }
                this.s = -1;
                this.t = null;
                if (this.l.b() && !aF.d().getBoolean("sliderOpenedByUser", false)) {
                    q();
                }
            } catch (JSONException e2) {
                aK.a(aS.b.REPORT_TYPE_ERROR).a(e2).a();
                B.a("Error parsing slider configuration", 3);
            }
        }
        return;
    }

    public static aV j() {
        aV aVVar;
        synchronized (aV.class) {
            try {
                if (z == null) {
                    z = new aV();
                }
                aVVar = z;
            } catch (Throwable th) {
                throw th;
            }
        }
        return aVVar;
    }

    public static JSONObject k() {
        return C0282t.a().b("slider-feed");
    }

    /* access modifiers changed from: private */
    public boolean n() {
        return !TextUtils.isEmpty(this.h);
    }

    /* access modifiers changed from: private */
    public void o() {
        double d2 = 0.5d;
        if (this.g != null) {
            Display defaultDisplay = this.g.getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            int i2 = displayMetrics.widthPixels;
            switch (MobileCore.c().getResources().getConfiguration().orientation) {
                case 1:
                    d2 = 0.8d;
                    break;
            }
            this.B = (int) (d2 * ((double) i2));
            this.f4u.c(this.B);
        }
    }

    /* access modifiers changed from: private */
    public void p() {
        if (this.x != null) {
            this.x.postDelayed(new Runnable() {
                /* class com.ironsource.mobilcore.aV.AnonymousClass7 */

                public final void run() {
                    ViewParent parent = aV.this.x.getParent();
                    if (parent instanceof View) {
                        Display defaultDisplay = aV.this.g.getWindowManager().getDefaultDisplay();
                        DisplayMetrics displayMetrics = new DisplayMetrics();
                        defaultDisplay.getMetrics(displayMetrics);
                        aV.this.x.measure(0, 0);
                        int i = displayMetrics.heightPixels;
                        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
                        layoutParams.addRule(9);
                        int height = (((View) parent).getHeight() / 2) - (aV.this.x.getHeight() / 2);
                        layoutParams.topMargin = height;
                        if (height <= 0 || height > i) {
                            layoutParams.addRule(15);
                        }
                        aV.this.x.setLayoutParams(layoutParams);
                    }
                }
            }, 100);
        }
    }

    /* access modifiers changed from: private */
    public void q() {
        this.s++;
        B.a("SliderMenuManager , addFTUERunnable() | mFTUEIntervalArrIndex:" + this.s, 55);
        if (this.s < this.r.length) {
            this.t = new Runnable() {
                /* class com.ironsource.mobilcore.aV.AnonymousClass8 */

                public final void run() {
                    boolean z = false;
                    if (!aF.j(MobileCore.c()).getBoolean("sliderOpenedByUser", false)) {
                        z = true;
                    }
                    if (z) {
                        aV.this.f4u.d();
                        aV.this.q();
                    }
                }
            };
            this.f4u.postDelayed(this.t, (long) this.r[this.s]);
        }
    }

    /* access modifiers changed from: private */
    public static void r() {
        aF.d().edit().putBoolean("sliderOpenedByUser", true).commit();
    }

    public final void a(C0282t.a aVar) {
        synchronized (this) {
            a("registerOnUpdateListener");
            if (!this.C.contains(aVar)) {
                this.C.add(aVar);
            }
        }
    }

    /* access modifiers changed from: protected */
    @Override // com.ironsource.mobilcore.C0274l
    public final boolean a() {
        return !this.A;
    }

    /* access modifiers changed from: protected */
    @Override // com.ironsource.mobilcore.C0274l
    public final C0274l.a b() {
        return new C0274l.a(MobileCore.AD_UNITS.SLIDER, "slider", "SLIDER_assets", "slider-feed", b.INIT, new c());
    }

    @Override // com.ironsource.mobilcore.MCISliderAPI
    public final void closeSliderMenu(boolean z2) {
        if (this.f4u != null) {
            this.f4u.b(z2);
        }
    }

    @Override // com.ironsource.mobilcore.C0274l
    public final String d() {
        return this.c;
    }

    @Override // com.ironsource.mobilcore.C0274l
    public final String e() {
        return this.b;
    }

    /* access modifiers changed from: protected */
    @Override // com.ironsource.mobilcore.C0274l
    public final void f() {
        super.f();
        this.A = true;
        a("Slider", "initMembers");
        this.i = false;
        this.j = new aI(this.a);
        this.k = new HashMap();
        this.o = new ArrayList();
        this.m = false;
        this.D = 0;
        this.E = 0;
        l();
        this.C = new ArrayList();
    }

    @Override // com.ironsource.mobilcore.MCISliderAPI
    public final String getWidgetTextProperty(String str, MCEWidgetTextProperties mCEWidgetTextProperties) {
        String a2;
        H h2 = (H) this.k.get(str);
        return (h2 == null || !(h2 instanceof I) || (a2 = ((I) h2).a(mCEWidgetTextProperties)) == null) ? "" : a2;
    }

    @Override // com.ironsource.mobilcore.MCISliderAPI
    public final void hideWidget(String str) {
        H h2;
        if (this.k.containsKey(str) && (h2 = (H) this.k.get(str)) != null) {
            h2.a(false);
        }
    }

    @Override // com.ironsource.mobilcore.C0274l
    public final void i() {
        if (System.currentTimeMillis() - this.D >= this.E) {
            this.D = System.currentTimeMillis();
            super.i();
        }
    }

    @Override // com.ironsource.mobilcore.MCISliderAPI
    public final boolean isSliderMenuOpen() {
        if (this.f4u != null) {
            return this.f4u.c();
        }
        return false;
    }

    @SuppressLint({"NewApi"})
    public final void l() {
        aF.a(new C0283u(new C0283u.a() {
            /* class com.ironsource.mobilcore.aV.AnonymousClass4 */

            @Override // com.ironsource.mobilcore.C0283u.a
            public final void a(String str) {
                boolean z = aV.this.w != null;
                String unused = aV.this.h = str;
                if (z) {
                    aV.this.b(str);
                }
            }
        }, this.d, "sliderConfig.json"), (Object[]) null);
    }

    public final int m() {
        return this.B;
    }

    @Override // com.ironsource.mobilcore.MCISliderAPI
    public final void openSliderMenu(boolean z2) {
        if (this.f4u != null) {
            this.f4u.a(z2);
            r();
        }
    }

    @Override // com.ironsource.mobilcore.MCISliderAPI
    public final void setContentViewWithSlider(Activity activity, int i2) {
        setContentViewWithSlider(activity, i2, -1);
    }

    @Override // com.ironsource.mobilcore.MCISliderAPI
    public final void setContentViewWithSlider(Activity activity, int i2, int i3) {
        this.g = activity;
        this.v = new W(this.g);
        this.v.setVerticalScrollBarEnabled(false);
        this.v.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
        this.w = new T(this.g, new T.a() {
            /* class com.ironsource.mobilcore.aV.AnonymousClass1 */

            @Override // com.ironsource.mobilcore.T.a
            public final boolean a() {
                if (!aV.this.isSliderMenuOpen()) {
                    return false;
                }
                aV.this.closeSliderMenu(true);
                return true;
            }
        });
        this.w.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        this.w.setOrientation(1);
        this.w.setFocusableInTouchMode(true);
        this.v.addView(this.w);
        this.f4u = C0247aj.a(this.g, 1);
        View inflate = activity.getLayoutInflater().inflate(i2, (ViewGroup) null);
        inflate.setLayoutParams(new RelativeLayout.LayoutParams(-1, -1));
        if (inflate.getBackground() == null) {
            b("getMainActivityView", "No background set. setting default default");
            inflate.setBackgroundColor(-1);
        }
        this.x = new ImageView(activity);
        this.x.setContentDescription("slider-handle");
        RelativeLayout relativeLayout = new RelativeLayout(activity);
        relativeLayout.addView(inflate);
        relativeLayout.addView(this.x);
        this.x.setOnClickListener(new View.OnClickListener() {
            /* class com.ironsource.mobilcore.aV.AnonymousClass6 */

            public final void onClick(View view) {
                aV.this.toggleSliderMenu(true);
            }
        });
        this.f4u.b(relativeLayout);
        this.f4u.a(this.v);
        o();
        p();
        if (this.p == null) {
            this.p = new OrientationEventListener(MobileCore.c(), 3) {
                /* class com.ironsource.mobilcore.aV.AnonymousClass2 */

                public final void onOrientationChanged(int i) {
                    int i2 = MobileCore.c().getResources().getConfiguration().orientation;
                    if (i2 != aV.this.q) {
                        Context c = MobileCore.c();
                        boolean z = false;
                        String packageName = c.getPackageName();
                        for (ActivityManager.RunningAppProcessInfo runningAppProcessInfo : ((ActivityManager) c.getSystemService("activity")).getRunningAppProcesses()) {
                            z = (runningAppProcessInfo.importance != 100 || !runningAppProcessInfo.processName.equals(packageName)) ? z : true;
                        }
                        if (z) {
                            int unused = aV.this.q = i2;
                            aV.this.o();
                            aV.this.p();
                        }
                    }
                }
            };
        }
        this.p.enable();
        final int i4 = this.g.getWindow().getAttributes().softInputMode;
        this.f4u.a(new C0247aj.a() {
            /* class com.ironsource.mobilcore.aV.AnonymousClass3 */

            /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
             method: com.ironsource.mobilcore.aV.a(com.ironsource.mobilcore.aV, boolean):boolean
             arg types: [com.ironsource.mobilcore.aV, int]
             candidates:
              com.ironsource.mobilcore.aV.a(com.ironsource.mobilcore.aV, int):int
              com.ironsource.mobilcore.aV.a(com.ironsource.mobilcore.aV, long):long
              com.ironsource.mobilcore.aV.a(android.view.ViewGroup, java.lang.String):com.ironsource.mobilcore.H
              com.ironsource.mobilcore.aV.a(com.ironsource.mobilcore.aV, java.lang.String):java.lang.String
              com.ironsource.mobilcore.aV.a(com.ironsource.mobilcore.aV, com.ironsource.mobilcore.H$a):void
              com.ironsource.mobilcore.l.a(com.ironsource.mobilcore.l$d, java.lang.String):void
              com.ironsource.mobilcore.l.a(java.lang.String, java.lang.String):void
              com.ironsource.mobilcore.aV.a(com.ironsource.mobilcore.aV, boolean):boolean */
            @Override // com.ironsource.mobilcore.C0247aj.a
            public final void a(int i) {
                int i2;
                H h;
                if (i == 4 || i == 2) {
                    aV.a(aV.this, H.a.SHOWING);
                    aV.r();
                } else if (i == 0 || i == 8) {
                    ((InputMethodManager) MobileCore.c().getSystemService("input_method")).hideSoftInputFromWindow(aV.this.v.getWindowToken(), 0);
                    if (!aV.this.m && !TextUtils.isEmpty(aV.this.n) && aV.this.k.containsKey(aV.this.n) && (h = (H) aV.this.k.get(aV.this.n)) != null && (h instanceof I)) {
                        ((I) h).n();
                        boolean unused = aV.this.m = true;
                    }
                    if (i == 8) {
                        B.a("onDrawerStateChange | Clearing download in progress flags when slider opens", 55);
                        aV.a(aV.this, H.a.VISIBLE);
                        if (aF.d().getBoolean("sliderOpenedByUser", false)) {
                            aK.a(aS.b.REPORT_TYPE_EVENT).a("slider", "slider_features", "opened").a();
                        }
                        i2 = 32;
                    } else if (i == 0) {
                        aV.a(aV.this, H.a.HIDDEN);
                        if (aF.d().getBoolean("sliderOpenedByUser", false)) {
                            aK.a(aS.b.REPORT_TYPE_EVENT).a("slider", "slider_features", "closed").a();
                        }
                        i2 = i4;
                    } else {
                        i2 = -1;
                    }
                    if (aV.this.g != null && i2 != -1) {
                        aV.this.g.getWindow().setSoftInputMode(i2);
                    }
                }
            }
        });
        if (n()) {
            b(this.h);
            return;
        }
        aF.a(new AsyncTask() {
            /* class com.ironsource.mobilcore.aV.AnonymousClass5 */

            /* access modifiers changed from: protected */
            @Override // android.os.AsyncTask
            public final /* synthetic */ Object doInBackground(Object[] objArr) {
                return aV.this.a(((Integer[]) objArr)[0].intValue());
            }

            /* access modifiers changed from: protected */
            @Override // android.os.AsyncTask
            public final /* synthetic */ void onPostExecute(Object obj) {
                String str = (String) obj;
                super.onPostExecute(str);
                if (!TextUtils.isEmpty(str) && !aV.this.n()) {
                    aV.this.b(str);
                }
            }
        }, Integer.valueOf(i3));
    }

    @Override // com.ironsource.mobilcore.MCISliderAPI
    public final void setEmphasizedWidget(String str) {
        this.n = str;
    }

    @Override // com.ironsource.mobilcore.MCISliderAPI
    public final void setWidgetIconResource(String str, int i2) {
        a(str, i2, true);
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: com.ironsource.mobilcore.aV.a(java.lang.String, com.ironsource.mobilcore.MCEWidgetTextProperties, java.lang.String, boolean):void
     arg types: [java.lang.String, com.ironsource.mobilcore.MCEWidgetTextProperties, java.lang.String, int]
     candidates:
      com.ironsource.mobilcore.aV.a(com.ironsource.mobilcore.aV, java.lang.String, int, boolean):void
      com.ironsource.mobilcore.l.a(android.app.Activity, org.json.JSONObject, java.lang.String, java.lang.String):void
      com.ironsource.mobilcore.aV.a(java.lang.String, com.ironsource.mobilcore.MCEWidgetTextProperties, java.lang.String, boolean):void */
    @Override // com.ironsource.mobilcore.MCISliderAPI
    public final void setWidgetTextProperty(String str, MCEWidgetTextProperties mCEWidgetTextProperties, String str2) {
        a(str, mCEWidgetTextProperties, str2, true);
    }

    @Override // com.ironsource.mobilcore.MCISliderAPI
    public final void showWidget(String str) {
        H h2;
        if (this.k.containsKey(str) && (h2 = (H) this.k.get(str)) != null) {
            h2.a(true);
        }
    }

    @Override // com.ironsource.mobilcore.MCISliderAPI
    public final void toggleSliderMenu(boolean z2) {
        if (this.f4u != null) {
            this.f4u.c(z2);
            r();
        }
    }
}
