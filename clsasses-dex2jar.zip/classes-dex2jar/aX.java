package com.ironsource.mobilcore;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LightingColorFilter;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.util.TypedValue;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.OvershootInterpolator;
import android.view.animation.ScaleAnimation;
import android.view.animation.Transformation;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import com.ironsource.mobilcore.MobileCore;
import com.ironsource.mobilcore.aQ;
import com.ironsource.mobilcore.ba;
import com.ironsource.mobilcore.bc;
import java.util.HashMap;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

final class aX extends RelativeLayout {
    private MobileCore.EStickeezPosition A;
    private boolean B;
    Animation.AnimationListener a = new Animation.AnimationListener() {
        /* class com.ironsource.mobilcore.aX.AnonymousClass1 */

        public final void onAnimationEnd(Animation animation) {
            aX.a(aX.this, ba.this.q);
        }

        public final void onAnimationRepeat(Animation animation) {
        }

        public final void onAnimationStart(Animation animation) {
        }
    };
    private b b;
    private bc.b c;
    private int d;
    private AlphaAnimation e;
    private Animation f;
    /* access modifiers changed from: private */
    public int g;
    private Drawable h;
    private Drawable i;
    private Drawable j;
    /* access modifiers changed from: private */
    public ImageView k;
    private ImageView l;
    /* access modifiers changed from: private */
    public LightingColorFilter m;
    /* access modifiers changed from: private */
    public LinearLayout n;
    /* access modifiers changed from: private */
    public aQ o;
    private LinearLayout p;
    /* access modifiers changed from: private */
    public LinearLayout q;
    private RelativeLayout r;
    private Handler s;
    private Runnable t;

    /* renamed from: u  reason: collision with root package name */
    private boolean f5u;
    /* access modifiers changed from: private */
    public ba.f v;
    private JSONArray w;
    private HashMap x;
    private ScaleAnimation y;
    private int z;

    public interface a {
        void a();
    }

    public interface b {
        void a();

        void a(JSONObject jSONObject);

        void b();

        void b(JSONObject jSONObject);
    }

    @SuppressLint({"UseSparseArrays"})
    public aX(Activity activity, b bVar, ba.f fVar) {
        super(activity);
        this.b = bVar;
        this.c = bc.b.SIMPLE_BANNER;
        this.x = new HashMap();
        this.d = aF.e(activity);
        this.v = fVar;
        this.f5u = false;
        this.m = new LightingColorFilter(-1, 4473924);
        this.y = new ScaleAnimation(0.0f, 1.0f, 0.0f, 1.0f, 1, 0.0f, 1, 0.7f);
        this.y.setDuration(500);
        this.y.setInterpolator(new OvershootInterpolator());
        this.y.setFillAfter(true);
        this.y.setAnimationListener(this.a);
        this.g = (int) TypedValue.applyDimension(1, 70.0f, getResources().getDisplayMetrics());
        this.f = new Animation() {
            /* class com.ironsource.mobilcore.aX.AnonymousClass4 */

            /* access modifiers changed from: protected */
            public final void applyTransformation(float f, Transformation transformation) {
                LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) aX.this.o.getLayoutParams();
                if (ba.this.r()) {
                    layoutParams.leftMargin = -((int) (((float) aX.this.g) * (1.0f - f)));
                    layoutParams.rightMargin = (int) (((float) aX.this.g) * (1.0f - f));
                } else {
                    layoutParams.leftMargin = (int) (((float) aX.this.g) * (1.0f - f));
                }
                aX.this.o.setLayoutParams(layoutParams);
            }
        };
        this.f.setFillAfter(true);
        this.f.setDuration(500);
        this.f.setAnimationListener(new Animation.AnimationListener() {
            /* class com.ironsource.mobilcore.aX.AnonymousClass5 */

            public final void onAnimationEnd(Animation animation) {
                C.a(ba.this.y);
                aX.this.c();
            }

            public final void onAnimationRepeat(Animation animation) {
            }

            public final void onAnimationStart(Animation animation) {
            }
        });
        this.e = new AlphaAnimation(1.0f, 0.0f);
        this.e.setDuration(500);
        this.e.setFillAfter(true);
        this.B = ba.this.M != null;
        this.A = ba.this.T;
        this.z = this.v.a();
        B.a("StickeezContainer | setupLayout | mIsAnchorViewProvided=" + this.B, 55);
        B.a("StickeezContainer | setupLayout | mStickeezPosition=" + this.A, 55);
        B.a("StickeezContainer | setupLayout | mTopMargin=" + this.z, 55);
        setLayoutParams(new RelativeLayout.LayoutParams(-1, -1));
        this.k = new ImageView(activity);
        this.k.setContentDescription("stickeez-handle");
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
        if (ba.this.r()) {
            layoutParams.addRule(11, -1);
        }
        this.k.setLayoutParams(layoutParams);
        C.a(this.k, ba.this.x);
        this.r = new RelativeLayout(activity);
        this.r.setContentDescription("stickeez-handle-clickable-area");
        RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(-2, -2);
        this.r.setId(10);
        if (ba.this.r()) {
            layoutParams2.addRule(11, -1);
        }
        this.r.setLayoutParams(layoutParams2);
        this.r.setOnClickListener(new View.OnClickListener() {
            /* class com.ironsource.mobilcore.aX.AnonymousClass7 */

            public final void onClick(View view) {
                aX.this.g();
            }
        });
        RelativeLayout relativeLayout = new RelativeLayout(activity);
        RelativeLayout.LayoutParams layoutParams3 = new RelativeLayout.LayoutParams(-2, -2);
        a(layoutParams3);
        relativeLayout.setLayoutParams(layoutParams3);
        relativeLayout.addView(this.k);
        if (ba.this.p()) {
            this.l = new ImageView(activity);
            this.l.setContentDescription("stickeez-x");
            this.l.setClickable(true);
            RelativeLayout.LayoutParams layoutParams4 = new RelativeLayout.LayoutParams(-2, -2);
            layoutParams4.addRule(11, this.r.getId());
            layoutParams4.addRule(10, this.r.getId());
            this.l.setLayoutParams(layoutParams4);
            this.l.setOnClickListener(new View.OnClickListener() {
                /* class com.ironsource.mobilcore.aX.AnonymousClass8 */

                public final void onClick(View view) {
                    B.a(getClass().getName() + "| 'X' clicked", 55);
                    ba.j().n();
                }
            });
            C.a(this.l, this.j);
            this.r.addView(this.l);
        } else {
            B.a("StickeezContainer | setupLayout | mXDrawable == null, can't add 'X' button to a stickee", 55);
        }
        relativeLayout.addView(this.r);
        this.o = new aQ(activity, null, this.d);
        this.o.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        this.o.setHorizontalScrollBarEnabled(false);
        this.o.a(new aQ.a() {
            /* class com.ironsource.mobilcore.aX.AnonymousClass9 */

            @Override // com.ironsource.mobilcore.aQ.a
            public final void a(int i) {
                aX.this.a(i);
                int i2 = 0;
                while (true) {
                    int i3 = i2;
                    if (i3 < aX.this.q.getChildCount()) {
                        ImageView imageView = (ImageView) aX.this.q.getChildAt(i3);
                        if (i3 == i) {
                            imageView.clearColorFilter();
                        } else {
                            imageView.setColorFilter(aX.this.m);
                        }
                        i2 = i3 + 1;
                    } else {
                        return;
                    }
                }
            }
        });
        this.n = new LinearLayout(activity);
        this.n.setVisibility(8);
        this.n.setOrientation(1);
        RelativeLayout.LayoutParams layoutParams5 = new RelativeLayout.LayoutParams(-1, -2);
        a(layoutParams5);
        this.n.setLayoutParams(layoutParams5);
        this.q = new LinearLayout(activity);
        this.q.setOrientation(0);
        this.q.setGravity(17);
        int applyDimension = (int) TypedValue.applyDimension(1, 5.0f, getResources().getDisplayMetrics());
        this.q.setPadding(0, applyDimension, 0, applyDimension);
        RelativeLayout.LayoutParams layoutParams6 = new RelativeLayout.LayoutParams(-1, -2);
        layoutParams6.addRule(2, this.o.getId());
        layoutParams6.addRule(14, -1);
        layoutParams6.addRule(12, -1);
        this.q.setLayoutParams(layoutParams6);
        this.n.addView(this.o);
        this.n.addView(this.q);
        addView(this.n);
        addView(relativeLayout);
        this.p = new LinearLayout(activity);
        this.p.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        this.o.addView(this.p);
    }

    /* access modifiers changed from: private */
    public void a(int i2) {
        if (!this.x.containsKey(Integer.valueOf(i2)) || !((Boolean) this.x.get(Integer.valueOf(i2))).booleanValue()) {
            try {
                this.b.b(this.w.getJSONObject(i2));
                this.x.put(Integer.valueOf(i2), true);
            } catch (JSONException e2) {
                e2.printStackTrace();
            }
        }
    }

    private void a(RelativeLayout.LayoutParams layoutParams) {
        B.a("StickeezContainer | setupLayoutParams", 55);
        if (!this.B) {
            switch (this.A) {
                case BOTTOM_LEFT:
                    layoutParams.addRule(12, -1);
                    return;
                case BOTTOM_RIGHT:
                    layoutParams.addRule(12, -1);
                    layoutParams.addRule(11, -1);
                    return;
                case TOP_LEFT:
                    layoutParams.setMargins(0, this.v.b(), 0, 0);
                    layoutParams.addRule(10, -1);
                    return;
                case TOP_RIGHT:
                    layoutParams.setMargins(0, this.v.b(), 0, 0);
                    layoutParams.addRule(10, -1);
                    layoutParams.addRule(11, -1);
                    return;
                case MIDDLE_LEFT:
                    layoutParams.addRule(15, -1);
                    layoutParams.addRule(9, -1);
                    return;
                case MIDDLE_RIGHT:
                    layoutParams.addRule(15, -1);
                    layoutParams.addRule(11, -1);
                    return;
                default:
                    return;
            }
        } else if (this.z != -1) {
            layoutParams.setMargins(0, this.z, 0, 0);
        } else {
            layoutParams.addRule(12, -1);
        }
    }

    static /* synthetic */ void a(aX aXVar, boolean z2) {
        B.a(aXVar.getClass().getName() + "| mAdsInAnimationListener onAnimationEnd", 55);
        aXVar.a(0);
        aXVar.o.clearAnimation();
        if (!z2) {
            C.a(aXVar.k, ba.this.y);
            aXVar.f.setStartOffset((long) C0271i.a(ba.this.y));
            C.a(ba.this.w);
            ImageView imageView = aXVar.k;
            C.b(ba.this.y);
        }
        aXVar.o.setAnimation(aXVar.f);
        aXVar.f.start();
    }

    private void a(Runnable runnable, long j2) {
        if (this.s == null) {
            this.s = new Handler();
        }
        if (this.t != null) {
            this.s.removeCallbacks(this.t);
        }
        this.t = runnable;
        this.s.postDelayed(runnable, j2);
    }

    /* access modifiers changed from: private */
    public void b(a aVar) {
        if (this.n.getVisibility() == 8 && this.k.getVisibility() == 8) {
            aVar.a();
        }
    }

    private void e() {
        C.a(this.k, ba.this.y);
        ImageView imageView = this.k;
        C.b(ba.this.y);
        a(new Runnable() {
            /* class com.ironsource.mobilcore.aX.AnonymousClass6 */

            public final void run() {
                C.a(ba.this.y);
                aX.this.c();
                aX.this.b(new a() {
                    /* class com.ironsource.mobilcore.aX.AnonymousClass6.AnonymousClass1 */

                    @Override // com.ironsource.mobilcore.aX.a
                    public final void a() {
                        aX.this.f();
                    }
                });
            }
        }, (long) C0271i.a(ba.this.y));
    }

    /* access modifiers changed from: private */
    public void f() {
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) this.o.getLayoutParams();
        if (ba.this.r()) {
            layoutParams.setMargins(-this.g, 0, this.g, 0);
        } else {
            layoutParams.setMargins(this.g, 0, 0, 0);
        }
        this.o.setLayoutParams(layoutParams);
        this.n.setVisibility(0);
        this.o.startAnimation(this.y);
        this.b.a();
    }

    /* access modifiers changed from: private */
    public void g() {
        B.a(getClass().getName() + "| doTriggerHandle", 55);
        if (!this.v.c()) {
            if (this.n.getVisibility() == 8) {
                if (this.l != null) {
                    this.l.setVisibility(8);
                }
                if (ba.this.q) {
                    e();
                } else {
                    f();
                }
            }
        }
    }

    public final void a() {
        if (this.k != null) {
            C.a(this.k, (Drawable) null);
        }
    }

    public final void a(Drawable drawable) {
        B.a(getClass().getName() + "| setXDrawable", 55);
        this.j = drawable;
        C.a(this.l, this.j);
    }

    public final void a(Drawable drawable, Drawable drawable2) {
        B.a(getClass().getName() + "| setHandleDrawables", 55);
        C.a(this.k, ba.this.x);
        this.k.measure(0, 0);
        this.r.getLayoutParams().width = this.k.getMeasuredHeight();
        this.r.getLayoutParams().height = this.k.getMeasuredHeight();
        this.h = drawable;
        this.i = drawable2;
    }

    public final void a(final a aVar) {
        B.a(getClass().getName() + "| dismissHandle", 55);
        this.f5u = true;
        if (this.k.getVisibility() == 0) {
            if (this.l != null && this.l.getVisibility() == 0) {
                this.l.setVisibility(8);
            }
            C.a(ba.this.x);
            C.a(ba.this.w);
            C.a(this.k, ba.this.y);
            ImageView imageView = this.k;
            C.b(ba.this.y);
            a(new Runnable() {
                /* class com.ironsource.mobilcore.aX.AnonymousClass11 */

                public final void run() {
                    C.a(ba.this.y);
                    aX.this.c();
                    aX.this.b(aVar);
                }
            }, (long) (C0271i.a(ba.this.y) + 100));
        } else {
            b(aVar);
        }
        if (this.n.getVisibility() != 8) {
            this.e.setAnimationListener(new Animation.AnimationListener() {
                /* class com.ironsource.mobilcore.aX.AnonymousClass2 */

                public final void onAnimationEnd(Animation animation) {
                    aX.this.n.clearAnimation();
                    aX.this.n.setVisibility(8);
                    aX.this.b(aVar);
                }

                public final void onAnimationRepeat(Animation animation) {
                }

                public final void onAnimationStart(Animation animation) {
                }
            });
            this.n.startAnimation(this.e);
        }
    }

    public final void a(JSONArray jSONArray) {
        bg bgVar;
        this.x.clear();
        this.w = jSONArray;
        this.p.removeAllViews();
        this.q.removeAllViews();
        int applyDimension = (int) TypedValue.applyDimension(1, 10.0f, getResources().getDisplayMetrics());
        for (int i2 = 0; i2 < this.w.length(); i2++) {
            JSONObject optJSONObject = this.w.optJSONObject(i2);
            try {
                optJSONObject.put("index", i2);
                bc.a aVar = new bc.a(bc.b.SIMPLE_BANNER, this.h, this.i, optJSONObject);
                LinearLayout linearLayout = this.p;
                Activity activity = (Activity) getContext();
                b bVar = this.b;
                switch (bc.AnonymousClass1.a[aVar.a().ordinal()]) {
                    case 1:
                        bgVar = new bg(activity, aVar, bVar);
                        break;
                    default:
                        bgVar = null;
                        break;
                }
                linearLayout.addView(bgVar);
                LinearLayout linearLayout2 = this.q;
                ImageView imageView = new ImageView(getContext());
                Bitmap createBitmap = Bitmap.createBitmap(applyDimension, applyDimension, Bitmap.Config.ARGB_8888);
                Canvas canvas = new Canvas(createBitmap);
                Paint paint = new Paint();
                paint.setAntiAlias(true);
                paint.setColor(-1);
                canvas.drawCircle((float) (applyDimension / 2), (float) (applyDimension / 2), (float) (applyDimension / 2), paint);
                paint.setColor(-7829368);
                canvas.drawCircle((float) (applyDimension / 2), (float) (applyDimension / 2), (float) ((applyDimension / 2) - ((int) TypedValue.applyDimension(1, 1.0f, getResources().getDisplayMetrics()))), paint);
                imageView.setAdjustViewBounds(true);
                imageView.setImageBitmap(createBitmap);
                imageView.setPadding((int) TypedValue.applyDimension(1, 2.0f, getResources().getDisplayMetrics()), 0, 0, 0);
                linearLayout2.addView(imageView);
            } catch (JSONException e2) {
                e2.printStackTrace();
            }
        }
        this.o.a(0);
        ((ImageView) this.q.getChildAt(0)).clearColorFilter();
        for (int i3 = 1; i3 < this.q.getChildCount(); i3++) {
            ((ImageView) this.q.getChildAt(i3)).setColorFilter(this.m);
        }
    }

    public final void b() {
        B.a(getClass().getName() + "| showHandle", 55);
        C.a(this.k, ba.this.x);
        this.k.setVisibility(0);
        if (this.l != null) {
            this.l.setVisibility(0);
        }
        ImageView imageView = this.k;
        C.b(ba.this.x);
        a(new Runnable() {
            /* class com.ironsource.mobilcore.aX.AnonymousClass10 */

            public final void run() {
                C.a(aX.this.k, ba.this.w);
                C.a(ba.this.x);
                ImageView unused = aX.this.k;
                C.b(ba.this.w);
            }
        }, (long) C0271i.a(ba.this.x));
    }

    public final void c() {
        B.a(getClass().getName() + "| hideHandle", 55);
        if (this.k.getVisibility() == 0) {
            this.k.setVisibility(8);
            this.r.setVisibility(8);
        }
    }

    public final void d() {
        B.a(getClass().getName() + "| triggerHandle", 55);
        g();
    }

    /* access modifiers changed from: protected */
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        B.a(getClass().getName() + "| onAttachedToWindow", 55);
        b bVar = this.b;
    }

    /* access modifiers changed from: protected */
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (!this.f5u) {
            B.a(getClass().getName() + "| onDetachedFromWindow", 55);
            b bVar = this.b;
            this.n.setVisibility(8);
        }
    }
}
