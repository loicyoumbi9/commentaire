package com.ironsource.mobilcore;

import android.content.Context;
import android.view.View;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.MessageFormat;
import org.json.JSONObject;

final class aB extends G {
    private String a;

    public aB(Context context, C0261ax axVar) {
        super(context, axVar);
    }

    @Override // com.ironsource.mobilcore.H, com.ironsource.mobilcore.G
    public final String a() {
        return "ironsourceSocialWidgetTwitter";
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: com.ironsource.mobilcore.aF.a(android.app.Activity, java.lang.String, boolean):void
     arg types: [android.app.Activity, java.lang.String, int]
     candidates:
      com.ironsource.mobilcore.aF.a(java.io.InputStream, java.lang.String, java.lang.String):java.io.File
      com.ironsource.mobilcore.aF.a(android.content.Context, java.lang.String, java.lang.String):java.lang.String
      com.ironsource.mobilcore.aF.a(android.app.Activity, java.lang.String, boolean):void */
    /* access modifiers changed from: protected */
    @Override // com.ironsource.mobilcore.H, com.ironsource.mobilcore.I
    public final void a(View view) {
        try {
            aF.a(this.e, MessageFormat.format("https://twitter.com/intent/tweet?text={0}&url={1}", URLEncoder.encode(this.a, "UTF-8"), URLEncoder.encode(aF.g(this.c), "UTF-8")), true);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        super.a(view);
    }

    @Override // com.ironsource.mobilcore.H, com.ironsource.mobilcore.G
    public final void a(JSONObject jSONObject) {
        this.a = jSONObject.optString("tweetText", "");
        super.a(jSONObject);
    }
}
