package u.aly;

import java.io.ByteArrayOutputStream;

public class cj extends ByteArrayOutputStream {
    public cj() {
    }

    public cj(int i) {
        super(i);
    }

    public byte[] a() {
        return this.buf;
    }

    public int b() {
        return this.count;
    }
}
