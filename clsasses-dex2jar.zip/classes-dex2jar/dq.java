package u.aly;

import u.aly.ch;

public abstract class dq<T extends ch> implements Cdo<T> {
}
