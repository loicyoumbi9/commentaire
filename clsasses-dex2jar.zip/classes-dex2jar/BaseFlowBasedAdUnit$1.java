package com.ironsource.mobilcore;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.ironsource.mobilcore.aS;

class BaseFlowBasedAdUnit$1 extends BroadcastReceiver {
    final /* synthetic */ C0274l a;

    BaseFlowBasedAdUnit$1(C0274l lVar) {
        this.a = lVar;
    }

    public void onReceive(Context context, Intent intent) {
        try {
            boolean b = aP.b(this.a.a);
            this.a.b("onReceive", "mobileCore connectivity, hasInternetConnection:" + b);
            if (b) {
                this.a.a.unregisterReceiver(this.a.i);
                this.a.h();
            }
        } catch (Exception e) {
            aK.a(aS.b.REPORT_TYPE_ERROR).a(e).a();
        }
    }
}
