package u.aly;

public interface p {
    void a();

    void a(q qVar);

    void b();

    void b(q qVar);

    void c();
}
