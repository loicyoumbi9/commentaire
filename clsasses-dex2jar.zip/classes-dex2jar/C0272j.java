package com.ironsource.mobilcore;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.widget.Toast;
import com.google.android.gms.drive.DriveFile;
import com.ironsource.mobilcore.aS;
import com.umeng.update.UpdateConfig;
import java.io.File;
import org.json.JSONObject;

/* renamed from: com.ironsource.mobilcore.j  reason: case insensitive filesystem */
final class C0272j {
    private static NotificationManager a;

    /* renamed from: com.ironsource.mobilcore.j$a */
    private static final class a {
        Context a;
        private String b;
        private String c;
        private String d = (this.b + File.separator + this.c);
        private String e;
        private String f;
        private String g;
        private String h;
        private String i;
        private String j;
        private Bitmap k;
        private boolean l;

        a(Context context, Intent intent, String str, boolean z) {
            this.a = context;
            this.b = str;
            this.c = intent.getStringExtra("com.ironsource.mobilcore.extra_download_filename");
            this.e = intent.getStringExtra("com.ironsource.mobilcore.extra_download_appname");
            this.f = intent.getStringExtra("com.ironsource.mobilcore.extra_download_url");
            this.g = intent.getStringExtra("com.ironsource.mobilcore.MobileCoreReport_extra_flow_type");
            this.h = intent.getStringExtra("com.ironsource.mobilecore.MobileCoreReport_extra_flow");
            this.i = intent.getStringExtra("com.ironsource.mobilcore.MobileCoreReport_extra_offer");
            this.l = z;
            this.j = intent.getStringExtra("com.ironsource.mobilcore.extra_download_app_img_name");
        }

        private String a() {
            return aF.a(this.a, this.b, aF.d(this.f));
        }

        /* JADX WARNING: Removed duplicated region for block: B:54:0x0174 A[Catch:{ all -> 0x01b8 }] */
        /* JADX WARNING: Removed duplicated region for block: B:57:0x017c A[SYNTHETIC, Splitter:B:57:0x017c] */
        /* JADX WARNING: Removed duplicated region for block: B:60:0x0184 A[Catch:{ IOException -> 0x0189 }] */
        /* JADX WARNING: Removed duplicated region for block: B:67:0x0196 A[SYNTHETIC, Splitter:B:67:0x0196] */
        /* JADX WARNING: Removed duplicated region for block: B:70:0x019e A[Catch:{ IOException -> 0x01a2 }] */
        /* JADX WARNING: Removed duplicated region for block: B:90:? A[RETURN, SYNTHETIC] */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        static /* synthetic */ void a(com.ironsource.mobilcore.C0272j.a r14) {
            /*
                java.io.File r0 = new java.io.File
                java.lang.String r1 = r14.b
                r0.<init>(r1)
                java.io.File r9 = new java.io.File
                java.lang.String r1 = r14.d
                r9.<init>(r1)
                android.content.Context r1 = r14.a
                java.lang.String r2 = r14.e
                com.ironsource.mobilcore.j$b r1 = com.ironsource.mobilcore.C0272j.a(r1, r2)
                java.lang.StringBuilder r2 = new java.lang.StringBuilder
                java.lang.String r3 = "downloadFile - "
                r2.<init>(r3)
                java.lang.String r3 = r14.e
                java.lang.StringBuilder r2 = r2.append(r3)
                java.lang.String r3 = " - "
                java.lang.StringBuilder r2 = r2.append(r3)
                java.lang.StringBuilder r2 = r2.append(r1)
                java.lang.String r2 = r2.toString()
                r3 = 55
                com.ironsource.mobilcore.B.a(r2, r3)
                com.ironsource.mobilcore.j$b r2 = com.ironsource.mobilcore.C0272j.b.DOWNLOAD_COMPLETED
                if (r1 != r2) goto L_0x0079
                boolean r2 = r9.exists()
                if (r2 == 0) goto L_0x0079
                long r2 = r9.length()
                r4 = 0
                int r2 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1))
                if (r2 <= 0) goto L_0x0079
                long r2 = r9.lastModified()
                r4 = 30000(0x7530, double:1.4822E-319)
                long r2 = r2 + r4
                long r4 = java.lang.System.currentTimeMillis()
                int r2 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1))
                if (r2 <= 0) goto L_0x0079
                java.lang.StringBuilder r0 = new java.lang.StringBuilder
                java.lang.String r1 = "downloadFile - "
                r0.<init>(r1)
                java.lang.String r1 = r14.e
                java.lang.StringBuilder r0 = r0.append(r1)
                java.lang.String r1 = " - skipping download"
                java.lang.StringBuilder r0 = r0.append(r1)
                java.lang.String r0 = r0.toString()
                r1 = 55
                com.ironsource.mobilcore.B.a(r0, r1)
                r14.b()
            L_0x0078:
                return
            L_0x0079:
                com.ironsource.mobilcore.j$b r2 = com.ironsource.mobilcore.C0272j.b.DOWNLOAD_STARTED
                if (r1 != r2) goto L_0x009a
                java.lang.StringBuilder r0 = new java.lang.StringBuilder
                java.lang.String r1 = "downloadFile - "
                r0.<init>(r1)
                java.lang.String r1 = r14.e
                java.lang.StringBuilder r0 = r0.append(r1)
                java.lang.String r1 = " - already started"
                java.lang.StringBuilder r0 = r0.append(r1)
                java.lang.String r0 = r0.toString()
                r1 = 55
                com.ironsource.mobilcore.B.a(r0, r1)
                goto L_0x0078
            L_0x009a:
                java.lang.String r1 = r14.j
                android.graphics.Bitmap r1 = com.ironsource.mobilcore.aF.b(r1)
                r14.k = r1
                android.content.Context r1 = r14.a
                java.lang.String r2 = r14.e
                com.ironsource.mobilcore.j$b r3 = com.ironsource.mobilcore.C0272j.b.DOWNLOAD_STARTED
                com.ironsource.mobilcore.C0272j.a(r1, r2, r3)
                android.content.Context r1 = r14.a
                com.ironsource.mobilcore.j$b r2 = com.ironsource.mobilcore.C0272j.b.DOWNLOAD_STARTED
                java.lang.String r3 = r14.e
                java.lang.String r4 = "Download In Progress..."
                android.graphics.Bitmap r5 = r14.k
                com.ironsource.mobilcore.C0272j.b(r1, r2, r3, r4, r5, 0)
                boolean r1 = r0.exists()
                if (r1 != 0) goto L_0x00c1
                r0.mkdirs()
            L_0x00c1:
                boolean r0 = r9.exists()
                if (r0 == 0) goto L_0x00ca
                r9.delete()
            L_0x00ca:
                r2 = 0
                r6 = 0
                r1 = 0
                r4 = 0
                r3 = 0
                r9.createNewFile()     // Catch:{ Exception -> 0x0169, all -> 0x018f }
                java.net.URL r0 = new java.net.URL     // Catch:{ Exception -> 0x0169, all -> 0x018f }
                java.lang.String r5 = r14.f     // Catch:{ Exception -> 0x0169, all -> 0x018f }
                r0.<init>(r5)     // Catch:{ Exception -> 0x0169, all -> 0x018f }
                java.net.URLConnection r0 = r0.openConnection()     // Catch:{ Exception -> 0x0169, all -> 0x018f }
                java.net.HttpURLConnection r0 = (java.net.HttpURLConnection) r0     // Catch:{ Exception -> 0x0169, all -> 0x018f }
                r5 = 5000(0x1388, float:7.006E-42)
                r0.setConnectTimeout(r5)     // Catch:{ Exception -> 0x0169, all -> 0x018f }
                java.lang.String r5 = "Range"
                java.lang.StringBuilder r7 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0169, all -> 0x018f }
                java.lang.String r8 = "bytes="
                r7.<init>(r8)     // Catch:{ Exception -> 0x0169, all -> 0x018f }
                r8 = 0
                java.lang.StringBuilder r7 = r7.append(r8)     // Catch:{ Exception -> 0x0169, all -> 0x018f }
                java.lang.String r8 = "-"
                java.lang.StringBuilder r7 = r7.append(r8)     // Catch:{ Exception -> 0x0169, all -> 0x018f }
                java.lang.String r7 = r7.toString()     // Catch:{ Exception -> 0x0169, all -> 0x018f }
                r0.setRequestProperty(r5, r7)     // Catch:{ Exception -> 0x0169, all -> 0x018f }
                r0.connect()     // Catch:{ Exception -> 0x0169, all -> 0x018f }
                int r5 = r0.getContentLength()     // Catch:{ Exception -> 0x0169, all -> 0x018f }
                long r10 = (long) r5     // Catch:{ Exception -> 0x0169, all -> 0x018f }
                java.io.InputStream r7 = r0.getInputStream()     // Catch:{ Exception -> 0x0169, all -> 0x018f }
                r0 = 1024(0x400, float:1.435E-42)
                byte[] r12 = new byte[r0]     // Catch:{ Exception -> 0x01ad, all -> 0x01a7 }
                boolean r0 = r14.l     // Catch:{ Exception -> 0x01ad, all -> 0x01a7 }
                if (r0 == 0) goto L_0x0145
                java.io.FileOutputStream r2 = new java.io.FileOutputStream     // Catch:{ Exception -> 0x01ad, all -> 0x01a7 }
                r2.<init>(r9)     // Catch:{ Exception -> 0x01ad, all -> 0x01a7 }
                r0 = 0
                r1 = 0
                r6 = r2
            L_0x011b:
                int r13 = r7.read(r12)     // Catch:{ Exception -> 0x01b1, all -> 0x01aa }
                r2 = -1
                if (r13 == r2) goto L_0x0151
                int r8 = r1 + r13
                r2 = 0
                int r1 = (r10 > r2 ? 1 : (r10 == r2 ? 0 : -1))
                if (r1 <= 0) goto L_0x01b6
                int r1 = r8 * 100
                long r2 = (long) r1     // Catch:{ Exception -> 0x01b1, all -> 0x01aa }
                long r2 = r2 / r10
                int r5 = (int) r2     // Catch:{ Exception -> 0x01b1, all -> 0x01aa }
                if (r0 == r5) goto L_0x01b6
                android.content.Context r0 = r14.a     // Catch:{ Exception -> 0x01b1, all -> 0x01aa }
                com.ironsource.mobilcore.j$b r1 = com.ironsource.mobilcore.C0272j.b.DOWNLOAD_STARTED     // Catch:{ Exception -> 0x01b1, all -> 0x01aa }
                java.lang.String r2 = r14.e     // Catch:{ Exception -> 0x01b1, all -> 0x01aa }
                java.lang.String r3 = "Download In Progress..."
                android.graphics.Bitmap r4 = r14.k     // Catch:{ Exception -> 0x01b1, all -> 0x01aa }
                com.ironsource.mobilcore.C0272j.b(r0, r1, r2, r3, r4, r5)     // Catch:{ Exception -> 0x01b1, all -> 0x01aa }
            L_0x013e:
                r0 = 0
                r6.write(r12, r0, r13)     // Catch:{ Exception -> 0x01b1, all -> 0x01aa }
                r1 = r8
                r0 = r5
                goto L_0x011b
            L_0x0145:
                android.content.Context r0 = r14.a     // Catch:{ Exception -> 0x01ad, all -> 0x01a7 }
                java.lang.String r2 = r14.c     // Catch:{ Exception -> 0x01ad, all -> 0x01a7 }
                r3 = 1
                java.io.FileOutputStream r6 = r0.openFileOutput(r2, r3)     // Catch:{ Exception -> 0x01ad, all -> 0x01a7 }
                r0 = 0
                r1 = 0
                goto L_0x011b
            L_0x0151:
                r14.b()     // Catch:{ Exception -> 0x01b1, all -> 0x01aa }
                if (r6 == 0) goto L_0x015c
                r6.flush()     // Catch:{ IOException -> 0x0163 }
                r6.close()     // Catch:{ IOException -> 0x0163 }
            L_0x015c:
                if (r7 == 0) goto L_0x0078
                r7.close()     // Catch:{ IOException -> 0x0163 }
                goto L_0x0078
            L_0x0163:
                r0 = move-exception
                r14.a(r0)
                goto L_0x0078
            L_0x0169:
                r2 = move-exception
                r0 = r1
            L_0x016b:
                r2.printStackTrace()     // Catch:{ all -> 0x01b8 }
                boolean r1 = r9.exists()     // Catch:{ all -> 0x01b8 }
                if (r1 == 0) goto L_0x0177
                r9.delete()     // Catch:{ all -> 0x01b8 }
            L_0x0177:
                r14.a(r2)     // Catch:{ all -> 0x01b8 }
                if (r0 == 0) goto L_0x0182
                r0.flush()     // Catch:{ IOException -> 0x0189 }
                r0.close()     // Catch:{ IOException -> 0x0189 }
            L_0x0182:
                if (r3 == 0) goto L_0x0078
                r3.close()     // Catch:{ IOException -> 0x0189 }
                goto L_0x0078
            L_0x0189:
                r0 = move-exception
                r14.a(r0)
                goto L_0x0078
            L_0x018f:
                r0 = move-exception
                r1 = r0
                r3 = r4
            L_0x0192:
                r6 = r2
                r7 = r3
            L_0x0194:
                if (r6 == 0) goto L_0x019c
                r6.flush()     // Catch:{ IOException -> 0x01a2 }
                r6.close()     // Catch:{ IOException -> 0x01a2 }
            L_0x019c:
                if (r7 == 0) goto L_0x01a1
                r7.close()     // Catch:{ IOException -> 0x01a2 }
            L_0x01a1:
                throw r1
            L_0x01a2:
                r0 = move-exception
                r14.a(r0)
                goto L_0x01a1
            L_0x01a7:
                r0 = move-exception
                r1 = r0
                goto L_0x0194
            L_0x01aa:
                r0 = move-exception
                r1 = r0
                goto L_0x0194
            L_0x01ad:
                r2 = move-exception
                r0 = r1
                r3 = r7
                goto L_0x016b
            L_0x01b1:
                r1 = move-exception
                r0 = r6
                r2 = r1
                r3 = r7
                goto L_0x016b
            L_0x01b6:
                r5 = r0
                goto L_0x013e
            L_0x01b8:
                r1 = move-exception
                r2 = r0
                goto L_0x0192
            */
            throw new UnsupportedOperationException("Method not decompiled: com.ironsource.mobilcore.C0272j.a.a(com.ironsource.mobilcore.j$a):void");
        }

        private void a(Exception exc) {
            aK.a(this.a, aS.b.REPORT_TYPE_ERROR).a(exc).a();
            C0272j.a(this.a, this.e, b.DOWNLOAD_FAILED);
            C0272j.b(this.a).cancel(495307123);
            MobileCore.b().post(new Runnable() {
                /* class com.ironsource.mobilcore.C0272j.a.AnonymousClass1 */

                public final void run() {
                    Toast.makeText(a.this.a, "Failed to download apk", 1).show();
                }
            });
        }

        private void b() {
            C0272j.a(this.a, this.e, b.DOWNLOAD_COMPLETED);
            C0272j.b(this.a).cancel(495307123);
            if (aF.b(this.a, a())) {
                aK.a(this.a, aS.b.REPORT_TYPE_RES).a(this.h, this.g).a(aS.a.REPORT_ACTION_ALREADY_INSTALLED).c(this.i).a();
                return;
            }
            Intent intent = new Intent("android.intent.action.VIEW");
            File file = new File(this.d);
            B.a("Installing pacakge from " + this.d + " (size " + file.length() + ")", 55);
            intent.setDataAndType(Uri.fromFile(file), "application/vnd.android.package-archive");
            intent.addFlags(DriveFile.MODE_READ_ONLY);
            this.a.startActivity(intent);
            aK.a(this.a, aS.b.REPORT_TYPE_RES).a(this.h, this.g).a(aS.a.REPORT_ACTION_START).c(this.i).a();
            Context context = this.a;
            String str = this.g;
            String a2 = a();
            String str2 = this.c;
            aF.a(context, str, a2, this.i, 0, this.h, -1);
        }
    }

    /* renamed from: com.ironsource.mobilcore.j$b */
    public enum b {
        DOWNLOAD_NONE,
        DOWNLOAD_STARTED,
        DOWNLOAD_COMPLETED,
        DOWNLOAD_FAILED;

        public static b a(int i) {
            b[] values = values();
            for (b bVar : values) {
                if (i == bVar.ordinal()) {
                    return bVar;
                }
            }
            throw new IllegalArgumentException();
        }
    }

    public static b a(Context context, String str) {
        try {
            b a2 = b.a(aF.j(context).getInt("apkDownloadFile_" + str, b.DOWNLOAD_NONE.ordinal()));
            B.a("Get shared pref apkDownloadFile_" + str + " to " + a2, 55);
            return a2;
        } catch (Exception e) {
            return b.DOWNLOAD_NONE;
        }
    }

    public static b a(Context context, JSONObject jSONObject) {
        try {
            return a(context, jSONObject.getString("appId"));
        } catch (Exception e) {
            return b.DOWNLOAD_NONE;
        }
    }

    public static void a(Context context, Intent intent) {
        String absolutePath;
        boolean z = true;
        if (aF.a(context, UpdateConfig.f) && "mounted".equals(Environment.getExternalStorageState())) {
            absolutePath = Environment.getExternalStorageDirectory() + "/mc_data";
        } else {
            absolutePath = context.getFilesDir().getAbsolutePath();
            z = false;
        }
        a.a(new a(context, intent, absolutePath, z));
    }

    public static void a(Context context, String str, b bVar) {
        aF.j(context).edit().putInt("apkDownloadFile_" + str, bVar.ordinal()).commit();
        B.a("Setting shared pref apkDownloadFile_" + str + " to " + bVar, 55);
    }

    private static NotificationManager b(Context context) {
        if (a == null) {
            a = (NotificationManager) context.getSystemService("notification");
        }
        return a;
    }

    /* access modifiers changed from: private */
    public static void b(Context context, b bVar, String str, String str2, Bitmap bitmap, int i) {
        Notification notification;
        boolean z = true;
        NotificationManager b2 = b(context);
        int i2 = bVar == b.DOWNLOAD_COMPLETED ? 17301634 : 17301633;
        if (Build.VERSION.SDK_INT >= 11) {
            boolean z2 = bVar == b.DOWNLOAD_COMPLETED;
            if (z2) {
                z = false;
            }
            Notification.Builder when = new Notification.Builder(context).setContentTitle(str).setContentText(str2).setSmallIcon(i2).setAutoCancel(z2).setOngoing(z).setWhen(0);
            if (bitmap != null) {
                when.setLargeIcon(bitmap);
            }
            if (bVar == b.DOWNLOAD_STARTED) {
                when.setProgress(100, i, false);
            }
            when.setContentIntent(PendingIntent.getActivity(context, 0, new Intent(), 0));
            notification = Build.VERSION.SDK_INT >= 16 ? when.build() : when.getNotification();
        } else {
            PendingIntent activity = PendingIntent.getActivity(context, 0, new Intent(), 0);
            if (bVar == b.DOWNLOAD_STARTED) {
                str2 = str2 + " - " + i + "%";
            }
            Notification notification2 = new Notification(i2, str, System.currentTimeMillis());
            if (bVar == b.DOWNLOAD_COMPLETED) {
                notification2.flags &= 2;
                notification2.flags |= 16;
            } else {
                notification2.flags &= 16;
                notification2.flags |= 2;
            }
            notification2.setLatestEventInfo(context, str, str2, activity);
            notification = notification2;
        }
        b2.notify(495307123, notification);
    }
}
