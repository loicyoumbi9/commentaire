package com.keyboard.yhadsmodule.install;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import com.alimama.mobile.csdk.umupdate.a.f;
import com.umeng.analytics.MobclickAgent;
import java.util.HashMap;

public class CustomInstallReceiver extends BroadcastReceiver {
    private static final String INSTALL_PKG = "install_pkg";
    private static final String INSTALL_REFERRER = "install_referer";

    public static String getCountry(Context context) {
        TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService("phone");
        String networkCountryIso = telephonyManager != null ? telephonyManager.getNetworkCountryIso() : "default";
        return TextUtils.isEmpty(networkCountryIso) ? "default" : networkCountryIso;
    }

    public static void onEventInstallPkg(Context context, String str) {
        HashMap hashMap = new HashMap();
        hashMap.put("pkg", str);
        hashMap.put(f.bj, getCountry(context));
        MobclickAgent.onEvent(context, INSTALL_PKG, hashMap);
    }

    public static void onEventInstallReferer(Context context, String str) {
        HashMap hashMap = new HashMap();
        hashMap.put("referer", str);
        hashMap.put(f.bj, getCountry(context));
        MobclickAgent.onEvent(context, INSTALL_REFERRER, hashMap);
    }

    public void onReceive(Context context, Intent intent) {
        if (intent != null) {
            String stringExtra = intent.getStringExtra("referrer");
            if (!TextUtils.isEmpty(stringExtra)) {
                Uri.parse(stringExtra);
                onEventInstallReferer(context, stringExtra);
            }
        }
    }
}
