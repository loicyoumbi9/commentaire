package com.keyboard.common.utilsmodule.encrypt;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Signature;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;

public class MD5Encrypt {
    public static void main(String[] strArr) {
        MD5Encrypt mD5Encrypt = new MD5Encrypt();
        System.out.println("Hello->MD5:" + mD5Encrypt.encryptToMD5("Hello"));
        SecretKey createSecretKey = mD5Encrypt.createSecretKey("DES");
        String encryptToDES = mD5Encrypt.encryptToDES(createSecretKey, "Hello");
        System.out.println("des -> Hello:" + encryptToDES);
        System.out.println("des jie:" + mD5Encrypt.decryptByDES(createSecretKey, encryptToDES));
        mD5Encrypt.createPairKey();
        mD5Encrypt.signToInfo("Hello", "mysign.bat");
        if (mD5Encrypt.validateSign("mysign.bat")) {
            System.out.println("Success!");
        } else {
            System.out.println("Fail!");
        }
    }

    public static byte uniteBytes(byte b, byte b2) {
        return (byte) (((byte) (Byte.decode("0x" + new String(new byte[]{b})).byteValue() << 4)) ^ Byte.decode("0x" + new String(new byte[]{b2})).byteValue());
    }

    public String byte2hex(byte[] bArr) {
        String str = "";
        for (byte b : bArr) {
            String hexString = Integer.toHexString(b & 255);
            str = hexString.length() == 1 ? str + "0" + hexString : str + hexString;
        }
        return str.toUpperCase();
    }

    public void createPairKey() {
        try {
            KeyPairGenerator instance = KeyPairGenerator.getInstance("DSA");
            SecureRandom secureRandom = new SecureRandom();
            secureRandom.setSeed(1000);
            instance.initialize(512, secureRandom);
            KeyPair generateKeyPair = instance.generateKeyPair();
            doObjToFile("mykeys.bat", new Object[]{generateKeyPair.getPrivate(), generateKeyPair.getPublic()});
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
    }

    public SecretKey createSecretKey(String str) {
        try {
            return KeyGenerator.getInstance(str).generateKey();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }

    public SecretKey createSecretKeyEx(String str, byte[] bArr) {
        new SecureRandom();
        try {
            return SecretKeyFactory.getInstance("DES").generateSecret(new DESKeySpec(bArr));
        } catch (Exception e) {
            return null;
        }
    }

    public String decryptByDES(SecretKey secretKey, String str) {
        SecureRandom secureRandom = new SecureRandom();
        byte[] bArr = null;
        try {
            Cipher instance = Cipher.getInstance("DES");
            instance.init(2, secretKey, secureRandom);
            bArr = instance.doFinal(hex2byte(str));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return bArr == null ? "" : new String(bArr);
    }

    public void doObjToFile(String str, Object[] objArr) {
        ObjectOutputStream objectOutputStream;
        ObjectOutputStream objectOutputStream2 = null;
        try {
            objectOutputStream = new ObjectOutputStream(new FileOutputStream(str));
            int i = 0;
            while (i < objArr.length) {
                try {
                    objectOutputStream.writeObject(objArr[i]);
                    i++;
                } catch (Exception e) {
                    e = e;
                    try {
                        e.printStackTrace();
                        try {
                            objectOutputStream.close();
                        } catch (IOException e2) {
                            e2.printStackTrace();
                            return;
                        }
                    } catch (Throwable th) {
                        th = th;
                        objectOutputStream2 = objectOutputStream;
                        objectOutputStream = objectOutputStream2;
                        try {
                            objectOutputStream.close();
                        } catch (IOException e3) {
                            e3.printStackTrace();
                        }
                        throw th;
                    }
                } catch (Throwable th2) {
                    th = th2;
                    objectOutputStream.close();
                    throw th;
                }
            }
            try {
                objectOutputStream.close();
            } catch (IOException e4) {
                e4.printStackTrace();
            }
        } catch (Exception e5) {
            e = e5;
            objectOutputStream = null;
            e.printStackTrace();
            objectOutputStream.close();
        } catch (Throwable th3) {
            th = th3;
            objectOutputStream = objectOutputStream2;
            objectOutputStream.close();
            throw th;
        }
    }

    public String encryptToDES(SecretKey secretKey, String str) {
        SecureRandom secureRandom = new SecureRandom();
        byte[] bArr = null;
        try {
            Cipher instance = Cipher.getInstance("DES");
            instance.init(1, secretKey, secureRandom);
            bArr = instance.doFinal(str.getBytes());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return byte2hex(bArr);
    }

    public String encryptToMD5(String str) {
        byte[] bArr = null;
        try {
            MessageDigest instance = MessageDigest.getInstance("MD5");
            instance.update(str.getBytes());
            bArr = instance.digest();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return byte2hex(bArr);
    }

    public String encryptToSHA(String str) {
        byte[] bArr = null;
        try {
            MessageDigest instance = MessageDigest.getInstance("SHA-1");
            instance.update(str.getBytes());
            bArr = instance.digest();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return byte2hex(bArr);
    }

    public Object getObjFromFile(String str, int i) {
        ObjectInputStream objectInputStream;
        Object obj;
        ObjectInputStream objectInputStream2 = null;
        try {
            objectInputStream = new ObjectInputStream(new FileInputStream(str));
            int i2 = 0;
            obj = null;
            while (i2 < i) {
                try {
                    obj = objectInputStream.readObject();
                    i2++;
                } catch (Exception e) {
                    e = e;
                    try {
                        e.printStackTrace();
                        try {
                            objectInputStream.close();
                        } catch (IOException e2) {
                            e2.printStackTrace();
                        }
                        return obj;
                    } catch (Throwable th) {
                        th = th;
                        objectInputStream2 = objectInputStream;
                        objectInputStream = objectInputStream2;
                        try {
                            objectInputStream.close();
                        } catch (IOException e3) {
                            e3.printStackTrace();
                        }
                        throw th;
                    }
                } catch (Throwable th2) {
                    th = th2;
                    objectInputStream.close();
                    throw th;
                }
            }
            try {
                objectInputStream.close();
            } catch (IOException e4) {
                e4.printStackTrace();
            }
        } catch (Exception e5) {
            e = e5;
            obj = null;
            objectInputStream = null;
            e.printStackTrace();
            objectInputStream.close();
            return obj;
        } catch (Throwable th3) {
            th = th3;
            objectInputStream = objectInputStream2;
            objectInputStream.close();
            throw th;
        }
        return obj;
    }

    public byte[] hex2byte(String str) {
        byte[] bytes = str.getBytes();
        byte[] bArr = new byte[(bytes.length / 2)];
        for (int i = 0; i < bytes.length / 2; i++) {
            bArr[i] = uniteBytes(bytes[i * 2], bytes[(i * 2) + 1]);
        }
        return bArr;
    }

    public byte[] hex2byteex(String str) {
        byte[] bArr = new byte[8];
        byte[] bytes = str.getBytes();
        for (int i = 0; i < 8; i++) {
            bArr[i] = uniteBytes(bytes[i * 2], bytes[(i * 2) + 1]);
        }
        return bArr;
    }

    public void signToInfo(String str, String str2) {
        PrivateKey privateKey = (PrivateKey) getObjFromFile("mykeys.bat", 1);
        PublicKey publicKey = (PublicKey) getObjFromFile("mykeys.bat", 2);
        try {
            Signature instance = Signature.getInstance("DSA");
            instance.initSign(privateKey);
            instance.update(str.getBytes());
            doObjToFile(str2, new Object[]{instance.sign(), publicKey, str});
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean validateSign(String str) {
        PublicKey publicKey = (PublicKey) getObjFromFile(str, 2);
        byte[] bArr = (byte[]) getObjFromFile(str, 1);
        String str2 = (String) getObjFromFile(str, 3);
        try {
            Signature instance = Signature.getInstance("DSA");
            instance.initVerify(publicKey);
            instance.update(str2.getBytes());
            System.out.println(str2);
            return instance.verify(bArr);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
