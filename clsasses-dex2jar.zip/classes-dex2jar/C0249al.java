package com.ironsource.mobilcore;

import android.view.animation.Interpolator;

/* renamed from: com.ironsource.mobilcore.al  reason: case insensitive filesystem */
final class C0249al implements Interpolator {
    private static final C0254aq a = new C0254aq();

    C0249al() {
    }

    public final float getInterpolation(float f) {
        if (f < 0.33333334f) {
            return a.getInterpolation(f * 3.0f);
        }
        if (f > 0.6666667f) {
            return 1.0f - a.getInterpolation(((0.33333334f + f) - 1.0f) * 3.0f);
        }
        return 1.0f;
    }
}
