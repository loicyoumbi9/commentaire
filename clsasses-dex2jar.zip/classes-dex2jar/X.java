package com.ironsource.mobilcore;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.ironsource.mobilcore.aS;
import java.text.MessageFormat;
import org.json.JSONObject;

final class X extends I {
    private String a;
    private EditText b;
    private ImageView t;

    public X(Context context, C0261ax axVar) {
        super(context, axVar);
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: com.ironsource.mobilcore.aF.a(android.app.Activity, java.lang.String, boolean):void
     arg types: [android.app.Activity, java.lang.String, int]
     candidates:
      com.ironsource.mobilcore.aF.a(java.io.InputStream, java.lang.String, java.lang.String):java.io.File
      com.ironsource.mobilcore.aF.a(android.content.Context, java.lang.String, java.lang.String):java.lang.String
      com.ironsource.mobilcore.aF.a(android.app.Activity, java.lang.String, boolean):void */
    static /* synthetic */ void a(X x) {
        String obj = x.b.getText().toString();
        if (!TextUtils.isEmpty(x.a) && !TextUtils.isEmpty(obj)) {
            String format = MessageFormat.format(x.a, obj);
            x.b.setText("");
            x.k();
            aF.a(x.e, format, true);
            aK.a(aS.b.REPORT_TYPE_EVENT).a("slider", "widget", "search_performed").a();
        }
    }

    @Override // com.ironsource.mobilcore.H
    public final String a() {
        return "ironsourceSearch";
    }

    /* access modifiers changed from: protected */
    @Override // com.ironsource.mobilcore.H, com.ironsource.mobilcore.I
    public final void a(View view) {
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: com.ironsource.mobilcore.I.a(org.json.JSONObject, boolean):void
     arg types: [org.json.JSONObject, int]
     candidates:
      com.ironsource.mobilcore.I.a(com.ironsource.mobilcore.MCEWidgetTextProperties, java.lang.String):void
      com.ironsource.mobilcore.I.a(org.json.JSONObject, boolean):void */
    @Override // com.ironsource.mobilcore.H
    public final void a(JSONObject jSONObject) {
        this.a = jSONObject.optString("baseSearchUrl", "http://search.spearmint-browser.com/results.php?s={0}&a=mcsldr");
        super.a(jSONObject, true);
        this.b.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            /* class com.ironsource.mobilcore.X.AnonymousClass1 */

            public final boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
                if (i != 3) {
                    return false;
                }
                X.a(X.this);
                return false;
            }
        });
        this.t.setOnClickListener(new View.OnClickListener() {
            /* class com.ironsource.mobilcore.X.AnonymousClass2 */

            public final void onClick(View view) {
                X.a(X.this);
            }
        });
    }

    /* access modifiers changed from: protected */
    @Override // com.ironsource.mobilcore.H
    public final void c() {
        this.h = new RelativeLayout(this.c);
        this.h.setPadding(this.d.h(), this.d.h(), this.d.h(), this.d.h());
    }

    /* access modifiers changed from: protected */
    @Override // com.ironsource.mobilcore.H
    public final void d() {
        this.t = new ImageView(this.c);
        this.t.setId(j());
        int b2 = C.b(this.c, 5.0f);
        this.t.setPadding(b2 * 2, b2, b2, b2);
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams.addRule(15);
        layoutParams.addRule(11);
        this.t.setLayoutParams(layoutParams);
        this.t.setImageDrawable(this.d.l());
        this.b = new EditText(this.c);
        RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(-1, -2);
        layoutParams2.addRule(0, this.t.getId());
        this.b.setLayoutParams(layoutParams2);
        this.b.setSingleLine();
        this.b.setImeOptions(3);
        this.b.setHintTextColor(this.d.c());
        this.b.setTextColor(this.d.d());
        C.a(this.b, (Drawable) null);
        this.b.setPadding(0, 0, 0, 0);
        RelativeLayout relativeLayout = new RelativeLayout(this.c);
        relativeLayout.setLayoutParams(new RelativeLayout.LayoutParams(-1, -2));
        relativeLayout.addView(this.t);
        relativeLayout.addView(this.b);
        C.a(relativeLayout, this.d.t());
        ((ViewGroup) this.h).addView(relativeLayout);
    }

    /* access modifiers changed from: protected */
    @Override // com.ironsource.mobilcore.H
    public final void e() {
        if (!TextUtils.isEmpty(this.l)) {
            this.b.setHint(this.l);
        }
    }

    /* access modifiers changed from: protected */
    @Override // com.ironsource.mobilcore.I
    public final boolean f() {
        return false;
    }
}
