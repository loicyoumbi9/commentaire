package com.ironsource.mobilcore;

import android.content.Context;
import android.content.Intent;
import com.ironsource.mobilcore.C0277o;
import org.json.JSONObject;

final class aJ extends Intent {
    private Context a;

    public aJ(Context context) {
        super(context, MobileCoreReport.class);
        this.a = context;
        putExtra("extra_service_type", C0277o.b.SERVICE_TYPE_APK_DOWNLOAD);
        putExtra("1%dns#ge1%dk1%do1%dt", MobileCore.a(context));
        putExtra("s#gds#gis#g_s#ge1%du1%dqs#gi1%dn1%dus#g_s#ga1%dr1%dt1%dxs#ge", aD.a(context).a());
    }

    public final void a() {
        this.a.startService(this);
    }

    public final void a(String str, String str2, String str3, JSONObject jSONObject) {
        String string = jSONObject.getString("appId");
        String string2 = jSONObject.getString("img");
        String d = aF.d(str);
        putExtra("com.ironsource.mobilcore.extra_download_url", str);
        putExtra("com.ironsource.mobilcore.extra_download_filename", d);
        putExtra("com.ironsource.mobilcore.extra_download_app_img_name", string2);
        putExtra("com.ironsource.mobilcore.extra_download_appname", string);
        putExtra("com.ironsource.mobilecore.MobileCoreReport_extra_flow", str3);
        putExtra("com.ironsource.mobilcore.MobileCoreReport_extra_flow_type", str2);
        putExtra("com.ironsource.mobilcore.MobileCoreReport_extra_offer", aR.c(jSONObject));
    }
}
