package u.aly;

import com.alimama.mobile.csdk.umupdate.a.f;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.BitSet;
import java.util.Collections;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class ax implements Serializable, Cloneable, ch<ax, e> {
    public static final Map<e, ct> e;
    /* access modifiers changed from: private */
    public static final dl f = new dl("IdJournal");
    /* access modifiers changed from: private */
    public static final db g = new db("domain", (byte) 11, 1);
    /* access modifiers changed from: private */
    public static final db h = new db("old_id", (byte) 11, 2);
    /* access modifiers changed from: private */
    public static final db i = new db("new_id", (byte) 11, 3);
    /* access modifiers changed from: private */
    public static final db j = new db(f.bP, (byte) 10, 4);
    private static final Map<Class<? extends Cdo>, dp> k = new HashMap();
    private static final int l = 0;
    public String a;
    public String b;
    public String c;
    public long d;
    private byte m;
    private e[] n;

    private static class a extends dq<ax> {
        private a() {
        }

        /* renamed from: a */
        public void b(dg dgVar, ax axVar) throws cn {
            dgVar.j();
            while (true) {
                db l = dgVar.l();
                if (l.b == 0) {
                    dgVar.k();
                    if (!axVar.o()) {
                        throw new dh("Required field 'ts' was not found in serialized data! Struct: " + toString());
                    }
                    axVar.p();
                    return;
                }
                switch (l.c) {
                    case 1:
                        if (l.b != 11) {
                            dj.a(dgVar, l.b);
                            break;
                        } else {
                            axVar.a = dgVar.z();
                            axVar.a(true);
                            break;
                        }
                    case 2:
                        if (l.b != 11) {
                            dj.a(dgVar, l.b);
                            break;
                        } else {
                            axVar.b = dgVar.z();
                            axVar.b(true);
                            break;
                        }
                    case 3:
                        if (l.b != 11) {
                            dj.a(dgVar, l.b);
                            break;
                        } else {
                            axVar.c = dgVar.z();
                            axVar.c(true);
                            break;
                        }
                    case 4:
                        if (l.b != 10) {
                            dj.a(dgVar, l.b);
                            break;
                        } else {
                            axVar.d = dgVar.x();
                            axVar.d(true);
                            break;
                        }
                    default:
                        dj.a(dgVar, l.b);
                        break;
                }
                dgVar.m();
            }
        }

        /* renamed from: b */
        public void a(dg dgVar, ax axVar) throws cn {
            axVar.p();
            dgVar.a(ax.f);
            if (axVar.a != null) {
                dgVar.a(ax.g);
                dgVar.a(axVar.a);
                dgVar.c();
            }
            if (axVar.b != null && axVar.i()) {
                dgVar.a(ax.h);
                dgVar.a(axVar.b);
                dgVar.c();
            }
            if (axVar.c != null) {
                dgVar.a(ax.i);
                dgVar.a(axVar.c);
                dgVar.c();
            }
            dgVar.a(ax.j);
            dgVar.a(axVar.d);
            dgVar.c();
            dgVar.d();
            dgVar.b();
        }
    }

    private static class b implements dp {
        private b() {
        }

        /* renamed from: a */
        public a b() {
            return new a();
        }
    }

    private static class c extends dr<ax> {
        private c() {
        }

        public void a(dg dgVar, ax axVar) throws cn {
            dm dmVar = (dm) dgVar;
            dmVar.a(axVar.a);
            dmVar.a(axVar.c);
            dmVar.a(axVar.d);
            BitSet bitSet = new BitSet();
            if (axVar.i()) {
                bitSet.set(0);
            }
            dmVar.a(bitSet, 1);
            if (axVar.i()) {
                dmVar.a(axVar.b);
            }
        }

        public void b(dg dgVar, ax axVar) throws cn {
            dm dmVar = (dm) dgVar;
            axVar.a = dmVar.z();
            axVar.a(true);
            axVar.c = dmVar.z();
            axVar.c(true);
            axVar.d = dmVar.x();
            axVar.d(true);
            if (dmVar.b(1).get(0)) {
                axVar.b = dmVar.z();
                axVar.b(true);
            }
        }
    }

    private static class d implements dp {
        private d() {
        }

        /* renamed from: a */
        public c b() {
            return new c();
        }
    }

    public enum e implements co {
        DOMAIN(1, "domain"),
        OLD_ID(2, "old_id"),
        NEW_ID(3, "new_id"),
        TS(4, f.bP);
        
        private static final Map<String, e> e = new HashMap();
        private final short f;
        private final String g;

        static {
            Iterator it = EnumSet.allOf(e.class).iterator();
            while (it.hasNext()) {
                e eVar = (e) it.next();
                e.put(eVar.b(), eVar);
            }
        }

        private e(short s, String str) {
            this.f = s;
            this.g = str;
        }

        public static e a(int i) {
            switch (i) {
                case 1:
                    return DOMAIN;
                case 2:
                    return OLD_ID;
                case 3:
                    return NEW_ID;
                case 4:
                    return TS;
                default:
                    return null;
            }
        }

        public static e a(String str) {
            return e.get(str);
        }

        public static e b(int i) {
            e a = a(i);
            if (a != null) {
                return a;
            }
            throw new IllegalArgumentException("Field " + i + " doesn't exist!");
        }

        @Override // u.aly.co
        public short a() {
            return this.f;
        }

        @Override // u.aly.co
        public String b() {
            return this.g;
        }
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: MutableMD:(java.lang.Object, java.lang.Object):java.lang.Object
     arg types: [u.aly.ax$e, u.aly.ct]
     candidates:
      MutableMD:(java.lang.Enum, java.lang.Object):java.lang.Object
      MutableMD:(java.lang.Object, java.lang.Object):java.lang.Object */
    static {
        k.put(dq.class, new b());
        k.put(dr.class, new d());
        EnumMap enumMap = new EnumMap(e.class);
        enumMap.put((Object) e.DOMAIN, (Object) new ct("domain", (byte) 1, new cu((byte) 11)));
        enumMap.put((Object) e.OLD_ID, (Object) new ct("old_id", (byte) 2, new cu((byte) 11)));
        enumMap.put((Object) e.NEW_ID, (Object) new ct("new_id", (byte) 1, new cu((byte) 11)));
        enumMap.put((Object) e.TS, (Object) new ct(f.bP, (byte) 1, new cu((byte) 10)));
        e = Collections.unmodifiableMap(enumMap);
        ct.a(ax.class, e);
    }

    public ax() {
        this.m = 0;
        this.n = new e[]{e.OLD_ID};
    }

    public ax(String str, String str2, long j2) {
        this();
        this.a = str;
        this.c = str2;
        this.d = j2;
        d(true);
    }

    public ax(ax axVar) {
        this.m = 0;
        this.n = new e[]{e.OLD_ID};
        this.m = axVar.m;
        if (axVar.e()) {
            this.a = axVar.a;
        }
        if (axVar.i()) {
            this.b = axVar.b;
        }
        if (axVar.l()) {
            this.c = axVar.c;
        }
        this.d = axVar.d;
    }

    private void a(ObjectInputStream objectInputStream) throws IOException, ClassNotFoundException {
        try {
            this.m = 0;
            a(new da(new ds(objectInputStream)));
        } catch (cn e2) {
            throw new IOException(e2.getMessage());
        }
    }

    private void a(ObjectOutputStream objectOutputStream) throws IOException {
        try {
            b(new da(new ds(objectOutputStream)));
        } catch (cn e2) {
            throw new IOException(e2.getMessage());
        }
    }

    /* renamed from: a */
    public e b(int i2) {
        return e.a(i2);
    }

    /* renamed from: a */
    public ax g() {
        return new ax(this);
    }

    public ax a(long j2) {
        this.d = j2;
        d(true);
        return this;
    }

    public ax a(String str) {
        this.a = str;
        return this;
    }

    @Override // u.aly.ch
    public void a(dg dgVar) throws cn {
        k.get(dgVar.D()).b().b(dgVar, this);
    }

    public void a(boolean z) {
        if (!z) {
            this.a = null;
        }
    }

    public ax b(String str) {
        this.b = str;
        return this;
    }

    @Override // u.aly.ch
    public void b() {
        this.a = null;
        this.b = null;
        this.c = null;
        d(false);
        this.d = 0;
    }

    @Override // u.aly.ch
    public void b(dg dgVar) throws cn {
        k.get(dgVar.D()).b().a(dgVar, this);
    }

    public void b(boolean z) {
        if (!z) {
            this.b = null;
        }
    }

    public String c() {
        return this.a;
    }

    public ax c(String str) {
        this.c = str;
        return this;
    }

    public void c(boolean z) {
        if (!z) {
            this.c = null;
        }
    }

    public void d() {
        this.a = null;
    }

    public void d(boolean z) {
        this.m = ce.a(this.m, 0, z);
    }

    public boolean e() {
        return this.a != null;
    }

    public String f() {
        return this.b;
    }

    public void h() {
        this.b = null;
    }

    public boolean i() {
        return this.b != null;
    }

    public String j() {
        return this.c;
    }

    public void k() {
        this.c = null;
    }

    public boolean l() {
        return this.c != null;
    }

    public long m() {
        return this.d;
    }

    public void n() {
        this.m = ce.b(this.m, 0);
    }

    public boolean o() {
        return ce.a(this.m, 0);
    }

    public void p() throws cn {
        if (this.a == null) {
            throw new dh("Required field 'domain' was not present! Struct: " + toString());
        } else if (this.c == null) {
            throw new dh("Required field 'new_id' was not present! Struct: " + toString());
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("IdJournal(");
        sb.append("domain:");
        if (this.a == null) {
            sb.append(f.b);
        } else {
            sb.append(this.a);
        }
        if (i()) {
            sb.append(", ");
            sb.append("old_id:");
            if (this.b == null) {
                sb.append(f.b);
            } else {
                sb.append(this.b);
            }
        }
        sb.append(", ");
        sb.append("new_id:");
        if (this.c == null) {
            sb.append(f.b);
        } else {
            sb.append(this.c);
        }
        sb.append(", ");
        sb.append("ts:");
        sb.append(this.d);
        sb.append(")");
        return sb.toString();
    }
}
