package com.ironsource.mobilcore;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;
import android.webkit.WebView;
import android.widget.Toast;
import com.alimama.mobile.csdk.umupdate.a.f;
import com.android.common.speech.LoggingEvents;
import com.google.android.gms.drive.DriveFile;
import com.ironsource.mobilcore.C0272j;
import com.ironsource.mobilcore.C0274l;
import com.ironsource.mobilcore.C0277o;
import com.ironsource.mobilcore.C0280r;
import com.ironsource.mobilcore.J;
import com.ironsource.mobilcore.MobileCore;
import com.ironsource.mobilcore.aS;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Arrays;
import java.util.HashMap;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

final class aR {
    private static HashMap a;

    public static String a(JSONArray jSONArray) {
        try {
            JSONArray jSONArray2 = new JSONArray();
            for (int i = 0; i < jSONArray.length(); i++) {
                jSONArray2.put(i, d(jSONArray.getJSONObject(i)));
            }
            return jSONArray2.toString();
        } catch (JSONException e) {
            aK.a(aS.b.REPORT_TYPE_ERROR).a(e).a();
            return null;
        }
    }

    public static JSONObject a(JSONObject jSONObject) {
        JSONObject jSONObject2 = new JSONObject();
        try {
            jSONObject2.put(f.bu, jSONObject.optString(f.bu));
        } catch (JSONException e) {
            aK.a(aS.b.REPORT_TYPE_ERROR).a(e).a();
        }
        return jSONObject2;
    }

    public static void a(Activity activity, WebView webView, JSONObject jSONObject, String str, String str2, C0274l.c cVar) {
        boolean z;
        String str3;
        boolean z2 = true;
        String reportValue = cVar.c == null ? null : cVar.c.getReportValue();
        if (!cVar.d.booleanValue()) {
            aK.a(aS.b.REPORT_TYPE_RES).a(str2, str).a(aS.a.REPORT_ACTION_CLICK).a(jSONObject).b("showTrigger", reportValue).a();
        }
        String optString = jSONObject.optString("click");
        if (TextUtils.isEmpty(optString)) {
            B.a("Click url is empty!", 3);
            if (cVar.a != null) {
                cVar.a.a();
                return;
            }
            return;
        }
        if (C0277o.a.a(jSONObject.optString("type")) == C0277o.a.OFFER_TYPE_APK_DOWNLOAD) {
            if (aF.b(activity == null ? MobileCore.c() : activity, jSONObject.optString("appId"))) {
                aK.a(aS.b.REPORT_TYPE_RES).a(str2, str).a(aS.a.REPORT_ACTION_ALREADY_INSTALLED).a(jSONObject).a();
                str3 = "Application already installed";
                z = true;
            } else {
                if (C0272j.a(activity == null ? MobileCore.c() : activity, jSONObject) == C0272j.b.DOWNLOAD_STARTED) {
                    str3 = "Already downloading this offer";
                    z = true;
                } else {
                    str3 = "The app will be downloaded to your device shortly";
                    z = false;
                }
            }
            Toast.makeText(MobileCore.c(), str3, 1).show();
        } else {
            z = false;
        }
        if (optString.startsWith("market://")) {
            a(optString, str, str2, jSONObject, cVar.c);
        } else {
            z2 = z;
        }
        if (!z2) {
            if (cVar.b != null) {
                cVar.b.a();
            } else if (activity != null) {
                C0271i.a(activity);
            }
            webView.loadUrl(optString);
        } else if (cVar.a != null) {
            cVar.a.a();
        }
    }

    public static void a(C0280r.a aVar) {
        if (a == null) {
            a = new HashMap();
        }
        a.put(aVar, Long.valueOf(System.currentTimeMillis()));
    }

    public static void a(C0280r.a aVar, J.a... aVarArr) {
        Long l;
        if (a != null && a.containsKey(aVar) && (l = (Long) a.get(aVar)) != null) {
            J.a[] aVarArr2 = (aVarArr == null || aVarArr.length <= 0) ? new J.a[1] : (J.a[]) Arrays.copyOf(aVarArr, aVarArr.length + 1);
            aVarArr2[aVarArr2.length - 1] = new J.a("duration", String.valueOf(System.currentTimeMillis() - l.longValue()));
            aK.a(aS.b.REPORT_TYPE_EVENT).a(aVar.a(), "time_measurement", aVar.b()).a(aVarArr2).a();
            a.remove(aVar);
        }
    }

    public static void a(String str, String str2, String str3, String str4, MobileCore.AD_UNIT_SHOW_TRIGGER ad_unit_show_trigger) {
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("Feed", str4);
            jSONObject.put("TransID", str3);
            JSONArray jSONArray = new JSONArray();
            jSONArray.put(jSONObject);
            aK.a(aS.b.REPORT_TYPE_RES).a(str, str2).a(aS.a.REPORT_ACTION_SHOWN).c(jSONArray.toString()).b("showTrigger", ad_unit_show_trigger == null ? null : ad_unit_show_trigger.getReportValue()).a();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public static void a(String str, String str2, String str3, JSONObject jSONObject) {
        B.a("doApkInstall " + str, 3);
        try {
            aJ aJVar = new aJ(MobileCore.c());
            aJVar.a(str, str2, str3, jSONObject);
            aJVar.a();
        } catch (Exception e) {
            aK.a(aS.b.REPORT_TYPE_ERROR).a(e).a();
        }
    }

    public static void a(String str, String str2, String str3, JSONObject jSONObject, MobileCore.AD_UNIT_SHOW_TRIGGER ad_unit_show_trigger) {
        aS.a aVar;
        Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(str));
        intent.setFlags(DriveFile.MODE_READ_ONLY);
        try {
            MobileCore.c().startActivity(intent);
        } catch (Exception e) {
            aK.a(aS.b.REPORT_TYPE_ERROR).a(e).a();
        }
        aS.a aVar2 = aS.a.REPORT_ACTION_ALREADY_INSTALLED;
        int indexOf = str.indexOf("id=");
        int i = indexOf + 3;
        int indexOf2 = str.indexOf("&", indexOf);
        String substring = indexOf >= 0 ? indexOf2 >= 0 ? str.substring(i, indexOf2) : str.substring(i) : "idFieldMissing";
        String c = c(jSONObject);
        if (!aF.b(MobileCore.c(), substring)) {
            aS.a aVar3 = aS.a.REPORT_ACTION_START;
            aF.a(MobileCore.c(), str2, substring, c, 0, str3, -1);
            aVar = aVar3;
        } else {
            aVar = aVar2;
        }
        aK.a(aS.b.REPORT_TYPE_RES).a(str3, str2).a(aVar).a(jSONObject).b("showTrigger", ad_unit_show_trigger == null ? null : ad_unit_show_trigger.getReportValue()).a();
        a(C0280r.a.INTERSTITIAL_CLICK_TO_START, new J.a("offer", a(jSONObject)));
    }

    public static boolean a(String str) {
        try {
            URI uri = new URI(str);
            if (!TextUtils.isEmpty(uri.getPath())) {
                return uri.getPath().endsWith(".apk");
            }
        } catch (URISyntaxException e) {
        }
        return false;
    }

    public static void b(JSONObject jSONObject) {
        HttpGet httpGet = new HttpGet(jSONObject.optString("impression"));
        DefaultHttpClient a2 = aF.a();
        HttpParams params = a2.getParams();
        HttpConnectionParams.setConnectionTimeout(params, 2000);
        HttpConnectionParams.setSoTimeout(params, 2000);
        a2.setParams(params);
        try {
            HttpResponse execute = a2.execute(httpGet);
            int statusCode = execute.getStatusLine().getStatusCode();
            execute.getEntity().consumeContent();
            jSONObject.put("impressionResult", statusCode);
        } catch (Exception e) {
            try {
                jSONObject.putOpt("impressionResult", -1);
            } catch (JSONException e2) {
                aK.a(aS.b.REPORT_TYPE_ERROR).a(e2).a();
            }
        }
    }

    public static String c(JSONObject jSONObject) {
        JSONArray jSONArray = new JSONArray();
        jSONArray.put(jSONObject);
        return a(jSONArray);
    }

    private static JSONObject d(JSONObject jSONObject) {
        JSONObject jSONObject2 = new JSONObject();
        if (jSONObject != null) {
            String str = jSONObject.optString(f.bu).split("-")[0];
            String optString = jSONObject.optString("impressionResult");
            jSONObject2.putOpt("Name", jSONObject.optString("title"));
            jSONObject2.putOpt("Feed", jSONObject.optString("aff"));
            jSONObject2.putOpt("Type", jSONObject.optString("type"));
            jSONObject2.putOpt("cpi", jSONObject.optString("cpi"));
            jSONObject2.putOpt("Number", jSONObject.optString("index"));
            jSONObject2.putOpt("TransID", str);
            if (!TextUtils.isEmpty(optString)) {
                jSONObject2.putOpt("impressionResult", optString);
            }
            JSONArray optJSONArray = jSONObject.optJSONArray("extra");
            if (optJSONArray != null) {
                for (int i = 0; i < optJSONArray.length(); i++) {
                    JSONObject optJSONObject = optJSONArray.optJSONObject(i);
                    try {
                        if ("report".equals(optJSONObject.getString("type"))) {
                            jSONObject2.put(optJSONObject.getString("name"), optJSONObject.getString(LoggingEvents.VoiceSearch.EXTRA_QUERY_UPDATED_VALUE));
                        }
                    } catch (JSONException e) {
                        B.a("parseExtra | Error: " + e.getLocalizedMessage(), 2);
                    }
                }
            }
        }
        return jSONObject2;
    }
}
