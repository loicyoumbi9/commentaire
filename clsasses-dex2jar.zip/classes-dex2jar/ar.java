package u.aly;

import com.alimama.mobile.csdk.umupdate.a.f;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.BitSet;
import java.util.Collections;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class ar implements Serializable, Cloneable, ch<ar, e> {
    /* access modifiers changed from: private */
    public static final db A = new db(f.bi, (byte) 11, 8);
    /* access modifiers changed from: private */
    public static final db B = new db(f.I, (byte) 12, 9);
    /* access modifiers changed from: private */
    public static final db C = new db("is_jailbroken", (byte) 2, 10);
    /* access modifiers changed from: private */
    public static final db D = new db("is_pirated", (byte) 2, 11);
    /* access modifiers changed from: private */
    public static final db E = new db("device_board", (byte) 11, 12);
    /* access modifiers changed from: private */
    public static final db F = new db("device_brand", (byte) 11, 13);
    /* access modifiers changed from: private */
    public static final db G = new db("device_manutime", (byte) 10, 14);
    /* access modifiers changed from: private */
    public static final db H = new db("device_manufacturer", (byte) 11, 15);
    /* access modifiers changed from: private */
    public static final db I = new db("device_manuid", (byte) 11, 16);
    /* access modifiers changed from: private */
    public static final db J = new db("device_name", (byte) 11, 17);
    private static final Map<Class<? extends Cdo>, dp> K = new HashMap();
    private static final int L = 0;
    private static final int M = 1;
    private static final int N = 2;
    public static final Map<e, ct> r;
    /* access modifiers changed from: private */
    public static final dl s = new dl("DeviceInfo");
    /* access modifiers changed from: private */
    public static final db t = new db(f.D, (byte) 11, 1);
    /* access modifiers changed from: private */

    /* renamed from: u  reason: collision with root package name */
    public static final db f16u = new db("idmd5", (byte) 11, 2);
    /* access modifiers changed from: private */
    public static final db v = new db("mac_address", (byte) 11, 3);
    /* access modifiers changed from: private */
    public static final db w = new db("open_udid", (byte) 11, 4);
    /* access modifiers changed from: private */
    public static final db x = new db("model", (byte) 11, 5);
    /* access modifiers changed from: private */
    public static final db y = new db(f.ay, (byte) 11, 6);
    /* access modifiers changed from: private */
    public static final db z = new db(f.F, (byte) 11, 7);
    private byte O = 0;
    private e[] P = {e.DEVICE_ID, e.IDMD5, e.MAC_ADDRESS, e.OPEN_UDID, e.MODEL, e.CPU, e.OS, e.OS_VERSION, e.RESOLUTION, e.IS_JAILBROKEN, e.IS_PIRATED, e.DEVICE_BOARD, e.DEVICE_BRAND, e.DEVICE_MANUTIME, e.DEVICE_MANUFACTURER, e.DEVICE_MANUID, e.DEVICE_NAME};
    public String a;
    public String b;
    public String c;
    public String d;
    public String e;
    public String f;
    public String g;
    public String h;
    public bi i;
    public boolean j;
    public boolean k;
    public String l;
    public String m;
    public long n;
    public String o;
    public String p;
    public String q;

    private static class a extends dq<ar> {
        private a() {
        }

        /* renamed from: a */
        public void b(dg dgVar, ar arVar) throws cn {
            dgVar.j();
            while (true) {
                db l = dgVar.l();
                if (l.b == 0) {
                    dgVar.k();
                    arVar.ac();
                    return;
                }
                switch (l.c) {
                    case 1:
                        if (l.b != 11) {
                            dj.a(dgVar, l.b);
                            break;
                        } else {
                            arVar.a = dgVar.z();
                            arVar.a(true);
                            break;
                        }
                    case 2:
                        if (l.b != 11) {
                            dj.a(dgVar, l.b);
                            break;
                        } else {
                            arVar.b = dgVar.z();
                            arVar.b(true);
                            break;
                        }
                    case 3:
                        if (l.b != 11) {
                            dj.a(dgVar, l.b);
                            break;
                        } else {
                            arVar.c = dgVar.z();
                            arVar.c(true);
                            break;
                        }
                    case 4:
                        if (l.b != 11) {
                            dj.a(dgVar, l.b);
                            break;
                        } else {
                            arVar.d = dgVar.z();
                            arVar.d(true);
                            break;
                        }
                    case 5:
                        if (l.b != 11) {
                            dj.a(dgVar, l.b);
                            break;
                        } else {
                            arVar.e = dgVar.z();
                            arVar.e(true);
                            break;
                        }
                    case 6:
                        if (l.b != 11) {
                            dj.a(dgVar, l.b);
                            break;
                        } else {
                            arVar.f = dgVar.z();
                            arVar.f(true);
                            break;
                        }
                    case 7:
                        if (l.b != 11) {
                            dj.a(dgVar, l.b);
                            break;
                        } else {
                            arVar.g = dgVar.z();
                            arVar.g(true);
                            break;
                        }
                    case 8:
                        if (l.b != 11) {
                            dj.a(dgVar, l.b);
                            break;
                        } else {
                            arVar.h = dgVar.z();
                            arVar.h(true);
                            break;
                        }
                    case 9:
                        if (l.b != 12) {
                            dj.a(dgVar, l.b);
                            break;
                        } else {
                            arVar.i = new bi();
                            arVar.i.a(dgVar);
                            arVar.i(true);
                            break;
                        }
                    case 10:
                        if (l.b != 2) {
                            dj.a(dgVar, l.b);
                            break;
                        } else {
                            arVar.j = dgVar.t();
                            arVar.k(true);
                            break;
                        }
                    case 11:
                        if (l.b != 2) {
                            dj.a(dgVar, l.b);
                            break;
                        } else {
                            arVar.k = dgVar.t();
                            arVar.m(true);
                            break;
                        }
                    case 12:
                        if (l.b != 11) {
                            dj.a(dgVar, l.b);
                            break;
                        } else {
                            arVar.l = dgVar.z();
                            arVar.n(true);
                            break;
                        }
                    case 13:
                        if (l.b != 11) {
                            dj.a(dgVar, l.b);
                            break;
                        } else {
                            arVar.m = dgVar.z();
                            arVar.o(true);
                            break;
                        }
                    case 14:
                        if (l.b != 10) {
                            dj.a(dgVar, l.b);
                            break;
                        } else {
                            arVar.n = dgVar.x();
                            arVar.p(true);
                            break;
                        }
                    case 15:
                        if (l.b != 11) {
                            dj.a(dgVar, l.b);
                            break;
                        } else {
                            arVar.o = dgVar.z();
                            arVar.q(true);
                            break;
                        }
                    case 16:
                        if (l.b != 11) {
                            dj.a(dgVar, l.b);
                            break;
                        } else {
                            arVar.p = dgVar.z();
                            arVar.r(true);
                            break;
                        }
                    case 17:
                        if (l.b != 11) {
                            dj.a(dgVar, l.b);
                            break;
                        } else {
                            arVar.q = dgVar.z();
                            arVar.s(true);
                            break;
                        }
                    default:
                        dj.a(dgVar, l.b);
                        break;
                }
                dgVar.m();
            }
        }

        /* renamed from: b */
        public void a(dg dgVar, ar arVar) throws cn {
            arVar.ac();
            dgVar.a(ar.s);
            if (arVar.a != null && arVar.e()) {
                dgVar.a(ar.t);
                dgVar.a(arVar.a);
                dgVar.c();
            }
            if (arVar.b != null && arVar.i()) {
                dgVar.a(ar.f16u);
                dgVar.a(arVar.b);
                dgVar.c();
            }
            if (arVar.c != null && arVar.l()) {
                dgVar.a(ar.v);
                dgVar.a(arVar.c);
                dgVar.c();
            }
            if (arVar.d != null && arVar.o()) {
                dgVar.a(ar.w);
                dgVar.a(arVar.d);
                dgVar.c();
            }
            if (arVar.e != null && arVar.r()) {
                dgVar.a(ar.x);
                dgVar.a(arVar.e);
                dgVar.c();
            }
            if (arVar.f != null && arVar.u()) {
                dgVar.a(ar.y);
                dgVar.a(arVar.f);
                dgVar.c();
            }
            if (arVar.g != null && arVar.x()) {
                dgVar.a(ar.z);
                dgVar.a(arVar.g);
                dgVar.c();
            }
            if (arVar.h != null && arVar.A()) {
                dgVar.a(ar.A);
                dgVar.a(arVar.h);
                dgVar.c();
            }
            if (arVar.i != null && arVar.D()) {
                dgVar.a(ar.B);
                arVar.i.b(dgVar);
                dgVar.c();
            }
            if (arVar.G()) {
                dgVar.a(ar.C);
                dgVar.a(arVar.j);
                dgVar.c();
            }
            if (arVar.J()) {
                dgVar.a(ar.D);
                dgVar.a(arVar.k);
                dgVar.c();
            }
            if (arVar.l != null && arVar.M()) {
                dgVar.a(ar.E);
                dgVar.a(arVar.l);
                dgVar.c();
            }
            if (arVar.m != null && arVar.P()) {
                dgVar.a(ar.F);
                dgVar.a(arVar.m);
                dgVar.c();
            }
            if (arVar.S()) {
                dgVar.a(ar.G);
                dgVar.a(arVar.n);
                dgVar.c();
            }
            if (arVar.o != null && arVar.V()) {
                dgVar.a(ar.H);
                dgVar.a(arVar.o);
                dgVar.c();
            }
            if (arVar.p != null && arVar.Y()) {
                dgVar.a(ar.I);
                dgVar.a(arVar.p);
                dgVar.c();
            }
            if (arVar.q != null && arVar.ab()) {
                dgVar.a(ar.J);
                dgVar.a(arVar.q);
                dgVar.c();
            }
            dgVar.d();
            dgVar.b();
        }
    }

    private static class b implements dp {
        private b() {
        }

        /* renamed from: a */
        public a b() {
            return new a();
        }
    }

    private static class c extends dr<ar> {
        private c() {
        }

        public void a(dg dgVar, ar arVar) throws cn {
            dm dmVar = (dm) dgVar;
            BitSet bitSet = new BitSet();
            if (arVar.e()) {
                bitSet.set(0);
            }
            if (arVar.i()) {
                bitSet.set(1);
            }
            if (arVar.l()) {
                bitSet.set(2);
            }
            if (arVar.o()) {
                bitSet.set(3);
            }
            if (arVar.r()) {
                bitSet.set(4);
            }
            if (arVar.u()) {
                bitSet.set(5);
            }
            if (arVar.x()) {
                bitSet.set(6);
            }
            if (arVar.A()) {
                bitSet.set(7);
            }
            if (arVar.D()) {
                bitSet.set(8);
            }
            if (arVar.G()) {
                bitSet.set(9);
            }
            if (arVar.J()) {
                bitSet.set(10);
            }
            if (arVar.M()) {
                bitSet.set(11);
            }
            if (arVar.P()) {
                bitSet.set(12);
            }
            if (arVar.S()) {
                bitSet.set(13);
            }
            if (arVar.V()) {
                bitSet.set(14);
            }
            if (arVar.Y()) {
                bitSet.set(15);
            }
            if (arVar.ab()) {
                bitSet.set(16);
            }
            dmVar.a(bitSet, 17);
            if (arVar.e()) {
                dmVar.a(arVar.a);
            }
            if (arVar.i()) {
                dmVar.a(arVar.b);
            }
            if (arVar.l()) {
                dmVar.a(arVar.c);
            }
            if (arVar.o()) {
                dmVar.a(arVar.d);
            }
            if (arVar.r()) {
                dmVar.a(arVar.e);
            }
            if (arVar.u()) {
                dmVar.a(arVar.f);
            }
            if (arVar.x()) {
                dmVar.a(arVar.g);
            }
            if (arVar.A()) {
                dmVar.a(arVar.h);
            }
            if (arVar.D()) {
                arVar.i.b(dmVar);
            }
            if (arVar.G()) {
                dmVar.a(arVar.j);
            }
            if (arVar.J()) {
                dmVar.a(arVar.k);
            }
            if (arVar.M()) {
                dmVar.a(arVar.l);
            }
            if (arVar.P()) {
                dmVar.a(arVar.m);
            }
            if (arVar.S()) {
                dmVar.a(arVar.n);
            }
            if (arVar.V()) {
                dmVar.a(arVar.o);
            }
            if (arVar.Y()) {
                dmVar.a(arVar.p);
            }
            if (arVar.ab()) {
                dmVar.a(arVar.q);
            }
        }

        public void b(dg dgVar, ar arVar) throws cn {
            dm dmVar = (dm) dgVar;
            BitSet b = dmVar.b(17);
            if (b.get(0)) {
                arVar.a = dmVar.z();
                arVar.a(true);
            }
            if (b.get(1)) {
                arVar.b = dmVar.z();
                arVar.b(true);
            }
            if (b.get(2)) {
                arVar.c = dmVar.z();
                arVar.c(true);
            }
            if (b.get(3)) {
                arVar.d = dmVar.z();
                arVar.d(true);
            }
            if (b.get(4)) {
                arVar.e = dmVar.z();
                arVar.e(true);
            }
            if (b.get(5)) {
                arVar.f = dmVar.z();
                arVar.f(true);
            }
            if (b.get(6)) {
                arVar.g = dmVar.z();
                arVar.g(true);
            }
            if (b.get(7)) {
                arVar.h = dmVar.z();
                arVar.h(true);
            }
            if (b.get(8)) {
                arVar.i = new bi();
                arVar.i.a(dmVar);
                arVar.i(true);
            }
            if (b.get(9)) {
                arVar.j = dmVar.t();
                arVar.k(true);
            }
            if (b.get(10)) {
                arVar.k = dmVar.t();
                arVar.m(true);
            }
            if (b.get(11)) {
                arVar.l = dmVar.z();
                arVar.n(true);
            }
            if (b.get(12)) {
                arVar.m = dmVar.z();
                arVar.o(true);
            }
            if (b.get(13)) {
                arVar.n = dmVar.x();
                arVar.p(true);
            }
            if (b.get(14)) {
                arVar.o = dmVar.z();
                arVar.q(true);
            }
            if (b.get(15)) {
                arVar.p = dmVar.z();
                arVar.r(true);
            }
            if (b.get(16)) {
                arVar.q = dmVar.z();
                arVar.s(true);
            }
        }
    }

    private static class d implements dp {
        private d() {
        }

        /* renamed from: a */
        public c b() {
            return new c();
        }
    }

    public enum e implements co {
        DEVICE_ID(1, f.D),
        IDMD5(2, "idmd5"),
        MAC_ADDRESS(3, "mac_address"),
        OPEN_UDID(4, "open_udid"),
        MODEL(5, "model"),
        CPU(6, f.ay),
        OS(7, f.F),
        OS_VERSION(8, f.bi),
        RESOLUTION(9, f.I),
        IS_JAILBROKEN(10, "is_jailbroken"),
        IS_PIRATED(11, "is_pirated"),
        DEVICE_BOARD(12, "device_board"),
        DEVICE_BRAND(13, "device_brand"),
        DEVICE_MANUTIME(14, "device_manutime"),
        DEVICE_MANUFACTURER(15, "device_manufacturer"),
        DEVICE_MANUID(16, "device_manuid"),
        DEVICE_NAME(17, "device_name");
        
        private static final Map<String, e> r = new HashMap();
        private final short s;
        private final String t;

        static {
            Iterator it = EnumSet.allOf(e.class).iterator();
            while (it.hasNext()) {
                e eVar = (e) it.next();
                r.put(eVar.b(), eVar);
            }
        }

        private e(short s2, String str) {
            this.s = s2;
            this.t = str;
        }

        public static e a(int i) {
            switch (i) {
                case 1:
                    return DEVICE_ID;
                case 2:
                    return IDMD5;
                case 3:
                    return MAC_ADDRESS;
                case 4:
                    return OPEN_UDID;
                case 5:
                    return MODEL;
                case 6:
                    return CPU;
                case 7:
                    return OS;
                case 8:
                    return OS_VERSION;
                case 9:
                    return RESOLUTION;
                case 10:
                    return IS_JAILBROKEN;
                case 11:
                    return IS_PIRATED;
                case 12:
                    return DEVICE_BOARD;
                case 13:
                    return DEVICE_BRAND;
                case 14:
                    return DEVICE_MANUTIME;
                case 15:
                    return DEVICE_MANUFACTURER;
                case 16:
                    return DEVICE_MANUID;
                case 17:
                    return DEVICE_NAME;
                default:
                    return null;
            }
        }

        public static e a(String str) {
            return r.get(str);
        }

        public static e b(int i) {
            e a = a(i);
            if (a != null) {
                return a;
            }
            throw new IllegalArgumentException("Field " + i + " doesn't exist!");
        }

        @Override // u.aly.co
        public short a() {
            return this.s;
        }

        @Override // u.aly.co
        public String b() {
            return this.t;
        }
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: MutableMD:(java.lang.Object, java.lang.Object):java.lang.Object
     arg types: [u.aly.ar$e, u.aly.ct]
     candidates:
      MutableMD:(java.lang.Enum, java.lang.Object):java.lang.Object
      MutableMD:(java.lang.Object, java.lang.Object):java.lang.Object */
    static {
        K.put(dq.class, new b());
        K.put(dr.class, new d());
        EnumMap enumMap = new EnumMap(e.class);
        enumMap.put((Object) e.DEVICE_ID, (Object) new ct(f.D, (byte) 2, new cu((byte) 11)));
        enumMap.put((Object) e.IDMD5, (Object) new ct("idmd5", (byte) 2, new cu((byte) 11)));
        enumMap.put((Object) e.MAC_ADDRESS, (Object) new ct("mac_address", (byte) 2, new cu((byte) 11)));
        enumMap.put((Object) e.OPEN_UDID, (Object) new ct("open_udid", (byte) 2, new cu((byte) 11)));
        enumMap.put((Object) e.MODEL, (Object) new ct("model", (byte) 2, new cu((byte) 11)));
        enumMap.put((Object) e.CPU, (Object) new ct(f.ay, (byte) 2, new cu((byte) 11)));
        enumMap.put((Object) e.OS, (Object) new ct(f.F, (byte) 2, new cu((byte) 11)));
        enumMap.put((Object) e.OS_VERSION, (Object) new ct(f.bi, (byte) 2, new cu((byte) 11)));
        enumMap.put((Object) e.RESOLUTION, (Object) new ct(f.I, (byte) 2, new cy((byte) 12, bi.class)));
        enumMap.put((Object) e.IS_JAILBROKEN, (Object) new ct("is_jailbroken", (byte) 2, new cu((byte) 2)));
        enumMap.put((Object) e.IS_PIRATED, (Object) new ct("is_pirated", (byte) 2, new cu((byte) 2)));
        enumMap.put((Object) e.DEVICE_BOARD, (Object) new ct("device_board", (byte) 2, new cu((byte) 11)));
        enumMap.put((Object) e.DEVICE_BRAND, (Object) new ct("device_brand", (byte) 2, new cu((byte) 11)));
        enumMap.put((Object) e.DEVICE_MANUTIME, (Object) new ct("device_manutime", (byte) 2, new cu((byte) 10)));
        enumMap.put((Object) e.DEVICE_MANUFACTURER, (Object) new ct("device_manufacturer", (byte) 2, new cu((byte) 11)));
        enumMap.put((Object) e.DEVICE_MANUID, (Object) new ct("device_manuid", (byte) 2, new cu((byte) 11)));
        enumMap.put((Object) e.DEVICE_NAME, (Object) new ct("device_name", (byte) 2, new cu((byte) 11)));
        r = Collections.unmodifiableMap(enumMap);
        ct.a(ar.class, r);
    }

    public ar() {
    }

    public ar(ar arVar) {
        this.O = arVar.O;
        if (arVar.e()) {
            this.a = arVar.a;
        }
        if (arVar.i()) {
            this.b = arVar.b;
        }
        if (arVar.l()) {
            this.c = arVar.c;
        }
        if (arVar.o()) {
            this.d = arVar.d;
        }
        if (arVar.r()) {
            this.e = arVar.e;
        }
        if (arVar.u()) {
            this.f = arVar.f;
        }
        if (arVar.x()) {
            this.g = arVar.g;
        }
        if (arVar.A()) {
            this.h = arVar.h;
        }
        if (arVar.D()) {
            this.i = new bi(arVar.i);
        }
        this.j = arVar.j;
        this.k = arVar.k;
        if (arVar.M()) {
            this.l = arVar.l;
        }
        if (arVar.P()) {
            this.m = arVar.m;
        }
        this.n = arVar.n;
        if (arVar.V()) {
            this.o = arVar.o;
        }
        if (arVar.Y()) {
            this.p = arVar.p;
        }
        if (arVar.ab()) {
            this.q = arVar.q;
        }
    }

    private void a(ObjectInputStream objectInputStream) throws IOException, ClassNotFoundException {
        try {
            this.O = 0;
            a(new da(new ds(objectInputStream)));
        } catch (cn e2) {
            throw new IOException(e2.getMessage());
        }
    }

    private void a(ObjectOutputStream objectOutputStream) throws IOException {
        try {
            b(new da(new ds(objectOutputStream)));
        } catch (cn e2) {
            throw new IOException(e2.getMessage());
        }
    }

    public boolean A() {
        return this.h != null;
    }

    public bi B() {
        return this.i;
    }

    public void C() {
        this.i = null;
    }

    public boolean D() {
        return this.i != null;
    }

    public boolean E() {
        return this.j;
    }

    public void F() {
        this.O = ce.b(this.O, 0);
    }

    public boolean G() {
        return ce.a(this.O, 0);
    }

    public boolean H() {
        return this.k;
    }

    public void I() {
        this.O = ce.b(this.O, 1);
    }

    public boolean J() {
        return ce.a(this.O, 1);
    }

    public String K() {
        return this.l;
    }

    public void L() {
        this.l = null;
    }

    public boolean M() {
        return this.l != null;
    }

    public String N() {
        return this.m;
    }

    public void O() {
        this.m = null;
    }

    public boolean P() {
        return this.m != null;
    }

    public long Q() {
        return this.n;
    }

    public void R() {
        this.O = ce.b(this.O, 2);
    }

    public boolean S() {
        return ce.a(this.O, 2);
    }

    public String T() {
        return this.o;
    }

    public void U() {
        this.o = null;
    }

    public boolean V() {
        return this.o != null;
    }

    public String W() {
        return this.p;
    }

    public void X() {
        this.p = null;
    }

    public boolean Y() {
        return this.p != null;
    }

    public String Z() {
        return this.q;
    }

    /* renamed from: a */
    public e b(int i2) {
        return e.a(i2);
    }

    /* renamed from: a */
    public ar g() {
        return new ar(this);
    }

    public ar a(long j2) {
        this.n = j2;
        p(true);
        return this;
    }

    public ar a(String str) {
        this.a = str;
        return this;
    }

    public ar a(bi biVar) {
        this.i = biVar;
        return this;
    }

    @Override // u.aly.ch
    public void a(dg dgVar) throws cn {
        K.get(dgVar.D()).b().b(dgVar, this);
    }

    public void a(boolean z2) {
        if (!z2) {
            this.a = null;
        }
    }

    public void aa() {
        this.q = null;
    }

    public boolean ab() {
        return this.q != null;
    }

    public void ac() throws cn {
        if (this.i != null) {
            this.i.j();
        }
    }

    public ar b(String str) {
        this.b = str;
        return this;
    }

    @Override // u.aly.ch
    public void b() {
        this.a = null;
        this.b = null;
        this.c = null;
        this.d = null;
        this.e = null;
        this.f = null;
        this.g = null;
        this.h = null;
        this.i = null;
        k(false);
        this.j = false;
        m(false);
        this.k = false;
        this.l = null;
        this.m = null;
        p(false);
        this.n = 0;
        this.o = null;
        this.p = null;
        this.q = null;
    }

    @Override // u.aly.ch
    public void b(dg dgVar) throws cn {
        K.get(dgVar.D()).b().a(dgVar, this);
    }

    public void b(boolean z2) {
        if (!z2) {
            this.b = null;
        }
    }

    public String c() {
        return this.a;
    }

    public ar c(String str) {
        this.c = str;
        return this;
    }

    public void c(boolean z2) {
        if (!z2) {
            this.c = null;
        }
    }

    public ar d(String str) {
        this.d = str;
        return this;
    }

    public void d() {
        this.a = null;
    }

    public void d(boolean z2) {
        if (!z2) {
            this.d = null;
        }
    }

    public ar e(String str) {
        this.e = str;
        return this;
    }

    public void e(boolean z2) {
        if (!z2) {
            this.e = null;
        }
    }

    public boolean e() {
        return this.a != null;
    }

    public String f() {
        return this.b;
    }

    public ar f(String str) {
        this.f = str;
        return this;
    }

    public void f(boolean z2) {
        if (!z2) {
            this.f = null;
        }
    }

    public ar g(String str) {
        this.g = str;
        return this;
    }

    public void g(boolean z2) {
        if (!z2) {
            this.g = null;
        }
    }

    public ar h(String str) {
        this.h = str;
        return this;
    }

    public void h() {
        this.b = null;
    }

    public void h(boolean z2) {
        if (!z2) {
            this.h = null;
        }
    }

    public ar i(String str) {
        this.l = str;
        return this;
    }

    public void i(boolean z2) {
        if (!z2) {
            this.i = null;
        }
    }

    public boolean i() {
        return this.b != null;
    }

    public String j() {
        return this.c;
    }

    public ar j(String str) {
        this.m = str;
        return this;
    }

    public ar j(boolean z2) {
        this.j = z2;
        k(true);
        return this;
    }

    public ar k(String str) {
        this.o = str;
        return this;
    }

    public void k() {
        this.c = null;
    }

    public void k(boolean z2) {
        this.O = ce.a(this.O, 0, z2);
    }

    public ar l(String str) {
        this.p = str;
        return this;
    }

    public ar l(boolean z2) {
        this.k = z2;
        m(true);
        return this;
    }

    public boolean l() {
        return this.c != null;
    }

    public String m() {
        return this.d;
    }

    public ar m(String str) {
        this.q = str;
        return this;
    }

    public void m(boolean z2) {
        this.O = ce.a(this.O, 1, z2);
    }

    public void n() {
        this.d = null;
    }

    public void n(boolean z2) {
        if (!z2) {
            this.l = null;
        }
    }

    public void o(boolean z2) {
        if (!z2) {
            this.m = null;
        }
    }

    public boolean o() {
        return this.d != null;
    }

    public String p() {
        return this.e;
    }

    public void p(boolean z2) {
        this.O = ce.a(this.O, 2, z2);
    }

    public void q() {
        this.e = null;
    }

    public void q(boolean z2) {
        if (!z2) {
            this.o = null;
        }
    }

    public void r(boolean z2) {
        if (!z2) {
            this.p = null;
        }
    }

    public boolean r() {
        return this.e != null;
    }

    public String s() {
        return this.f;
    }

    public void s(boolean z2) {
        if (!z2) {
            this.q = null;
        }
    }

    public void t() {
        this.f = null;
    }

    public String toString() {
        boolean z2 = false;
        StringBuilder sb = new StringBuilder("DeviceInfo(");
        boolean z3 = true;
        if (e()) {
            sb.append("device_id:");
            if (this.a == null) {
                sb.append(f.b);
            } else {
                sb.append(this.a);
            }
            z3 = false;
        }
        if (i()) {
            if (!z3) {
                sb.append(", ");
            }
            sb.append("idmd5:");
            if (this.b == null) {
                sb.append(f.b);
            } else {
                sb.append(this.b);
            }
            z3 = false;
        }
        if (l()) {
            if (!z3) {
                sb.append(", ");
            }
            sb.append("mac_address:");
            if (this.c == null) {
                sb.append(f.b);
            } else {
                sb.append(this.c);
            }
            z3 = false;
        }
        if (o()) {
            if (!z3) {
                sb.append(", ");
            }
            sb.append("open_udid:");
            if (this.d == null) {
                sb.append(f.b);
            } else {
                sb.append(this.d);
            }
            z3 = false;
        }
        if (r()) {
            if (!z3) {
                sb.append(", ");
            }
            sb.append("model:");
            if (this.e == null) {
                sb.append(f.b);
            } else {
                sb.append(this.e);
            }
            z3 = false;
        }
        if (u()) {
            if (!z3) {
                sb.append(", ");
            }
            sb.append("cpu:");
            if (this.f == null) {
                sb.append(f.b);
            } else {
                sb.append(this.f);
            }
            z3 = false;
        }
        if (x()) {
            if (!z3) {
                sb.append(", ");
            }
            sb.append("os:");
            if (this.g == null) {
                sb.append(f.b);
            } else {
                sb.append(this.g);
            }
            z3 = false;
        }
        if (A()) {
            if (!z3) {
                sb.append(", ");
            }
            sb.append("os_version:");
            if (this.h == null) {
                sb.append(f.b);
            } else {
                sb.append(this.h);
            }
            z3 = false;
        }
        if (D()) {
            if (!z3) {
                sb.append(", ");
            }
            sb.append("resolution:");
            if (this.i == null) {
                sb.append(f.b);
            } else {
                sb.append(this.i);
            }
            z3 = false;
        }
        if (G()) {
            if (!z3) {
                sb.append(", ");
            }
            sb.append("is_jailbroken:");
            sb.append(this.j);
            z3 = false;
        }
        if (J()) {
            if (!z3) {
                sb.append(", ");
            }
            sb.append("is_pirated:");
            sb.append(this.k);
            z3 = false;
        }
        if (M()) {
            if (!z3) {
                sb.append(", ");
            }
            sb.append("device_board:");
            if (this.l == null) {
                sb.append(f.b);
            } else {
                sb.append(this.l);
            }
            z3 = false;
        }
        if (P()) {
            if (!z3) {
                sb.append(", ");
            }
            sb.append("device_brand:");
            if (this.m == null) {
                sb.append(f.b);
            } else {
                sb.append(this.m);
            }
            z3 = false;
        }
        if (S()) {
            if (!z3) {
                sb.append(", ");
            }
            sb.append("device_manutime:");
            sb.append(this.n);
            z3 = false;
        }
        if (V()) {
            if (!z3) {
                sb.append(", ");
            }
            sb.append("device_manufacturer:");
            if (this.o == null) {
                sb.append(f.b);
            } else {
                sb.append(this.o);
            }
            z3 = false;
        }
        if (Y()) {
            if (!z3) {
                sb.append(", ");
            }
            sb.append("device_manuid:");
            if (this.p == null) {
                sb.append(f.b);
            } else {
                sb.append(this.p);
            }
        } else {
            z2 = z3;
        }
        if (ab()) {
            if (!z2) {
                sb.append(", ");
            }
            sb.append("device_name:");
            if (this.q == null) {
                sb.append(f.b);
            } else {
                sb.append(this.q);
            }
        }
        sb.append(")");
        return sb.toString();
    }

    public boolean u() {
        return this.f != null;
    }

    public String v() {
        return this.g;
    }

    public void w() {
        this.g = null;
    }

    public boolean x() {
        return this.g != null;
    }

    public String y() {
        return this.h;
    }

    public void z() {
        this.h = null;
    }
}
