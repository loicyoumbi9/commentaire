package org.w3c.dom.views;

public interface DocumentView {
    AbstractView getDefaultView();
}
