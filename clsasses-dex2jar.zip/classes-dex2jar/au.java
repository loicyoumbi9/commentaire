package u.aly;

public enum au implements cl {
    LEGIT(1),
    ALIEN(2);
    
    private final int c;

    private au(int i) {
        this.c = i;
    }

    public static au a(int i) {
        switch (i) {
            case 1:
                return LEGIT;
            case 2:
                return ALIEN;
            default:
                return null;
        }
    }

    @Override // u.aly.cl
    public int a() {
        return this.c;
    }
}
