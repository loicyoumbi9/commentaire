package com.ironsource.mobilcore;

import com.ironsource.mobilcore.MobileCore;

public interface AdUnitEventListener {

    public enum EVENT_TYPE {
        AD_UNIT_READY,
        AD_UNIT_NOT_READY,
        AD_UNIT_DISMISSED
    }

    void onAdUnitEvent(MobileCore.AD_UNITS ad_units, EVENT_TYPE event_type);
}
