package org.w3c.dom.smil;

public interface SMILRootLayoutElement extends SMILElement, ElementLayout {
}
