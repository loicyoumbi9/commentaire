package u.aly;

import com.alimama.mobile.csdk.umupdate.a.f;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.Collections;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class bl implements Serializable, Cloneable, ch<bl, e> {
    public static final Map<e, ct> h;
    /* access modifiers changed from: private */
    public static final dl i = new dl("Session");
    /* access modifiers changed from: private */
    public static final db j = new db(f.bu, (byte) 11, 1);
    /* access modifiers changed from: private */
    public static final db k = new db(f.bI, (byte) 10, 2);
    /* access modifiers changed from: private */
    public static final db l = new db(f.bJ, (byte) 10, 3);
    /* access modifiers changed from: private */
    public static final db m = new db("duration", (byte) 10, 4);
    /* access modifiers changed from: private */
    public static final db n = new db("pages", dn.m, 5);
    /* access modifiers changed from: private */
    public static final db o = new db("locations", dn.m, 6);
    /* access modifiers changed from: private */
    public static final db p = new db("traffic", (byte) 12, 7);
    private static final Map<Class<? extends Cdo>, dp> q = new HashMap();
    private static final int r = 0;
    private static final int s = 1;
    private static final int t = 2;
    public String a;
    public long b;
    public long c;
    public long d;
    public List<bg> e;
    public List<be> f;
    public bm g;

    /* renamed from: u  reason: collision with root package name */
    private byte f19u;
    private e[] v;

    private static class a extends dq<bl> {
        private a() {
        }

        /* renamed from: a */
        public void b(dg dgVar, bl blVar) throws cn {
            dgVar.j();
            while (true) {
                db l = dgVar.l();
                if (l.b == 0) {
                    dgVar.k();
                    if (!blVar.i()) {
                        throw new dh("Required field 'start_time' was not found in serialized data! Struct: " + toString());
                    } else if (!blVar.l()) {
                        throw new dh("Required field 'end_time' was not found in serialized data! Struct: " + toString());
                    } else if (!blVar.o()) {
                        throw new dh("Required field 'duration' was not found in serialized data! Struct: " + toString());
                    } else {
                        blVar.C();
                        return;
                    }
                } else {
                    switch (l.c) {
                        case 1:
                            if (l.b != 11) {
                                dj.a(dgVar, l.b);
                                break;
                            } else {
                                blVar.a = dgVar.z();
                                blVar.a(true);
                                break;
                            }
                        case 2:
                            if (l.b != 10) {
                                dj.a(dgVar, l.b);
                                break;
                            } else {
                                blVar.b = dgVar.x();
                                blVar.b(true);
                                break;
                            }
                        case 3:
                            if (l.b != 10) {
                                dj.a(dgVar, l.b);
                                break;
                            } else {
                                blVar.c = dgVar.x();
                                blVar.c(true);
                                break;
                            }
                        case 4:
                            if (l.b != 10) {
                                dj.a(dgVar, l.b);
                                break;
                            } else {
                                blVar.d = dgVar.x();
                                blVar.d(true);
                                break;
                            }
                        case 5:
                            if (l.b != 15) {
                                dj.a(dgVar, l.b);
                                break;
                            } else {
                                dc p = dgVar.p();
                                blVar.e = new ArrayList(p.b);
                                for (int i = 0; i < p.b; i++) {
                                    bg bgVar = new bg();
                                    bgVar.a(dgVar);
                                    blVar.e.add(bgVar);
                                }
                                dgVar.q();
                                blVar.e(true);
                                break;
                            }
                        case 6:
                            if (l.b != 15) {
                                dj.a(dgVar, l.b);
                                break;
                            } else {
                                dc p2 = dgVar.p();
                                blVar.f = new ArrayList(p2.b);
                                for (int i2 = 0; i2 < p2.b; i2++) {
                                    be beVar = new be();
                                    beVar.a(dgVar);
                                    blVar.f.add(beVar);
                                }
                                dgVar.q();
                                blVar.f(true);
                                break;
                            }
                        case 7:
                            if (l.b != 12) {
                                dj.a(dgVar, l.b);
                                break;
                            } else {
                                blVar.g = new bm();
                                blVar.g.a(dgVar);
                                blVar.g(true);
                                break;
                            }
                        default:
                            dj.a(dgVar, l.b);
                            break;
                    }
                    dgVar.m();
                }
            }
        }

        /* renamed from: b */
        public void a(dg dgVar, bl blVar) throws cn {
            blVar.C();
            dgVar.a(bl.i);
            if (blVar.a != null) {
                dgVar.a(bl.j);
                dgVar.a(blVar.a);
                dgVar.c();
            }
            dgVar.a(bl.k);
            dgVar.a(blVar.b);
            dgVar.c();
            dgVar.a(bl.l);
            dgVar.a(blVar.c);
            dgVar.c();
            dgVar.a(bl.m);
            dgVar.a(blVar.d);
            dgVar.c();
            if (blVar.e != null && blVar.t()) {
                dgVar.a(bl.n);
                dgVar.a(new dc((byte) 12, blVar.e.size()));
                for (bg bgVar : blVar.e) {
                    bgVar.b(dgVar);
                }
                dgVar.f();
                dgVar.c();
            }
            if (blVar.f != null && blVar.y()) {
                dgVar.a(bl.o);
                dgVar.a(new dc((byte) 12, blVar.f.size()));
                for (be beVar : blVar.f) {
                    beVar.b(dgVar);
                }
                dgVar.f();
                dgVar.c();
            }
            if (blVar.g != null && blVar.B()) {
                dgVar.a(bl.p);
                blVar.g.b(dgVar);
                dgVar.c();
            }
            dgVar.d();
            dgVar.b();
        }
    }

    private static class b implements dp {
        private b() {
        }

        /* renamed from: a */
        public a b() {
            return new a();
        }
    }

    private static class c extends dr<bl> {
        private c() {
        }

        public void a(dg dgVar, bl blVar) throws cn {
            dm dmVar = (dm) dgVar;
            dmVar.a(blVar.a);
            dmVar.a(blVar.b);
            dmVar.a(blVar.c);
            dmVar.a(blVar.d);
            BitSet bitSet = new BitSet();
            if (blVar.t()) {
                bitSet.set(0);
            }
            if (blVar.y()) {
                bitSet.set(1);
            }
            if (blVar.B()) {
                bitSet.set(2);
            }
            dmVar.a(bitSet, 3);
            if (blVar.t()) {
                dmVar.a(blVar.e.size());
                for (bg bgVar : blVar.e) {
                    bgVar.b(dmVar);
                }
            }
            if (blVar.y()) {
                dmVar.a(blVar.f.size());
                for (be beVar : blVar.f) {
                    beVar.b(dmVar);
                }
            }
            if (blVar.B()) {
                blVar.g.b(dmVar);
            }
        }

        public void b(dg dgVar, bl blVar) throws cn {
            dm dmVar = (dm) dgVar;
            blVar.a = dmVar.z();
            blVar.a(true);
            blVar.b = dmVar.x();
            blVar.b(true);
            blVar.c = dmVar.x();
            blVar.c(true);
            blVar.d = dmVar.x();
            blVar.d(true);
            BitSet b = dmVar.b(3);
            if (b.get(0)) {
                dc dcVar = new dc((byte) 12, dmVar.w());
                blVar.e = new ArrayList(dcVar.b);
                for (int i = 0; i < dcVar.b; i++) {
                    bg bgVar = new bg();
                    bgVar.a(dmVar);
                    blVar.e.add(bgVar);
                }
                blVar.e(true);
            }
            if (b.get(1)) {
                dc dcVar2 = new dc((byte) 12, dmVar.w());
                blVar.f = new ArrayList(dcVar2.b);
                for (int i2 = 0; i2 < dcVar2.b; i2++) {
                    be beVar = new be();
                    beVar.a(dmVar);
                    blVar.f.add(beVar);
                }
                blVar.f(true);
            }
            if (b.get(2)) {
                blVar.g = new bm();
                blVar.g.a(dmVar);
                blVar.g(true);
            }
        }
    }

    private static class d implements dp {
        private d() {
        }

        /* renamed from: a */
        public c b() {
            return new c();
        }
    }

    public enum e implements co {
        ID(1, f.bu),
        START_TIME(2, f.bI),
        END_TIME(3, f.bJ),
        DURATION(4, "duration"),
        PAGES(5, "pages"),
        LOCATIONS(6, "locations"),
        TRAFFIC(7, "traffic");
        
        private static final Map<String, e> h = new HashMap();
        private final short i;
        private final String j;

        static {
            Iterator it = EnumSet.allOf(e.class).iterator();
            while (it.hasNext()) {
                e eVar = (e) it.next();
                h.put(eVar.b(), eVar);
            }
        }

        private e(short s, String str) {
            this.i = s;
            this.j = str;
        }

        public static e a(int i2) {
            switch (i2) {
                case 1:
                    return ID;
                case 2:
                    return START_TIME;
                case 3:
                    return END_TIME;
                case 4:
                    return DURATION;
                case 5:
                    return PAGES;
                case 6:
                    return LOCATIONS;
                case 7:
                    return TRAFFIC;
                default:
                    return null;
            }
        }

        public static e a(String str) {
            return h.get(str);
        }

        public static e b(int i2) {
            e a = a(i2);
            if (a != null) {
                return a;
            }
            throw new IllegalArgumentException("Field " + i2 + " doesn't exist!");
        }

        @Override // u.aly.co
        public short a() {
            return this.i;
        }

        @Override // u.aly.co
        public String b() {
            return this.j;
        }
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: MutableMD:(java.lang.Object, java.lang.Object):java.lang.Object
     arg types: [u.aly.bl$e, u.aly.ct]
     candidates:
      MutableMD:(java.lang.Enum, java.lang.Object):java.lang.Object
      MutableMD:(java.lang.Object, java.lang.Object):java.lang.Object */
    static {
        q.put(dq.class, new b());
        q.put(dr.class, new d());
        EnumMap enumMap = new EnumMap(e.class);
        enumMap.put((Object) e.ID, (Object) new ct(f.bu, (byte) 1, new cu((byte) 11)));
        enumMap.put((Object) e.START_TIME, (Object) new ct(f.bI, (byte) 1, new cu((byte) 10)));
        enumMap.put((Object) e.END_TIME, (Object) new ct(f.bJ, (byte) 1, new cu((byte) 10)));
        enumMap.put((Object) e.DURATION, (Object) new ct("duration", (byte) 1, new cu((byte) 10)));
        enumMap.put((Object) e.PAGES, (Object) new ct("pages", (byte) 2, new cv(dn.m, new cy((byte) 12, bg.class))));
        enumMap.put((Object) e.LOCATIONS, (Object) new ct("locations", (byte) 2, new cv(dn.m, new cy((byte) 12, be.class))));
        enumMap.put((Object) e.TRAFFIC, (Object) new ct("traffic", (byte) 2, new cy((byte) 12, bm.class)));
        h = Collections.unmodifiableMap(enumMap);
        ct.a(bl.class, h);
    }

    public bl() {
        this.f19u = 0;
        this.v = new e[]{e.PAGES, e.LOCATIONS, e.TRAFFIC};
    }

    public bl(String str, long j2, long j3, long j4) {
        this();
        this.a = str;
        this.b = j2;
        b(true);
        this.c = j3;
        c(true);
        this.d = j4;
        d(true);
    }

    public bl(bl blVar) {
        this.f19u = 0;
        this.v = new e[]{e.PAGES, e.LOCATIONS, e.TRAFFIC};
        this.f19u = blVar.f19u;
        if (blVar.e()) {
            this.a = blVar.a;
        }
        this.b = blVar.b;
        this.c = blVar.c;
        this.d = blVar.d;
        if (blVar.t()) {
            ArrayList arrayList = new ArrayList();
            for (bg bgVar : blVar.e) {
                arrayList.add(new bg(bgVar));
            }
            this.e = arrayList;
        }
        if (blVar.y()) {
            ArrayList arrayList2 = new ArrayList();
            for (be beVar : blVar.f) {
                arrayList2.add(new be(beVar));
            }
            this.f = arrayList2;
        }
        if (blVar.B()) {
            this.g = new bm(blVar.g);
        }
    }

    private void a(ObjectInputStream objectInputStream) throws IOException, ClassNotFoundException {
        try {
            this.f19u = 0;
            a(new da(new ds(objectInputStream)));
        } catch (cn e2) {
            throw new IOException(e2.getMessage());
        }
    }

    private void a(ObjectOutputStream objectOutputStream) throws IOException {
        try {
            b(new da(new ds(objectOutputStream)));
        } catch (cn e2) {
            throw new IOException(e2.getMessage());
        }
    }

    public void A() {
        this.g = null;
    }

    public boolean B() {
        return this.g != null;
    }

    public void C() throws cn {
        if (this.a == null) {
            throw new dh("Required field 'id' was not present! Struct: " + toString());
        } else if (this.g != null) {
            this.g.j();
        }
    }

    /* renamed from: a */
    public e b(int i2) {
        return e.a(i2);
    }

    /* renamed from: a */
    public bl g() {
        return new bl(this);
    }

    public bl a(long j2) {
        this.b = j2;
        b(true);
        return this;
    }

    public bl a(String str) {
        this.a = str;
        return this;
    }

    public bl a(List<bg> list) {
        this.e = list;
        return this;
    }

    public bl a(bm bmVar) {
        this.g = bmVar;
        return this;
    }

    public void a(be beVar) {
        if (this.f == null) {
            this.f = new ArrayList();
        }
        this.f.add(beVar);
    }

    public void a(bg bgVar) {
        if (this.e == null) {
            this.e = new ArrayList();
        }
        this.e.add(bgVar);
    }

    @Override // u.aly.ch
    public void a(dg dgVar) throws cn {
        q.get(dgVar.D()).b().b(dgVar, this);
    }

    public void a(boolean z) {
        if (!z) {
            this.a = null;
        }
    }

    public bl b(long j2) {
        this.c = j2;
        c(true);
        return this;
    }

    public bl b(List<be> list) {
        this.f = list;
        return this;
    }

    @Override // u.aly.ch
    public void b() {
        this.a = null;
        b(false);
        this.b = 0;
        c(false);
        this.c = 0;
        d(false);
        this.d = 0;
        this.e = null;
        this.f = null;
        this.g = null;
    }

    @Override // u.aly.ch
    public void b(dg dgVar) throws cn {
        q.get(dgVar.D()).b().a(dgVar, this);
    }

    public void b(boolean z) {
        this.f19u = ce.a(this.f19u, 0, z);
    }

    public String c() {
        return this.a;
    }

    public bl c(long j2) {
        this.d = j2;
        d(true);
        return this;
    }

    public void c(boolean z) {
        this.f19u = ce.a(this.f19u, 1, z);
    }

    public void d() {
        this.a = null;
    }

    public void d(boolean z) {
        this.f19u = ce.a(this.f19u, 2, z);
    }

    public void e(boolean z) {
        if (!z) {
            this.e = null;
        }
    }

    public boolean e() {
        return this.a != null;
    }

    public long f() {
        return this.b;
    }

    public void f(boolean z) {
        if (!z) {
            this.f = null;
        }
    }

    public void g(boolean z) {
        if (!z) {
            this.g = null;
        }
    }

    public void h() {
        this.f19u = ce.b(this.f19u, 0);
    }

    public boolean i() {
        return ce.a(this.f19u, 0);
    }

    public long j() {
        return this.c;
    }

    public void k() {
        this.f19u = ce.b(this.f19u, 1);
    }

    public boolean l() {
        return ce.a(this.f19u, 1);
    }

    public long m() {
        return this.d;
    }

    public void n() {
        this.f19u = ce.b(this.f19u, 2);
    }

    public boolean o() {
        return ce.a(this.f19u, 2);
    }

    public int p() {
        if (this.e == null) {
            return 0;
        }
        return this.e.size();
    }

    public Iterator<bg> q() {
        if (this.e == null) {
            return null;
        }
        return this.e.iterator();
    }

    public List<bg> r() {
        return this.e;
    }

    public void s() {
        this.e = null;
    }

    public boolean t() {
        return this.e != null;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("Session(");
        sb.append("id:");
        if (this.a == null) {
            sb.append(f.b);
        } else {
            sb.append(this.a);
        }
        sb.append(", ");
        sb.append("start_time:");
        sb.append(this.b);
        sb.append(", ");
        sb.append("end_time:");
        sb.append(this.c);
        sb.append(", ");
        sb.append("duration:");
        sb.append(this.d);
        if (t()) {
            sb.append(", ");
            sb.append("pages:");
            if (this.e == null) {
                sb.append(f.b);
            } else {
                sb.append(this.e);
            }
        }
        if (y()) {
            sb.append(", ");
            sb.append("locations:");
            if (this.f == null) {
                sb.append(f.b);
            } else {
                sb.append(this.f);
            }
        }
        if (B()) {
            sb.append(", ");
            sb.append("traffic:");
            if (this.g == null) {
                sb.append(f.b);
            } else {
                sb.append(this.g);
            }
        }
        sb.append(")");
        return sb.toString();
    }

    public int u() {
        if (this.f == null) {
            return 0;
        }
        return this.f.size();
    }

    public Iterator<be> v() {
        if (this.f == null) {
            return null;
        }
        return this.f.iterator();
    }

    public List<be> w() {
        return this.f;
    }

    public void x() {
        this.f = null;
    }

    public boolean y() {
        return this.f != null;
    }

    public bm z() {
        return this.g;
    }
}
