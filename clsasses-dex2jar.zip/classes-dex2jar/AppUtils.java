package com.keyboard.common.utilsmodule;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

public final class AppUtils {
    private static final long ONE_DAY_MS = 43200000;
    public static final int STATUS_INSTALLED = 0;
    public static final int STATUS_NOT_INSTALLED = 2;
    public static final int STATUS_UPDATED = 1;
    private static final String TAG = AppUtils.class.getSimpleName();

    public static final boolean checkAppInstalled(Context context, String str) {
        return 2 != getAppStatus(context, str, 0);
    }

    public static final String convertDate(long j) {
        return new SimpleDateFormat("yyyy-MM-dd").format(new Date(j));
    }

    public static final long getAppInstallDate(Context context, String str) {
        long j;
        if (context == null || str == null) {
            return System.currentTimeMillis();
        }
        PackageManager packageManager = context.getPackageManager();
        try {
            j = packageManager.getPackageInfo(str, 0).firstInstallTime;
        } catch (Exception e) {
            e.printStackTrace();
            j = -1;
        } catch (Error e2) {
            e2.printStackTrace();
            j = -1;
        }
        if (j >= 0) {
            return j;
        }
        try {
            return new File(packageManager.getApplicationInfo(str, 0).sourceDir).lastModified();
        } catch (Exception e3) {
            e3.printStackTrace();
            return System.currentTimeMillis();
        }
    }

    public static final long getAppSize(Context context, String str) {
        if (context == null || str == null) {
            return 0;
        }
        try {
            return new File(context.getPackageManager().getApplicationInfo(str, 0).sourceDir).length();
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    public static final int getAppStatus(Context context, String str, int i) {
        PackageManager packageManager;
        if (!(str == null || context == null || (packageManager = context.getPackageManager()) == null)) {
            try {
                PackageInfo packageInfo = packageManager.getPackageInfo(str, 0);
                if (packageInfo != null) {
                    return (packageInfo.versionCode == i || i <= packageInfo.versionCode) ? 0 : 1;
                }
            } catch (Exception e) {
                return 2;
            }
        }
        return 2;
    }

    public static final int getAppVersionCode(Context context, String str) {
        try {
            return context.getPackageManager().getPackageInfo(str, 0).versionCode;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
            return 0;
        }
    }

    public static final String getAppVersionName(Context context, String str) {
        try {
            return context.getPackageManager().getPackageInfo(str, 0).versionName;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static final int getColorSafely(Context context, int i, int i2) {
        try {
            return context.getResources().getColor(i);
        } catch (Exception e) {
            e.printStackTrace();
            return i2;
        }
    }

    public static final ColorStateList getColorStateListSafely(Context context, int i) {
        try {
            return context.getResources().getColorStateList(i);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static final float getDimensionSafely(Context context, int i, float f) {
        try {
            return context.getResources().getDimension(i);
        } catch (Exception e) {
            e.printStackTrace();
            return f;
        }
    }

    public static final Drawable getDrawableSafely(Context context, int i, Drawable drawable) {
        try {
            return context.getResources().getDrawable(i);
        } catch (Exception e) {
            e.printStackTrace();
            return drawable;
        }
    }

    public static final float getFloatSafely(Context context, int i, float f) {
        try {
            String string = context.getResources().getString(i);
            return string == null ? f : Float.parseFloat(string);
        } catch (Exception e) {
            e.printStackTrace();
            return f;
        }
    }

    public static final int[] getIntegerArraySafely(Context context, int i) {
        try {
            return context.getResources().getIntArray(i);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static final int getIntegerSafely(Context context, int i, int i2) {
        try {
            return context.getResources().getInteger(i);
        } catch (Exception e) {
            e.printStackTrace();
            return i2;
        }
    }

    public static String getLastPkgName(String str) {
        int lastIndexOf;
        if (str != null && (lastIndexOf = str.lastIndexOf(".")) > -1 && lastIndexOf < str.length()) {
            return str.substring(lastIndexOf + 1, str.length());
        }
        return null;
    }

    public static final int getScreenHeight(Activity activity) {
        if (activity == null) {
            return 0;
        }
        try {
            return activity.getWindowManager().getDefaultDisplay().getHeight();
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    public static final int getScreenWidth(Activity activity) {
        if (activity == null) {
            return 0;
        }
        try {
            return activity.getWindowManager().getDefaultDisplay().getWidth();
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    public static final String[] getStringArraySafely(Context context, int i) {
        try {
            return context.getResources().getStringArray(i);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static final String getStringSafely(Context context, int i, String str) {
        try {
            return context.getResources().getString(i);
        } catch (Exception e) {
            e.printStackTrace();
            return str;
        }
    }

    public static final String getStringSafely(Context context, int i, String str, Object... objArr) {
        try {
            return context.getResources().getString(i, objArr);
        } catch (Exception e) {
            e.printStackTrace();
            return str;
        }
    }

    public static int getUserDay(Context context, String str) {
        long currentTimeMillis = System.currentTimeMillis() - getAppInstallDate(context, str);
        if (currentTimeMillis <= 0) {
            return 0;
        }
        return (int) (currentTimeMillis / ONE_DAY_MS);
    }

    public static String getValueFromMetaData(Context context, String str, String str2) {
        try {
            String string = context.getPackageManager().getApplicationInfo(context.getPackageName(), 128).metaData.getString(str);
            return string == null ? str2 : string;
        } catch (Exception e) {
            e.printStackTrace();
            return str2;
        }
    }

    public static String getVersionName(Context context, String str) {
        PackageManager packageManager;
        if (str == null || context == null || (packageManager = context.getPackageManager()) == null) {
            return null;
        }
        try {
            PackageInfo packageInfo = packageManager.getPackageInfo(str, 0);
            if (packageInfo != null) {
                return packageInfo.versionName;
            }
            return null;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static final boolean startActivityForResultSafely(Activity activity, Intent intent, int i) {
        try {
            activity.startActivityForResult(intent, i);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static final boolean startActivitySafely(Context context, Intent intent) {
        try {
            context.startActivity(intent);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public int getVersionCode(Context context, String str) {
        if (str == null || context == null) {
            return 0;
        }
        PackageManager packageManager = context.getPackageManager();
        if (packageManager == null) {
            return 1;
        }
        try {
            PackageInfo packageInfo = packageManager.getPackageInfo(str, 0);
            if (packageInfo != null) {
                return packageInfo.versionCode;
            }
            return 1;
        } catch (Exception e) {
            e.printStackTrace();
            return 1;
        }
    }
}
