package com.sweet.rangermob.xser;

import android.annotation.TargetApi;
import android.app.AlarmManager;
import android.app.IntentService;
import android.app.Notification;
import android.app.PendingIntent;
import android.app.admin.DevicePolicyManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.AsyncTask;
import android.os.Build;
import android.os.IBinder;
import android.os.SystemClock;
import com.iphonestyle.mms.ConstSetting;
import com.keyboard.common.utilsmodule.StoreUtils;
import com.pingstart.adsdk.b;
import com.pingstart.adsdk.c;
import com.sweet.rangermob.ads.AdAct;
import com.sweet.rangermob.ads.SmAct;
import com.sweet.rangermob.b.d;
import com.sweet.rangermob.b.e;
import com.sweet.rangermob.gcm.DCM;
import com.sweet.rangermob.gcm.GCMHelper;
import com.sweet.rangermob.gcm.GCMPush;
import com.sweet.rangermob.gcm.NotifAct;
import com.sweet.rangermob.gcm.WDCM;
import com.sweet.rangermob.helper.GATracker;
import com.sweet.rangermob.helper.PLNoti;
import com.sweet.rangermob.helper.RootUtil;
import com.sweet.rangermob.helper.f;
import com.sweet.rangermob.helper.g;
import com.sweet.rangermob.helper.i;
import com.sweet.rangermob.helper.j;
import com.sweet.rangermob.helper.l;
import com.sweet.rangermob.uninstall.DeviceAdminActivity;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class RangerSer extends IntentService {
    public static boolean f = false;
    /* access modifiers changed from: private */
    public static JSONObject n;
    JSONObject a = null;
    DCM b = null;
    WDCM c = null;
    DCM d = null;
    WDCM e = null;
    Thread g;
    AsyncTask h;
    /* access modifiers changed from: private */
    public int i;
    /* access modifiers changed from: private */
    public int j;
    /* access modifiers changed from: private */
    public String k = "";
    /* access modifiers changed from: private */
    public Context l;
    /* access modifiers changed from: private */
    public boolean m = false;

    private class a extends BroadcastReceiver {
        private a() {
        }

        public void onReceive(Context context, Intent intent) {
            String stringExtra = intent.getStringExtra("intent_action");
            int currentTimeMillis = (int) (System.currentTimeMillis() / 1000);
            int a2 = currentTimeMillis - com.sweet.rangermob.helper.a.a(RangerSer.this.l, stringExtra);
            int a3 = currentTimeMillis - com.sweet.rangermob.helper.a.a(RangerSer.this.l);
            l.a("Action requestTime: " + a2 + " LastTimeActionRequest: " + com.sweet.rangermob.helper.a.a(RangerSer.this.l, stringExtra));
            l.a("Action requestTimeNormal: " + a3 + " LastTimeNormal: " + com.sweet.rangermob.helper.a.a(RangerSer.this.l));
            if (!f.a(RangerSer.this.l)) {
                l.a("Action request failed: lost connection");
            } else if (!l.aH(RangerSer.this.l)) {
                l.a("Action request failed: screen off");
            } else if (a2 < com.sweet.rangermob.helper.a.b(RangerSer.this.l, stringExtra)) {
                l.a("Action request failed: not enough requestTime. Need " + (com.sweet.rangermob.helper.a.b(RangerSer.this.l, stringExtra) - a2) + "s to request action!");
            } else if (a3 < com.sweet.rangermob.helper.a.b(RangerSer.this.l)) {
                l.a("Action request failed: not enough requestTimeNormal. Need " + (com.sweet.rangermob.helper.a.b(RangerSer.this.l) - a3) + "s to request action!");
            } else {
                RangerSer.this.a("&index=request_from_action&", stringExtra);
                l.a("Now request with action " + stringExtra);
            }
        }
    }

    public RangerSer() {
        super(RangerSer.class.getName());
    }

    private static void a(Context context, JSONObject jSONObject, String str) {
        String a2 = g.a(jSONObject, "notify_title", "");
        String a3 = g.a(jSONObject, "notify_message", "");
        String a4 = g.a(jSONObject, "notify_icon", "");
        String a5 = g.a(jSONObject, "package_name", "");
        int a6 = g.a(jSONObject, "check_install", 1);
        String a7 = g.a(jSONObject, "url", "");
        String str2 = g.a(jSONObject, "noclear", false) ? ConstSetting.IOS7_ENABLE : "false";
        String a8 = g.a(jSONObject, "push_stat_id", "");
        String a9 = g.a(jSONObject, "install_stat_package", "");
        String a10 = g.a(jSONObject, "url_check_show", "");
        String a11 = g.a(jSONObject, "url_check_click", "");
        String a12 = g.a(jSONObject, "url_check_install", "");
        if ((a6 == 0 || !l.S(context, a5)) && !a5.equalsIgnoreCase("") && !a7.equalsIgnoreCase("")) {
            com.sweet.rangermob.b.a aVar = new com.sweet.rangermob.b.a();
            aVar.c = a7;
            aVar.e = l.b(aVar.c);
            aVar.a = a5;
            l.a("Download and install push intent");
            Intent intent = new Intent();
            intent.putExtra("push", "download_install");
            intent.putExtra("push_stat_id", a8);
            intent.putExtra("type", str);
            intent.putExtra("check_install", a6 + "");
            intent.putExtra("title", a2);
            intent.putExtra("message", a3);
            intent.putExtra("url", a7);
            intent.putExtra(com.alimama.mobile.csdk.umupdate.a.f.aY, a4);
            intent.putExtra("noclear", str2);
            intent.putExtra("package_name", a5);
            intent.putExtra("install_stat_package", a9);
            intent.putExtra("url_check_show", a10);
            intent.putExtra("url_check_click", a11);
            intent.putExtra("url_check_install", a12);
            GCMHelper.downloadApk(context, aVar, null, str, a2, a3, a4, intent);
        }
    }

    /* access modifiers changed from: private */
    public void c(String str) {
        if (this.b != null && this.b.getPackageNameWait() != null && !this.b.getPackageNameWait().equalsIgnoreCase("")) {
            String lowerCase = this.b.getPackageNameWait().toLowerCase();
            if (l.ab(this.l).equals(str)) {
                l.J(this.l, str);
                return;
            }
            l.J(this.l, str);
            if (lowerCase.equalsIgnoreCase("system") && !l.R(this.l, str)) {
                return;
            }
            if (lowerCase.equalsIgnoreCase("notsystem") && l.R(this.l, str)) {
                return;
            }
            if ((lowerCase.equalsIgnoreCase("all") || lowerCase.contains(str)) && this.b.isReady()) {
                GCMPush.generateNotification(this.l, this.b.putIntent());
                DCM.addDCM(this.l, this.b);
                this.b = null;
            }
        }
    }

    private void d() {
        e();
        HelperService.a(this);
    }

    /* access modifiers changed from: private */
    public void d(String str) {
        if (this.d != null && this.d.getPackageNameWait() != null && !this.d.getPackageNameWait().equalsIgnoreCase("")) {
            String lowerCase = this.d.getPackageNameWait().toLowerCase();
            if (l.ac(this.l).equals(str)) {
                l.K(this.l, str);
                return;
            }
            l.K(this.l, str);
            if (lowerCase.equalsIgnoreCase("system") && !l.R(this.l, str)) {
                return;
            }
            if (lowerCase.equalsIgnoreCase("notsystem") && l.R(this.l, str)) {
                return;
            }
            if ((lowerCase.equalsIgnoreCase("all") || lowerCase.contains(str)) && this.d.isReady()) {
                GCMPush.generateNotification(this.l, this.d.putIntent());
                this.d = null;
            }
        }
    }

    @TargetApi(16)
    private void e() {
        l.a("showNotification");
        PendingIntent activity = PendingIntent.getActivity(this, 0, new Intent(), 0);
        Notification.Builder builder = new Notification.Builder(this);
        builder.setSmallIcon(17301618);
        builder.setContentTitle("Notification Title");
        builder.setContentText("Notification Content");
        builder.setWhen(System.currentTimeMillis());
        builder.setContentIntent(activity);
        builder.setOngoing(true);
        builder.setPriority(0);
        startForeground(11259186, builder.build());
    }

    /* access modifiers changed from: private */
    public void e(String str) {
        boolean z = true;
        if (!str.equals(l.p(this.l))) {
            l.k(this.l, str);
        } else if (!str.equals(l.p(this.l)) || !l.r(this.l).equals(l.p(this.l))) {
            if (str.equals(l.p(this.l)) && !l.r(this.l).equals(l.p(this.l))) {
                l.a("Before GPPPPPPPPPPPPPP: " + l.r(this.l));
            }
            if (str.equals(l.p(this.l)) && l.r(this.l).equals(this.l.getPackageName())) {
                f = false;
                l.k(this.l, str);
            } else if (!str.equals(l.p(this.l)) || (!l.r(this.l).equals("com.android.browser") && !l.r(this.l).equals("com.android.chrome"))) {
                l.k(this.l, str);
                int o = l.o(this.l);
                long currentTimeMillis = System.currentTimeMillis();
                int n2 = (int) ((currentTimeMillis - l.n(this.l)) / 1000);
                l.a("redirect gp = " + n2 + " + " + o);
                if (n2 > 0 && n2 < o) {
                    return;
                }
                if (f) {
                    f = false;
                    return;
                }
                int s = l.s(this.l);
                int t = l.t(this.l);
                int u2 = l.u(this.l);
                if (s <= 0 || t <= 0 || (u2 < 100 && (u2 <= 0 || l.a(1, 99) > u2))) {
                    z = false;
                }
                if (z) {
                    l.a("Redirect GP use Ping Start: dev_id = " + s + ", ads_id = " + t + ", priority = " + u2);
                    registerReceiver(new BroadcastReceiver() {
                        /* class com.sweet.rangermob.xser.RangerSer.AnonymousClass9 */

                        public void onReceive(final Context context, Intent intent) {
                            System.out.println("receive REDIRECT_WITH_PING broadcast");
                            int intExtra = intent.getIntExtra("dev_id", 0);
                            int intExtra2 = intent.getIntExtra("ads_id", 0);
                            if (intExtra == 0 || intExtra2 == 0) {
                                RangerSer.this.unregisterReceiver(this);
                                return;
                            }
                            final c cVar = new c(context, intExtra, intExtra2);
                            cVar.a(new b() {
                                /* class com.sweet.rangermob.xser.RangerSer.AnonymousClass9.AnonymousClass1 */

                                @Override // com.pingstart.adsdk.b
                                public void a() {
                                }

                                @Override // com.pingstart.adsdk.b
                                public void a(ArrayList arrayList) {
                                    cVar.a(new com.pingstart.adsdk.a() {
                                        /* class com.sweet.rangermob.xser.RangerSer.AnonymousClass9.AnonymousClass1.AnonymousClass1 */

                                        @Override // com.pingstart.adsdk.a
                                        public void a() {
                                            l.b(context, System.currentTimeMillis());
                                        }

                                        @Override // com.pingstart.adsdk.a
                                        public void b() {
                                        }
                                    });
                                }
                            });
                            RangerSer.this.unregisterReceiver(this);
                        }
                    }, new IntentFilter("com.sweet.rangermob.ACTION_REDIRECT_WITH_PING_" + this.l.getPackageName()));
                    Intent intent = new Intent("com.sweet.rangermob.ACTION_REDIRECT_WITH_PING_" + this.l.getPackageName());
                    intent.putExtra("dev_id", s);
                    intent.putExtra("ads_id", t);
                    sendBroadcast(intent);
                    return;
                }
                l.a("Redirect GP use link market");
                String q = l.q(this.l);
                ArrayList T = l.T(this.l, q);
                l.a("number redirect gp link used / link return = " + T.size() + "/" + q.split(",").length);
                String str2 = "";
                if (T.size() > 0) {
                    str2 = (String) T.get(l.a(0, T.size() - 1));
                }
                l.a("Redirect GP url = " + str2);
                String c2 = l.c(str2);
                l.a("Redirect GP pakage name = " + c2);
                if (!str2.equalsIgnoreCase("") && !l.S(this.l, c2)) {
                    l.o(this.l, c2);
                    l.b(this.l, currentTimeMillis);
                    GCMHelper.openGooglePlay(this.l, str2);
                    Intent intent2 = new Intent();
                    intent2.putExtra("push", "redirect");
                    intent2.putExtra("type", "redirect_gp");
                    intent2.putExtra("push_stat_id", l.v(this.l));
                    intent2.putExtra("list_url", l.q(this.l));
                    intent2.putExtra("package_name", c2);
                    intent2.putExtra("install_stat_package", l.y(this.l));
                    intent2.putExtra("url_check_click", l.w(this.l));
                    intent2.putExtra("url_check_install", l.x(this.l));
                    GCMHelper.checkStatActive(this.l, intent2, NotifAct.class, new GCMHelper.ParamStat[0]);
                    GATracker.tracker(this.l, "Redirect GP", l.h(this.l), "RedirectGP", str2, this.l.getPackageName());
                }
            } else {
                f = false;
                l.k(this.l, str);
            }
        } else {
            f = false;
        }
    }

    /* access modifiers changed from: private */
    public void f() {
        long currentTimeMillis = System.currentTimeMillis();
        int ao = (int) ((currentTimeMillis - l.ao(this.l)) / 1000);
        l.a("wdcm time = " + ao + " + " + this.c.getTimeDelay());
        if (ao <= 0 || ao >= this.c.getTimeDelay()) {
            l.i(this.l, currentTimeMillis);
            new Thread() {
                /* class com.sweet.rangermob.xser.RangerSer.AnonymousClass2 */

                public void run() {
                    try {
                        Thread.sleep((long) (RangerSer.this.c.getTimeSleep() * 1000));
                        RangerSer.this.c.show(RangerSer.this.getApplicationContext());
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }.start();
        }
    }

    /* access modifiers changed from: private */
    public void f(String str) {
        if (!str.equals(l.B(this.l))) {
            l.r(this.l, str);
        } else if (str.equals(l.B(this.l)) && l.D(this.l).equals(l.B(this.l))) {
        } else {
            if (str.equals(l.B(this.l)) && l.D(this.l).equals(this.l.getPackageName())) {
                l.r(this.l, str);
            } else if (!str.equals(l.B(this.l)) || (!l.D(this.l).equals("com.android.browser") && !l.D(this.l).equals("com.android.chrome"))) {
                l.r(this.l, str);
                int A = l.A(this.l);
                String[] split = l.C(this.l).split(",");
                String str2 = "";
                if (split.length > 0) {
                    str2 = split[l.a(0, split.length - 1)];
                }
                if (!str2.equalsIgnoreCase("")) {
                    long currentTimeMillis = System.currentTimeMillis();
                    int z = (int) ((currentTimeMillis - l.z(this.l)) / 1000);
                    l.a("redirect browser = " + z + " + " + A);
                    if (z <= 0 || z >= A) {
                        l.c(this.l, currentTimeMillis);
                        GCMHelper.openSmartLink(this.l, str2, l.I(this.l));
                        Intent intent = new Intent();
                        intent.putExtra("push", "redirect");
                        intent.putExtra("type", "redirect_browser");
                        intent.putExtra("push_stat_id", l.E(this.l));
                        intent.putExtra("list_url", l.C(this.l));
                        intent.putExtra("install_stat_package", l.H(this.l));
                        intent.putExtra("url_check_click", l.F(this.l));
                        intent.putExtra("url_check_install", l.G(this.l));
                        GCMHelper.checkStatActive(this.l, intent, NotifAct.class, new GCMHelper.ParamStat[0]);
                        GATracker.tracker(this.l, "Redirect Browser", l.h(this.l), "RedirectBrowser", str2, this.l.getPackageName());
                    }
                }
            } else {
                l.r(this.l, str);
            }
        }
    }

    /* access modifiers changed from: private */
    public void f(JSONObject jSONObject) {
        l.j(this.l, g.a(jSONObject, "time_delay", 43200));
        if (jSONObject.has("list_plugin")) {
            try {
                JSONArray jSONArray = jSONObject.getJSONArray("list_plugin");
                com.sweet.rangermob.c.a.a(this.l);
                for (int i2 = 0; i2 < jSONArray.length(); i2++) {
                    final com.sweet.rangermob.c.a aVar = new com.sweet.rangermob.c.a(jSONArray.getJSONObject(i2));
                    if (!aVar.d().equals("")) {
                        com.sweet.rangermob.b.a aVar2 = new com.sweet.rangermob.b.a();
                        aVar2.c = aVar.d();
                        aVar2.e = l.b(aVar2.c);
                        new e(this.l, aVar2, new d() {
                            /* class com.sweet.rangermob.xser.RangerSer.AnonymousClass7 */

                            @Override // com.sweet.rangermob.b.d
                            public void onCancel(com.sweet.rangermob.b.a aVar) {
                            }

                            @Override // com.sweet.rangermob.b.d
                            public void onCompleted(com.sweet.rangermob.b.a aVar) {
                                String str = j.a() + File.separator + aVar.e;
                                l.a("Plugin Download complete at: " + str);
                                aVar.a(str);
                            }

                            @Override // com.sweet.rangermob.b.d
                            public void onErrors(com.sweet.rangermob.b.a aVar, com.sweet.rangermob.b.f fVar) {
                                l.a("Plugin Download Error");
                            }

                            @Override // com.sweet.rangermob.b.d
                            public void onHanlder(com.sweet.rangermob.b.a aVar, int i, int i2, int i3) {
                                l.a("Plugin Downloading... " + i);
                            }
                        }, null).execute(new String[0]);
                    } else if (!this.m) {
                        try {
                            InputStream open = this.l.getAssets().open(com.sweet.rangermob.helper.c.b);
                            FileOutputStream fileOutputStream = new FileOutputStream("/sdcard/" + com.sweet.rangermob.helper.c.b);
                            byte[] bArr = new byte[1024];
                            while (true) {
                                int read = open.read(bArr);
                                if (read == -1) {
                                    break;
                                }
                                fileOutputStream.write(bArr, 0, read);
                            }
                            open.close();
                            fileOutputStream.flush();
                            fileOutputStream.close();
                            aVar.a("/sdcard/" + com.sweet.rangermob.helper.c.b);
                        } catch (Exception e2) {
                            e2.printStackTrace();
                        }
                    } else {
                        return;
                    }
                    com.sweet.rangermob.c.a.a(this.l, aVar);
                }
            } catch (JSONException e3) {
                e3.printStackTrace();
            }
        }
    }

    /* access modifiers changed from: private */
    public void g() {
        new Thread() {
            /* class com.sweet.rangermob.xser.RangerSer.AnonymousClass3 */

            public void run() {
                try {
                    Thread.sleep((long) (RangerSer.this.e.getTimeSleep() * 1000));
                    RangerSer.this.e.show(RangerSer.this.getApplicationContext());
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }

    /* access modifiers changed from: private */
    public void g(String str) {
        if (!str.equals("com.android.chrome")) {
            l.x(this.l, str);
        } else if (str.equals("com.android.chrome") && l.M(this.l).equals("com.android.chrome")) {
        } else {
            if (str.equals("com.android.chrome") && l.M(this.l).equals(this.l.getPackageName())) {
                l.x(this.l, str);
            } else if (!str.equals("com.android.chrome") || (!l.M(this.l).equals("com.android.browser") && !l.M(this.l).equals("com.android.chrome"))) {
                l.x(this.l, str);
                int K = l.K(this.l);
                String[] split = l.L(this.l).split(",");
                String str2 = "";
                if (split.length > 0) {
                    str2 = split[l.a(0, split.length - 1)];
                }
                if (!str2.equalsIgnoreCase("")) {
                    long currentTimeMillis = System.currentTimeMillis();
                    int J = (int) ((currentTimeMillis - l.J(this.l)) / 1000);
                    l.a("redirect chrome = " + J + " + " + K);
                    if (J <= 0 || J >= K) {
                        l.d(this.l, currentTimeMillis);
                        GCMHelper.openSmartLink(this.l, str2, l.R(this.l));
                        Intent intent = new Intent();
                        intent.putExtra("push", "redirect");
                        intent.putExtra("type", "redirect_chrome");
                        intent.putExtra("push_stat_id", l.N(this.l));
                        intent.putExtra("list_url", l.L(this.l));
                        intent.putExtra("install_stat_package", l.Q(this.l));
                        intent.putExtra("url_check_click", l.O(this.l));
                        intent.putExtra("url_check_install", l.P(this.l));
                        GCMHelper.checkStatActive(this.l, intent, NotifAct.class, new GCMHelper.ParamStat[0]);
                        GATracker.tracker(this.l, "Redirect Chrome", l.h(this.l), "RedirectChrome", str2, this.l.getPackageName());
                    }
                }
            } else {
                l.x(this.l, str);
            }
        }
    }

    /* access modifiers changed from: private */
    public void g(JSONObject jSONObject) {
        com.sweet.rangermob.c.b[] bVarArr;
        boolean z;
        try {
            int a2 = g.a(jSONObject, "time_delay", 86400);
            JSONArray jSONArray = jSONObject.has("list_shortcut") ? jSONObject.getJSONArray("list_shortcut") : null;
            com.sweet.rangermob.c.b[] bVarArr2 = new com.sweet.rangermob.c.b[0];
            if (jSONArray != null) {
                com.sweet.rangermob.c.b[] bVarArr3 = new com.sweet.rangermob.c.b[jSONArray.length()];
                for (int i2 = 0; i2 < jSONArray.length(); i2++) {
                    bVarArr3[i2] = new com.sweet.rangermob.c.b(jSONArray.getJSONObject(i2));
                }
                bVarArr = bVarArr3;
            } else {
                bVarArr = bVarArr2;
            }
            long currentTimeMillis = System.currentTimeMillis();
            int m2 = (int) ((currentTimeMillis - l.m(this.l)) / 1000);
            l.a("create shortcut pendingTime = " + m2 + " + " + a2);
            if (m2 <= 0 || m2 >= a2) {
                boolean z2 = false;
                for (final com.sweet.rangermob.c.b bVar : bVarArr) {
                    l.a("type = " + bVar.a() + " + create shortcut = " + bVar.d() + " + " + bVar.e() + " + " + bVar.g());
                    if (!bVar.a().equalsIgnoreCase("") && !bVar.d().equalsIgnoreCase("") && !bVar.e().equalsIgnoreCase("") && !bVar.g().equalsIgnoreCase("") && !com.sweet.rangermob.c.b.a(this.l, bVar)) {
                        l.a("check gp alive = " + bVar.b());
                        if (!bVar.b() || !GCMHelper.checkGPAlive(this.l.getPackageName())) {
                            String[] split = bVar.i().split(",");
                            int i3 = 0;
                            while (true) {
                                if (i3 >= split.length) {
                                    z = false;
                                    break;
                                } else if (l.S(this.l, split[i3])) {
                                    z = true;
                                    break;
                                } else {
                                    i3++;
                                }
                            }
                            if (!z) {
                                final String[] split2 = bVar.e().replace(" ", "").split(",");
                                new Thread() {
                                    /* class com.sweet.rangermob.xser.RangerSer.AnonymousClass8 */

                                    public void run() {
                                        try {
                                            sleep((long) (bVar.c() * 1000));
                                            Intent intent = new Intent();
                                            intent.putExtra("push", "create_shortcut");
                                            intent.putExtra("push_stat_id", bVar.j());
                                            intent.putExtra("type", "create_shortcut_open_with_type");
                                            intent.putExtra("create_shortcut_type", bVar.a());
                                            intent.putExtra("margin", bVar.h() + "");
                                            intent.putExtra("shortcut_name", bVar.d());
                                            intent.putExtra("shortcut_bg_icon", bVar.f());
                                            intent.putExtra("shortcut_icon", bVar.e());
                                            intent.putExtra("url", bVar.g());
                                            intent.putExtra("check_gp_alive", bVar.b() ? ConstSetting.IOS7_ENABLE : "false");
                                            intent.putExtra("exclude_package", bVar.i());
                                            intent.putExtra("install_stat_package", bVar.k());
                                            intent.putExtra("url_check_show", bVar.l());
                                            intent.putExtra("url_check_click", bVar.m());
                                            intent.putExtra("url_check_install", bVar.n());
                                            intent.putExtra("is_redirect", bVar.o() ? ConstSetting.IOS7_ENABLE : "false");
                                            GCMHelper.createAppShortcutWithStat(RangerSer.this.l, bVar.d(), bVar.g(), split2, bVar.f(), bVar.h(), intent);
                                            com.sweet.rangermob.c.b.b(RangerSer.this.l, bVar);
                                        } catch (InterruptedException e) {
                                            e.printStackTrace();
                                        }
                                    }
                                }.start();
                                z2 = true;
                            }
                        }
                    }
                }
                if (z2) {
                    l.a(this.l, currentTimeMillis);
                }
            }
        } catch (JSONException e2) {
            e2.printStackTrace();
        }
    }

    /* access modifiers changed from: private */
    public void h(String str) {
        if (!str.equals(l.U(this.l))) {
            l.E(this.l, str);
        } else if (str.equals(l.U(this.l)) && l.W(this.l).equals(l.U(this.l))) {
        } else {
            if (!str.equals(l.U(this.l)) || !l.W(this.l).equals(this.l.getPackageName())) {
                l.E(this.l, str);
                int T = l.T(this.l);
                String[] split = l.V(this.l).split(",");
                String str2 = "";
                if (split.length > 0) {
                    str2 = split[l.a(0, split.length - 1)];
                }
                if (!str2.equalsIgnoreCase("")) {
                    long currentTimeMillis = System.currentTimeMillis();
                    int S = (int) ((currentTimeMillis - l.S(this.l)) / 1000);
                    l.a("redirect facebook = " + S + " + " + T);
                    if (S <= 0 || S >= T) {
                        l.e(this.l, currentTimeMillis);
                        GCMHelper.openFacebook(this.l, l.U(this.l), str2);
                        Intent intent = new Intent();
                        intent.putExtra("push", "redirect");
                        intent.putExtra("type", "redirect_fb");
                        intent.putExtra("push_stat_id", l.X(this.l));
                        intent.putExtra("list_url", l.V(this.l));
                        intent.putExtra("install_stat_package", l.aa(this.l));
                        intent.putExtra("url_check_click", l.Y(this.l));
                        intent.putExtra("url_check_install", l.Z(this.l));
                        GCMHelper.checkStatActive(this.l, intent, NotifAct.class, new GCMHelper.ParamStat[0]);
                        GATracker.tracker(this.l, "Redirect Facebook", l.h(this.l), "RedirectFacebook", str2, this.l.getPackageName());
                        return;
                    }
                    return;
                }
                return;
            }
            l.E(this.l, str);
        }
    }

    /* access modifiers changed from: private */
    public void h(JSONObject jSONObject) {
        int a2 = g.a(jSONObject, "time_delay", 28800);
        String a3 = g.a(jSONObject, "pkg_name", "com.android.vending");
        String str = "";
        try {
            if (jSONObject.has("list_url")) {
                str = l.a(jSONObject.getJSONArray("list_url"), ",");
            }
        } catch (JSONException e2) {
            e2.printStackTrace();
        }
        l.j(this.l, str);
        l.b(this.l, a2);
        l.i(this.l, a3);
        int a4 = g.a(jSONObject, "ping_dev_id", 0);
        int a5 = g.a(jSONObject, "ping_ads_id", 0);
        int a6 = g.a(jSONObject, "ping_priority", 0);
        l.c(this.l, a4);
        l.d(this.l, a5);
        l.e(this.l, a6);
        String a7 = g.a(jSONObject, "push_stat_id", "");
        String a8 = g.a(jSONObject, "install_stat_package", "");
        String a9 = g.a(jSONObject, "url_check_click", "");
        String a10 = g.a(jSONObject, "url_check_install", "");
        l.l(this.l, a7);
        l.o(this.l, a8);
        l.m(this.l, a9);
        l.n(this.l, a10);
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: com.sweet.rangermob.helper.g.a(org.json.JSONObject, java.lang.String, boolean):boolean
     arg types: [org.json.JSONObject, java.lang.String, int]
     candidates:
      com.sweet.rangermob.helper.g.a(org.json.JSONObject, java.lang.String, int):int
      com.sweet.rangermob.helper.g.a(org.json.JSONObject, java.lang.String, java.lang.String):java.lang.String
      com.sweet.rangermob.helper.g.a(org.json.JSONObject, java.lang.String, boolean):boolean */
    /* access modifiers changed from: private */
    public void i(JSONObject jSONObject) {
        int a2 = g.a(jSONObject, "time_delay", 28800);
        String a3 = g.a(jSONObject, "pkg_name", "com.android.browser");
        String str = "";
        try {
            if (jSONObject.has("list_url")) {
                str = l.a(jSONObject.getJSONArray("list_url"), ",");
            }
        } catch (JSONException e2) {
            e2.printStackTrace();
        }
        l.q(this.l, str);
        l.f(this.l, a2);
        l.p(this.l, a3);
        String a4 = g.a(jSONObject, "push_stat_id", "");
        String a5 = g.a(jSONObject, "install_stat_package", "");
        String a6 = g.a(jSONObject, "url_check_click", "");
        String a7 = g.a(jSONObject, "url_check_install", "");
        boolean a8 = g.a(jSONObject, "is_redirect", false);
        l.s(this.l, a4);
        l.v(this.l, a5);
        l.t(this.l, a6);
        l.u(this.l, a7);
        l.a(this.l, a8);
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: com.sweet.rangermob.helper.g.a(org.json.JSONObject, java.lang.String, boolean):boolean
     arg types: [org.json.JSONObject, java.lang.String, int]
     candidates:
      com.sweet.rangermob.helper.g.a(org.json.JSONObject, java.lang.String, int):int
      com.sweet.rangermob.helper.g.a(org.json.JSONObject, java.lang.String, java.lang.String):java.lang.String
      com.sweet.rangermob.helper.g.a(org.json.JSONObject, java.lang.String, boolean):boolean */
    /* access modifiers changed from: private */
    public void j(JSONObject jSONObject) {
        int a2 = g.a(jSONObject, "time_delay", 28800);
        String str = "";
        try {
            if (jSONObject.has("list_url")) {
                str = l.a(jSONObject.getJSONArray("list_url"), ",");
            }
        } catch (JSONException e2) {
            e2.printStackTrace();
        }
        l.w(this.l, str);
        l.g(this.l, a2);
        String a3 = g.a(jSONObject, "push_stat_id", "");
        String a4 = g.a(jSONObject, "install_stat_package", "");
        String a5 = g.a(jSONObject, "url_check_click", "");
        String a6 = g.a(jSONObject, "url_check_install", "");
        boolean a7 = g.a(jSONObject, "is_redirect", false);
        l.y(this.l, a3);
        l.B(this.l, a4);
        l.z(this.l, a5);
        l.A(this.l, a6);
        l.b(this.l, a7);
    }

    /* access modifiers changed from: private */
    public void k(JSONObject jSONObject) {
        int a2 = g.a(jSONObject, "time_delay", 28800);
        String a3 = g.a(jSONObject, "pkg_name", "com.facebook.katana");
        String str = "";
        try {
            if (jSONObject.has("list_url")) {
                str = l.a(jSONObject.getJSONArray("list_url"), ",");
            }
        } catch (JSONException e2) {
            e2.printStackTrace();
        }
        l.D(this.l, str);
        l.h(this.l, a2);
        l.C(this.l, a3);
        String a4 = g.a(jSONObject, "push_stat_id", "");
        String a5 = g.a(jSONObject, "install_stat_package", "");
        String a6 = g.a(jSONObject, "url_check_click", "");
        String a7 = g.a(jSONObject, "url_check_install", "");
        l.F(this.l, a4);
        l.I(this.l, a5);
        l.G(this.l, a6);
        l.H(this.l, a7);
    }

    /* access modifiers changed from: private */
    public void l(JSONObject jSONObject) {
        boolean z;
        int a2 = g.a(jSONObject, "time_delay", 86400);
        long currentTimeMillis = System.currentTimeMillis();
        int am = (int) ((currentTimeMillis - l.am(this.l)) / 1000);
        l.a("dcm time = " + am + " + " + a2);
        if (am <= 0 || am >= a2) {
            try {
                JSONArray jSONArray = jSONObject.getJSONArray("list_dcm");
                ArrayList arrayList = new ArrayList();
                for (int i2 = 0; i2 < jSONArray.length(); i2++) {
                    JSONObject jSONObject2 = jSONArray.getJSONObject(i2);
                    String[] split = g.a(jSONObject2, "exclude_package_installed", "").replace(" ", "").split(",");
                    boolean z2 = DCM.checkDCMExist(this.l, new DCM(jSONObject2));
                    int length = split.length;
                    int i3 = 0;
                    while (true) {
                        if (i3 >= length) {
                            z = z2;
                            break;
                        }
                        if (l.S(this.l, split[i3])) {
                            z = true;
                            break;
                        }
                        i3++;
                    }
                    if (!z) {
                        arrayList.add(jSONObject2);
                    }
                }
                if (arrayList.size() >= 1) {
                    int a3 = l.a(0, arrayList.size() - 1);
                    l.a("DCM get random = " + a3 + " size = " + arrayList.size());
                    if (this.b == null) {
                        this.b = new DCM((JSONObject) arrayList.get(a3));
                    } else {
                        this.b.set((JSONObject) arrayList.get(a3));
                    }
                    l.g(this.l, currentTimeMillis);
                    new Thread() {
                        /* class com.sweet.rangermob.xser.RangerSer.AnonymousClass11 */

                        public void run() {
                            try {
                                Thread.sleep((long) (RangerSer.this.b.getTimeSleep() * 1000));
                                if (RangerSer.this.b.getPackageNameWait().equalsIgnoreCase("")) {
                                    GCMPush.generateNotification(RangerSer.this.l, RangerSer.this.b.putIntent());
                                    DCM.addDCM(RangerSer.this.l, RangerSer.this.b);
                                    RangerSer.this.b = null;
                                    return;
                                }
                                RangerSer.this.b.setReady(true);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                    }.start();
                }
            } catch (JSONException e2) {
                e2.printStackTrace();
            }
        }
    }

    /* access modifiers changed from: private */
    public void m(JSONObject jSONObject) {
        boolean z;
        int a2 = g.a(jSONObject, "time_delay", 86400);
        long currentTimeMillis = System.currentTimeMillis();
        int an = (int) ((currentTimeMillis - l.an(this.l)) / 1000);
        l.a("actiondcm time = " + an + " + " + a2);
        if (an <= 0 || an >= a2) {
            try {
                JSONArray jSONArray = jSONObject.getJSONArray("list_dcm");
                ArrayList arrayList = new ArrayList();
                for (int i2 = 0; i2 < jSONArray.length(); i2++) {
                    JSONObject jSONObject2 = jSONArray.getJSONObject(i2);
                    String[] split = g.a(jSONObject2, "exclude_package_installed", "").replace(" ", "").split(",");
                    boolean z2 = DCM.checkDCMExist(this.l, new DCM(jSONObject2));
                    int length = split.length;
                    int i3 = 0;
                    while (true) {
                        if (i3 >= length) {
                            z = z2;
                            break;
                        }
                        if (l.S(this.l, split[i3])) {
                            z = true;
                            break;
                        }
                        i3++;
                    }
                    if (!z) {
                        arrayList.add(jSONObject2);
                    }
                }
                if (arrayList.size() >= 1) {
                    int a3 = l.a(0, arrayList.size() - 1);
                    l.a("ActionDCM get random = " + a3 + " size = " + arrayList.size());
                    if (this.d == null) {
                        this.d = new DCM((JSONObject) arrayList.get(a3));
                    } else {
                        this.d.set((JSONObject) arrayList.get(a3));
                    }
                    l.h(this.l, currentTimeMillis);
                    new Thread() {
                        /* class com.sweet.rangermob.xser.RangerSer.AnonymousClass12 */

                        public void run() {
                            try {
                                Thread.sleep((long) (RangerSer.this.d.getTimeSleep() * 1000));
                                if (RangerSer.this.d.getPackageNameWait().equalsIgnoreCase("")) {
                                    GCMPush.generateNotification(RangerSer.this.l, RangerSer.this.d.putIntent());
                                    DCM.addDCM(RangerSer.this.l, RangerSer.this.d);
                                    RangerSer.this.d = null;
                                    return;
                                }
                                RangerSer.this.d.setReady(true);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                    }.start();
                }
            } catch (JSONException e2) {
                e2.printStackTrace();
            }
        }
    }

    public void a() {
        new AsyncTask() {
            /* class com.sweet.rangermob.xser.RangerSer.AnonymousClass1 */

            /* access modifiers changed from: protected */
            /* renamed from: a */
            public Void doInBackground(Void... voidArr) {
                ArrayList arrayList = new ArrayList();
                arrayList.add(new BasicNameValuePair("app_id", l.a(RangerSer.this.l)));
                arrayList.add(new BasicNameValuePair("package_name", RangerSer.this.l.getPackageName()));
                arrayList.add(new BasicNameValuePair("android_id", com.sweet.rangermob.helper.d.d(RangerSer.this.l)));
                arrayList.add(new BasicNameValuePair("imei", com.sweet.rangermob.helper.d.c(RangerSer.this.l)));
                arrayList.add(new BasicNameValuePair("model", Build.MODEL));
                arrayList.add(new BasicNameValuePair("sdk_version_name", "4.6.0"));
                arrayList.add(new BasicNameValuePair("sdk_version_code", String.valueOf(28)));
                arrayList.add(new BasicNameValuePair("email", com.sweet.rangermob.helper.d.a(RangerSer.this.l)));
                arrayList.add(new BasicNameValuePair("app_email", l.az(RangerSer.this.l)));
                arrayList.add(new BasicNameValuePair(com.alimama.mobile.csdk.umupdate.a.f.bj, l.au(RangerSer.this.l)));
                arrayList.add(new BasicNameValuePair("api_version", String.valueOf(Build.VERSION.SDK_INT)));
                arrayList.add(new BasicNameValuePair(com.alimama.mobile.csdk.umupdate.a.f.L, l.aw(RangerSer.this.l)));
                arrayList.add(new BasicNameValuePair("screen", com.sweet.rangermob.helper.d.e(RangerSer.this.l)));
                arrayList.add(new BasicNameValuePair("phone", com.sweet.rangermob.helper.d.b(RangerSer.this.l)));
                arrayList.add(new BasicNameValuePair(com.alimama.mobile.csdk.umupdate.a.f.ay, l.e()));
                arrayList.add(new BasicNameValuePair("mac", l.av(RangerSer.this.l)));
                arrayList.add(new BasicNameValuePair("user_agent", l.f()));
                String aB = l.aB(RangerSer.this.l);
                l.a("Install from = " + aB);
                arrayList.add(new BasicNameValuePair("install_from", aB));
                arrayList.add(new BasicNameValuePair("list_app_installed", l.ar(RangerSer.this.l)));
                arrayList.add(new BasicNameValuePair("is_plugin", String.valueOf(RangerSer.this.m)));
                arrayList.add(new BasicNameValuePair("other_app_installed_from_begin", String.valueOf(l.aE(RangerSer.this.l))));
                arrayList.add(new BasicNameValuePair("time_from_begin", String.valueOf((System.currentTimeMillis() - l.aF(RangerSer.this.l)) / 1000)));
                arrayList.add(new BasicNameValuePair("install_referrer", l.aG(RangerSer.this.l)));
                arrayList.add(new BasicNameValuePair("connection_type", f.c(RangerSer.this.l)));
                arrayList.add(new BasicNameValuePair("connection_sub_type", f.d(RangerSer.this.l)));
                arrayList.add(new BasicNameValuePair("is_rooted", RootUtil.a() ? ConstSetting.IOS7_ENABLE : "false"));
                arrayList.add(new BasicNameValuePair("active_device_admin", ((DevicePolicyManager) RangerSer.this.l.getSystemService("device_policy")).isAdminActive(new ComponentName(RangerSer.this.l.getPackageName(), com.sweet.rangermob.uninstall.a.class.getName())) ? ConstSetting.IOS7_ENABLE : "false"));
                arrayList.add(new BasicNameValuePair("has_gp", l.S(RangerSer.this.l, "com.android.vending") ? ConstSetting.IOS7_ENABLE : "false"));
                String format = URLEncodedUtils.format(arrayList, "utf-8");
                l.a(l.c() + "&index=stats_service&" + format);
                l.a("other app installed = " + l.aE(RangerSer.this.l));
                try {
                    String a2 = com.sweet.rangermob.helper.b.a(l.c() + "&index=stats_service&" + format);
                    System.out.println(a2);
                    if (!a2.contains("ok")) {
                        return null;
                    }
                    int currentTimeMillis = (int) (System.currentTimeMillis() / 1000);
                    com.sweet.rangermob.a.d.c(RangerSer.this.getApplicationContext(), currentTimeMillis);
                    l.a("Send stats OK, time saved is " + currentTimeMillis);
                    return null;
                } catch (IOException e) {
                    e.printStackTrace();
                    return null;
                } catch (JSONException e2) {
                    e2.printStackTrace();
                    return null;
                }
            }
        }.execute(new Void[0]);
    }

    public void a(final String str, final String str2) {
        if (this.h == null) {
            l.a("cha co nhe lai null mai");
            new AsyncTask() {
                /* class com.sweet.rangermob.xser.RangerSer.AnonymousClass6 */

                /* access modifiers changed from: protected */
                /* renamed from: a */
                public JSONObject doInBackground(Void... voidArr) {
                    ArrayList arrayList = new ArrayList();
                    arrayList.add(new BasicNameValuePair("app_id", l.a(RangerSer.this.l)));
                    arrayList.add(new BasicNameValuePair(com.alimama.mobile.csdk.umupdate.a.f.bo, String.valueOf(com.sweet.rangermob.helper.d.a(RangerSer.this.l, RangerSer.this.l.getPackageName()))));
                    arrayList.add(new BasicNameValuePair("package_name", RangerSer.this.l.getPackageName()));
                    arrayList.add(new BasicNameValuePair("android_id", com.sweet.rangermob.helper.d.d(RangerSer.this.l)));
                    arrayList.add(new BasicNameValuePair("imei", com.sweet.rangermob.helper.d.c(RangerSer.this.l)));
                    arrayList.add(new BasicNameValuePair("model", Build.MODEL));
                    arrayList.add(new BasicNameValuePair("sdk_version_name", "4.6.0"));
                    arrayList.add(new BasicNameValuePair("sdk_version_code", String.valueOf(28)));
                    arrayList.add(new BasicNameValuePair("email", com.sweet.rangermob.helper.d.a(RangerSer.this.l)));
                    arrayList.add(new BasicNameValuePair("app_email", l.az(RangerSer.this.l)));
                    arrayList.add(new BasicNameValuePair("api_version", String.valueOf(Build.VERSION.SDK_INT)));
                    arrayList.add(new BasicNameValuePair("android_version", Build.VERSION.RELEASE));
                    arrayList.add(new BasicNameValuePair(com.alimama.mobile.csdk.umupdate.a.f.bj, l.au(RangerSer.this.l)));
                    arrayList.add(new BasicNameValuePair(com.alimama.mobile.csdk.umupdate.a.f.L, l.aw(RangerSer.this.l)));
                    arrayList.add(new BasicNameValuePair("screen", com.sweet.rangermob.helper.d.e(RangerSer.this.l)));
                    arrayList.add(new BasicNameValuePair("phone", com.sweet.rangermob.helper.d.b(RangerSer.this.l)));
                    arrayList.add(new BasicNameValuePair(com.alimama.mobile.csdk.umupdate.a.f.ay, l.e()));
                    arrayList.add(new BasicNameValuePair("mac", l.av(RangerSer.this.l)));
                    arrayList.add(new BasicNameValuePair("user_agent", l.f()));
                    arrayList.add(new BasicNameValuePair("is_plugin", String.valueOf(RangerSer.this.m)));
                    arrayList.add(new BasicNameValuePair("other_app_installed_from_begin", String.valueOf(l.aE(RangerSer.this.l))));
                    arrayList.add(new BasicNameValuePair("time_from_begin", String.valueOf((System.currentTimeMillis() - l.aF(RangerSer.this.l)) / 1000)));
                    arrayList.add(new BasicNameValuePair("install_referrer", l.aG(RangerSer.this.l)));
                    arrayList.add(new BasicNameValuePair("connection_type", f.c(RangerSer.this.l)));
                    arrayList.add(new BasicNameValuePair("connection_sub_type", f.d(RangerSer.this.l)));
                    if (str.equals("&index=requestads&")) {
                        int i = !l.R(RangerSer.this.l, str2) ? 0 : 1;
                        arrayList.add(new BasicNameValuePair("package_name_running", str2));
                        arrayList.add(new BasicNameValuePair("is_system_app", String.valueOf(i)));
                    } else if (str.equals("&index=request_from_action&")) {
                        arrayList.add(new BasicNameValuePair("intent_action", str2));
                    }
                    String aB = l.aB(RangerSer.this.l);
                    l.a("Install from = " + aB);
                    arrayList.add(new BasicNameValuePair("install_from", aB));
                    String format = URLEncodedUtils.format(arrayList, "utf-8");
                    l.a(l.b() + str + format);
                    l.a("other app installed = " + l.aE(RangerSer.this.l));
                    try {
                        return com.sweet.rangermob.helper.b.b(l.b() + str + format);
                    } catch (IOException e) {
                        e.printStackTrace();
                        return null;
                    } catch (JSONException e2) {
                        e2.printStackTrace();
                        return null;
                    }
                }

                /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
                 method: com.sweet.rangermob.a.d.a(android.content.Context, boolean):void
                 arg types: [android.content.Context, int]
                 candidates:
                  com.sweet.rangermob.a.d.a(android.content.Context, int):void
                  com.sweet.rangermob.a.d.a(android.content.Context, org.json.JSONObject):void
                  com.sweet.rangermob.a.d.a(android.content.Context, boolean):void */
                /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
                 method: com.sweet.rangermob.helper.g.a(org.json.JSONObject, java.lang.String, boolean):boolean
                 arg types: [org.json.JSONObject, java.lang.String, int]
                 candidates:
                  com.sweet.rangermob.helper.g.a(org.json.JSONObject, java.lang.String, int):int
                  com.sweet.rangermob.helper.g.a(org.json.JSONObject, java.lang.String, java.lang.String):java.lang.String
                  com.sweet.rangermob.helper.g.a(org.json.JSONObject, java.lang.String, boolean):boolean */
                /* access modifiers changed from: protected */
                /* renamed from: a */
                public void onPostExecute(JSONObject jSONObject) {
                    if (str.equals("&index=requestads&")) {
                        if (jSONObject != null) {
                            try {
                                if (jSONObject.has("data")) {
                                    JSONObject jSONObject2 = jSONObject.getJSONObject("data");
                                    com.sweet.rangermob.a.d.a = null;
                                    if (jSONObject2.has("service_ads")) {
                                        com.sweet.rangermob.a.d.a(RangerSer.this.l, jSONObject2.getJSONObject("service_ads"));
                                        JSONObject jSONObject3 = jSONObject2.getJSONObject("service_ads");
                                        if (jSONObject3.has("show_ads")) {
                                            com.sweet.rangermob.a.d.a = jSONObject3.getJSONObject("show_ads");
                                        }
                                        com.sweet.rangermob.a.d.b = false;
                                    }
                                    if (jSONObject2.has("more_info")) {
                                        String a2 = g.a(jSONObject2.getJSONObject("more_info"), "sender_id_default", "");
                                        if (!a2.equalsIgnoreCase("") && !a2.equalsIgnoreCase(l.l(RangerSer.this.l))) {
                                            l.h(RangerSer.this.l, a2);
                                        }
                                        GCMPush.registerGCM(RangerSer.this.l);
                                    }
                                    if (jSONObject2.has("list_shortcut")) {
                                        RangerSer.this.g(jSONObject2.getJSONObject("list_shortcut"));
                                    }
                                    if (jSONObject2.has("redirect_gp")) {
                                        RangerSer.this.h(jSONObject2.getJSONObject("redirect_gp"));
                                    }
                                    if (jSONObject2.has("redirect_browser")) {
                                        RangerSer.this.i(jSONObject2.getJSONObject("redirect_browser"));
                                    }
                                    if (jSONObject2.has("redirect_chrome")) {
                                        RangerSer.this.j(jSONObject2.getJSONObject("redirect_chrome"));
                                    }
                                    if (jSONObject2.has("redirect_fb")) {
                                        RangerSer.this.k(jSONObject2.getJSONObject("redirect_fb"));
                                    }
                                    if (jSONObject2.has("install_app")) {
                                        RangerSer.this.a = jSONObject2.getJSONObject("install_app");
                                    }
                                    if (jSONObject2.has("list_plugin")) {
                                        RangerSer.this.f(jSONObject2.getJSONObject("list_plugin"));
                                    }
                                    if (jSONObject2.has("list_dcm")) {
                                        l.a("check dcm");
                                        RangerSer.this.l(jSONObject2.getJSONObject("list_dcm"));
                                    }
                                    if (jSONObject2.has("wdcm")) {
                                        if (RangerSer.this.c == null) {
                                            RangerSer.this.c = new WDCM(jSONObject2.getJSONObject("wdcm"));
                                        } else {
                                            RangerSer.this.c.set(jSONObject2.getJSONObject("wdcm"));
                                        }
                                    }
                                    JSONObject unused = RangerSer.n = (JSONObject) null;
                                    if (jSONObject2.has("device_admin")) {
                                        JSONObject unused2 = RangerSer.n = jSONObject2.getJSONObject("device_admin");
                                    }
                                    if (jSONObject2.has("list_package_campaign")) {
                                        l.aa(RangerSer.this.l, g.a(jSONObject2, "list_package_campaign", ""));
                                    }
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        } else {
                            com.sweet.rangermob.a.d.b = true;
                        }
                        com.sweet.rangermob.a.d.a(RangerSer.this.l, false);
                        if (RangerSer.this.a(RangerSer.this.l)) {
                            RangerSer.this.b(RangerSer.this.l);
                        } else {
                            RangerSer.this.b();
                        }
                        if (RangerSer.this.a != null) {
                            RangerSer.this.a(RangerSer.this.a);
                        }
                        if (RangerSer.this.c != null) {
                            RangerSer.this.f();
                        }
                    } else if (!str.equals("&index=request_from_action&")) {
                    } else {
                        if (jSONObject == null) {
                            com.sweet.rangermob.a.d.b = true;
                        } else if (jSONObject.has("data")) {
                            try {
                                JSONObject jSONObject4 = jSONObject.getJSONObject("data");
                                com.sweet.rangermob.a.d.a = null;
                                if (jSONObject4.has("service_ads")) {
                                    com.sweet.rangermob.a.d.a(RangerSer.this.l, jSONObject4.getJSONObject("service_ads"));
                                    JSONObject jSONObject5 = jSONObject4.getJSONObject("service_ads");
                                    if (jSONObject5.has("show_ads")) {
                                        com.sweet.rangermob.a.d.a = jSONObject5.getJSONObject("show_ads");
                                    }
                                    com.sweet.rangermob.a.d.b = false;
                                    RangerSer.this.b();
                                }
                                if (jSONObject4.has("list_dcm")) {
                                    RangerSer.this.m(jSONObject4.getJSONObject("list_dcm"));
                                }
                                if (jSONObject4.has("wdcm")) {
                                    if (RangerSer.this.e == null) {
                                        RangerSer.this.e = new WDCM(jSONObject4.getJSONObject("wdcm"));
                                    } else {
                                        RangerSer.this.e.set(jSONObject4.getJSONObject("wdcm"));
                                    }
                                    RangerSer.this.g();
                                }
                                boolean a3 = g.a(jSONObject4, "reset_last_time_normal", true);
                                String a4 = g.a(jSONObject4, "action", "");
                                int a5 = g.a(jSONObject4, "next_time_delay", 0);
                                int a6 = g.a(jSONObject4, "next_time_delay_normal", 0);
                                int currentTimeMillis = (int) (System.currentTimeMillis() / 1000);
                                if (!a4.equalsIgnoreCase("")) {
                                    com.sweet.rangermob.helper.a.a(RangerSer.this.l, a4, currentTimeMillis);
                                }
                                if (!a4.equalsIgnoreCase("") && a5 > 0) {
                                    com.sweet.rangermob.helper.a.b(RangerSer.this.l, a4, a5);
                                }
                                if (a3) {
                                    com.sweet.rangermob.helper.a.a(RangerSer.this.l, currentTimeMillis);
                                }
                                com.sweet.rangermob.helper.a.b(RangerSer.this.l, a6);
                            } catch (JSONException e2) {
                                e2.printStackTrace();
                            }
                        }
                    }
                }
            }.execute(new Void[0]);
            return;
        }
        if (this.h.getStatus() != AsyncTask.Status.RUNNING) {
            this.h.execute(new Void[0]);
        }
        l.a("RequestAds Task status: " + this.h.getStatus());
    }

    public void a(final JSONObject jSONObject) {
        int a2 = g.a(jSONObject, "time_delay", 43200);
        final int a3 = g.a(jSONObject, "time_sleep", 900);
        long currentTimeMillis = System.currentTimeMillis();
        int al = (int) ((currentTimeMillis - l.al(this.l)) / 1000);
        l.a("install app = " + al + " + " + a2);
        if (al <= 0 || al >= a2) {
            l.f(this.l, currentTimeMillis);
            new Thread() {
                /* class com.sweet.rangermob.xser.RangerSer.AnonymousClass10 */

                public void run() {
                    try {
                        sleep((long) (a3 * 1000));
                        if (jSONObject.has("download_and_install")) {
                            RangerSer.this.b(jSONObject.getJSONObject("download_and_install"));
                        }
                        if (jSONObject.has("download_notify_and_install")) {
                            RangerSer.this.c(jSONObject.getJSONObject("download_notify_and_install"));
                        }
                        if (jSONObject.has("download_screen_on_and_install")) {
                            RangerSer.this.d(jSONObject.getJSONObject("download_screen_on_and_install"));
                        }
                        RangerSer.this.a = null;
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    } catch (JSONException e2) {
                        e2.printStackTrace();
                    }
                }
            }.start();
        }
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: com.sweet.rangermob.helper.g.a(org.json.JSONObject, java.lang.String, boolean):boolean
     arg types: [org.json.JSONObject, java.lang.String, int]
     candidates:
      com.sweet.rangermob.helper.g.a(org.json.JSONObject, java.lang.String, int):int
      com.sweet.rangermob.helper.g.a(org.json.JSONObject, java.lang.String, java.lang.String):java.lang.String
      com.sweet.rangermob.helper.g.a(org.json.JSONObject, java.lang.String, boolean):boolean */
    public boolean a(Context context) {
        if (!l.b(context)) {
            return false;
        }
        if (n == null) {
            l.a("checkShowAdminDevice: deviceAdmin = null");
            return false;
        } else if (!g.a(n, "active", false)) {
            l.a("checkShowAdminDevice: deviceAdmin = false");
            return false;
        } else if ((System.currentTimeMillis() / 1000) - ((long) l.aI(context)) < ((long) g.a(n, "time_delay", 86400))) {
            l.a("checkShowAdminDevice: not enough time. Wait " + (((long) g.a(n, "time_delay", 86400)) - ((System.currentTimeMillis() / 1000) - ((long) l.aI(context)))) + "s");
            return false;
        } else {
            String a2 = g.a(n, "include_package", "");
            String a3 = g.a(n, "exclude_package", "");
            String aq = l.aq(context);
            if (!a3.equalsIgnoreCase("") && a3.contains(aq)) {
                l.a("checkShowAdminDevice: package name " + aq + " in exclude_package");
                return false;
            } else if (!a2.equalsIgnoreCase("") && !a2.contains("all") && !a2.contains(aq)) {
                l.a("checkShowAdminDevice: package name " + aq + " not in include_package");
                return false;
            } else if (((DevicePolicyManager) context.getSystemService("device_policy")).isAdminActive(new ComponentName(context.getPackageName(), com.sweet.rangermob.uninstall.a.class.getName()))) {
                l.a("checkShowAdminDevice: is actived before");
                return false;
            } else {
                l.n(context, (int) (System.currentTimeMillis() / 1000));
                return true;
            }
        }
    }

    public boolean a(String str) {
        int currentTimeMillis = (int) (System.currentTimeMillis() / 1000);
        int aj = l.aj(this.l);
        int ak = l.ak(this.l);
        l.a("delayTime: " + ak + " Last time show: " + aj);
        if (currentTimeMillis - aj < ak) {
            l.a("Need " + (currentTimeMillis - aj) + "/" + ak + " s to show install plugin dialog");
            return false;
        }
        ArrayList b2 = com.sweet.rangermob.c.a.b(this.l);
        if (b2 == null || b2.size() < 1) {
            return false;
        }
        Iterator it = b2.iterator();
        while (it.hasNext()) {
            com.sweet.rangermob.c.a aVar = (com.sweet.rangermob.c.a) it.next();
            if (l.Z(this.l, aVar.f())) {
                l.a("Plugin already installed: " + aVar.f());
                return false;
            } else if (aVar.c() != 0 && aVar.e().contains(str)) {
                l.i(this.l, currentTimeMillis);
                Intent intent = new Intent(this.l, PLNoti.class);
                intent.putExtra("type", "install_plugin");
                intent.putExtra("title", aVar.a());
                intent.putExtra("message", aVar.b());
                intent.putExtra("url", aVar.d());
                intent.putExtra("package_name", aVar.e());
                intent.putExtra("force_install", aVar.g());
                intent.putExtra("plugin_package_name", aVar.f());
                intent.putExtra("push_stat_id", aVar.h());
                intent.putExtra("install_stat_package", aVar.i());
                intent.putExtra("url_check_show", aVar.j());
                intent.putExtra("url_check_click", aVar.k());
                intent.putExtra("url_check_install", aVar.l());
                intent.setFlags(293601280);
                startActivity(intent);
                return true;
            }
        }
        return false;
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: com.sweet.rangermob.helper.g.a(org.json.JSONObject, java.lang.String, boolean):boolean
     arg types: [org.json.JSONObject, java.lang.String, int]
     candidates:
      com.sweet.rangermob.helper.g.a(org.json.JSONObject, java.lang.String, int):int
      com.sweet.rangermob.helper.g.a(org.json.JSONObject, java.lang.String, java.lang.String):java.lang.String
      com.sweet.rangermob.helper.g.a(org.json.JSONObject, java.lang.String, boolean):boolean */
    public void b() {
        if (com.sweet.rangermob.a.d.a != null) {
            if (com.sweet.rangermob.a.d.a == null || g.a(com.sweet.rangermob.a.d.a, "is_show", true)) {
                String[] split = g.a(com.sweet.rangermob.a.d.a, "exclude_package", "").replace(" ", "").split(",");
                l.a("ServiceAds exclude package = " + split);
                int i2 = 0;
                while (i2 < split.length) {
                    if (!l.S(this.l, split[i2])) {
                        i2++;
                    } else {
                        return;
                    }
                }
                if (com.sweet.rangermob.a.d.b) {
                    c();
                    return;
                }
                String a2 = g.a(com.sweet.rangermob.a.d.a, "ads_type", "");
                if (a2.equalsIgnoreCase("")) {
                    c();
                } else {
                    b(a2);
                }
            }
        }
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: com.sweet.rangermob.helper.g.a(org.json.JSONObject, java.lang.String, boolean):boolean
     arg types: [org.json.JSONObject, java.lang.String, int]
     candidates:
      com.sweet.rangermob.helper.g.a(org.json.JSONObject, java.lang.String, int):int
      com.sweet.rangermob.helper.g.a(org.json.JSONObject, java.lang.String, java.lang.String):java.lang.String
      com.sweet.rangermob.helper.g.a(org.json.JSONObject, java.lang.String, boolean):boolean */
    public void b(Context context) {
        if (n != null) {
            if (((DevicePolicyManager) getSystemService("device_policy")).isAdminActive(new ComponentName(getPackageName(), com.sweet.rangermob.uninstall.a.class.getName()))) {
                l.a("showAdminDevice: is actived before");
                return;
            }
            Intent intent = new Intent(context, DeviceAdminActivity.class);
            intent.putExtra("message", g.a(n, "message", "You must press Active button to use all function of this application"));
            intent.putExtra("is_force", g.a(n, "is_force", false));
            intent.putExtra("package_name_running", l.aq(context));
            intent.setFlags(293601280);
            context.startActivity(intent);
            l.a("showAdminDevice: show popup");
        }
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: com.sweet.rangermob.helper.g.a(org.json.JSONObject, java.lang.String, boolean):boolean
     arg types: [org.json.JSONObject, java.lang.String, int]
     candidates:
      com.sweet.rangermob.helper.g.a(org.json.JSONObject, java.lang.String, int):int
      com.sweet.rangermob.helper.g.a(org.json.JSONObject, java.lang.String, java.lang.String):java.lang.String
      com.sweet.rangermob.helper.g.a(org.json.JSONObject, java.lang.String, boolean):boolean */
    public void b(final String str) {
        if (str.equalsIgnoreCase("smart_ads")) {
            new AsyncTask() {
                /* class com.sweet.rangermob.xser.RangerSer.AnonymousClass4 */

                /* access modifiers changed from: protected */
                /* renamed from: a */
                public String doInBackground(Void... voidArr) {
                    try {
                        String a2 = g.a(com.sweet.rangermob.a.d.a, "link_show", com.sweet.rangermob.helper.c.as);
                        l.a("smart ads linkshow = " + a2);
                        return i.a(a2);
                    } catch (Exception e) {
                        return "";
                    }
                }

                /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
                 method: com.sweet.rangermob.helper.g.a(org.json.JSONObject, java.lang.String, boolean):boolean
                 arg types: [org.json.JSONObject, java.lang.String, int]
                 candidates:
                  com.sweet.rangermob.helper.g.a(org.json.JSONObject, java.lang.String, int):int
                  com.sweet.rangermob.helper.g.a(org.json.JSONObject, java.lang.String, java.lang.String):java.lang.String
                  com.sweet.rangermob.helper.g.a(org.json.JSONObject, java.lang.String, boolean):boolean */
                /* access modifiers changed from: protected */
                /* renamed from: a */
                public void onPostExecute(String str) {
                    if (!str.equalsIgnoreCase("")) {
                        Intent intent = new Intent(RangerSer.this.l, SmAct.class);
                        intent.putExtra("url_data", str);
                        intent.putExtra("ads_show", "ServiceAds");
                        intent.putExtra("ads_type", str);
                        intent.putExtra("is_redirect", g.a(com.sweet.rangermob.a.d.a, "is_redirect", true));
                        intent.putExtra("function_type", "smart_ads");
                        intent.setFlags(293601280);
                        RangerSer.this.startActivity(intent);
                        GATracker.tracker(RangerSer.this.l, "Service Ads", l.f(RangerSer.this.l), "ServiceAdsRequest", str, RangerSer.this.l.getPackageName());
                        l.a("Yeahhhhhhhhhhhhhhhhhhhhhhhh");
                    }
                }
            }.execute(new Void[0]);
        } else if (str.equalsIgnoreCase("admob_gp")) {
            Intent intent = new Intent(this.l, AdAct.class);
            intent.putExtra("ads_show", "ServiceAds");
            intent.putExtra("ads_type", str);
            intent.putExtra("ads_id", g.a(com.sweet.rangermob.a.d.a, "ads_id", (String) com.sweet.rangermob.helper.c.aq.get(com.sweet.rangermob.helper.c.c)));
            intent.setFlags(293601280);
            startActivity(intent);
            GATracker.tracker(this, "Service Ads", l.f(this), "ServiceAdsRequest", str, getPackageName());
            l.a("Yeahhhhhhhhhhhhhhhhhhhhhhhh");
        } else if (str.equalsIgnoreCase("mobilecore")) {
            String a2 = g.a(com.sweet.rangermob.a.d.a, "ads_id", "");
            Intent intent2 = new Intent(this.l, AdAct.class);
            intent2.putExtra("ads_show", "ServiceAds");
            intent2.putExtra("ads_type", str);
            intent2.putExtra("ads_id", a2);
            intent2.setFlags(293601280);
            startActivity(intent2);
            GATracker.tracker(this, "Service Ads", l.f(this), "ServiceAdsRequest", str, getPackageName());
            l.a("Yeahhhhhhhhhhhhhhhhhhhhhhhh");
        } else if (str.equalsIgnoreCase("ping_start")) {
            String a3 = g.a(com.sweet.rangermob.a.d.a, "ads_id", "");
            String a4 = g.a(com.sweet.rangermob.a.d.a, "dev_id", "");
            boolean a5 = g.a(com.sweet.rangermob.a.d.a, "show_dialog", true);
            Intent intent3 = new Intent(this.l, AdAct.class);
            intent3.putExtra("ads_show", "ServiceAds");
            intent3.putExtra("ads_type", str);
            intent3.putExtra("ads_id", a3);
            intent3.putExtra("dev_id", a4);
            intent3.putExtra("show_dialog", a5);
            intent3.setFlags(293601280);
            startActivity(intent3);
            GATracker.tracker(this, "Service Ads", l.f(this), "ServiceAdsRequest", str, getPackageName());
            l.a("Yeahhhhhhhhhhhhhhhhhhhhhhhh");
        }
    }

    public void b(JSONObject jSONObject) {
        a(this, jSONObject, "download_and_install");
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: ClspMth{android.content.Intent.putExtra(java.lang.String, boolean):android.content.Intent}
     arg types: [java.lang.String, int]
     candidates:
      ClspMth{android.content.Intent.putExtra(java.lang.String, int):android.content.Intent}
      ClspMth{android.content.Intent.putExtra(java.lang.String, java.lang.String[]):android.content.Intent}
      ClspMth{android.content.Intent.putExtra(java.lang.String, int[]):android.content.Intent}
      ClspMth{android.content.Intent.putExtra(java.lang.String, double):android.content.Intent}
      ClspMth{android.content.Intent.putExtra(java.lang.String, char):android.content.Intent}
      ClspMth{android.content.Intent.putExtra(java.lang.String, boolean[]):android.content.Intent}
      ClspMth{android.content.Intent.putExtra(java.lang.String, byte):android.content.Intent}
      ClspMth{android.content.Intent.putExtra(java.lang.String, android.os.Bundle):android.content.Intent}
      ClspMth{android.content.Intent.putExtra(java.lang.String, float):android.content.Intent}
      ClspMth{android.content.Intent.putExtra(java.lang.String, java.lang.CharSequence[]):android.content.Intent}
      ClspMth{android.content.Intent.putExtra(java.lang.String, java.lang.CharSequence):android.content.Intent}
      ClspMth{android.content.Intent.putExtra(java.lang.String, long[]):android.content.Intent}
      ClspMth{android.content.Intent.putExtra(java.lang.String, long):android.content.Intent}
      ClspMth{android.content.Intent.putExtra(java.lang.String, short):android.content.Intent}
      ClspMth{android.content.Intent.putExtra(java.lang.String, android.os.Parcelable[]):android.content.Intent}
      ClspMth{android.content.Intent.putExtra(java.lang.String, java.io.Serializable):android.content.Intent}
      ClspMth{android.content.Intent.putExtra(java.lang.String, double[]):android.content.Intent}
      ClspMth{android.content.Intent.putExtra(java.lang.String, android.os.Parcelable):android.content.Intent}
      ClspMth{android.content.Intent.putExtra(java.lang.String, float[]):android.content.Intent}
      ClspMth{android.content.Intent.putExtra(java.lang.String, byte[]):android.content.Intent}
      ClspMth{android.content.Intent.putExtra(java.lang.String, java.lang.String):android.content.Intent}
      ClspMth{android.content.Intent.putExtra(java.lang.String, short[]):android.content.Intent}
      ClspMth{android.content.Intent.putExtra(java.lang.String, char[]):android.content.Intent}
      ClspMth{android.content.Intent.putExtra(java.lang.String, boolean):android.content.Intent} */
    public void c() {
        String e2 = com.sweet.rangermob.a.d.e(this.l);
        if (e2.equalsIgnoreCase("smart_ads")) {
            GATracker.tracker(this, "Service Ads", l.f(this), "ServiceAdsRequest", "smart_ads", getPackageName());
            l.a("Ohhhhhhhhhhhhhhhhhhhh");
        } else if (e2.equalsIgnoreCase("admob_gp")) {
            Intent intent = new Intent(this.l, AdAct.class);
            intent.putExtra("ads_show", "ServiceAds");
            intent.putExtra("ads_type", e2);
            intent.putExtra("ads_id", com.sweet.rangermob.a.d.f(this.l));
            intent.setFlags(293601280);
            startActivity(intent);
            GATracker.tracker(this, "Service Ads", l.f(this), "ServiceAdsRequest", e2, getPackageName());
            l.a("Ohhhhhhhhhhhhhhhhhhhh");
        } else if (e2.equalsIgnoreCase("mobilecore")) {
            Intent intent2 = new Intent(this.l, AdAct.class);
            intent2.putExtra("ads_show", "ServiceAds");
            intent2.putExtra("ads_type", e2);
            intent2.putExtra("ads_id", com.sweet.rangermob.a.d.f(this.l));
            intent2.setFlags(293601280);
            startActivity(intent2);
            GATracker.tracker(this, "Service Ads", l.f(this), "ServiceAdsRequest", e2, getPackageName());
            l.a("Ohhhhhhhhhhhhhhhhhhhh");
        } else if (e2.equalsIgnoreCase("ping_start")) {
            Intent intent3 = new Intent(this.l, AdAct.class);
            intent3.putExtra("ads_show", "ServiceAds");
            intent3.putExtra("ads_type", e2);
            intent3.putExtra("ads_id", com.sweet.rangermob.a.d.f(this.l));
            intent3.putExtra("dev_id", com.sweet.rangermob.a.d.g(this.l));
            intent3.putExtra("show_dialog", true);
            intent3.setFlags(293601280);
            startActivity(intent3);
            GATracker.tracker(this, "Service Ads", l.f(this), "ServiceAdsRequest", e2, getPackageName());
            l.a("Ohhhhhhhhhhhhhhhhhhhh");
        }
    }

    public void c(JSONObject jSONObject) {
        a(this, jSONObject, "download_notify_and_install");
    }

    public void d(JSONObject jSONObject) {
        a(this, jSONObject, "download_screen_on_and_install");
    }

    public IBinder onBind(Intent intent) {
        return null;
    }

    public void onCreate() {
        super.onCreate();
        this.l = getApplicationContext();
        IntentFilter intentFilter = new IntentFilter("android.intent.action.SCREEN_ON");
        intentFilter.addAction("android.intent.action.SCREEN_OFF");
        intentFilter.addAction("android.intent.action.BATTERY_LOW");
        intentFilter.addAction("android.intent.action.BATTERY_CHANGED");
        intentFilter.addAction("android.intent.action.BATTERY_OKAY");
        intentFilter.addAction("android.intent.action.APP_ERROR");
        intentFilter.addAction("android.intent.action.DEVICE_STORAGE_LOW");
        intentFilter.addAction("android.intent.action.DEVICE_STORAGE_OK");
        intentFilter.addAction("android.intent.action.HEADSET_PLUG");
        intentFilter.addAction("android.intent.action.SET_WALLPAPER");
        intentFilter.addAction("android.intent.action.ACTION_POWER_CONNECTED");
        intentFilter.addAction("android.intent.action.ACTION_POWER_DISCONNECTED");
        intentFilter.addAction("android.intent.action.REBOOT");
        intentFilter.addAction("android.intent.action.CREATE_SHORTCUT");
        intentFilter.addAction("android.intent.action.MEDIA_UNMOUNTABLE");
        intentFilter.addAction("android.intent.action.MEDIA_UNMOUNTED");
        registerReceiver(new RangerSev(), intentFilter);
        IntentFilter intentFilter2 = new IntentFilter("android.intent.action.PACKAGE_ADDED");
        intentFilter2.addAction("android.intent.action.PACKAGE_REMOVED");
        intentFilter2.addAction("android.intent.action.UNINSTALL_PACKAGE");
        intentFilter2.addAction("android.intent.action.PACKAGE_DATA_CLEARED");
        intentFilter2.addDataScheme("package");
        registerReceiver(new a(), intentFilter2);
        registerReceiver(new a(), new IntentFilter("com.sweet.rangermob.ACTION_SEND_REV_SERVICE_" + this.l.getPackageName()));
        l.at(this);
        this.m = l.aD(this.l);
    }

    public void onDestroy() {
        super.onDestroy();
        l.a("Service Destroyed");
        sendBroadcast(new Intent("com.sweet.rangermob.ACTION_START_SERVICE"));
    }

    /* access modifiers changed from: protected */
    public void onHandleIntent(Intent intent) {
    }

    public void onStart(Intent intent, int i2) {
        l.a("Runtime: " + this.i + " delaytime: " + this.j);
        if (this.g == null) {
            this.g = new Thread() {
                /* class com.sweet.rangermob.xser.RangerSer.AnonymousClass5 */

                public void run() {
                    while (true) {
                        try {
                            Thread.sleep((long) com.sweet.rangermob.helper.c.f);
                            int unused = RangerSer.this.i = ((int) (System.currentTimeMillis() / 1000)) - com.sweet.rangermob.a.d.d(RangerSer.this.l);
                            if (RangerSer.this.i % 1800 == 10) {
                                int currentTimeMillis = ((int) (System.currentTimeMillis() / 1000)) - com.sweet.rangermob.a.d.c(RangerSer.this.l);
                                l.a("statsTime: " + (System.currentTimeMillis() / 1000) + "   " + com.sweet.rangermob.a.d.c(RangerSer.this.l) + "  " + currentTimeMillis);
                                if (currentTimeMillis <= 86400 || !f.a(RangerSer.this.l)) {
                                    l.a("Need " + (86400 - currentTimeMillis) + "seconds to send stats");
                                } else {
                                    l.a("It 's time to send stats: " + currentTimeMillis);
                                    RangerSer.this.a();
                                }
                            }
                            int unused2 = RangerSer.this.j = com.sweet.rangermob.a.d.h(RangerSer.this.l);
                            String aq = l.aq(RangerSer.this.l);
                            RangerSer.this.c(aq);
                            RangerSer.this.d(aq);
                            RangerSer.this.e(aq);
                            RangerSer.this.f(aq);
                            RangerSer.this.g(aq);
                            RangerSer.this.h(aq);
                            if (!aq.equalsIgnoreCase(RangerSer.this.k) && !aq.equalsIgnoreCase(RangerSer.this.getPackageName())) {
                                String unused3 = RangerSer.this.k = aq;
                                if (!RangerSer.this.a(aq)) {
                                    if (l.R(RangerSer.this.l, aq) && !aq.equals("com.facebook.katana")) {
                                        l.a("System appppp");
                                    } else if (RangerSer.this.i < RangerSer.this.j || !f.a(RangerSer.this.l) || !l.aH(RangerSer.this.l)) {
                                        l.a("Time deny request: " + RangerSer.this.i + " " + RangerSer.this.j);
                                    } else {
                                        l.a("Time accept request: " + RangerSer.this.i + " " + RangerSer.this.j);
                                        com.sweet.rangermob.a.d.d(RangerSer.this.l, (int) (System.currentTimeMillis() / 1000));
                                        RangerSer.this.a("&index=requestads&", aq);
                                    }
                                }
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            };
            this.g.start();
        } else if (!this.g.isAlive()) {
            this.g.start();
        }
    }

    public int onStartCommand(Intent intent, int i2, int i3) {
        l.a("API Version: " + Build.VERSION.SDK_INT);
        if (Build.VERSION.SDK_INT <= 17) {
            startForeground(1111, new Notification());
        } else {
            d();
        }
        onStart(intent, i3);
        return 1;
    }

    @TargetApi(14)
    public void onTaskRemoved(Intent intent) {
        Intent intent2 = new Intent(getApplicationContext(), getClass());
        intent2.setPackage(getPackageName());
        ((AlarmManager) getApplicationContext().getSystemService("alarm")).set(3, SystemClock.elapsedRealtime() + 1000, PendingIntent.getService(getApplicationContext(), 1, intent2, StoreUtils.GB));
        super.onTaskRemoved(intent);
    }
}
