package com.ironsource.mobilcore;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import org.json.JSONObject;

final class Y extends I {
    private int a;

    public Y(Context context, C0261ax axVar) {
        super(context, axVar);
    }

    @Override // com.ironsource.mobilcore.H
    public final String a() {
        return "groupHeader";
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: com.ironsource.mobilcore.I.a(org.json.JSONObject, boolean):void
     arg types: [org.json.JSONObject, int]
     candidates:
      com.ironsource.mobilcore.I.a(com.ironsource.mobilcore.MCEWidgetTextProperties, java.lang.String):void
      com.ironsource.mobilcore.I.a(org.json.JSONObject, boolean):void */
    @Override // com.ironsource.mobilcore.H
    public final void a(JSONObject jSONObject) {
        this.a = this.d.f();
        super.a(jSONObject, true);
    }

    /* access modifiers changed from: protected */
    @Override // com.ironsource.mobilcore.H
    public final void c() {
        this.h = new RelativeLayout(this.c);
        this.h.setEnabled(false);
    }

    /* access modifiers changed from: protected */
    @Override // com.ironsource.mobilcore.H
    public final void d() {
        View view = new View(this.c);
        view.setLayoutParams(new RelativeLayout.LayoutParams(-1, C.b(this.c, (float) this.a)));
        C.a(view, this.d.r());
        ((ViewGroup) this.h).addView(view);
    }

    /* access modifiers changed from: protected */
    @Override // com.ironsource.mobilcore.H
    public final void e() {
    }

    /* access modifiers changed from: protected */
    @Override // com.ironsource.mobilcore.I
    public final boolean f() {
        return false;
    }
}
