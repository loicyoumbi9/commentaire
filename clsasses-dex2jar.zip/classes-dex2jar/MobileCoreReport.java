package com.ironsource.mobilcore;

import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import com.ironsource.mobilcore.C0277o;
import com.ironsource.mobilcore.aS;
import java.util.ArrayList;
import java.util.concurrent.LinkedBlockingQueue;

public class MobileCoreReport extends Service {
    private ArrayList a;
    /* access modifiers changed from: private */
    public LinkedBlockingQueue b;
    private Handler c;
    private int d;
    private Runnable e = new Runnable() {
        /* class com.ironsource.mobilcore.MobileCoreReport.AnonymousClass1 */

        public final void run() {
            B.a("MobileCoreReport service , mStopSelfRunnable , run() | called. stopping self", 55);
            MobileCoreReport.this.stopSelf();
        }
    };

    public final class a {
        private int b;
        private Intent c;

        public a(int i, Intent intent) {
            this.b = i;
            this.c = intent;
        }

        /* JADX INFO: Can't fix incorrect switch cases order, some code will duplicate */
        public final void a() {
            if (this.c != null) {
                B.a("MobileCoreReport service , ServiceTask , doJob() | mStartId:" + this.b, 55);
                try {
                    switch ((C0277o.b) this.c.getSerializableExtra("extra_service_type")) {
                        case SERVICE_TYPE_REPORT:
                            new aK().a(MobileCoreReport.this, this.c);
                            return;
                        case SERVICE_TYPE_APK_DOWNLOAD:
                            C0272j.a(MobileCoreReport.this, this.c);
                            return;
                        default:
                            return;
                    }
                } catch (Exception e) {
                    B.a("MobileCoreReport service , ServiceTask , doJob() | dropping request", 55);
                }
                B.a("MobileCoreReport service , ServiceTask , doJob() | dropping request", 55);
            }
        }
    }

    public final class b extends Thread {
        public b() {
        }

        public final void run() {
            super.run();
            while (true) {
                try {
                    MobileCoreReport.this.b();
                    ((a) MobileCoreReport.this.b.take()).a();
                    MobileCoreReport.this.a();
                    MobileCoreReport.b(MobileCoreReport.this);
                } catch (InterruptedException e) {
                    return;
                }
            }
        }
    }

    private void a(boolean z) {
        B.a("MobileCoreReport service , addRemoveStopSelfRunnable() | called. doAdd:" + z, 55);
        if (z) {
            this.c.postDelayed(this.e, 5000);
        } else {
            this.c.removeCallbacks(this.e);
        }
    }

    static /* synthetic */ void b(MobileCoreReport mobileCoreReport) {
        if (mobileCoreReport.b.isEmpty() && mobileCoreReport.c() == 0) {
            mobileCoreReport.a(true);
        }
    }

    private int c() {
        int i;
        synchronized (this) {
            i = this.d;
        }
        return i;
    }

    public final void a() {
        synchronized (this) {
            this.d--;
        }
    }

    public final void b() {
        synchronized (this) {
            this.d++;
        }
    }

    public IBinder onBind(Intent intent) {
        return null;
    }

    public void onCreate() {
        B.a("MobileCoreReport service onCreate() | called", 55);
        MobileCore.b(this);
        this.b = new LinkedBlockingQueue(50);
        this.a = new ArrayList(5);
        this.c = new Handler();
        this.d = 0;
        for (int i = 0; i < 5; i++) {
            b bVar = new b();
            this.a.add(bVar);
            bVar.start();
        }
    }

    public void onDestroy() {
        B.a("MobileCoreReport service onDestroy() | called", 55);
        super.onDestroy();
        this.b.clear();
        this.a.clear();
    }

    public int onStartCommand(Intent intent, int i, int i2) {
        B.a("MobileCoreReport service , onStartCommand() | startId:" + i2, 55);
        a aVar = new a(i2, intent);
        try {
            a(false);
            this.b.add(aVar);
            return 1;
        } catch (IllegalStateException e2) {
            B.a("MobileCoreReport service , ServiceTask , doJob() | dropping request:" + i2, 55);
            new Thread(new Runnable() {
                /* class com.ironsource.mobilcore.MobileCoreReport.AnonymousClass2 */

                public final void run() {
                    aL aLVar = new aL(MobileCoreReport.this, aS.b.REPORT_TYPE_ERROR);
                    aLVar.putExtra("com.ironsource.mobilcore.MobileCoreReport_extra_ex", "MobileCoreReport ### Task queue is full, dropping request");
                    new aK().a(MobileCoreReport.this, aLVar);
                }
            }).start();
            return 1;
        }
    }
}
