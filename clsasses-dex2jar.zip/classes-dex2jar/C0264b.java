package com.ironsource.mobilcore;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Looper;
import com.ironsource.mobilcore.C0269g;
import java.io.IOException;

/* renamed from: com.ironsource.mobilcore.b  reason: case insensitive filesystem */
final class C0264b {

    /* renamed from: com.ironsource.mobilcore.b$a */
    public interface a {
        void a();

        void a(String str, boolean z);
    }

    public static void a(final Context context, final a aVar) {
        if (aVar != null) {
            try {
                if (Looper.myLooper() == Looper.getMainLooper()) {
                    aF.a(new AsyncTask() {
                        /* class com.ironsource.mobilcore.C0264b.AnonymousClass1 */

                        /* access modifiers changed from: protected */
                        @Override // android.os.AsyncTask
                        public final /* synthetic */ Object doInBackground(Object[] objArr) {
                            return C0264b.b(context);
                        }

                        /* access modifiers changed from: protected */
                        @Override // android.os.AsyncTask
                        public final /* synthetic */ void onPostExecute(Object obj) {
                            C0264b.b((C0269g.a) obj, aVar);
                        }
                    }, (Object[]) null);
                } else {
                    b(b(context), aVar);
                }
            } catch (Exception e) {
                aVar.a();
            }
        }
    }

    /* access modifiers changed from: private */
    public static C0269g.a b(Context context) {
        try {
            return C0269g.a(context);
        } catch (C0265c | IOException | Exception e) {
            return null;
        } catch (IllegalStateException e2) {
            e2.printStackTrace();
            return null;
        } catch (C0266d e3) {
            e3.printStackTrace();
            return null;
        }
    }

    /* access modifiers changed from: private */
    public static void b(C0269g.a aVar, a aVar2) {
        if (aVar != null) {
            aVar2.a(aVar.a(), aVar.b());
        } else {
            aVar2.a();
        }
    }
}
