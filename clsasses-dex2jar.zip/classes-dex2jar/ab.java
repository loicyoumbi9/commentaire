package u.aly;

public class ab {
    public String a;
    public long b;

    public ab(String str, long j) {
        this.a = str;
        this.b = j;
    }
}
