package u.aly;

import com.alimama.mobile.csdk.umupdate.a.f;
import com.android.common.Search;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.BitSet;
import java.util.Collections;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class at implements Serializable, Cloneable, ch<at, e> {
    public static final Map<e, ct> d;
    /* access modifiers changed from: private */
    public static final dl e = new dl("Error");
    /* access modifiers changed from: private */
    public static final db f = new db(f.bP, (byte) 10, 1);
    /* access modifiers changed from: private */
    public static final db g = new db("context", (byte) 11, 2);
    /* access modifiers changed from: private */
    public static final db h = new db(Search.SOURCE, (byte) 8, 3);
    private static final Map<Class<? extends Cdo>, dp> i = new HashMap();
    private static final int j = 0;
    public long a;
    public String b;
    public au c;
    private byte k;
    private e[] l;

    private static class a extends dq<at> {
        private a() {
        }

        /* renamed from: a */
        public void b(dg dgVar, at atVar) throws cn {
            dgVar.j();
            while (true) {
                db l = dgVar.l();
                if (l.b == 0) {
                    dgVar.k();
                    if (!atVar.e()) {
                        throw new dh("Required field 'ts' was not found in serialized data! Struct: " + toString());
                    }
                    atVar.m();
                    return;
                }
                switch (l.c) {
                    case 1:
                        if (l.b != 10) {
                            dj.a(dgVar, l.b);
                            break;
                        } else {
                            atVar.a = dgVar.x();
                            atVar.b(true);
                            break;
                        }
                    case 2:
                        if (l.b != 11) {
                            dj.a(dgVar, l.b);
                            break;
                        } else {
                            atVar.b = dgVar.z();
                            atVar.c(true);
                            break;
                        }
                    case 3:
                        if (l.b != 8) {
                            dj.a(dgVar, l.b);
                            break;
                        } else {
                            atVar.c = au.a(dgVar.w());
                            atVar.d(true);
                            break;
                        }
                    default:
                        dj.a(dgVar, l.b);
                        break;
                }
                dgVar.m();
            }
        }

        /* renamed from: b */
        public void a(dg dgVar, at atVar) throws cn {
            atVar.m();
            dgVar.a(at.e);
            dgVar.a(at.f);
            dgVar.a(atVar.a);
            dgVar.c();
            if (atVar.b != null) {
                dgVar.a(at.g);
                dgVar.a(atVar.b);
                dgVar.c();
            }
            if (atVar.c != null && atVar.l()) {
                dgVar.a(at.h);
                dgVar.a(atVar.c.a());
                dgVar.c();
            }
            dgVar.d();
            dgVar.b();
        }
    }

    private static class b implements dp {
        private b() {
        }

        /* renamed from: a */
        public a b() {
            return new a();
        }
    }

    private static class c extends dr<at> {
        private c() {
        }

        public void a(dg dgVar, at atVar) throws cn {
            dm dmVar = (dm) dgVar;
            dmVar.a(atVar.a);
            dmVar.a(atVar.b);
            BitSet bitSet = new BitSet();
            if (atVar.l()) {
                bitSet.set(0);
            }
            dmVar.a(bitSet, 1);
            if (atVar.l()) {
                dmVar.a(atVar.c.a());
            }
        }

        public void b(dg dgVar, at atVar) throws cn {
            dm dmVar = (dm) dgVar;
            atVar.a = dmVar.x();
            atVar.b(true);
            atVar.b = dmVar.z();
            atVar.c(true);
            if (dmVar.b(1).get(0)) {
                atVar.c = au.a(dmVar.w());
                atVar.d(true);
            }
        }
    }

    private static class d implements dp {
        private d() {
        }

        /* renamed from: a */
        public c b() {
            return new c();
        }
    }

    public enum e implements co {
        TS(1, f.bP),
        CONTEXT(2, "context"),
        SOURCE(3, Search.SOURCE);
        
        private static final Map<String, e> d = new HashMap();
        private final short e;
        private final String f;

        static {
            Iterator it = EnumSet.allOf(e.class).iterator();
            while (it.hasNext()) {
                e eVar = (e) it.next();
                d.put(eVar.b(), eVar);
            }
        }

        private e(short s, String str) {
            this.e = s;
            this.f = str;
        }

        public static e a(int i) {
            switch (i) {
                case 1:
                    return TS;
                case 2:
                    return CONTEXT;
                case 3:
                    return SOURCE;
                default:
                    return null;
            }
        }

        public static e a(String str) {
            return d.get(str);
        }

        public static e b(int i) {
            e a = a(i);
            if (a != null) {
                return a;
            }
            throw new IllegalArgumentException("Field " + i + " doesn't exist!");
        }

        @Override // u.aly.co
        public short a() {
            return this.e;
        }

        @Override // u.aly.co
        public String b() {
            return this.f;
        }
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: MutableMD:(java.lang.Object, java.lang.Object):java.lang.Object
     arg types: [u.aly.at$e, u.aly.ct]
     candidates:
      MutableMD:(java.lang.Enum, java.lang.Object):java.lang.Object
      MutableMD:(java.lang.Object, java.lang.Object):java.lang.Object */
    static {
        i.put(dq.class, new b());
        i.put(dr.class, new d());
        EnumMap enumMap = new EnumMap(e.class);
        enumMap.put((Object) e.TS, (Object) new ct(f.bP, (byte) 1, new cu((byte) 10)));
        enumMap.put((Object) e.CONTEXT, (Object) new ct("context", (byte) 1, new cu((byte) 11)));
        enumMap.put((Object) e.SOURCE, (Object) new ct(Search.SOURCE, (byte) 2, new cs(dn.n, au.class)));
        d = Collections.unmodifiableMap(enumMap);
        ct.a(at.class, d);
    }

    public at() {
        this.k = 0;
        this.l = new e[]{e.SOURCE};
    }

    public at(long j2, String str) {
        this();
        this.a = j2;
        b(true);
        this.b = str;
    }

    public at(at atVar) {
        this.k = 0;
        this.l = new e[]{e.SOURCE};
        this.k = atVar.k;
        this.a = atVar.a;
        if (atVar.i()) {
            this.b = atVar.b;
        }
        if (atVar.l()) {
            this.c = atVar.c;
        }
    }

    private void a(ObjectInputStream objectInputStream) throws IOException, ClassNotFoundException {
        try {
            this.k = 0;
            a(new da(new ds(objectInputStream)));
        } catch (cn e2) {
            throw new IOException(e2.getMessage());
        }
    }

    private void a(ObjectOutputStream objectOutputStream) throws IOException {
        try {
            b(new da(new ds(objectOutputStream)));
        } catch (cn e2) {
            throw new IOException(e2.getMessage());
        }
    }

    /* renamed from: a */
    public e b(int i2) {
        return e.a(i2);
    }

    /* renamed from: a */
    public at g() {
        return new at(this);
    }

    public at a(long j2) {
        this.a = j2;
        b(true);
        return this;
    }

    public at a(String str) {
        this.b = str;
        return this;
    }

    public at a(au auVar) {
        this.c = auVar;
        return this;
    }

    @Override // u.aly.ch
    public void a(dg dgVar) throws cn {
        i.get(dgVar.D()).b().b(dgVar, this);
    }

    @Override // u.aly.ch
    public void b() {
        b(false);
        this.a = 0;
        this.b = null;
        this.c = null;
    }

    @Override // u.aly.ch
    public void b(dg dgVar) throws cn {
        i.get(dgVar.D()).b().a(dgVar, this);
    }

    public void b(boolean z) {
        this.k = ce.a(this.k, 0, z);
    }

    public long c() {
        return this.a;
    }

    public void c(boolean z) {
        if (!z) {
            this.b = null;
        }
    }

    public void d() {
        this.k = ce.b(this.k, 0);
    }

    public void d(boolean z) {
        if (!z) {
            this.c = null;
        }
    }

    public boolean e() {
        return ce.a(this.k, 0);
    }

    public String f() {
        return this.b;
    }

    public void h() {
        this.b = null;
    }

    public boolean i() {
        return this.b != null;
    }

    public au j() {
        return this.c;
    }

    public void k() {
        this.c = null;
    }

    public boolean l() {
        return this.c != null;
    }

    public void m() throws cn {
        if (this.b == null) {
            throw new dh("Required field 'context' was not present! Struct: " + toString());
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("Error(");
        sb.append("ts:");
        sb.append(this.a);
        sb.append(", ");
        sb.append("context:");
        if (this.b == null) {
            sb.append(f.b);
        } else {
            sb.append(this.b);
        }
        if (l()) {
            sb.append(", ");
            sb.append("source:");
            if (this.c == null) {
                sb.append(f.b);
            } else {
                sb.append(this.c);
            }
        }
        sb.append(")");
        return sb.toString();
    }
}
