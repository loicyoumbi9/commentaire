package com.android.fontmodule;

import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ListActivity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.support.v4.view.ViewCompat;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.alimama.mobile.csdk.umupdate.a.f;
import com.android.common.inbuymodule.TrackerWrapper;
import com.android.common.inbuymodule.UpdateVersion;
import com.android.fontmodule.scanfonts.ScanTtf;
import com.android.fontmodule.scanfonts.TtfFontInfo;
import com.android.fontmodule.scanfonts.TtfFontsListActivity;
import com.google.android.gms.drive.DriveFile;
import com.google.android.gms.location.LocationRequest;
import com.iphonestyle.mms.ConstSetting;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

public class FontFileListActivity extends ListActivity {
    private static final String APP_PKG = "com.crazygame.inputmethod.keyboard7";
    private static String PKG_THEME_NAME = "/sdcard/.keyboard7_font.log";
    private static String PKG_THEME_SELECT = "pref_key_font_pkg_name";
    /* access modifiers changed from: private */
    public static String THEME_URL = "https://play.google.com/store/search?q=FlipFont&c=apps&price=1";
    public static ActivityManager am;
    private static boolean mBuyStatus = false;
    private String ADS;
    /* access modifiers changed from: private */
    public Handler mHandler;
    private String mKey = "";
    /* access modifiers changed from: private */
    public List<TtfFontInfo> mList;
    /* access modifiers changed from: private */
    public ScanTtf mScanTtf = null;
    String[][] mThemes;
    /* access modifiers changed from: private */
    public long time;

    public interface OnUpdateListener {
        void onUpdate(List<BaseAppItem> list);
    }

    public class ProcessAdapter extends BaseAdapter {
        public ProcessAdapter(List<TtfFontInfo> list) {
        }

        public int getCount() {
            return FontFileListActivity.this.mList.size();
        }

        public TtfFontInfo getItem(int i) {
            if (FontFileListActivity.this.mList.size() > 0) {
                return (TtfFontInfo) FontFileListActivity.this.mList.get(i);
            }
            return null;
        }

        public long getItemId(int i) {
            return (long) i;
        }

        /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
         method: ClspMth{android.view.LayoutInflater.inflate(int, android.view.ViewGroup, boolean):android.view.View}
         arg types: [int, android.view.ViewGroup, int]
         candidates:
          ClspMth{android.view.LayoutInflater.inflate(org.xmlpull.v1.XmlPullParser, android.view.ViewGroup, boolean):android.view.View}
          ClspMth{android.view.LayoutInflater.inflate(int, android.view.ViewGroup, boolean):android.view.View} */
        public View getView(int i, View view, ViewGroup viewGroup) {
            TtfFontInfo item = getItem(i);
            if (view == null) {
                view = FontFileListActivity.this.getLayoutInflater().inflate(R.layout.theme_preview, viewGroup, false);
            }
            ImageView imageView = (ImageView) view.findViewById(16908294);
            TextView textView = (TextView) view.findViewById(16908310);
            CheckBox checkBox = (CheckBox) view.findViewById(R.id.alert_select);
            if (item != null) {
                boolean access$800 = FontFileListActivity.this.checkSelect(FontFileListActivity.this.getBaseContext(), item.getPackageName() + ":" + item.getFile());
                if (access$800 && !checkBox.isChecked()) {
                    checkBox.setChecked(true);
                } else if (!access$800) {
                    checkBox.setChecked(false);
                }
                checkBox.setTag(item);
                checkBox.setOnClickListener(new View.OnClickListener() {
                    /* class com.android.fontmodule.FontFileListActivity.ProcessAdapter.AnonymousClass1 */

                    public void onClick(View view) {
                        if (view instanceof CheckBox) {
                            boolean isChecked = ((CheckBox) view).isChecked();
                            TtfFontInfo ttfFontInfo = (TtfFontInfo) view.getTag();
                            String str = !isChecked ? "" : ttfFontInfo.getPackageName() + ":" + ttfFontInfo.getFile();
                            FontFileListActivity.this.setSelect(view.getContext(), str);
                            if (str.length() > 0) {
                                UpdateVersion.onEventClickThemeSwitch(view.getContext(), str, "");
                            }
                            ProcessAdapter.this.notifyDataSetChanged();
                        }
                    }
                });
                Drawable icon = item.getIcon();
                textView.setTextColor((int) ViewCompat.MEASURED_STATE_MASK);
                if (icon != null) {
                    icon.setAlpha(255);
                }
                imageView.setImageDrawable(icon);
                imageView.setVisibility(8);
                textView.setText(item.getFile());
                Context context = view.getContext();
                Typeface font = item.getFont();
                if (font == null) {
                    font = ScanTtf.getInstance(context).getTtfFont(context, item.getPkg(), item.getFile());
                    item.setFont(font);
                }
                if (font != null) {
                    textView.setTypeface(font);
                }
                Log.e("Time", "used time:" + (System.currentTimeMillis() - FontFileListActivity.this.time));
            }
            return view;
        }
    }

    public FontFileListActivity() {
        String[] strArr = {"Classic Black", "water_black", "com.wavestudio.theme.black"};
        String[] strArr2 = {"Red Love", "redlove", "com.wavestudio.theme.redlove"};
        this.mThemes = new String[][]{new String[]{"Default", "crazystudio_defaut", "4"}, strArr, new String[]{"White Blue Circle", "water_whiteblue_circle", "com.wavestudio.theme.whiteblue"}, strArr2, new String[]{"GO White Flat", "ic_go_white_emojikeyboard", "com.jb.gokeyboard.theme.white"}, new String[]{"White Flat", "crazystudio_white_flat", "5"}};
        this.time = 0;
        this.ADS = "";
    }

    private static boolean checkAppExist(Context context, String str) {
        Context context2 = null;
        try {
            context2 = context.createPackageContext(str, 2);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return context2 != null;
    }

    private static boolean checkGooglePlay(Context context) {
        Context context2;
        try {
            context2 = context.createPackageContext("com.android.vending", 2);
        } catch (Exception e) {
            e.printStackTrace();
            context2 = null;
        }
        return context2 != null;
    }

    /* access modifiers changed from: private */
    public boolean checkSelect(Context context, String str) {
        return PreferenceManager.getDefaultSharedPreferences(context).getString(this.mKey, "").equalsIgnoreCase(str);
    }

    public static BaseAppItem constructBaseAppItem(Context context, String str) {
        PackageManager packageManager = context.getPackageManager();
        try {
            return new BaseAppItem((String) packageManager.getPackageInfo(str, 0).applicationInfo.loadLabel(packageManager), str, null);
        } catch (Exception e) {
            return null;
        }
    }

    public static int getAppVersionCode(Context context, String str) {
        try {
            return context.createPackageContext(str, 2).getPackageManager().getPackageInfo(str, 0).versionCode;
        } catch (Exception e) {
            Log.e("VersionInfo", "Exception", e);
            return 0;
        }
    }

    public static void getNeedAppItems(Context context, String str, List<BaseAppItem> list) {
        int i = 0;
        Intent intent = new Intent("android.intent.action.MAIN", (Uri) null);
        intent.addCategory("android.intent.category.LAUNCHER");
        PackageManager packageManager = context.getPackageManager();
        PackageManager packageManager2 = context.getPackageManager();
        List<ResolveInfo> queryIntentActivities = packageManager.queryIntentActivities(intent, 0);
        while (true) {
            try {
                int i2 = i;
                if (i2 < queryIntentActivities.size()) {
                    int i3 = packageManager2.getApplicationInfo(queryIntentActivities.get(i2).activityInfo.packageName, 0).flags;
                    int i4 = queryIntentActivities.get(i2).activityInfo.flags;
                    if ((i3 & 1) != 0 && queryIntentActivities.get(i2).activityInfo.packageName.contains(str)) {
                        list.add(0, constructBaseAppItem(context, queryIntentActivities.get(i2).activityInfo.packageName));
                    }
                    i = i2 + 1;
                } else {
                    return;
                }
            } catch (Exception e) {
                e.printStackTrace();
                return;
            }
        }
    }

    public static void getNeedAppItems(Context context, String[] strArr, List<BaseAppItem> list) {
        Intent intent = new Intent("android.intent.action.MAIN", (Uri) null);
        intent.addCategory("android.intent.category.LAUNCHER");
        PackageManager packageManager = context.getPackageManager();
        PackageManager packageManager2 = context.getPackageManager();
        List<ResolveInfo> queryIntentActivities = packageManager.queryIntentActivities(intent, 0);
        int i = 0;
        while (i < queryIntentActivities.size()) {
            try {
                int i2 = packageManager2.getApplicationInfo(queryIntentActivities.get(i).activityInfo.packageName, 0).flags;
                int i3 = queryIntentActivities.get(i).activityInfo.flags;
                if ((i2 & 1) != 0) {
                    String str = queryIntentActivities.get(i).activityInfo.packageName;
                    int i4 = 0;
                    while (true) {
                        if (i4 >= strArr.length) {
                            break;
                        } else if (str.equalsIgnoreCase(strArr[i4])) {
                            list.add(0, constructBaseAppItem(context, queryIntentActivities.get(i).activityInfo.packageName));
                            break;
                        } else {
                            i4++;
                        }
                    }
                }
                i++;
            } catch (Exception e) {
                e.printStackTrace();
                return;
            }
        }
    }

    public static Drawable getRes(Context context, String str, String str2, String str3) {
        PackageManager packageManager = context.getPackageManager();
        if (packageManager == null) {
            return null;
        }
        try {
            Resources resourcesForApplication = packageManager.getResourcesForApplication(str);
            int identifier = resourcesForApplication.getIdentifier(str3, str2, str);
            if (identifier > 0) {
                return resourcesForApplication.getDrawable(identifier);
            }
            return null;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static boolean getStatus(Context context) {
        return mBuyStatus;
    }

    /* access modifiers changed from: private */
    public void installThemeTip(boolean z) {
        final SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        if (z || !defaultSharedPreferences.getBoolean("pref_key_ignore_popup", false)) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            String str = this.mList.size() <= 0 ? "Do you want to install more Fonts?" + "\nCan't find any font." : "Do you want to install more Fonts?";
            View inflate = LayoutInflater.from(this).inflate(R.layout.custom_dialog, (ViewGroup) null);
            ((TextView) inflate.findViewById(R.id.message)).setText(str);
            CheckBox checkBox = (CheckBox) inflate.findViewById(R.id.ignore_it);
            if (defaultSharedPreferences.getBoolean("pref_key_ignore_popup", false)) {
                checkBox.setChecked(true);
            }
            checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                /* class com.android.fontmodule.FontFileListActivity.AnonymousClass1 */

                public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                    defaultSharedPreferences.edit().putBoolean("pref_key_ignore_popup", z).commit();
                }
            });
            builder.setView(inflate);
            builder.setTitle("Install");
            String onlineKeyValue = TrackerWrapper.getOnlineKeyValue(this, "theme_url");
            if (onlineKeyValue.length() > 0 && !onlineKeyValue.equalsIgnoreCase(f.b)) {
                THEME_URL = onlineKeyValue;
            }
            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                /* class com.android.fontmodule.FontFileListActivity.AnonymousClass2 */

                public void onClick(DialogInterface dialogInterface, int i) {
                    FontFileListActivity.rateDirectBrowser(FontFileListActivity.this, FontFileListActivity.THEME_URL);
                }
            });
            builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                /* class com.android.fontmodule.FontFileListActivity.AnonymousClass3 */

                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                }
            });
            builder.create().show();
        }
    }

    private boolean isValidPkg(String str) {
        return str.length() > 3;
    }

    public static void killProcess(String str) {
        am.restartPackage(str);
    }

    /* access modifiers changed from: private */
    public void load(boolean z) {
        if (z) {
            TtfFontsListActivity.resetFont();
            TtfFontsListActivity.initFonts(this);
        }
        this.mList = TtfFontsListActivity.getFont();
        if (this.mList.size() <= 0) {
            TtfFontsListActivity.initFonts(this);
        }
        if (getIntent() != null) {
            String stringExtra = getIntent().getStringExtra("buystatus");
            if (stringExtra != null && stringExtra.equalsIgnoreCase(ConstSetting.IOS7_ENABLE)) {
                mBuyStatus = true;
            }
            Log.e("BUYSTATUS", "status:" + mBuyStatus);
        }
        boolean checkAppExist = checkAppExist(this, APP_PKG);
        am = (ActivityManager) getSystemService("activity");
        if (checkAppExist) {
            new Handler().postDelayed(new Runnable() {
                /* class com.android.fontmodule.FontFileListActivity.AnonymousClass4 */

                public void run() {
                    FontFileListActivity.this.installThemeTip(false);
                }
            }, 500);
        }
        String[] strArr = new String[this.mList.size()];
        int i = 0;
        while (true) {
            int i2 = i;
            if (i2 >= strArr.length) {
                break;
            }
            strArr[i2] = new String(this.mList.get(i2).getFile());
            i = i2 + 1;
        }
        ListView listView = (ListView) findViewById(16908298);
        if (this.mList.size() > 0) {
            setListAdapter(new ProcessAdapter(this.mList));
        }
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            /* class com.android.fontmodule.FontFileListActivity.AnonymousClass5 */

            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                if (FontFileListActivity.this.mList != null) {
                    TtfFontInfo ttfFontInfo = (TtfFontInfo) FontFileListActivity.this.mList.get(i);
                    ((CheckBox) view.findViewById(R.id.alert_select)).setChecked(true);
                    String str = ttfFontInfo.getPackageName() + ":" + ttfFontInfo.getFile();
                    FontFileListActivity.this.setSelect(view.getContext(), str);
                    if (str.length() > 0) {
                        UpdateVersion.onEventClickThemeSwitch(view.getContext(), str, "");
                    }
                    ((ProcessAdapter) FontFileListActivity.this.getListAdapter()).notifyDataSetChanged();
                }
            }
        });
        loadAdView();
        Log.e("Time", "used time:" + (System.currentTimeMillis() - this.time));
    }

    private void loadAdView() {
        TrackerWrapper.getOnlineKeyValue(this, "publish-allow");
        RelativeLayout relativeLayout = (RelativeLayout) findViewById(R.id.mainLayout);
        if (relativeLayout != null) {
            relativeLayout.setVisibility(8);
        }
    }

    private boolean noneedFlatWhite() {
        return TrackerWrapper.getOnlineKeyValue(this, "whiteflat-allow").equalsIgnoreCase("false");
    }

    public static void rate(Context context, String str) {
        try {
            if (checkGooglePlay(context)) {
                rateMarket(context, str);
            } else {
                rateBrowser(context, str);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void rateBrowser(Context context, String str) {
        Uri parse = Uri.parse("http://market.android.com/details?id=" + str);
        if (!TextUtils.isEmpty("") && !"".equalsIgnoreCase(f.b)) {
            parse = Uri.parse("");
        }
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.setData(parse);
        context.startActivity(intent);
    }

    public static void rateDirectBrowser(Context context, String str) {
        Uri parse = Uri.parse(str);
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.setData(parse);
        intent.addFlags(DriveFile.MODE_READ_ONLY);
        context.startActivity(intent);
    }

    private static void rateMarket(Context context, String str) {
        Uri parse = Uri.parse("market://details?id=" + str);
        if (!TextUtils.isEmpty("") && !"".equalsIgnoreCase(f.b)) {
            parse = Uri.parse("");
        }
        Intent intent = new Intent();
        intent.setData(parse);
        context.startActivity(intent);
    }

    private static String readSDFile(Context context, String str) {
        try {
            FileInputStream fileInputStream = new FileInputStream(str);
            byte[] bArr = new byte[fileInputStream.available()];
            if (fileInputStream.read(bArr) > 0) {
                return new String(bArr);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    private void scanfont(String str) {
        final CustomDialog customDialog = new CustomDialog(this);
        customDialog.show();
        this.mScanTtf = ScanTtf.getInstance(this);
        this.mScanTtf.startScan(str);
        ((Button) customDialog.findViewById(R.id.cancel)).setOnClickListener(new View.OnClickListener() {
            /* class com.android.fontmodule.FontFileListActivity.AnonymousClass6 */

            public void onClick(View view) {
                FontFileListActivity.this.mScanTtf.cancel();
            }
        });
        this.mScanTtf.setUpdateListener(new ScanTtf.OnScanListener() {
            /* class com.android.fontmodule.FontFileListActivity.AnonymousClass7 */

            @Override // com.android.fontmodule.scanfonts.ScanTtf.OnScanListener
            public void onUpdate(List<TtfFontInfo> list, String str) {
                if (str.equalsIgnoreCase("-1")) {
                    if (list == null || list.size() <= 0) {
                        Toast.makeText(FontFileListActivity.this, "Please try to click \"Scan all Font!\"", 5000).show();
                    }
                    customDialog.dismiss();
                    return;
                }
                FontFileListActivity.this.setCurrentPkg(customDialog, str);
                FontFileListActivity.this.setFindResult(customDialog, "Find out " + list.size() + " font files.");
            }
        });
        customDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            /* class com.android.fontmodule.FontFileListActivity.AnonymousClass8 */

            public void onDismiss(DialogInterface dialogInterface) {
                FontFileListActivity.this.load(true);
            }
        });
    }

    /* access modifiers changed from: private */
    public void setCurrentPkg(Dialog dialog, String str) {
        TextView textView = (TextView) dialog.findViewById(R.id.ttffile);
        if (textView != null) {
            textView.setText(str);
        }
    }

    /* access modifiers changed from: private */
    public void setFindResult(Dialog dialog, String str) {
        TextView textView = (TextView) dialog.findViewById(R.id.scanresult);
        if (textView != null) {
            textView.setText(str);
        }
    }

    /* access modifiers changed from: private */
    public void setSelect(Context context, String str) {
        PreferenceManager.getDefaultSharedPreferences(context).edit().putString(this.mKey, str).commit();
    }

    private void setThemePkg(String str) {
        writeSDFile(PKG_THEME_NAME, str);
    }

    private void testKeyboard() {
        final EditText editText = new EditText(this);
        new AlertDialog.Builder(this).setTitle("Preview Keyboard Font:").setIcon(17301659).setView(editText).setPositiveButton("OK", (DialogInterface.OnClickListener) null).setNegativeButton("Cancel", (DialogInterface.OnClickListener) null).show();
        new Handler().postDelayed(new Runnable() {
            /* class com.android.fontmodule.FontFileListActivity.AnonymousClass10 */

            public void run() {
                editText.requestFocus();
                ((InputMethodManager) FontFileListActivity.this.getSystemService("input_method")).showSoftInput(editText, 0);
            }
        }, 300);
    }

    private void updateItemFont(final Context context) {
        if (this.mList != null) {
            new Thread(new Runnable() {
                /* class com.android.fontmodule.FontFileListActivity.AnonymousClass9 */

                public void run() {
                    int i = 0;
                    while (true) {
                        int i2 = i;
                        if (i2 < FontFileListActivity.this.mList.size()) {
                            TtfFontInfo ttfFontInfo = (TtfFontInfo) FontFileListActivity.this.mList.get(i2);
                            if (ttfFontInfo.getFont() == null) {
                                ttfFontInfo.setFont(ScanTtf.getInstance(context).getTtfFont(context, ttfFontInfo.getPkg(), ttfFontInfo.getFile()));
                            }
                            i = i2 + 1;
                        } else {
                            FontFileListActivity.this.mHandler.post(new Runnable() {
                                /* class com.android.fontmodule.FontFileListActivity.AnonymousClass9.AnonymousClass1 */

                                public void run() {
                                    ListAdapter adapter = FontFileListActivity.this.getListView().getAdapter();
                                    if (adapter instanceof ProcessAdapter) {
                                        ((ProcessAdapter) adapter).notifyDataSetChanged();
                                    }
                                }
                            });
                            return;
                        }
                    }
                }
            }).start();
        }
    }

    public static void writeSDFile(String str, String str2) {
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(str);
            fileOutputStream.write(str2.getBytes());
            fileOutputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<BaseAppItem> getGoThemes(Context context, String str, List<BaseAppItem> list, OnUpdateListener onUpdateListener) {
        String str2;
        ArrayList arrayList = new ArrayList();
        List<PackageInfo> installedPackages = context.getPackageManager().getInstalledPackages(0);
        for (int i = 0; i < installedPackages.size(); i++) {
            PackageInfo packageInfo = installedPackages.get(i);
            String str3 = packageInfo.packageName;
            int i2 = 0;
            while (true) {
                if (i2 >= this.mThemes.length) {
                    str2 = str3;
                    break;
                } else if (this.mThemes[i2][2].equalsIgnoreCase(str3)) {
                    str2 = "";
                    break;
                } else {
                    i2++;
                }
            }
            if (str2.contains(str)) {
                list.add(0, constructBaseAppItem(context, packageInfo.packageName));
                if (onUpdateListener != null) {
                    onUpdateListener.onUpdate(arrayList);
                }
            }
        }
        return list;
    }

    public void initDefaultThemes(Context context) {
        String packageName = context.getPackageName();
        for (int i = 0; i < this.mThemes.length; i++) {
            Drawable res = getRes(context, packageName, f.bv, this.mThemes[i][1]);
            if (res != null && ((!this.mThemes[i][2].equalsIgnoreCase("com.jb.gokeyboard.theme.white") || checkAppExist(context, this.mThemes[i][2])) && (!noneedFlatWhite() || !this.mThemes[i][2].equalsIgnoreCase("5")))) {
                new BaseAppItem(this.mThemes[i][0], this.mThemes[i][2], res);
            }
        }
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.time = System.currentTimeMillis();
        this.mHandler = new Handler();
        if (getIntent() != null) {
            this.mKey = getIntent().getStringExtra("key_name");
            if (this.mKey == null || this.mKey.length() <= 0) {
                finish();
                return;
            }
            this.ADS = getIntent().getStringExtra("key_adsid");
        }
        setContentView(R.layout.themelist);
        this.mScanTtf = ScanTtf.getInstance(this);
        if (getIntent() != null) {
            getIntent().getStringExtra("scantype");
        }
        TtfFontsListActivity.initFonts(this);
        if (TtfFontsListActivity.getFont().size() <= 0) {
            scanfont("simple");
        } else {
            load(false);
        }
        UpdateVersion.checkUpdateWhenStart(this);
    }

    /* access modifiers changed from: protected */
    public void onDestroy() {
        if (this.mList != null) {
            int i = 0;
            while (true) {
                int i2 = i;
                if (i2 >= this.mList.size()) {
                    break;
                }
                TtfFontInfo ttfFontInfo = this.mList.get(i2);
                if (ttfFontInfo.getFont() != null) {
                    ttfFontInfo.setFont(null);
                }
                i = i2 + 1;
            }
            System.gc();
        }
        super.onDestroy();
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case 101:
                installThemeTip(true);
                break;
            case 103:
                testKeyboard();
                break;
            case LocationRequest.PRIORITY_LOW_POWER /*104*/:
                scanfont("");
                break;
            case LocationRequest.PRIORITY_NO_POWER /*105*/:
                scanfont("simple");
                break;
        }
        return super.onOptionsItemSelected(menuItem);
    }

    /* access modifiers changed from: protected */
    public void onPause() {
        super.onPause();
    }

    public boolean onPrepareOptionsMenu(Menu menu) {
        menu.clear();
        menu.addSubMenu(0, (int) LocationRequest.PRIORITY_NO_POWER, 1, R.string.quick_scan_font).setIcon((Drawable) null);
        menu.addSubMenu(0, (int) LocationRequest.PRIORITY_LOW_POWER, 1, R.string.scan_font).setIcon((Drawable) null);
        menu.addSubMenu(0, 101, 1, R.string.more_themes).setIcon((Drawable) null);
        return super.onPrepareOptionsMenu(menu);
    }

    /* access modifiers changed from: protected */
    public void onResume() {
        super.onResume();
        UpdateVersion.onEventOpenActivity(this, "fontsetting");
    }
}
