package com.android.fontmodule;

import android.app.Activity;
import android.os.Bundle;

public class UpdateActivity extends Activity {
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
    }
}
