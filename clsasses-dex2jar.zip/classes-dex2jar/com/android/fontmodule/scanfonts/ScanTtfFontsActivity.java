package com.android.fontmodule.scanfonts;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import com.android.fontmodule.FontFileListActivity;
import com.android.fontmodule.R;
import com.android.fontmodule.scanfonts.ScanTtf;
import java.util.List;

public class ScanTtfFontsActivity extends Activity {
    /* access modifiers changed from: private */
    public ScanTtf mScanTtf = null;

    /* access modifiers changed from: private */
    public void setCurrentPkg(String str) {
        TextView textView = (TextView) findViewById(R.id.ttffile);
        if (textView != null) {
            textView.setText(str);
        }
    }

    /* access modifiers changed from: private */
    public void setFindResult(String str) {
        TextView textView = (TextView) findViewById(R.id.scanresult);
        if (textView != null) {
            textView.setText(str);
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.scan_ttf);
        this.mScanTtf = ScanTtf.getInstance(this);
        ((Button) findViewById(R.id.cancel)).setOnClickListener(new View.OnClickListener() {
            /* class com.android.fontmodule.scanfonts.ScanTtfFontsActivity.AnonymousClass1 */

            public void onClick(View view) {
                ScanTtfFontsActivity.this.mScanTtf.cancel();
                ScanTtfFontsActivity.this.finish();
            }
        });
        this.mScanTtf.setUpdateListener(new ScanTtf.OnScanListener() {
            /* class com.android.fontmodule.scanfonts.ScanTtfFontsActivity.AnonymousClass2 */

            @Override // com.android.fontmodule.scanfonts.ScanTtf.OnScanListener
            public void onUpdate(List<TtfFontInfo> list, String str) {
                if (str.equalsIgnoreCase("-1")) {
                    ScanTtfFontsActivity.this.finish();
                    return;
                }
                ScanTtfFontsActivity.this.setCurrentPkg(str);
                ScanTtfFontsActivity.this.setFindResult("Find out " + list.size() + " font files.");
            }
        });
        String str = "";
        if (getIntent() != null) {
            str = getIntent().getStringExtra("scantype");
        }
        TtfFontsListActivity.initFonts(this, "scan_ttf_fonts");
        TtfFontsListActivity.initFonts(this, "scan_ttf_fonts_flipfont");
        if (this.mScanTtf.getFonts().size() <= 0) {
            this.mScanTtf.startScan(str);
            this.mScanTtf.setUpdateListener(new ScanTtf.OnScanListener() {
                /* class com.android.fontmodule.scanfonts.ScanTtfFontsActivity.AnonymousClass3 */

                @Override // com.android.fontmodule.scanfonts.ScanTtf.OnScanListener
                public void onUpdate(List<TtfFontInfo> list, String str) {
                    if (str.equalsIgnoreCase("-1")) {
                        ScanTtfFontsActivity.this.startActivity(new Intent(ScanTtfFontsActivity.this, FontFileListActivity.class));
                        ScanTtfFontsActivity.this.finish();
                    }
                }
            });
            return;
        }
        startActivity(new Intent(this, FontFileListActivity.class));
        finish();
    }
}
