package com.android.fontmodule.scanfonts;

import android.graphics.Typeface;
import android.graphics.drawable.Drawable;

public class TtfFontInfo {
    String file;
    Typeface font;
    String pkg;

    public TtfFontInfo(String str, String str2) {
        this.pkg = str;
        this.file = str2;
    }

    public String getFile() {
        return this.file;
    }

    public Typeface getFont() {
        return this.font;
    }

    public Drawable getIcon() {
        return null;
    }

    public String getPackageName() {
        return this.pkg;
    }

    public String getPkg() {
        return this.pkg;
    }

    public void setFont(Typeface typeface) {
        this.font = typeface;
    }
}
