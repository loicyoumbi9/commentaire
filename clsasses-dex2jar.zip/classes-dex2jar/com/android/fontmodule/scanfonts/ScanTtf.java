package com.android.fontmodule.scanfonts;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ScanTtf {
    private static final String FLIPFONT = "com.monotype.android.font";
    public static final String SCAN_TTF_RESULT = "scan_ttf_fonts";
    public static final String SCAN_TTF_RESULT_FLIPFONT = "scan_ttf_fonts_flipfont";
    private static ScanTtf mInstance = null;
    Context mContext = null;
    List<String> mDownloardApp = new ArrayList();
    boolean mExit = false;
    Handler mHandler = new Handler();
    public ArrayList<TtfFontInfo> mListFont = new ArrayList<>();
    OnScanListener mScanUpdateListener = null;

    public interface OnScanListener {
        void onUpdate(List<TtfFontInfo> list, String str);
    }

    public interface OnUpdateListener {
        void onUpdate(List<String> list);
    }

    public ScanTtf(Context context) {
        this.mContext = context;
    }

    public static List<String> getAllApps(Context context, OnUpdateListener onUpdateListener) {
        int i = 0;
        ArrayList arrayList = new ArrayList();
        List<PackageInfo> installedPackages = context.getPackageManager().getInstalledPackages(0);
        while (true) {
            int i2 = i;
            if (i2 >= installedPackages.size()) {
                return arrayList;
            }
            PackageInfo packageInfo = installedPackages.get(i2);
            String str = packageInfo.packageName;
            if (TextUtils.isEmpty(str)) {
                str = packageInfo.applicationInfo.packageName;
            }
            if (TextUtils.isEmpty(str)) {
                str = packageInfo.applicationInfo.processName;
            }
            if (!TextUtils.isEmpty(str) && str != null) {
                arrayList.add(str);
                if (onUpdateListener != null) {
                    onUpdateListener.onUpdate(arrayList);
                }
            }
            i = i2 + 1;
        }
    }

    public static List<String> getDownloadApps(Context context, OnUpdateListener onUpdateListener) {
        int i = 0;
        ArrayList arrayList = new ArrayList();
        List<PackageInfo> installedPackages = context.getPackageManager().getInstalledPackages(0);
        while (true) {
            int i2 = i;
            if (i2 >= installedPackages.size()) {
                return arrayList;
            }
            PackageInfo packageInfo = installedPackages.get(i2);
            int i3 = packageInfo.applicationInfo.flags;
            ApplicationInfo applicationInfo = packageInfo.applicationInfo;
            if ((i3 & 1) <= 0) {
                String str = packageInfo.packageName;
                if (TextUtils.isEmpty(str)) {
                    str = packageInfo.applicationInfo.packageName;
                }
                if (TextUtils.isEmpty(str)) {
                    str = packageInfo.applicationInfo.processName;
                }
                if (!TextUtils.isEmpty(str) && str != null) {
                    arrayList.add(str);
                    if (onUpdateListener != null) {
                        onUpdateListener.onUpdate(arrayList);
                    }
                }
            }
            i = i2 + 1;
        }
    }

    public static ScanTtf getInstance(Context context) {
        if (mInstance == null) {
            mInstance = new ScanTtf(context);
        }
        return mInstance;
    }

    private String getOutput() {
        String str = "follow font info:";
        int i = 0;
        while (true) {
            String str2 = str;
            if (i >= this.mListFont.size()) {
                return str2;
            }
            Log.e("Font", "pkg:" + this.mListFont.get(i).pkg + "file:" + this.mListFont.get(i).file);
            str = str2 + "pkg:" + this.mListFont.get(i).pkg + "file:" + this.mListFont.get(i).file + "\n";
            i++;
        }
    }

    public static List<String> getSystemApps(Context context, OnUpdateListener onUpdateListener) {
        int i = 0;
        ArrayList arrayList = new ArrayList();
        Intent intent = new Intent("android.intent.action.MAIN", (Uri) null);
        intent.addCategory("android.intent.category.LAUNCHER");
        PackageManager packageManager = context.getPackageManager();
        PackageManager packageManager2 = context.getPackageManager();
        List<ResolveInfo> queryIntentActivities = packageManager.queryIntentActivities(intent, 0);
        while (true) {
            try {
                int i2 = i;
                if (i2 >= queryIntentActivities.size()) {
                    break;
                }
                int i3 = packageManager2.getApplicationInfo(queryIntentActivities.get(i2).activityInfo.packageName, 0).flags;
                int i4 = queryIntentActivities.get(i2).activityInfo.flags;
                if ((i3 & 1) != 0) {
                    arrayList.add(queryIntentActivities.get(i2).activityInfo.packageName);
                    if (onUpdateListener != null) {
                        onUpdateListener.onUpdate(arrayList);
                    }
                }
                i = i2 + 1;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return arrayList;
    }

    private Typeface getTtfFont(Resources resources, String str) {
        try {
            return Typeface.createFromAsset(resources.getAssets(), str);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private boolean needScan(String str) {
        return !str.equalsIgnoreCase("images") && str.length() > 0 && !(((str.equalsIgnoreCase("kioskmode") | str.equalsIgnoreCase("sounds")) | str.equalsIgnoreCase("armeabi")) | str.equalsIgnoreCase("x86")) && !str.equalsIgnoreCase("mips") && !str.equalsIgnoreCase("webkit") && (str.equalsIgnoreCase("font") || str.equalsIgnoreCase("fonts"));
    }

    private void saveTtfResult(Context context, String str) {
        String str2 = "";
        for (int i = 0; i < this.mListFont.size(); i++) {
            str2 = str2 + "" + this.mListFont.get(i).pkg + ":" + this.mListFont.get(i).file + "\n";
        }
        writeData(context, str2, str);
    }

    private void saveTtfResultExcludeFlip(Context context, String str) {
        String str2 = "";
        int i = 0;
        while (i < this.mListFont.size()) {
            String str3 = this.mListFont.get(i).pkg.contains(FLIPFONT) ? str2 : str2 + "" + this.mListFont.get(i).pkg + ":" + this.mListFont.get(i).file + "\n";
            i++;
            str2 = str3;
        }
        writeData(context, str2, str);
    }

    private void scanAssets(Resources resources, String str, String str2, String str3) {
        try {
            String[] list = resources.getAssets().list(str);
            if (str.length() == 0) {
                Log.e("TAG", "size:" + list.length + "pkg:" + str3);
            }
            for (String str4 : list) {
                if (str4.contains(".") || !needScan(str4)) {
                    if (str4.endsWith(".ttf") || str4.endsWith(".ttc") || str4.endsWith(".otf")) {
                        this.mListFont.add(new TtfFontInfo(str3, str2 + str4));
                    }
                } else if (str.length() == 0) {
                    scanAssets(resources, str4, str2 + str4 + "/", str3);
                } else {
                    scanAssets(resources, str + "/" + str4, str2 + "/" + str4 + "/", str3);
                }
            }
        } catch (IOException e) {
        }
    }

    /* access modifiers changed from: private */
    public void scanTtfFonts(Context context, final List<String> list) {
        PackageManager packageManager = context.getPackageManager();
        final int i = 0;
        while (true) {
            if (i >= list.size()) {
                break;
            }
            try {
                if (list.get(i).contains(FLIPFONT)) {
                    continue;
                } else {
                    scanAssets(packageManager.getResourcesForApplication(list.get(i)), "", "", list.get(i));
                    this.mHandler.post(new Runnable() {
                        /* class com.android.fontmodule.scanfonts.ScanTtf.AnonymousClass2 */

                        public void run() {
                            if (ScanTtf.this.mScanUpdateListener != null) {
                                ScanTtf.this.mScanUpdateListener.onUpdate(ScanTtf.this.mListFont, (String) list.get(i));
                            }
                        }
                    });
                    if (this.mExit) {
                        saveTtfResultExcludeFlip(this.mContext, "scan_ttf_fonts");
                        break;
                    }
                }
            } catch (Exception e) {
            }
            i++;
        }
        saveTtfResultExcludeFlip(this.mContext, "scan_ttf_fonts");
    }

    private static void writeData(Context context, String str, String str2) {
        try {
            FileOutputStream openFileOutput = context.openFileOutput(str2, 0);
            openFileOutput.write(str.getBytes());
            openFileOutput.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void cancel() {
        this.mExit = true;
    }

    public List<TtfFontInfo> getFonts() {
        return this.mListFont;
    }

    public Typeface getTtfFont(Context context, String str, String str2) {
        try {
            return Typeface.createFromAsset(context.getPackageManager().getResourcesForApplication(str).getAssets(), str2);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public void scanFlipFont(final List<String> list) {
        PackageManager packageManager = this.mContext.getPackageManager();
        int i = 0;
        while (true) {
            final int i2 = i;
            if (i2 < list.size()) {
                if (list.get(i2).contains(FLIPFONT)) {
                    try {
                        scanAssets(packageManager.getResourcesForApplication(list.get(i2)), "", "", list.get(i2));
                        if (!this.mExit) {
                            this.mHandler.post(new Runnable() {
                                /* class com.android.fontmodule.scanfonts.ScanTtf.AnonymousClass3 */

                                public void run() {
                                    if (ScanTtf.this.mScanUpdateListener != null) {
                                        ScanTtf.this.mScanUpdateListener.onUpdate(ScanTtf.this.mListFont, (String) list.get(i2));
                                    }
                                }
                            });
                        } else {
                            return;
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                i = i2 + 1;
            } else {
                saveTtfResult(this.mContext, "scan_ttf_fonts_flipfont");
                return;
            }
        }
    }

    public void setUpdateListener(OnScanListener onScanListener) {
        this.mScanUpdateListener = onScanListener;
    }

    public void startScan(final String str) {
        this.mExit = false;
        new Thread(new Runnable() {
            /* class com.android.fontmodule.scanfonts.ScanTtf.AnonymousClass1 */

            public void run() {
                ScanTtf.this.mListFont.clear();
                List<String> allApps = ScanTtf.getAllApps(ScanTtf.this.mContext, null);
                if (str == null || !str.equalsIgnoreCase("simple")) {
                    ScanTtf.this.scanFlipFont(allApps);
                    ScanTtf.this.scanTtfFonts(ScanTtf.this.mContext, allApps);
                } else {
                    ScanTtf.this.scanFlipFont(allApps);
                }
                ScanTtf.this.mHandler.post(new Runnable() {
                    /* class com.android.fontmodule.scanfonts.ScanTtf.AnonymousClass1.AnonymousClass1 */

                    public void run() {
                        if (ScanTtf.this.mScanUpdateListener != null) {
                            ScanTtf.this.mScanUpdateListener.onUpdate(ScanTtf.this.mListFont, "-1");
                        }
                    }
                });
            }
        }).start();
    }
}
