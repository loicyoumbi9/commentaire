package com.android.fontmodule;

import android.graphics.drawable.Drawable;

public class BaseAppItem {
    private Drawable icon;
    private String name;
    private String packageName;

    public BaseAppItem(String str, String str2, Drawable drawable) {
        this.name = str;
        this.packageName = str2;
        this.icon = drawable;
    }

    public boolean equals(Object obj) {
        boolean z = true;
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            z = false;
        }
        if (super.getClass() != obj.getClass()) {
            z = false;
        }
        BaseAppItem baseAppItem = (BaseAppItem) obj;
        if (this.packageName == null) {
            if (baseAppItem.packageName == null) {
                return z;
            }
            z = false;
        }
        if (!this.packageName.equals(baseAppItem.packageName)) {
            return false;
        }
        return z;
    }

    public Drawable getIcon() {
        return this.icon;
    }

    public String getName() {
        return this.name;
    }

    public String getPackageName() {
        return this.packageName;
    }

    public int hashCode() {
        return (this.packageName == null ? 31 : this.packageName.hashCode()) + 31;
    }
}
