package com.android.fontmodule;

import android.app.Activity;
import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class CustomDialog extends Dialog implements View.OnClickListener {
    public Activity c;
    public Dialog d;
    public Button no;
    public Button yes;

    public CustomDialog(Activity activity) {
        super(activity);
        this.c = activity;
    }

    public void onClick(View view) {
        dismiss();
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(1);
        setContentView(R.layout.scan_ttf);
        this.no = (Button) findViewById(R.id.cancel);
        this.no.setOnClickListener(this);
    }
}
