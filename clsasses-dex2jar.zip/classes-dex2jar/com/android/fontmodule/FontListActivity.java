package com.android.fontmodule;

import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.ListActivity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.support.v4.view.ViewCompat;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import com.alimama.mobile.csdk.umupdate.a.f;
import com.android.common.inbuymodule.TrackerWrapper;
import com.android.common.inbuymodule.UpdateVersion;
import com.google.android.gms.drive.DriveFile;
import com.iphonestyle.mms.ConstSetting;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

public class FontListActivity extends ListActivity {
    private static final String APP_PKG = "com.crazygame.inputmethod.keyboard7";
    private static String PKG_THEME_NAME = "/sdcard/.keyboard7_theme.log";
    private static String PKG_THEME_SELECT = "pref_key_theme_pkg_name";
    /* access modifiers changed from: private */
    public static String THEME_URL = "https://play.google.com/store/search?q=Flip+Font&c=apps&price=1";
    public static ActivityManager am;
    private static boolean mBuyStatus = false;
    /* access modifiers changed from: private */
    public List<BaseAppItem> mList;
    String[][] mThemes;

    public interface OnUpdateListener {
        void onUpdate(List<BaseAppItem> list);
    }

    public class ProcessAdapter extends BaseAdapter {
        public ProcessAdapter(List<BaseAppItem> list) {
        }

        public int getCount() {
            return FontListActivity.this.mList.size();
        }

        public BaseAppItem getItem(int i) {
            return (BaseAppItem) FontListActivity.this.mList.get(i);
        }

        public long getItemId(int i) {
            return (long) i;
        }

        /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
         method: ClspMth{android.view.LayoutInflater.inflate(int, android.view.ViewGroup, boolean):android.view.View}
         arg types: [int, android.view.ViewGroup, int]
         candidates:
          ClspMth{android.view.LayoutInflater.inflate(org.xmlpull.v1.XmlPullParser, android.view.ViewGroup, boolean):android.view.View}
          ClspMth{android.view.LayoutInflater.inflate(int, android.view.ViewGroup, boolean):android.view.View} */
        public View getView(int i, View view, ViewGroup viewGroup) {
            BaseAppItem item = getItem(i);
            if (view == null) {
                view = FontListActivity.this.getLayoutInflater().inflate(R.layout.theme_preview, viewGroup, false);
            }
            ImageView imageView = (ImageView) view.findViewById(16908294);
            TextView textView = (TextView) view.findViewById(16908310);
            CheckBox checkBox = (CheckBox) view.findViewById(R.id.alert_select);
            if (item != null) {
                boolean access$600 = FontListActivity.this.checkSelect(FontListActivity.this.getBaseContext(), item.getPackageName());
                if (access$600 && !checkBox.isChecked()) {
                    checkBox.setChecked(true);
                } else if (!access$600) {
                    checkBox.setChecked(false);
                }
                checkBox.setTag(item);
                checkBox.setOnClickListener(new View.OnClickListener() {
                    /* class com.android.fontmodule.FontListActivity.ProcessAdapter.AnonymousClass1 */

                    public void onClick(View view) {
                        if (view instanceof CheckBox) {
                            boolean isChecked = ((CheckBox) view).isChecked();
                            String packageName = ((BaseAppItem) view.getTag()).getPackageName();
                            if (!FontListActivity.this.isValidPkg(packageName) || FontListActivity.checkAppExist(view.getContext(), packageName)) {
                                if (!isChecked) {
                                    packageName = "";
                                }
                                FontListActivity.this.setSelect(view.getContext(), packageName);
                                FontListActivity.this.setThemePkg(packageName);
                                if (packageName.length() > 0) {
                                    UpdateVersion.onEventClickThemeSwitch(view.getContext(), packageName, "");
                                }
                                ProcessAdapter.this.notifyDataSetChanged();
                                return;
                            }
                            FontListActivity.this.installKeyboardTheme("Install theme", packageName, packageName + " has not installed, you should install it first!");
                            ((CheckBox) view).setChecked(false);
                        }
                    }
                });
                Drawable icon = item.getIcon();
                if (icon == null) {
                    icon = FontListActivity.getRes(view.getContext(), item.getPackageName(), f.bv, "preview_img");
                }
                textView.setTextColor((int) ViewCompat.MEASURED_STATE_MASK);
                if (icon != null) {
                    icon.setAlpha(255);
                }
                imageView.setImageDrawable(icon);
                imageView.setVisibility(8);
                textView.setText(item.getName());
            }
            return view;
        }
    }

    public FontListActivity() {
        String[] strArr = {"White Blue Circle", "water_whiteblue_circle", "com.wavestudio.theme.whiteblue"};
        this.mThemes = new String[][]{new String[]{"Default", "crazystudio_defaut", "4"}, new String[]{"Classic Black", "water_black", "com.wavestudio.theme.black"}, strArr, new String[]{"Red Love", "redlove", "com.wavestudio.theme.redlove"}, new String[]{"GO White Flat", "ic_go_white_emojikeyboard", "com.jb.gokeyboard.theme.white"}, new String[]{"White Flat", "crazystudio_white_flat", "5"}};
    }

    /* access modifiers changed from: private */
    public static boolean checkAppExist(Context context, String str) {
        Context context2 = null;
        try {
            context2 = context.createPackageContext(str, 2);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return context2 != null;
    }

    private static boolean checkGooglePlay(Context context) {
        Context context2;
        try {
            context2 = context.createPackageContext("com.android.vending", 2);
        } catch (Exception e) {
            e.printStackTrace();
            context2 = null;
        }
        return context2 != null;
    }

    /* access modifiers changed from: private */
    public boolean checkSelect(Context context, String str) {
        return PreferenceManager.getDefaultSharedPreferences(context).getString(PKG_THEME_SELECT, "").equalsIgnoreCase(str);
    }

    public static BaseAppItem constructBaseAppItem(Context context, String str) {
        PackageManager packageManager = context.getPackageManager();
        try {
            return new BaseAppItem((String) packageManager.getPackageInfo(str, 0).applicationInfo.loadLabel(packageManager), str, null);
        } catch (Exception e) {
            return null;
        }
    }

    public static int getAppVersionCode(Context context, String str) {
        try {
            return context.createPackageContext(str, 2).getPackageManager().getPackageInfo(str, 0).versionCode;
        } catch (Exception e) {
            Log.e("VersionInfo", "Exception", e);
            return 0;
        }
    }

    public static void getNeedAppItems(Context context, String str, List<BaseAppItem> list) {
        int i = 0;
        Intent intent = new Intent("android.intent.action.MAIN", (Uri) null);
        intent.addCategory("android.intent.category.LAUNCHER");
        PackageManager packageManager = context.getPackageManager();
        PackageManager packageManager2 = context.getPackageManager();
        List<ResolveInfo> queryIntentActivities = packageManager.queryIntentActivities(intent, 0);
        while (true) {
            try {
                int i2 = i;
                if (i2 < queryIntentActivities.size()) {
                    int i3 = packageManager2.getApplicationInfo(queryIntentActivities.get(i2).activityInfo.packageName, 0).flags;
                    int i4 = queryIntentActivities.get(i2).activityInfo.flags;
                    if ((i3 & 1) != 0 && queryIntentActivities.get(i2).activityInfo.packageName.contains(str)) {
                        list.add(0, constructBaseAppItem(context, queryIntentActivities.get(i2).activityInfo.packageName));
                    }
                    i = i2 + 1;
                } else {
                    return;
                }
            } catch (Exception e) {
                e.printStackTrace();
                return;
            }
        }
    }

    public static void getNeedAppItems(Context context, String[] strArr, List<BaseAppItem> list) {
        Intent intent = new Intent("android.intent.action.MAIN", (Uri) null);
        intent.addCategory("android.intent.category.LAUNCHER");
        PackageManager packageManager = context.getPackageManager();
        PackageManager packageManager2 = context.getPackageManager();
        List<ResolveInfo> queryIntentActivities = packageManager.queryIntentActivities(intent, 0);
        int i = 0;
        while (i < queryIntentActivities.size()) {
            try {
                int i2 = packageManager2.getApplicationInfo(queryIntentActivities.get(i).activityInfo.packageName, 0).flags;
                int i3 = queryIntentActivities.get(i).activityInfo.flags;
                if ((i2 & 1) != 0) {
                    String str = queryIntentActivities.get(i).activityInfo.packageName;
                    int i4 = 0;
                    while (true) {
                        if (i4 >= strArr.length) {
                            break;
                        } else if (str.equalsIgnoreCase(strArr[i4])) {
                            list.add(0, constructBaseAppItem(context, queryIntentActivities.get(i).activityInfo.packageName));
                            break;
                        } else {
                            i4++;
                        }
                    }
                }
                i++;
            } catch (Exception e) {
                e.printStackTrace();
                return;
            }
        }
    }

    public static Drawable getRes(Context context, String str, String str2, String str3) {
        PackageManager packageManager = context.getPackageManager();
        if (packageManager == null) {
            return null;
        }
        try {
            Resources resourcesForApplication = packageManager.getResourcesForApplication(str);
            int identifier = resourcesForApplication.getIdentifier(str3, str2, str);
            if (identifier > 0) {
                return resourcesForApplication.getDrawable(identifier);
            }
            return null;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static boolean getStatus(Context context) {
        return mBuyStatus;
    }

    /* access modifiers changed from: private */
    public void installKeyboardTheme(String str, final String str2, String str3) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(str3);
        builder.setTitle(str);
        builder.setIcon(R.drawable.ic_dialog);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            /* class com.android.fontmodule.FontListActivity.AnonymousClass1 */

            public void onClick(DialogInterface dialogInterface, int i) {
                FontListActivity.rate(FontListActivity.this, str2);
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            /* class com.android.fontmodule.FontListActivity.AnonymousClass2 */

            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });
        builder.create().show();
    }

    private void installKeyboardTip(boolean z) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        String str = "Can not find Emoji Keyboard 7, I am just an theme manager for it, you should install it first!";
        if (z) {
            str = "Please upgrade your Emoji Keyboard 7 to support more themes, else it can not support change any theme!";
        }
        builder.setMessage(str);
        builder.setTitle("Emoji Keyboard 7");
        builder.setIcon(R.drawable.ic_dialog);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            /* class com.android.fontmodule.FontListActivity.AnonymousClass3 */

            public void onClick(DialogInterface dialogInterface, int i) {
                FontListActivity.rate(FontListActivity.this, FontListActivity.APP_PKG);
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            /* class com.android.fontmodule.FontListActivity.AnonymousClass4 */

            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });
        builder.create().show();
    }

    /* access modifiers changed from: private */
    public void installThemeTip() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        String str = "Do you want to install more Keyboard Themes?";
        if (this.mList.size() <= 0) {
            str = "Do you want to install more Keyboard Themes?" + "\nCan't find any keyboard theme.";
        }
        builder.setMessage(str);
        builder.setTitle("Install");
        builder.setIcon(R.drawable.ic_dialog);
        String onlineKeyValue = TrackerWrapper.getOnlineKeyValue(this, "theme_url");
        if (onlineKeyValue.length() > 0 && !onlineKeyValue.equalsIgnoreCase(f.b)) {
            THEME_URL = onlineKeyValue;
        }
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            /* class com.android.fontmodule.FontListActivity.AnonymousClass5 */

            public void onClick(DialogInterface dialogInterface, int i) {
                FontListActivity.rateDirectBrowser(FontListActivity.this, FontListActivity.THEME_URL);
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            /* class com.android.fontmodule.FontListActivity.AnonymousClass6 */

            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });
        builder.create().show();
    }

    /* access modifiers changed from: private */
    public boolean isValidPkg(String str) {
        return str.length() > 3;
    }

    public static void killProcess(String str) {
        am.restartPackage(str);
    }

    private void loadAdView() {
    }

    private boolean noneedFlatWhite() {
        return TrackerWrapper.getOnlineKeyValue(this, "whiteflat-allow").equalsIgnoreCase("false");
    }

    public static void rate(Context context, String str) {
        try {
            if (checkGooglePlay(context)) {
                rateMarket(context, str);
            } else {
                rateBrowser(context, str);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void rateBrowser(Context context, String str) {
        Uri parse = Uri.parse("http://market.android.com/details?id=" + str);
        if (!TextUtils.isEmpty("") && !"".equalsIgnoreCase(f.b)) {
            parse = Uri.parse("");
        }
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.setData(parse);
        context.startActivity(intent);
    }

    public static void rateDirectBrowser(Context context, String str) {
        Uri parse = Uri.parse(str);
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.setData(parse);
        intent.addFlags(DriveFile.MODE_READ_ONLY);
        context.startActivity(intent);
    }

    private static void rateMarket(Context context, String str) {
        Uri parse = Uri.parse("market://details?id=" + str);
        if (!TextUtils.isEmpty("") && !"".equalsIgnoreCase(f.b)) {
            parse = Uri.parse("");
        }
        Intent intent = new Intent();
        intent.setData(parse);
        context.startActivity(intent);
    }

    private static String readSDFile(Context context, String str) {
        try {
            FileInputStream fileInputStream = new FileInputStream(str);
            byte[] bArr = new byte[fileInputStream.available()];
            if (fileInputStream.read(bArr) > 0) {
                return new String(bArr);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    /* access modifiers changed from: private */
    public void setSelect(Context context, String str) {
        PreferenceManager.getDefaultSharedPreferences(context).edit().putString(PKG_THEME_SELECT, str).commit();
    }

    /* access modifiers changed from: private */
    public void setThemePkg(String str) {
        writeSDFile(PKG_THEME_NAME, str);
    }

    private void testKeyboard() {
        final EditText editText = new EditText(this);
        new AlertDialog.Builder(this).setTitle("Preview Keyboard Theme:").setIcon(17301659).setView(editText).setIcon(R.drawable.ic_dialog).setPositiveButton("OK", (DialogInterface.OnClickListener) null).setNegativeButton("Cancel", (DialogInterface.OnClickListener) null).show();
        new Handler().postDelayed(new Runnable() {
            /* class com.android.fontmodule.FontListActivity.AnonymousClass9 */

            public void run() {
                editText.requestFocus();
                ((InputMethodManager) FontListActivity.this.getSystemService("input_method")).showSoftInput(editText, 0);
            }
        }, 300);
    }

    public static void writeSDFile(String str, String str2) {
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(str);
            fileOutputStream.write(str2.getBytes());
            fileOutputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<BaseAppItem> getGoThemes(Context context, String str, List<BaseAppItem> list, OnUpdateListener onUpdateListener) {
        String str2;
        ArrayList arrayList = new ArrayList();
        List<PackageInfo> installedPackages = context.getPackageManager().getInstalledPackages(0);
        for (int i = 0; i < installedPackages.size(); i++) {
            PackageInfo packageInfo = installedPackages.get(i);
            String str3 = packageInfo.packageName;
            int i2 = 0;
            while (true) {
                if (i2 >= this.mThemes.length) {
                    str2 = str3;
                    break;
                } else if (this.mThemes[i2][2].equalsIgnoreCase(str3)) {
                    str2 = "";
                    break;
                } else {
                    i2++;
                }
            }
            if (str2.contains(str)) {
                list.add(0, constructBaseAppItem(context, packageInfo.packageName));
                if (onUpdateListener != null) {
                    onUpdateListener.onUpdate(arrayList);
                }
            }
        }
        return list;
    }

    public void initDefaultThemes(Context context) {
        String packageName = context.getPackageName();
        int i = 0;
        for (int i2 = 0; i2 < this.mThemes.length; i2++) {
            Drawable res = getRes(context, packageName, f.bv, this.mThemes[i2][1]);
            if (res != null && ((!this.mThemes[i2][2].equalsIgnoreCase("com.jb.gokeyboard.theme.white") || checkAppExist(context, this.mThemes[i2][2])) && (!noneedFlatWhite() || !this.mThemes[i2][2].equalsIgnoreCase("5")))) {
                this.mList.add(i, new BaseAppItem(this.mThemes[i2][0], this.mThemes[i2][2], res));
                i++;
            }
        }
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.themelist);
        if (getIntent() != null) {
            String stringExtra = getIntent().getStringExtra("buystatus");
            if (stringExtra != null && stringExtra.equalsIgnoreCase(ConstSetting.IOS7_ENABLE)) {
                mBuyStatus = true;
            }
            Log.e("BUYSTATUS", "status:" + mBuyStatus);
        }
        boolean checkAppExist = checkAppExist(this, APP_PKG);
        boolean z = getAppVersionCode(this, APP_PKG) > 12;
        if (!checkAppExist || !z) {
            if (!checkAppExist) {
                installKeyboardTip(false);
            } else {
                installKeyboardTip(true);
            }
        }
        am = (ActivityManager) getSystemService("activity");
        this.mList = new ArrayList();
        getGoThemes(this, "com.monotype.android.font", this.mList, null);
        if (checkAppExist && z) {
            new Handler().postDelayed(new Runnable() {
                /* class com.android.fontmodule.FontListActivity.AnonymousClass7 */

                public void run() {
                    FontListActivity.this.installThemeTip();
                }
            }, 500);
        }
        String[] strArr = new String[this.mList.size()];
        for (int i = 0; i < strArr.length; i++) {
            strArr[i] = new String(this.mList.get(i).getName());
        }
        ListView listView = (ListView) findViewById(16908298);
        if (this.mList.size() > 0) {
            setListAdapter(new ProcessAdapter(this.mList));
        }
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            /* class com.android.fontmodule.FontListActivity.AnonymousClass8 */

            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                String packageName = ((BaseAppItem) FontListActivity.this.mList.get(i)).getPackageName();
                if (FontListActivity.this.isValidPkg(packageName) && !FontListActivity.checkAppExist(view.getContext(), packageName)) {
                    FontListActivity.this.installKeyboardTheme("Install theme", packageName, packageName + " has not installed, you should install it first!");
                }
            }
        });
        loadAdView();
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.actions, menu);
        return super.onCreateOptionsMenu(menu);
    }

    /* access modifiers changed from: protected */
    public void onDestroy() {
        super.onDestroy();
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case 101:
                installThemeTip();
                break;
            case 102:
                rate(this, APP_PKG);
                break;
            case 103:
                testKeyboard();
                break;
        }
        return super.onOptionsItemSelected(menuItem);
    }

    /* access modifiers changed from: protected */
    public void onPause() {
        super.onPause();
    }

    public boolean onPrepareOptionsMenu(Menu menu) {
        menu.clear();
        return super.onPrepareOptionsMenu(menu);
    }

    /* access modifiers changed from: protected */
    public void onResume() {
        super.onResume();
    }
}
