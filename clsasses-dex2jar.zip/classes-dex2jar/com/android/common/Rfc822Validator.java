package com.android.common;

import android.text.TextUtils;
import android.text.util.Rfc822Token;
import android.text.util.Rfc822Tokenizer;
import android.widget.AutoCompleteTextView;
import java.util.regex.Pattern;

public class Rfc822Validator implements AutoCompleteTextView.Validator {
    private static final Pattern EMAIL_ADDRESS_PATTERN = Pattern.compile("[^\\s@]+@([^\\s@\\.]+\\.)+[a-zA-z][a-zA-Z][a-zA-Z]*");
    private String mDomain;

    public Rfc822Validator(String str) {
        this.mDomain = str;
    }

    private String removeIllegalCharacters(String str) {
        StringBuilder sb = new StringBuilder();
        int length = str.length();
        for (int i = 0; i < length; i++) {
            char charAt = str.charAt(i);
            if (!(charAt <= ' ' || charAt > '~' || charAt == '(' || charAt == ')' || charAt == '<' || charAt == '>' || charAt == '@' || charAt == ',' || charAt == ';' || charAt == ':' || charAt == '\\' || charAt == '\"' || charAt == '[' || charAt == ']')) {
                sb.append(charAt);
            }
        }
        return sb.toString();
    }

    public CharSequence fixText(CharSequence charSequence) {
        if (TextUtils.getTrimmedLength(charSequence) == 0) {
            return "";
        }
        Rfc822Token[] rfc822TokenArr = Rfc822Tokenizer.tokenize(charSequence);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < rfc822TokenArr.length; i++) {
            String address = rfc822TokenArr[i].getAddress();
            int indexOf = address.indexOf(64);
            if (indexOf < 0) {
                rfc822TokenArr[i].setAddress(removeIllegalCharacters(address) + "@" + this.mDomain);
            } else {
                String removeIllegalCharacters = removeIllegalCharacters(address.substring(0, indexOf));
                String removeIllegalCharacters2 = removeIllegalCharacters(address.substring(indexOf + 1));
                Rfc822Token rfc822Token = rfc822TokenArr[i];
                StringBuilder append = new StringBuilder().append(removeIllegalCharacters).append("@");
                if (removeIllegalCharacters2.length() == 0) {
                    removeIllegalCharacters2 = this.mDomain;
                }
                rfc822Token.setAddress(append.append(removeIllegalCharacters2).toString());
            }
            sb.append(rfc822TokenArr[i].toString());
            if (i + 1 < rfc822TokenArr.length) {
                sb.append(", ");
            }
        }
        return sb;
    }

    public boolean isValid(CharSequence charSequence) {
        Rfc822Token[] rfc822TokenArr = Rfc822Tokenizer.tokenize(charSequence);
        return rfc822TokenArr.length == 1 && EMAIL_ADDRESS_PATTERN.matcher(rfc822TokenArr[0].getAddress()).matches();
    }
}
