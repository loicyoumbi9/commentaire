package com.android.common.inbuymodule.scanfonts;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.LinearLayout;

public class CustomLineLayout extends LinearLayout {
    public CustomLineLayout(Context context) {
        super(context);
    }

    public CustomLineLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public CustomLineLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
    }
}
