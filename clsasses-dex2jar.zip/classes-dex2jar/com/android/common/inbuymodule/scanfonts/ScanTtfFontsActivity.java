package com.android.common.inbuymodule.scanfonts;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import com.android.common.inbuymodule.R;
import com.android.common.inbuymodule.scanfonts.ScanTtf;
import java.util.List;

public class ScanTtfFontsActivity extends Activity {
    /* access modifiers changed from: private */
    public ScanTtf mScanTtf = null;

    /* access modifiers changed from: private */
    public void setCurrentPkg(String str) {
        TextView textView = (TextView) findViewById(R.id.ttffile);
        if (textView != null) {
            textView.setText(str);
        }
    }

    /* access modifiers changed from: private */
    public void setFindResult(String str) {
        TextView textView = (TextView) findViewById(R.id.scanresult);
        if (textView != null) {
            textView.setText(str);
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.scan_ttf);
        this.mScanTtf = ScanTtf.getInstance(this);
        ((Button) findViewById(R.id.cancel)).setOnClickListener(new View.OnClickListener() {
            /* class com.android.common.inbuymodule.scanfonts.ScanTtfFontsActivity.AnonymousClass1 */

            public void onClick(View view) {
                ScanTtfFontsActivity.this.mScanTtf.cancel();
                ScanTtfFontsActivity.this.finish();
            }
        });
        this.mScanTtf.setUpdateListener(new ScanTtf.OnScanListener() {
            /* class com.android.common.inbuymodule.scanfonts.ScanTtfFontsActivity.AnonymousClass2 */

            @Override // com.android.common.inbuymodule.scanfonts.ScanTtf.OnScanListener
            public void onUpdate(List<TtfFontInfo> list, String str) {
                if (str.equalsIgnoreCase("-1")) {
                    ScanTtfFontsActivity.this.finish();
                    return;
                }
                ScanTtfFontsActivity.this.setCurrentPkg(str);
                ScanTtfFontsActivity.this.setFindResult("Find out " + list.size() + " font files.");
            }
        });
        String str = "";
        if (getIntent() != null) {
            str = getIntent().getStringExtra("scantype");
        }
        this.mScanTtf.startScan(str);
    }
}
