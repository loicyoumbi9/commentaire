package com.android.common.inbuymodule.scanfonts;

import android.content.Context;
import android.preference.Preference;
import android.util.AttributeSet;
import android.view.View;

public class ViewPreference extends Preference {
    private View mView = null;

    public ViewPreference(Context context) {
        super(context);
    }

    public ViewPreference(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public ViewPreference(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    public View getView() {
        return this.mView;
    }

    /* access modifiers changed from: protected */
    public void onBindView(View view) {
        super.onBindView(view);
        this.mView = view;
    }
}
