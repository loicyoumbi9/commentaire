package com.android.common.inbuymodule.scanfonts;

import android.app.Activity;
import android.content.Context;
import android.graphics.Typeface;
import android.preference.Preference;
import android.preference.PreferenceManager;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class ChooseFontPreference extends Preference {
    private Typeface mFont = null;
    public View mView = null;

    public ChooseFontPreference(Context context) {
        super(context);
    }

    public ChooseFontPreference(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public ChooseFontPreference(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    private Typeface getTtfFont(String str, String str2) {
        try {
            return Typeface.createFromAsset(getContext().getPackageManager().getResourcesForApplication(str).getAssets(), str2);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /* access modifiers changed from: protected */
    public void onBindView(View view) {
        super.onBindView(view);
        TextView textView = (TextView) view.findViewById(16908304);
        this.mView = view;
        Log.e("CHILD", "" + view.getParent() + " context:" + view.getContext());
        if (view.getContext() instanceof Activity) {
            Log.e("ROOT", "root:" + ((ViewGroup) ((Activity) view.getContext()).getWindow().getDecorView()));
        }
        if (textView != null) {
            if (this.mFont == null) {
                String string = PreferenceManager.getDefaultSharedPreferences(getContext()).getString("pref_key_ttffont_select", "");
                if (string.length() > 0) {
                    String[] split = string.split(":");
                    if (split.length == 2) {
                        this.mFont = getTtfFont(split[0], split[1]);
                    }
                }
            }
            if (this.mFont != null) {
                textView.setTypeface(this.mFont);
            }
        }
    }

    public void setFont(Typeface typeface) {
        this.mFont = typeface;
    }
}
