package com.android.common.inbuymodule.scanfonts;

public class TtfFontInfo {
    String file;
    String pkg;

    public TtfFontInfo(String str, String str2) {
        this.pkg = str;
        this.file = str2;
    }
}
