package com.android.common.inbuymodule.scanfonts;

import android.content.Context;
import android.graphics.Typeface;
import android.preference.Preference;
import android.util.AttributeSet;
import android.view.View;
import android.widget.TextView;

public class FontItemPreference extends Preference {
    private Typeface mTypeface = null;

    public FontItemPreference(Context context) {
        super(context);
    }

    public FontItemPreference(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public FontItemPreference(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    private Typeface getTtfFont(String str, String str2) {
        try {
            return Typeface.createFromAsset(getContext().getPackageManager().getResourcesForApplication(str).getAssets(), str2);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /* access modifiers changed from: protected */
    public void onBindView(View view) {
        super.onBindView(view);
        TextView textView = (TextView) view.findViewById(16908304);
        TextView textView2 = (TextView) view.findViewById(16908310);
        if (textView2 != null) {
            String charSequence = textView2.getText().toString();
            if (textView != null) {
                if (this.mTypeface == null) {
                    this.mTypeface = getTtfFont(textView.getText().toString(), charSequence);
                }
                if (this.mTypeface != null) {
                    textView2.setTypeface(this.mTypeface);
                }
            }
        }
    }
}
