package com.android.common.inbuymodule.scanfonts;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.preference.Preference;
import android.preference.PreferenceActivity;
import android.preference.PreferenceManager;
import com.android.common.inbuymodule.R;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;

public class TtfFontsListActivity extends PreferenceActivity {
    public static final String PREF_TTFFONT_SELECT = "pref_key_ttffont_select";
    List<TtfFontInfo> mFontList = new ArrayList();

    public static String getFontName(Context context) {
        return PreferenceManager.getDefaultSharedPreferences(context).getString("pref_key_ttffont_select", "");
    }

    public static List<TtfFontInfo> getScanFonts(Context context, String str) {
        ArrayList arrayList = new ArrayList();
        String[] split = readFileData(context, str).split("\n");
        if (split != null) {
            for (String str2 : split) {
                String[] split2 = str2.split(":");
                if (split2 != null && split2.length == 2) {
                    arrayList.add(new TtfFontInfo(split2[0], split2[1]));
                }
            }
        }
        return arrayList;
    }

    public static Typeface getTtfFont(Context context) {
        String[] split;
        String string = PreferenceManager.getDefaultSharedPreferences(context).getString("pref_key_ttffont_select", "");
        if (string.length() <= 0 || (split = string.split(":")) == null || split.length < 2) {
            return null;
        }
        try {
            return Typeface.createFromAsset(context.getPackageManager().getResourcesForApplication(split[0]).getAssets(), split[1]);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private void initScanFonts(String str) {
        String[] split = readFileData(this, str).split("\n");
        if (split != null) {
            for (String str2 : split) {
                String[] split2 = str2.split(":");
                if (split2 != null && split2.length == 2) {
                    this.mFontList.add(new TtfFontInfo(split2[0], split2[1]));
                    FontItemPreference fontItemPreference = new FontItemPreference(this);
                    fontItemPreference.setTitle(split2[1]);
                    fontItemPreference.setSummary(split2[0]);
                    fontItemPreference.setLayoutResource(R.layout.custom_preference);
                    fontItemPreference.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
                        /* class com.android.common.inbuymodule.scanfonts.TtfFontsListActivity.AnonymousClass1 */

                        public boolean onPreferenceClick(Preference preference) {
                            SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(preference.getContext());
                            defaultSharedPreferences.edit().putString("pref_key_ttffont_select", preference.getSummary().toString() + ":" + preference.getTitle().toString()).commit();
                            TtfFontsListActivity.this.finish();
                            return false;
                        }
                    });
                    getPreferenceScreen().addPreference(fontItemPreference);
                }
            }
        }
    }

    private static String readFileData(Context context, String str) {
        try {
            FileInputStream openFileInput = context.openFileInput(str);
            byte[] bArr = new byte[openFileInput.available()];
            if (openFileInput.read(bArr) > 0) {
                return new String(bArr);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        addPreferencesFromResource(R.xml.font_prefs);
        initScanFonts("scan_ttf_fonts");
        initScanFonts("scan_ttf_fonts_flipfont");
    }
}
