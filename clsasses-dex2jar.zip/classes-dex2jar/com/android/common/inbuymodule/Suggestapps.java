package com.android.common.inbuymodule;

import android.content.Context;
import android.preference.Preference;
import android.preference.PreferenceGroup;
import android.text.TextUtils;
import android.util.Log;
import com.umeng.analytics.MobclickAgent;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONObject;

public class Suggestapps {
    private static final String AND_PARAM = "&";
    private static final String API_GET_MORE_APP_LIST = "http://apis.heyemoji.com/v2/ads/list";
    private static final String KEY_APP_ICON_URL = "ad_img";
    private static final String KEY_APP_LIST = "data";
    private static final String KEY_APP_PKG = "data";
    private static final String KEY_APP_SUMMARY = "desc";
    private static final String KEY_APP_TITLE = "title";
    private static final String KEY_APP_URL = "ad_url";
    private static final String MORE_APP_LIST_PARAM_APPID = "appid";
    private static final String TAG = Suggestapps.class.getSimpleName();
    private static final String VALUE = "=";
    private static final String WITH_PARAM = "?";
    public static ArrayList<SuggestAppInfo> mSuggestApps = new ArrayList<>();
    public static ArrayList<SuggestAppInfo> mSuggestKeyboardContent = new ArrayList<>();

    public static ArrayList<SuggestAppInfo> addMoreSuggestAppsPreference(Context context, PreferenceGroup preferenceGroup, PreferenceGroup preferenceGroup2, String str, final ArrayList<SuggestAppInfo> arrayList) {
        try {
            String configParams = MobclickAgent.getConfigParams(context, str);
            if (!TextUtils.isEmpty(configParams)) {
                JSONArray jSONArray = new JSONObject(configParams).getJSONArray(str);
                for (int i = 0; i < jSONArray.length(); i++) {
                    JSONObject jSONObject = (JSONObject) jSONArray.get(i);
                    arrayList.add(i, new SuggestAppInfo((String) jSONObject.get("title"), (String) jSONObject.get("summary"), (String) jSONObject.get("url"), (String) jSONObject.get("pkg")));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        for (int i2 = 0; i2 < arrayList.size(); i2++) {
            Preference preference = new Preference(context);
            preference.setTitle(arrayList.get(i2).mTitle);
            preference.setSummary(arrayList.get(i2).mSummary);
            preference.setKey(i2 + "");
            preference.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
                /* class com.android.common.inbuymodule.Suggestapps.AnonymousClass1 */

                public boolean onPreferenceClick(Preference preference) {
                    int parseInt = Integer.parseInt(preference.getKey());
                    String str = ((SuggestAppInfo) arrayList.get(parseInt)).mPkg;
                    if (TextUtils.isEmpty(str)) {
                        UpdateVersion.rateDirectBrowser(preference.getContext(), ((SuggestAppInfo) arrayList.get(parseInt)).mUrl);
                        UpdateVersion.onEventClickSuggest(preference.getContext(), "more_app", "activity");
                        return false;
                    }
                    UpdateVersion.install(preference.getContext(), str);
                    UpdateVersion.onEventClickSuggest(preference.getContext(), str, "activity");
                    return false;
                }
            });
            if (preferenceGroup != null) {
                preferenceGroup.addPreference(preference);
            }
        }
        if (!(arrayList.size() > 0 || preferenceGroup2 == null || preferenceGroup == null)) {
            preferenceGroup2.removePreference(preferenceGroup);
        }
        return arrayList;
    }

    public static String assembleGetMoreAppListUrl(String str) {
        return "http://apis.heyemoji.com/v2/ads/list?appid=" + str + "&page=1&num=20";
    }

    public static boolean decodeSuggestListRaw(ArrayList<SuggestAppInfo> arrayList, JSONObject jSONObject) {
        JSONArray jSONArray;
        boolean z;
        boolean z2 = true;
        if (arrayList == null || jSONObject == null) {
            Log.w(TAG, "decodeSuggestListRaw output or input null !!");
            return false;
        }
        try {
            jSONArray = jSONObject.getJSONArray("data");
        } catch (Exception e) {
            e.printStackTrace();
            jSONArray = null;
        }
        if (jSONArray == null) {
            Log.w(TAG, "decode error: get suggest list error !");
            return false;
        }
        arrayList.clear();
        int length = jSONArray.length();
        for (int i = 0; i < length; i++) {
            try {
                JSONObject jSONObject2 = jSONArray.getJSONObject(i);
                if (jSONObject2 == null) {
                    z = z2;
                } else {
                    try {
                        arrayList.add(new SuggestAppInfo(jSONObject2.getString("title"), jSONObject2.getString(KEY_APP_SUMMARY), jSONObject2.getString(KEY_APP_URL), jSONObject2.getString("data"), jSONObject2.getString(KEY_APP_ICON_URL)));
                        z = z2;
                    } catch (Exception e2) {
                        e = e2;
                        e.printStackTrace();
                        Log.w(TAG, "decode error: get suggest info values in suggest index: " + i);
                        z = false;
                        z2 = z;
                    }
                }
            } catch (Exception e3) {
                e = e3;
                e.printStackTrace();
                Log.w(TAG, "decode error: get suggest info values in suggest index: " + i);
                z = false;
                z2 = z;
            }
            z2 = z;
        }
        return z2;
    }

    public static ArrayList<SuggestAppInfo> getKeyboardSuggestContent(Context context, String str, ArrayList<SuggestAppInfo> arrayList) {
        try {
            String configParams = MobclickAgent.getConfigParams(context, str);
            if (!TextUtils.isEmpty(configParams)) {
                JSONArray jSONArray = new JSONObject(configParams).getJSONArray(str);
                int i = 0;
                while (true) {
                    int i2 = i;
                    if (i2 >= jSONArray.length()) {
                        break;
                    }
                    JSONObject jSONObject = (JSONObject) jSONArray.get(i2);
                    arrayList.add(i2, new SuggestAppInfo((String) jSONObject.get("title"), (String) jSONObject.get("summary"), (String) jSONObject.get("url"), (String) jSONObject.get("pkg")));
                    i = i2 + 1;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return arrayList;
    }

    public static ArrayList<SuggestAppInfo> getQuickmenuSuggestApps(Context context, String str, String str2, ArrayList<SuggestAppInfo> arrayList) {
        try {
            String configParams = MobclickAgent.getConfigParams(context, str);
            if (!TextUtils.isEmpty(configParams)) {
                JSONArray jSONArray = new JSONObject(configParams).getJSONArray(str2);
                int i = 0;
                while (true) {
                    int i2 = i;
                    if (i2 >= jSONArray.length()) {
                        break;
                    }
                    JSONObject jSONObject = (JSONObject) jSONArray.get(i2);
                    arrayList.add(i2, new SuggestAppInfo((String) jSONObject.get("title"), (String) jSONObject.get("summary"), (String) jSONObject.get("url"), (String) jSONObject.get("pkg"), (String) jSONObject.get("iconurl")));
                    i = i2 + 1;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return arrayList;
    }
}
