package com.android.common.inbuymodule;

import android.app.Activity;
import android.os.Bundle;

public class UpdateActivity extends Activity {
    public static String CHECK_ACTION = "check_action";
    public static final String CHECK_UPDATESNOW = "updatenow";

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        if (getIntent().getStringExtra(CHECK_ACTION).equalsIgnoreCase("umeng")) {
            UpdateVersion.checkUpdateEx(this, false, null);
        } else {
            UpdateVersion.checkUpdateWhenStart(this);
        }
    }
}
