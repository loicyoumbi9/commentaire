package com.android.common.inbuymodule;

import android.content.Context;
import com.umeng.analytics.MobclickAgent;
import java.util.HashMap;

public class TrackerWrapper {
    public static void event(Context context, String str, HashMap<String, String> hashMap) {
        MobclickAgent.onEvent(context, str, hashMap);
    }

    public static String getOnlineKeyValue(Context context, String str) {
        return MobclickAgent.getConfigParams(context, str);
    }

    public static void pause(Context context) {
        MobclickAgent.onPause(context);
    }

    public static void reportError(Context context, String str) {
        MobclickAgent.reportError(context, str);
    }

    public static void resume(Context context) {
        MobclickAgent.onResume(context);
    }

    public static void updateParams(Context context) {
        MobclickAgent.updateOnlineConfig(context);
    }
}
