package com.android.common.inbuymodule;

public class SuggestAppInfo {
    public String mIconUrl;
    public String mPkg;
    public String mSummary;
    public String mTitle;
    public String mUrl;

    public SuggestAppInfo(String str, String str2, String str3, String str4) {
        this.mTitle = str;
        this.mSummary = str2;
        this.mUrl = str3;
        this.mPkg = str4;
    }

    public SuggestAppInfo(String str, String str2, String str3, String str4, String str5) {
        this.mTitle = str;
        this.mSummary = str2;
        this.mUrl = str3;
        this.mPkg = str4;
        this.mIconUrl = str5;
    }

    public String getIconUrl() {
        return this.mIconUrl;
    }

    public String getPackageName() {
        return this.mPkg;
    }

    public String getTitle() {
        return this.mTitle;
    }

    public String getUrl() {
        return this.mUrl;
    }
}
