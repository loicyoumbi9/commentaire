package com.android.common.inbuymodule;

public final class R {

    public static final class attr {
        public static final int adSize = 2130771972;
        public static final int adSizes = 2130771973;
        public static final int adUnitId = 2130771974;
        public static final int buyButtonAppearance = 2130772027;
        public static final int buyButtonHeight = 2130772024;
        public static final int buyButtonText = 2130772026;
        public static final int buyButtonWidth = 2130772025;
        public static final int cameraBearing = 2130771983;
        public static final int cameraTargetLat = 2130771984;
        public static final int cameraTargetLng = 2130771985;
        public static final int cameraTilt = 2130771986;
        public static final int cameraZoom = 2130771987;
        public static final int environment = 2130772021;
        public static final int fragmentMode = 2130772023;
        public static final int fragmentStyle = 2130772022;
        public static final int mapType = 2130771982;
        public static final int maskedWalletDetailsBackground = 2130772030;
        public static final int maskedWalletDetailsButtonBackground = 2130772032;
        public static final int maskedWalletDetailsButtonTextAppearance = 2130772031;
        public static final int maskedWalletDetailsHeaderTextAppearance = 2130772029;
        public static final int maskedWalletDetailsLogoImageType = 2130772034;
        public static final int maskedWalletDetailsLogoTextColor = 2130772033;
        public static final int maskedWalletDetailsTextAppearance = 2130772028;
        public static final int theme = 2130772020;
        public static final int uiCompass = 2130771988;
        public static final int uiRotateGestures = 2130771989;
        public static final int uiScrollGestures = 2130771990;
        public static final int uiTiltGestures = 2130771991;
        public static final int uiZoomControls = 2130771992;
        public static final int uiZoomGestures = 2130771993;
        public static final int useViewLifecycle = 2130771994;
        public static final int zOrderOnTop = 2130771995;
    }

    public static final class color {
        public static final int common_action_bar_splitter = 2131230731;
        public static final int common_signin_btn_dark_text_default = 2131230732;
        public static final int common_signin_btn_dark_text_disabled = 2131230733;
        public static final int common_signin_btn_dark_text_focused = 2131230734;
        public static final int common_signin_btn_dark_text_pressed = 2131230735;
        public static final int common_signin_btn_default_background = 2131230736;
        public static final int common_signin_btn_light_text_default = 2131230737;
        public static final int common_signin_btn_light_text_disabled = 2131230738;
        public static final int common_signin_btn_light_text_focused = 2131230739;
        public static final int common_signin_btn_light_text_pressed = 2131230740;
        public static final int common_signin_btn_text_dark = 2131230885;
        public static final int common_signin_btn_text_light = 2131230886;
        public static final int tb_munion_item_force = 2131230836;
        public static final int wallet_bright_foreground_disabled_holo_light = 2131230853;
        public static final int wallet_bright_foreground_holo_dark = 2131230854;
        public static final int wallet_bright_foreground_holo_light = 2131230855;
        public static final int wallet_dim_foreground_disabled_holo_dark = 2131230856;
        public static final int wallet_dim_foreground_holo_dark = 2131230857;
        public static final int wallet_dim_foreground_inverse_disabled_holo_dark = 2131230858;
        public static final int wallet_dim_foreground_inverse_holo_dark = 2131230859;
        public static final int wallet_highlighted_text_holo_dark = 2131230860;
        public static final int wallet_highlighted_text_holo_light = 2131230861;
        public static final int wallet_hint_foreground_holo_dark = 2131230862;
        public static final int wallet_hint_foreground_holo_light = 2131230863;
        public static final int wallet_holo_blue_light = 2131230864;
        public static final int wallet_link_text_light = 2131230865;
        public static final int wallet_primary_text_holo_light = 2131230897;
        public static final int wallet_secondary_text_holo_dark = 2131230898;
    }

    public static final class dimen {
        public static final int popup_dialog_height = 2131296301;
    }

    public static final class drawable {
        public static final int ads_app_icon_clear_master = 2130837504;
        public static final int ads_app_icon_default = 2130837505;
        public static final int ads_app_icon_emoji_guess = 2130837506;
        public static final int common_signin_btn_icon_dark = 2130837578;
        public static final int common_signin_btn_icon_disabled_dark = 2130837579;
        public static final int common_signin_btn_icon_disabled_focus_dark = 2130837580;
        public static final int common_signin_btn_icon_disabled_focus_light = 2130837581;
        public static final int common_signin_btn_icon_disabled_light = 2130837582;
        public static final int common_signin_btn_icon_focus_dark = 2130837583;
        public static final int common_signin_btn_icon_focus_light = 2130837584;
        public static final int common_signin_btn_icon_light = 2130837585;
        public static final int common_signin_btn_icon_normal_dark = 2130837586;
        public static final int common_signin_btn_icon_normal_light = 2130837587;
        public static final int common_signin_btn_icon_pressed_dark = 2130837588;
        public static final int common_signin_btn_icon_pressed_light = 2130837589;
        public static final int common_signin_btn_text_dark = 2130837590;
        public static final int common_signin_btn_text_disabled_dark = 2130837591;
        public static final int common_signin_btn_text_disabled_focus_dark = 2130837592;
        public static final int common_signin_btn_text_disabled_focus_light = 2130837593;
        public static final int common_signin_btn_text_disabled_light = 2130837594;
        public static final int common_signin_btn_text_focus_dark = 2130837595;
        public static final int common_signin_btn_text_focus_light = 2130837596;
        public static final int common_signin_btn_text_light = 2130837597;
        public static final int common_signin_btn_text_normal_dark = 2130837598;
        public static final int common_signin_btn_text_normal_light = 2130837599;
        public static final int common_signin_btn_text_pressed_dark = 2130837600;
        public static final int common_signin_btn_text_pressed_light = 2130837601;
        public static final int ic_plusone_medium_off_client = 2130838871;
        public static final int ic_plusone_small_off_client = 2130838872;
        public static final int ic_plusone_standard_off_client = 2130838873;
        public static final int ic_plusone_tall_off_client = 2130838874;
        public static final int powered_by_google_dark = 2130838988;
        public static final int powered_by_google_light = 2130838989;
        public static final int tb_munion_icon = 2130839104;
        public static final int tb_munion_item_selector = 2130839105;
        public static final int umeng_common_gradient_green = 2130839137;
        public static final int umeng_common_gradient_orange = 2130839138;
        public static final int umeng_common_gradient_red = 2130839139;
        public static final int umeng_update_btn_check_off_focused_holo_light = 2130839144;
        public static final int umeng_update_btn_check_off_holo_light = 2130839145;
        public static final int umeng_update_btn_check_off_pressed_holo_light = 2130839146;
        public static final int umeng_update_btn_check_on_focused_holo_light = 2130839147;
        public static final int umeng_update_btn_check_on_holo_light = 2130839148;
        public static final int umeng_update_btn_check_on_pressed_holo_light = 2130839149;
        public static final int umeng_update_button_cancel_bg_focused = 2130839150;
        public static final int umeng_update_button_cancel_bg_normal = 2130839151;
        public static final int umeng_update_button_cancel_bg_selector = 2130839152;
        public static final int umeng_update_button_cancel_bg_tap = 2130839153;
        public static final int umeng_update_button_check_selector = 2130839154;
        public static final int umeng_update_button_close_bg_selector = 2130839155;
        public static final int umeng_update_button_ok_bg_focused = 2130839156;
        public static final int umeng_update_button_ok_bg_normal = 2130839157;
        public static final int umeng_update_button_ok_bg_selector = 2130839158;
        public static final int umeng_update_button_ok_bg_tap = 2130839159;
        public static final int umeng_update_close_bg_normal = 2130839160;
        public static final int umeng_update_close_bg_tap = 2130839161;
        public static final int umeng_update_dialog_bg = 2130839162;
        public static final int umeng_update_title_bg = 2130839163;
        public static final int umeng_update_wifi_disable = 2130839164;
    }

    public static final class id {
        public static final int ad_image = 2131362112;
        public static final int book_now = 2131361812;
        public static final int buyButton = 2131361808;
        public static final int buy_now = 2131361813;
        public static final int buy_with_google = 2131361814;
        public static final int cancel = 2131362059;
        public static final int classic = 2131361815;
        public static final int grayscale = 2131361816;
        public static final int holo_dark = 2131361803;
        public static final int holo_light = 2131361804;
        public static final int hybrid = 2131361794;
        public static final int loading = 2131362116;
        public static final int mainLayout = 2131361827;
        public static final int match_parent = 2131361810;
        public static final int monochrome = 2131361817;
        public static final int none = 2131361795;
        public static final int normal = 2131361796;
        public static final int production = 2131361805;
        public static final int progress_frame = 2131362114;
        public static final int promoter_frame = 2131362113;
        public static final int sandbox = 2131361806;
        public static final int satellite = 2131361797;
        public static final int scanresult = 2131362058;
        public static final int selectionDetails = 2131361809;
        public static final int status_msg = 2131362115;
        public static final int strict_sandbox = 2131361807;
        public static final int terrain = 2131361798;
        public static final int ttffile = 2131362057;
        public static final int umeng_common_icon_view = 2131362136;
        public static final int umeng_common_notification = 2131362132;
        public static final int umeng_common_notification_controller = 2131362137;
        public static final int umeng_common_progress_bar = 2131362135;
        public static final int umeng_common_progress_text = 2131362131;
        public static final int umeng_common_rich_notification_cancel = 2131362139;
        public static final int umeng_common_rich_notification_continue = 2131362138;
        public static final int umeng_common_title = 2131362133;
        public static final int umeng_update_content = 2131362149;
        public static final int umeng_update_frame = 2131362146;
        public static final int umeng_update_id_cancel = 2131362152;
        public static final int umeng_update_id_check = 2131362150;
        public static final int umeng_update_id_close = 2131362148;
        public static final int umeng_update_id_ignore = 2131362153;
        public static final int umeng_update_id_ok = 2131362151;
        public static final int umeng_update_wifi_indicator = 2131362147;
        public static final int update_ignore = 2131362155;
        public static final int update_tip_info = 2131362154;
        public static final int wrap_content = 2131361811;
    }

    public static final class integer {
        public static final int google_play_services_version = 2131427333;
    }

    public static final class layout {
        public static final int ad_layout = 2130903040;
        public static final int bottom_banner_ad = 2130903043;
        public static final int custom_preference = 2130903057;
        public static final int scan_ttf = 2130903121;
        public static final int tb_munion_aditem = 2130903155;
        public static final int tb_munion_adview = 2130903156;
        public static final int umeng_common_download_notification = 2130903165;
        public static final int umeng_update_dialog = 2130903167;
        public static final int update_layout = 2130903168;
    }

    public static final class string {
        public static final int UMAppUpdate = 2131558401;
        public static final int UMBreak_Network = 2131558402;
        public static final int UMDialog_InstallAPK = 2131558403;
        public static final int UMGprsCondition = 2131558404;
        public static final int UMIgnore = 2131558405;
        public static final int UMNewVersion = 2131558406;
        public static final int UMNotNow = 2131558407;
        public static final int UMTargetSize = 2131558408;
        public static final int UMToast_IsUpdating = 2131558409;
        public static final int UMUpdateCheck = 2131558410;
        public static final int UMUpdateContent = 2131558411;
        public static final int UMUpdateNow = 2131558412;
        public static final int UMUpdateSize = 2131558413;
        public static final int UMUpdateTitle = 2131558414;
        public static final int ads_clear_master_title = 2131558429;
        public static final int ads_default_title = 2131558430;
        public static final int ads_emoji_guess_title = 2131558431;
        public static final int auth_client_needs_enabling_title = 2131558452;
        public static final int auth_client_needs_installation_title = 2131558453;
        public static final int auth_client_needs_update_title = 2131558454;
        public static final int auth_client_play_services_err_notification_msg = 2131558455;
        public static final int auth_client_requested_by_msg = 2131558456;
        public static final int auth_client_using_bad_version_title = 2131558457;
        public static final int common_google_play_services_enable_button = 2131558488;
        public static final int common_google_play_services_enable_text = 2131558489;
        public static final int common_google_play_services_enable_title = 2131558490;
        public static final int common_google_play_services_error_notification_requested_by_msg = 2131558491;
        public static final int common_google_play_services_install_button = 2131558492;
        public static final int common_google_play_services_install_text_phone = 2131558493;
        public static final int common_google_play_services_install_text_tablet = 2131558494;
        public static final int common_google_play_services_install_title = 2131558495;
        public static final int common_google_play_services_invalid_account_text = 2131558496;
        public static final int common_google_play_services_invalid_account_title = 2131558497;
        public static final int common_google_play_services_needs_enabling_title = 2131558498;
        public static final int common_google_play_services_network_error_text = 2131558499;
        public static final int common_google_play_services_network_error_title = 2131558500;
        public static final int common_google_play_services_notification_needs_installation_title = 2131558501;
        public static final int common_google_play_services_notification_needs_update_title = 2131558502;
        public static final int common_google_play_services_notification_ticker = 2131558503;
        public static final int common_google_play_services_unknown_issue = 2131558504;
        public static final int common_google_play_services_unsupported_date_text = 2131558505;
        public static final int common_google_play_services_unsupported_text = 2131558506;
        public static final int common_google_play_services_unsupported_title = 2131558507;
        public static final int common_google_play_services_update_button = 2131558508;
        public static final int common_google_play_services_update_text = 2131558509;
        public static final int common_google_play_services_update_title = 2131558510;
        public static final int common_signin_button_text = 2131558511;
        public static final int common_signin_button_text_long = 2131558512;
        public static final int tb_munion_tip_download_prefix = 2131559047;
        public static final int umeng_common_action_cancel = 2131559084;
        public static final int umeng_common_action_continue = 2131559085;
        public static final int umeng_common_action_info_exist = 2131559086;
        public static final int umeng_common_action_pause = 2131559087;
        public static final int umeng_common_download_failed = 2131559088;
        public static final int umeng_common_download_finish = 2131559089;
        public static final int umeng_common_download_notification_prefix = 2131559090;
        public static final int umeng_common_icon = 2131559091;
        public static final int umeng_common_info_interrupt = 2131559092;
        public static final int umeng_common_network_break_alert = 2131559093;
        public static final int umeng_common_patch_finish = 2131559094;
        public static final int umeng_common_pause_notification_prefix = 2131559095;
        public static final int umeng_common_silent_download_finish = 2131559096;
        public static final int umeng_common_start_download_notification = 2131559097;
        public static final int umeng_common_start_patch_notification = 2131559098;
        public static final int update_tip = 2131559109;
        public static final int wallet_buy_button_place_holder = 2131559116;
    }

    public static final class style {
        public static final int Theme_IAPTheme = 2131623948;
        public static final int WalletFragmentDefaultButtonTextAppearance = 2131623950;
        public static final int WalletFragmentDefaultDetailsHeaderTextAppearance = 2131623951;
        public static final int WalletFragmentDefaultDetailsTextAppearance = 2131623952;
        public static final int WalletFragmentDefaultStyle = 2131623953;
    }

    public static final class styleable {
        public static final int[] AdsAttrs = {2130771972, 2130771973, 2130771974};
        public static final int AdsAttrs_adSize = 0;
        public static final int AdsAttrs_adSizes = 1;
        public static final int AdsAttrs_adUnitId = 2;
        public static final int[] MapAttrs = {2130771982, 2130771983, 2130771984, 2130771985, 2130771986, 2130771987, 2130771988, 2130771989, 2130771990, 2130771991, 2130771992, 2130771993, 2130771994, 2130771995};
        public static final int MapAttrs_cameraBearing = 1;
        public static final int MapAttrs_cameraTargetLat = 2;
        public static final int MapAttrs_cameraTargetLng = 3;
        public static final int MapAttrs_cameraTilt = 4;
        public static final int MapAttrs_cameraZoom = 5;
        public static final int MapAttrs_mapType = 0;
        public static final int MapAttrs_uiCompass = 6;
        public static final int MapAttrs_uiRotateGestures = 7;
        public static final int MapAttrs_uiScrollGestures = 8;
        public static final int MapAttrs_uiTiltGestures = 9;
        public static final int MapAttrs_uiZoomControls = 10;
        public static final int MapAttrs_uiZoomGestures = 11;
        public static final int MapAttrs_useViewLifecycle = 12;
        public static final int MapAttrs_zOrderOnTop = 13;
        public static final int[] WalletFragmentOptions = {2130772020, 2130772021, 2130772022, 2130772023};
        public static final int WalletFragmentOptions_environment = 1;
        public static final int WalletFragmentOptions_fragmentMode = 3;
        public static final int WalletFragmentOptions_fragmentStyle = 2;
        public static final int WalletFragmentOptions_theme = 0;
        public static final int[] WalletFragmentStyle = {2130772024, 2130772025, 2130772026, 2130772027, 2130772028, 2130772029, 2130772030, 2130772031, 2130772032, 2130772033, 2130772034};
        public static final int WalletFragmentStyle_buyButtonAppearance = 3;
        public static final int WalletFragmentStyle_buyButtonHeight = 0;
        public static final int WalletFragmentStyle_buyButtonText = 2;
        public static final int WalletFragmentStyle_buyButtonWidth = 1;
        public static final int WalletFragmentStyle_maskedWalletDetailsBackground = 6;
        public static final int WalletFragmentStyle_maskedWalletDetailsButtonBackground = 8;
        public static final int WalletFragmentStyle_maskedWalletDetailsButtonTextAppearance = 7;
        public static final int WalletFragmentStyle_maskedWalletDetailsHeaderTextAppearance = 5;
        public static final int WalletFragmentStyle_maskedWalletDetailsLogoImageType = 10;
        public static final int WalletFragmentStyle_maskedWalletDetailsLogoTextColor = 9;
        public static final int WalletFragmentStyle_maskedWalletDetailsTextAppearance = 4;
    }

    public static final class xml {
        public static final int font_prefs = 2131034112;
    }
}
