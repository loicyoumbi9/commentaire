package com.android.common.inbuymodule;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import com.iphonestyle.mms.ConstSetting;
import com.keyboard.common.remotemodule.core.zero.ZeroClient;

public class AdsControlUtils {
    public static final String ADS_CONFIG_APP_LAUNCH_KEY = "_launch";
    public static final String ADS_CONFIG_NAME = "ads_config";
    private static final String[] CLEAR_MASTER_COUNTRY = {"us", "it", "es", "de", "fr", "pt", "nl", "at", "ch", "se", "dk", ZeroClient.CLICK_LABEL_NO, "fi", "gb"};
    private static final String DEFAULT_SUGGEST_PKG = "com.barleygame.guessemoji";
    private static final String DEFAULT_SUGGEST_TITLE = "Guess Emoji World";
    public static final String ONLINE_ADS_ID_FIRST = "publish-adsid-first";
    public static final String ONLINE_ADS_ID_SECOND = "publish-adsid-second";
    public static final String ONLINE_ADS_SWITCH_FIRST = "publish-allow-first";
    public static final String ONLINE_ADS_SWITCH_SECOND = "publish-allow-second";
    private static final String PKG_CLEAR_MASTER_INSTALL = "com.cleanmaster.mguard&referrer=utm_source%3D2010003371";
    private static final String PKG_CLEAR_MASTER_LAUNCH = "com.cleanmaster.mguard";

    public static class AdsAppInfo {
        public Drawable mIcon;
        public String mPkg;
        public String mTitle;
    }

    private static String assembleAppLaunchConfigKey(String str) {
        return str + ADS_CONFIG_APP_LAUNCH_KEY;
    }

    public static boolean checkBuy(Context context) {
        return UpdateVersion.getStatus(context) | InappBuy.getInstance(context).getStatus();
    }

    public static boolean checkEnableEmojiPanelGift(Context context) {
        String onlineKeyValue = UpdateVersion.getOnlineKeyValue(context, "yh_enable_emoji_panel_gift");
        return TextUtils.isEmpty(onlineKeyValue) || !onlineKeyValue.equalsIgnoreCase("false");
    }

    public static boolean checkEnableIconGift(Context context) {
        String onlineKeyValue = UpdateVersion.getOnlineKeyValue(context, "yh_enable_icon_gift_new");
        return TextUtils.isEmpty(onlineKeyValue) || !onlineKeyValue.equalsIgnoreCase("false");
    }

    public static boolean checkYhEnable(Context context) {
        String onlineKeyValue = UpdateVersion.getOnlineKeyValue(context, "yh_enable_gift");
        return TextUtils.isEmpty(onlineKeyValue) || !onlineKeyValue.equalsIgnoreCase("false");
    }

    public static boolean checkYhLuckyEnable(Context context) {
        String onlineKeyValue = UpdateVersion.getOnlineKeyValue(context, "yh_enable_lucky_gift");
        return TextUtils.isEmpty(onlineKeyValue) || !onlineKeyValue.equalsIgnoreCase("false");
    }

    public static boolean checkYhLuckyLinkEnable(Context context) {
        String onlineKeyValue = UpdateVersion.getOnlineKeyValue(context, "yh_enable_lucky_link_gift");
        return !TextUtils.isEmpty(onlineKeyValue) && onlineKeyValue.equalsIgnoreCase(ConstSetting.IOS7_ENABLE);
    }

    public static boolean checkYhTextLinkEnable(Context context) {
        String onlineKeyValue = UpdateVersion.getOnlineKeyValue(context, "yh_enable_textlink");
        return TextUtils.isEmpty(onlineKeyValue) || !onlineKeyValue.equalsIgnoreCase("false");
    }

    public static String convertAdsPkg(String str) {
        int indexOf;
        if (str == null || TextUtils.isEmpty(str) || (indexOf = str.indexOf("&")) <= -1) {
            return str;
        }
        try {
            return str.substring(0, indexOf);
        } catch (Exception e) {
            return str;
        }
    }

    public static AdsAppInfo getAdsDefaultAppInfo(Context context) {
        Resources resources = context.getResources();
        AdsAppInfo adsAppInfo = new AdsAppInfo();
        if (showAdsClearMaster(context)) {
            adsAppInfo.mIcon = resources.getDrawable(R.drawable.ads_app_icon_clear_master);
            adsAppInfo.mTitle = resources.getString(R.string.ads_clear_master_title);
            adsAppInfo.mPkg = PKG_CLEAR_MASTER_INSTALL;
        } else {
            adsAppInfo.mIcon = resources.getDrawable(R.drawable.ads_app_icon_default);
            adsAppInfo.mTitle = resources.getString(R.string.ads_default_title);
            adsAppInfo.mPkg = DEFAULT_SUGGEST_PKG;
        }
        return adsAppInfo;
    }

    public static String getCountry(Context context) {
        TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService("phone");
        String networkCountryIso = telephonyManager != null ? telephonyManager.getNetworkCountryIso() : "default";
        return TextUtils.isEmpty(networkCountryIso) ? "default" : networkCountryIso;
    }

    public static String getDefaultPkg(Context context) {
        String onlineKeyValue = UpdateVersion.getOnlineKeyValue(context, "gift_default_package");
        return onlineKeyValue.length() <= 0 ? DEFAULT_SUGGEST_PKG : onlineKeyValue;
    }

    public static String getDefaultTitle(Context context) {
        String onlineKeyValue = UpdateVersion.getOnlineKeyValue(context, "gift_default_pkg_title");
        return onlineKeyValue.length() <= 0 ? DEFAULT_SUGGEST_TITLE : onlineKeyValue;
    }

    public static String getPosterSuggestPkg(Context context) {
        String onlineKeyValue = UpdateVersion.getOnlineKeyValue(context, "gift_poster_suggest_pkg");
        return onlineKeyValue.length() <= 0 ? DEFAULT_SUGGEST_PKG : onlineKeyValue;
    }

    public static String getPosterSuggestTitle(Context context) {
        String onlineKeyValue = UpdateVersion.getOnlineKeyValue(context, "gift_poster_suggest_title");
        return onlineKeyValue.length() <= 0 ? DEFAULT_SUGGEST_TITLE : onlineKeyValue;
    }

    public static boolean isAdsAppLaunched(Context context, String str) {
        return context.getSharedPreferences(ADS_CONFIG_NAME, 0).getInt(assembleAppLaunchConfigKey(convertAdsPkg(str)), 0) > 0;
    }

    public static boolean isAdsClearMaster(String str) {
        return PKG_CLEAR_MASTER_LAUNCH.equals(SuggestApkUtils.getPkgNameFromInstallSource(str));
    }

    public static void markAdsAppLaunched(Context context, String str) {
        context.getSharedPreferences(ADS_CONFIG_NAME, 0).edit().putInt(assembleAppLaunchConfigKey(convertAdsPkg(str)), 1).commit();
    }

    public static boolean needAdsClearMaster(Context context) {
        String country = getCountry(context);
        for (int i = 0; i < CLEAR_MASTER_COUNTRY.length; i++) {
            if (CLEAR_MASTER_COUNTRY[i].equalsIgnoreCase(country)) {
                return true;
            }
        }
        return false;
    }

    public static boolean needPubnativeAds(Context context) {
        String country = getCountry(context);
        if (TextUtils.isEmpty(country) || country.equalsIgnoreCase("cn")) {
        }
        return true;
    }

    public static boolean showAdsClearMaster(Context context) {
        return needAdsClearMaster(context) && !isAdsAppLaunched(context, PKG_CLEAR_MASTER_LAUNCH);
    }
}
