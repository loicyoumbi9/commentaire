package com.android.common.inbuymodule;

import android.content.Context;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import com.alimama.mobile.csdk.umupdate.a.f;
import com.umeng.analytics.MobclickAgent;
import java.util.HashMap;

public class UmengStatsUtils {
    public static final String DEFAULT_COUNTRY = "unknown";

    public static void addCommonStatsInfo(Context context, HashMap<String, String> hashMap) {
        if (hashMap != null) {
            hashMap.put("newusedays", UpdateVersion.getUserDays(context) + "");
            hashMap.put(f.bj, getCountry(context));
        }
    }

    public static String getCountry(Context context) {
        if (context == null) {
            return "unknown";
        }
        String countryFromSim = getCountryFromSim(context);
        if (countryFromSim != null && !TextUtils.isEmpty(countryFromSim)) {
            return countryFromSim;
        }
        String countryFromLanguage = getCountryFromLanguage(context);
        return (countryFromLanguage == null || TextUtils.isEmpty(countryFromLanguage)) ? "unknown" : countryFromLanguage;
    }

    private static String getCountryFromLanguage(Context context) {
        return context.getResources().getConfiguration().locale.getLanguage();
    }

    private static String getCountryFromSim(Context context) {
        TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService("phone");
        if (telephonyManager == null) {
            return null;
        }
        return telephonyManager.getNetworkCountryIso();
    }

    public static void postStatsEvent(Context context, String str, String str2, String str3) {
        postStatsEvent(context, str, str2, str3, true);
    }

    public static void postStatsEvent(Context context, String str, String str2, String str3, boolean z) {
        HashMap hashMap = new HashMap();
        hashMap.put(str2, str3);
        if (z) {
            addCommonStatsInfo(context, hashMap);
        }
        MobclickAgent.onEvent(context, str, hashMap);
    }

    public static void updateOnlineConfig(Context context) {
        MobclickAgent.updateOnlineConfig(context);
    }
}
