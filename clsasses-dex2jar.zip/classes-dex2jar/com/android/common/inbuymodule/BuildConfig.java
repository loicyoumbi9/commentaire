package com.android.common.inbuymodule;

public final class BuildConfig {
    public static final String APPLICATION_ID = "com.android.common.inbuymodule";
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final String FLAVOR = "";
    public static final int VERSION_CODE = 6;
    public static final String VERSION_NAME = "1.06";
}
