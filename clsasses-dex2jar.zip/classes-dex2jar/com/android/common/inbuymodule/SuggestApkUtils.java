package com.android.common.inbuymodule;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import com.google.android.gms.drive.DriveFile;

public class SuggestApkUtils {
    private static final String DEFAULT_SOURCE = "unknow";
    private static final String INSTALL_SOURCE = "&referrer=utm_source%3D";
    private static final String SOURCE_ID_KEY = "_";
    private static final String TAG = SuggestApkUtils.class.getSimpleName();

    private static String assembleInstallSource(String str, String str2, String str3) {
        String substring;
        if (str2 == null) {
            substring = DEFAULT_SOURCE;
        } else {
            int lastIndexOf = str2.lastIndexOf(".");
            substring = (lastIndexOf <= -1 || lastIndexOf >= str2.length()) ? DEFAULT_SOURCE : str2.substring(lastIndexOf + 1, str2.length());
        }
        return str + INSTALL_SOURCE + substring + SOURCE_ID_KEY + str3;
    }

    private static Intent assembleLaunchIntent(Context context, String str) {
        String str2 = "";
        Intent launchIntentForPackage = context.getPackageManager().getLaunchIntentForPackage(str);
        if (launchIntentForPackage == null) {
            return null;
        }
        if (launchIntentForPackage.getComponent() != null) {
            str2 = launchIntentForPackage.getComponent().getClassName();
        }
        Intent intent = new Intent("android.intent.action.MAIN");
        intent.addCategory("android.intent.category.LAUNCHER");
        intent.setComponent(new ComponentName(str, str2));
        intent.setFlags(DriveFile.MODE_READ_ONLY);
        return intent;
    }

    public static String getPkgNameFromInstallSource(String str) {
        int indexOf;
        return (str != null && (indexOf = str.indexOf(38)) > -1) ? str.substring(0, indexOf) : str;
    }

    public static void goToInstallApk(Context context, String str, String str2, String str3) {
        if (str != null) {
            String pkgNameFromInstallSource = getPkgNameFromInstallSource(str);
            if (str.equals(pkgNameFromInstallSource)) {
                str = assembleInstallSource(pkgNameFromInstallSource, str2, str3);
            }
            Log.i(TAG, "assembleInstallSource: " + str);
            UpdateVersion.install(context, str);
        }
    }

    public static void goToRateApk(Context context, String str) {
        UpdateVersion.install(context, getPkgNameFromInstallSource(str));
    }

    public static boolean isApkInstalled(Context context, String str) {
        String pkgNameFromInstallSource = getPkgNameFromInstallSource(str);
        if (pkgNameFromInstallSource == null) {
            return false;
        }
        try {
            return context.getPackageManager().getPackageInfo(pkgNameFromInstallSource, 0) != null;
        } catch (Exception e) {
            return false;
        }
    }

    public static void launchAppMainActivity(Context context, String str) {
        String pkgNameFromInstallSource = getPkgNameFromInstallSource(str);
        try {
            Intent assembleLaunchIntent = assembleLaunchIntent(context, pkgNameFromInstallSource);
            if (assembleLaunchIntent != null) {
                context.startActivity(assembleLaunchIntent);
            } else {
                Log.w(TAG, "can't find launch activity from: " + pkgNameFromInstallSource);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
