package com.android.common.inbuymodule;

import android.app.Activity;
import android.content.Context;
import android.preference.PreferenceManager;
import android.util.Log;
import com.android.common.inbuymodule.bill.IabHelper;
import com.android.common.inbuymodule.bill.IabResult;
import com.android.common.inbuymodule.bill.Inventory;
import com.android.common.inbuymodule.bill.Purchase;

public class InappBuy {
    public static final int RC_REQUEST = 10001;
    static final String SKU_PREMIUM = "premium";
    static final String TAG = "Kitkat";
    static final int TANK_MAX = 4;
    private static InappBuy mInappBuy = null;
    private static String mRSAKey = "";
    /* access modifiers changed from: private */
    public OnQueryFinishedListener mBuyFinished = null;
    IabHelper.OnConsumeFinishedListener mConsumeFinishedListener = new IabHelper.OnConsumeFinishedListener() {
        /* class com.android.common.inbuymodule.InappBuy.AnonymousClass4 */

        @Override // com.android.common.inbuymodule.bill.IabHelper.OnConsumeFinishedListener
        public void onConsumeFinished(Purchase purchase, IabResult iabResult) {
            int i = 4;
            Log.d(InappBuy.TAG, "Consumption finished. Purchase: " + purchase + ", result: " + iabResult);
            if (InappBuy.this.mHelper != null) {
                if (iabResult.isSuccess()) {
                    Log.d(InappBuy.TAG, "Consumption successful. Provisioning.");
                    InappBuy inappBuy = InappBuy.this;
                    if (InappBuy.this.mTank != 4) {
                        i = InappBuy.this.mTank + 1;
                    }
                    inappBuy.mTank = i;
                    InappBuy.this.saveData();
                    InappBuy.this.alert("You filled 1/4 tank. Your tank is now " + String.valueOf(InappBuy.this.mTank) + "/4 full!");
                } else {
                    InappBuy.this.complain("Error while consuming: " + iabResult);
                }
                InappBuy.this.updateUi();
                InappBuy.this.setWaitScreen(false);
                Log.d(InappBuy.TAG, "End consumption flow.");
            }
        }
    };
    private Context mContext = null;
    /* access modifiers changed from: private */
    public boolean mFinishQuery = false;
    IabHelper.QueryInventoryFinishedListener mGotInventoryListener = new IabHelper.QueryInventoryFinishedListener() {
        /* class com.android.common.inbuymodule.InappBuy.AnonymousClass2 */

        @Override // com.android.common.inbuymodule.bill.IabHelper.QueryInventoryFinishedListener
        public void onQueryInventoryFinished(IabResult iabResult, Inventory inventory) {
            Log.d(InappBuy.TAG, "Query inventory finished.");
            if (InappBuy.this.mHelper != null) {
                if (iabResult.isFailure()) {
                    InappBuy.this.complain("Failed to query inventory: " + iabResult);
                    return;
                }
                Log.d(InappBuy.TAG, "Query inventory was successful.");
                Purchase purchase = inventory.getPurchase(InappBuy.SKU_PREMIUM);
                InappBuy.this.mIsPremium = purchase != null && InappBuy.this.verifyDeveloperPayload(purchase);
                Log.d(InappBuy.TAG, "User is " + (InappBuy.this.mIsPremium ? "PREMIUM" : "NOT PREMIUM"));
                InappBuy.this.updateUi();
                InappBuy.this.setWaitScreen(false);
                Log.d(InappBuy.TAG, "Initial inventory query finished; enabling main UI.");
                if (InappBuy.this.mQueryFinished != null) {
                    InappBuy.this.mQueryFinished.onFinished(InappBuy.this.mIsPremium);
                }
                boolean unused = InappBuy.this.mFinishQuery = true;
            }
        }
    };
    IabHelper mHelper;
    boolean mIsPremium = false;
    IabHelper.OnIabPurchaseFinishedListener mPurchaseFinishedListener = new IabHelper.OnIabPurchaseFinishedListener() {
        /* class com.android.common.inbuymodule.InappBuy.AnonymousClass3 */

        @Override // com.android.common.inbuymodule.bill.IabHelper.OnIabPurchaseFinishedListener
        public void onIabPurchaseFinished(IabResult iabResult, Purchase purchase) {
            Log.d(InappBuy.TAG, "Purchase finished: " + iabResult + ", purchase: " + purchase);
            if (InappBuy.this.mHelper != null) {
                if (iabResult.isFailure()) {
                    InappBuy.this.complain("Error purchasing: " + iabResult);
                    InappBuy.this.setWaitScreen(false);
                } else if (!InappBuy.this.verifyDeveloperPayload(purchase)) {
                    InappBuy.this.complain("Error purchasing. Authenticity verification failed.");
                    InappBuy.this.setWaitScreen(false);
                } else {
                    Log.d(InappBuy.TAG, "Purchase successful.");
                    if (purchase.getSku().equals(InappBuy.SKU_PREMIUM)) {
                        Log.d(InappBuy.TAG, "Purchase is premium upgrade. Congratulating user.");
                        InappBuy.this.alert("Thank you for upgrading to premium!");
                        InappBuy.this.mIsPremium = true;
                        InappBuy.this.updateUi();
                        InappBuy.this.setWaitScreen(false);
                    }
                    if (InappBuy.this.mBuyFinished != null) {
                        InappBuy.this.mBuyFinished.onFinished(InappBuy.this.mIsPremium);
                    }
                }
            }
        }
    };
    /* access modifiers changed from: private */
    public OnQueryFinishedListener mQueryFinished = null;
    boolean mSubscribedToInfiniteGas = false;
    int mTank;

    public interface OnQueryFinishedListener {
        void onFinished(boolean z);
    }

    public static boolean check(Context context) {
        return PreferenceManager.getDefaultSharedPreferences(context).getBoolean("pref_key_buypro_status", false);
    }

    private Context getActivity() {
        return this.mContext;
    }

    public static InappBuy getInstance(Context context) {
        if (mInappBuy == null) {
            mInappBuy = new InappBuy();
            mInappBuy.setActivity(context);
        } else {
            mInappBuy.setActivity(context);
        }
        return mInappBuy;
    }

    private void setActivity(Context context) {
        if (context != null) {
            this.mContext = context.getApplicationContext();
        }
    }

    public static void setRSAKey(String str) {
        mRSAKey = str;
    }

    /* access modifiers changed from: package-private */
    public void alert(String str) {
        Log.e(TAG, "Showing alert dialog: " + str);
    }

    /* access modifiers changed from: package-private */
    public void complain(String str) {
        Log.e(TAG, "**** InappBuy Error: " + str);
        alert("Error: " + str);
    }

    public void dispose() {
        try {
            if (this.mHelper != null) {
                this.mHelper.dispose();
                this.mHelper = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public IabHelper getHelper() {
        return this.mHelper;
    }

    public boolean getStatus() {
        return this.mIsPremium;
    }

    public boolean isActive() {
        return this.mHelper != null;
    }

    public boolean isFinishQuery() {
        return this.mFinishQuery;
    }

    /* access modifiers changed from: package-private */
    public void loadData() {
    }

    public void onInAppBilling() {
        if (this.mHelper == null) {
            loadData();
            String str = mRSAKey;
            if (str.length() > 0) {
                Log.e(TAG, "Creating IAB helper." + getActivity());
                this.mHelper = new IabHelper(getActivity(), str);
                this.mHelper.enableDebugLogging(false);
                Log.d(TAG, "Starting setup.");
                try {
                    this.mHelper.startSetup(new IabHelper.OnIabSetupFinishedListener() {
                        /* class com.android.common.inbuymodule.InappBuy.AnonymousClass1 */

                        @Override // com.android.common.inbuymodule.bill.IabHelper.OnIabSetupFinishedListener
                        public void onIabSetupFinished(IabResult iabResult) {
                            Log.d(InappBuy.TAG, "Setup finished.");
                            if (!iabResult.isSuccess()) {
                                InappBuy.this.complain("Problem setting up in-app billing: " + iabResult);
                                if (InappBuy.this.mQueryFinished != null) {
                                    InappBuy.this.mQueryFinished.onFinished(InappBuy.this.mIsPremium);
                                }
                            } else if (InappBuy.this.mHelper != null) {
                                Log.d(InappBuy.TAG, "Setup successful. Querying inventory.");
                                InappBuy.this.mHelper.queryInventoryAsync(InappBuy.this.mGotInventoryListener);
                            }
                        }
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                    if (this.mQueryFinished != null) {
                        this.mQueryFinished.onFinished(this.mIsPremium);
                    }
                }
            }
        }
    }

    public void onUpgradeAppButtonClicked(Activity activity) {
        Log.d(TAG, "Upgrade button clicked; launching purchase flow for upgrade.");
        setWaitScreen(true);
        try {
            this.mHelper.launchPurchaseFlow(activity, SKU_PREMIUM, 10001, this.mPurchaseFinishedListener, "");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void release() {
        dispose();
        this.mContext = null;
        setFinishedListener(null);
        setBuyListener(null);
    }

    /* access modifiers changed from: package-private */
    public void saveData() {
    }

    public void setBuyListener(OnQueryFinishedListener onQueryFinishedListener) {
        this.mBuyFinished = onQueryFinishedListener;
    }

    public void setFinishedListener(OnQueryFinishedListener onQueryFinishedListener) {
        this.mQueryFinished = onQueryFinishedListener;
    }

    /* access modifiers changed from: package-private */
    public void setWaitScreen(boolean z) {
    }

    public void updateUi() {
    }

    /* access modifiers changed from: package-private */
    public boolean verifyDeveloperPayload(Purchase purchase) {
        purchase.getDeveloperPayload();
        return true;
    }
}
