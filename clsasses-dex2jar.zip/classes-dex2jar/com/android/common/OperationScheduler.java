package com.android.common;

import android.content.SharedPreferences;
import android.net.http.AndroidHttpClient;
import android.text.format.Time;
import java.util.Iterator;
import java.util.TreeSet;

public class OperationScheduler {
    private static final String PREFIX = "OperationScheduler_";
    private final SharedPreferences mStorage;

    public static class Options {
        public long backoffFixedMillis = 0;
        public long backoffIncrementalMillis = 5000;
        public long maxMoratoriumMillis = 86400000;
        public long minTriggerMillis = 0;
        public long periodicIntervalMillis = 0;

        public String toString() {
            return String.format("OperationScheduler.Options[backoff=%.1f+%.1f max=%.1f min=%.1f period=%.1f]", Double.valueOf(((double) this.backoffFixedMillis) / 1000.0d), Double.valueOf(((double) this.backoffIncrementalMillis) / 1000.0d), Double.valueOf(((double) this.maxMoratoriumMillis) / 1000.0d), Double.valueOf(((double) this.minTriggerMillis) / 1000.0d), Double.valueOf(((double) this.periodicIntervalMillis) / 1000.0d));
        }
    }

    public OperationScheduler(SharedPreferences sharedPreferences) {
        this.mStorage = sharedPreferences;
    }

    private long getTimeBefore(String str, long j) {
        long j2 = this.mStorage.getLong(str, 0);
        if (j2 <= j) {
            return j2;
        }
        SharedPreferencesCompat.apply(this.mStorage.edit().putLong(str, j));
        return j;
    }

    public static Options parseOptions(String str, Options options) throws IllegalArgumentException {
        String[] split = str.split(" +");
        for (String str2 : split) {
            if (str2.length() != 0) {
                if (str2.startsWith("backoff=")) {
                    int indexOf = str2.indexOf(43, 8);
                    if (indexOf < 0) {
                        options.backoffFixedMillis = parseSeconds(str2.substring(8));
                    } else {
                        if (indexOf > 8) {
                            options.backoffFixedMillis = parseSeconds(str2.substring(8, indexOf));
                        }
                        options.backoffIncrementalMillis = parseSeconds(str2.substring(indexOf + 1));
                    }
                } else if (str2.startsWith("max=")) {
                    options.maxMoratoriumMillis = parseSeconds(str2.substring(4));
                } else if (str2.startsWith("min=")) {
                    options.minTriggerMillis = parseSeconds(str2.substring(4));
                } else if (str2.startsWith("period=")) {
                    options.periodicIntervalMillis = parseSeconds(str2.substring(7));
                } else {
                    options.periodicIntervalMillis = parseSeconds(str2);
                }
            }
        }
        return options;
    }

    private static long parseSeconds(String str) throws NumberFormatException {
        return (long) (Float.parseFloat(str) * 1000.0f);
    }

    /* access modifiers changed from: protected */
    public long currentTimeMillis() {
        return System.currentTimeMillis();
    }

    public long getLastAttemptTimeMillis() {
        return Math.max(this.mStorage.getLong("OperationScheduler_lastSuccessTimeMillis", 0), this.mStorage.getLong("OperationScheduler_lastErrorTimeMillis", 0));
    }

    public long getLastSuccessTimeMillis() {
        return this.mStorage.getLong("OperationScheduler_lastSuccessTimeMillis", 0);
    }

    public long getNextTimeMillis(Options options) {
        if (!this.mStorage.getBoolean("OperationScheduler_enabledState", true) || this.mStorage.getBoolean("OperationScheduler_permanentError", false)) {
            return Long.MAX_VALUE;
        }
        int i = this.mStorage.getInt("OperationScheduler_errorCount", 0);
        long currentTimeMillis = currentTimeMillis();
        long timeBefore = getTimeBefore("OperationScheduler_lastSuccessTimeMillis", currentTimeMillis);
        long timeBefore2 = getTimeBefore("OperationScheduler_lastErrorTimeMillis", currentTimeMillis);
        long j = this.mStorage.getLong("OperationScheduler_triggerTimeMillis", Long.MAX_VALUE);
        long timeBefore3 = getTimeBefore("OperationScheduler_moratoriumTimeMillis", getTimeBefore("OperationScheduler_moratoriumSetTimeMillis", currentTimeMillis) + options.maxMoratoriumMillis);
        if (options.periodicIntervalMillis > 0) {
            j = Math.min(j, options.periodicIntervalMillis + timeBefore);
        }
        long max = Math.max(Math.max(j, timeBefore3), options.minTriggerMillis + timeBefore);
        if (i <= 0) {
            return max;
        }
        return Math.max(max, (((long) i) * options.backoffIncrementalMillis) + options.backoffFixedMillis + timeBefore2);
    }

    public void onPermanentError() {
        SharedPreferencesCompat.apply(this.mStorage.edit().putBoolean("OperationScheduler_permanentError", true));
    }

    public void onSuccess() {
        resetTransientError();
        resetPermanentError();
        SharedPreferencesCompat.apply(this.mStorage.edit().remove("OperationScheduler_errorCount").remove("OperationScheduler_lastErrorTimeMillis").remove("OperationScheduler_permanentError").remove("OperationScheduler_triggerTimeMillis").putLong("OperationScheduler_lastSuccessTimeMillis", currentTimeMillis()));
    }

    public void onTransientError() {
        SharedPreferences.Editor edit = this.mStorage.edit();
        edit.putLong("OperationScheduler_lastErrorTimeMillis", currentTimeMillis());
        edit.putInt("OperationScheduler_errorCount", this.mStorage.getInt("OperationScheduler_errorCount", 0) + 1);
        SharedPreferencesCompat.apply(edit);
    }

    public void resetPermanentError() {
        SharedPreferencesCompat.apply(this.mStorage.edit().remove("OperationScheduler_permanentError"));
    }

    public void resetTransientError() {
        SharedPreferencesCompat.apply(this.mStorage.edit().remove("OperationScheduler_errorCount"));
    }

    public void setEnabledState(boolean z) {
        SharedPreferencesCompat.apply(this.mStorage.edit().putBoolean("OperationScheduler_enabledState", z));
    }

    public boolean setMoratoriumTimeHttp(String str) {
        try {
            setMoratoriumTimeMillis((Long.valueOf(str).longValue() * 1000) + currentTimeMillis());
            return true;
        } catch (NumberFormatException e) {
            try {
                setMoratoriumTimeMillis(AndroidHttpClient.parseDate(str));
                return true;
            } catch (IllegalArgumentException e2) {
                return false;
            }
        }
    }

    public void setMoratoriumTimeMillis(long j) {
        SharedPreferencesCompat.apply(this.mStorage.edit().putLong("OperationScheduler_moratoriumTimeMillis", j).putLong("OperationScheduler_moratoriumSetTimeMillis", currentTimeMillis()));
    }

    public void setTriggerTimeMillis(long j) {
        SharedPreferencesCompat.apply(this.mStorage.edit().putLong("OperationScheduler_triggerTimeMillis", j));
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("[OperationScheduler:");
        Iterator it = new TreeSet(this.mStorage.getAll().keySet()).iterator();
        while (it.hasNext()) {
            String str = (String) it.next();
            if (str.startsWith(PREFIX)) {
                if (str.endsWith("TimeMillis")) {
                    Time time = new Time();
                    time.set(this.mStorage.getLong(str, 0));
                    sb.append(" ").append(str.substring(PREFIX.length(), str.length() - 10));
                    sb.append("=").append(time.format("%Y-%m-%d/%H:%M:%S"));
                } else {
                    sb.append(" ").append(str.substring(PREFIX.length()));
                    sb.append("=").append(this.mStorage.getAll().get(str).toString());
                }
            }
        }
        return sb.append("]").toString();
    }
}
