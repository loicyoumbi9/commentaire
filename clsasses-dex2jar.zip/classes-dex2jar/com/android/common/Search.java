package com.android.common;

public class Search {
    public static final String SOURCE = "source";

    private Search() {
    }
}
