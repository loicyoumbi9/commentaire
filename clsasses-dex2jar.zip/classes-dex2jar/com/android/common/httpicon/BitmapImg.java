package com.android.common.httpicon;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import java.io.File;

public class BitmapImg {
    public int calculateInSampleSize(BitmapFactory.Options options, int i, int i2) {
        int i3 = options.outHeight;
        int i4 = options.outWidth;
        if (i3 <= i2 && i4 <= i) {
            return 1;
        }
        int round = Math.round(((float) i3) / ((float) i2));
        int round2 = Math.round(((float) i4) / ((float) i));
        return round < round2 ? round : round2;
    }

    public Bitmap decodeSampledBitmapFromResource(String str, int i, int i2) {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(str, options);
        options.inSampleSize = calculateInSampleSize(options, i, i2);
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeFile(str, options);
    }

    public Drawable getDrawable(Context context, String str, int i) {
        BitmapDrawable bitmapDrawable;
        try {
            File file = new File(str);
            if (!file.exists()) {
                return null;
            }
            if (file.length() <= 0) {
                file.delete();
                return null;
            }
            int dimensionPixelSize = context.getResources().getDimensionPixelSize(i);
            Bitmap decodeSampledBitmapFromResource = decodeSampledBitmapFromResource(str, dimensionPixelSize, dimensionPixelSize);
            bitmapDrawable = decodeSampledBitmapFromResource != null ? new BitmapDrawable(decodeSampledBitmapFromResource) : null;
            return bitmapDrawable;
        } catch (Exception e) {
            e.printStackTrace();
            bitmapDrawable = null;
        }
    }
}
