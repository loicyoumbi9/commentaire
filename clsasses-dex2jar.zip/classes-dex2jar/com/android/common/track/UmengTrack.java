package com.android.common.track;

import android.content.Context;
import com.android.common.inbuymodule.UpdateVersion;
import com.umeng.analytics.MobclickAgent;
import java.util.HashMap;

public class UmengTrack implements TrackImpl {
    public UmengTrack(Context context) {
        MobclickAgent.updateOnlineConfig(context);
    }

    public static void addUseDay(Context context, HashMap<String, String> hashMap) {
        if (hashMap != null) {
            hashMap.put("newusedays", UpdateVersion.getUserDays(context) + "");
        }
    }

    @Override // com.android.common.track.TrackImpl
    public String getName() {
        return "UmengSDK";
    }

    @Override // com.android.common.track.TrackImpl
    public void pauseTrack(Context context) {
        MobclickAgent.onPause(context);
    }

    @Override // com.android.common.track.TrackImpl
    public void postEvent(Context context, String str, HashMap<String, String> hashMap) {
        addUseDay(context, hashMap);
        MobclickAgent.onEvent(context, str, hashMap);
    }

    @Override // com.android.common.track.TrackImpl
    public void resumeTrack(Context context) {
        MobclickAgent.onResume(context);
    }

    @Override // com.android.common.track.TrackImpl
    public void setErrorHandler(Context context) {
    }

    @Override // com.android.common.track.TrackImpl
    public void startTrack(Context context) {
    }

    @Override // com.android.common.track.TrackImpl
    public void stopTrack(Context context) {
    }
}
