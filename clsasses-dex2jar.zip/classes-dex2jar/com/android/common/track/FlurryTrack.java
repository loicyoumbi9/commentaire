package com.android.common.track;

import android.content.Context;
import java.util.HashMap;

public class FlurryTrack implements TrackImpl {
    public FlurryTrack(Context context, String str) {
    }

    @Override // com.android.common.track.TrackImpl
    public String getName() {
        return "FlurryAnalytics";
    }

    @Override // com.android.common.track.TrackImpl
    public void pauseTrack(Context context) {
    }

    @Override // com.android.common.track.TrackImpl
    public void postEvent(Context context, String str, HashMap<String, String> hashMap) {
    }

    @Override // com.android.common.track.TrackImpl
    public void resumeTrack(Context context) {
    }

    @Override // com.android.common.track.TrackImpl
    public void setErrorHandler(Context context) {
    }

    @Override // com.android.common.track.TrackImpl
    public void startTrack(Context context) {
    }

    @Override // com.android.common.track.TrackImpl
    public void stopTrack(Context context) {
    }
}
