package com.android.common.track;

import android.content.Context;
import java.util.HashMap;

public interface TrackImpl {
    String getName();

    void pauseTrack(Context context);

    void postEvent(Context context, String str, HashMap<String, String> hashMap);

    void resumeTrack(Context context);

    void setErrorHandler(Context context);

    void startTrack(Context context);

    void stopTrack(Context context);
}
