package com.android.common.track;

import android.content.Context;
import android.util.Log;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public class TrackManager {
    private static final String TAG = TrackManager.class.getSimpleName();
    private static TrackManager sInstance = null;
    private Context mContext = null;
    private ArrayList<TrackImpl> mImplList = null;
    private boolean mIsInit = false;

    private TrackManager(Context context) {
        this.mContext = context.getApplicationContext();
    }

    private boolean checkInit() {
        if (this.mIsInit) {
            return true;
        }
        Log.d(TAG, "before you TrackManager, you must call init first !!");
        return false;
    }

    public static TrackManager getInstance(Context context) {
        if (sInstance == null) {
            synchronized (TrackManager.class) {
                try {
                    if (sInstance == null) {
                        sInstance = new TrackManager(context);
                    }
                } catch (Throwable th) {
                    while (true) {
                        throw th;
                    }
                }
            }
        }
        return sInstance;
    }

    public void init(String str, String str2, String str3) {
        if (this.mIsInit) {
            Log.d(TAG, "is already init ignore it !!");
            return;
        }
        this.mIsInit = true;
        this.mImplList = new ArrayList<>();
        TrackImpl trackImpl = null;
        if (str != null) {
            trackImpl = new UmengTrack(this.mContext);
            this.mImplList.add(trackImpl);
        }
        if (str2 != null) {
            this.mImplList.add(trackImpl);
        }
        if (str3 != null) {
            this.mImplList.add(new FlurryTrack(this.mContext, str3));
        }
        Iterator<TrackImpl> it = this.mImplList.iterator();
        while (it.hasNext()) {
            Log.d(TAG, "add track impl: " + it.next().getName());
        }
    }

    public void pauseTrack(Context context) {
        if (checkInit()) {
            Iterator<TrackImpl> it = this.mImplList.iterator();
            while (it.hasNext()) {
                TrackImpl next = it.next();
                if (next != null) {
                    next.pauseTrack(context);
                }
            }
        }
    }

    public void postEvent(String str, HashMap<String, String> hashMap) {
        if (checkInit()) {
            Iterator<TrackImpl> it = this.mImplList.iterator();
            while (it.hasNext()) {
                TrackImpl next = it.next();
                if (next != null) {
                    next.postEvent(this.mContext, str, hashMap);
                }
            }
        }
    }

    public void resumeTrack(Context context) {
        if (checkInit()) {
            Iterator<TrackImpl> it = this.mImplList.iterator();
            while (it.hasNext()) {
                TrackImpl next = it.next();
                if (next != null) {
                    next.resumeTrack(context);
                }
            }
        }
    }

    public void setErrorHandler(Context context) {
        if (checkInit()) {
            Iterator<TrackImpl> it = this.mImplList.iterator();
            while (it.hasNext()) {
                TrackImpl next = it.next();
                if (next != null) {
                    next.setErrorHandler(context);
                }
            }
        }
    }

    public void startTrack(Context context) {
        if (checkInit()) {
            Iterator<TrackImpl> it = this.mImplList.iterator();
            while (it.hasNext()) {
                TrackImpl next = it.next();
                if (next != null) {
                    next.startTrack(context);
                }
            }
        }
    }

    public void stopTrack(Context context) {
        if (checkInit()) {
            Iterator<TrackImpl> it = this.mImplList.iterator();
            while (it.hasNext()) {
                TrackImpl next = it.next();
                if (next != null) {
                    next.stopTrack(context);
                }
            }
        }
    }
}
