package com.android.common.track;

import android.app.Activity;
import android.os.Bundle;

public class TrackActivity extends Activity {
    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        TrackManager.getInstance(this).setErrorHandler(this);
    }

    /* access modifiers changed from: protected */
    public void onPause() {
        super.onPause();
        TrackManager.getInstance(this).pauseTrack(this);
    }

    /* access modifiers changed from: protected */
    public void onResume() {
        super.onResume();
        TrackManager.getInstance(this).resumeTrack(this);
    }

    /* access modifiers changed from: protected */
    public void onStart() {
        super.onStart();
        TrackManager.getInstance(this).startTrack(this);
    }

    /* access modifiers changed from: protected */
    public void onStop() {
        super.onStop();
        TrackManager.getInstance(this).stopTrack(this);
    }
}
