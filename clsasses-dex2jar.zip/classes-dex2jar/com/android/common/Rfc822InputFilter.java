package com.android.common;

import android.text.InputFilter;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import com.google.android.gms.location.places.Place;

public class Rfc822InputFilter implements InputFilter {
    public CharSequence filter(CharSequence charSequence, int i, int i2, Spanned spanned, int i3, int i4) {
        if (i2 - i == 1 && charSequence.charAt(i) == ' ') {
            boolean z = false;
            while (true) {
                if (i3 > 0) {
                    i3--;
                    switch (spanned.charAt(i3)) {
                        case Place.TYPE_GYM /*44*/:
                            break;
                        case Place.TYPE_HARDWARE_STORE /*46*/:
                            z = true;
                            break;
                        case '@':
                            if (z) {
                                if (!(charSequence instanceof Spanned)) {
                                    return ", ";
                                }
                                SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder(",");
                                spannableStringBuilder.append(charSequence);
                                return spannableStringBuilder;
                            }
                            break;
                    }
                }
            }
        }
        return null;
    }
}
