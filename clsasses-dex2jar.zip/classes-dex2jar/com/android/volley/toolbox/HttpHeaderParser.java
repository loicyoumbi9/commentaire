package com.android.volley.toolbox;

import com.android.volley.Cache;
import com.android.volley.NetworkResponse;
import com.iphonestyle.mms.transaction.MessageSender;
import java.util.Map;
import org.apache.http.impl.cookie.DateParseException;
import org.apache.http.impl.cookie.DateUtils;

public class HttpHeaderParser {
    public static Cache.Entry parseCacheHeaders(NetworkResponse networkResponse) {
        long j;
        long j2;
        boolean z;
        boolean z2;
        long j3;
        long j4;
        long currentTimeMillis = System.currentTimeMillis();
        Map map = networkResponse.headers;
        long j5 = 0;
        String str = (String) map.get("Date");
        if (str != null) {
            j5 = parseDateAsEpoch(str);
        }
        String str2 = (String) map.get("Cache-Control");
        if (str2 != null) {
            String[] split = str2.split(",");
            boolean z3 = false;
            long j6 = 0;
            long j7 = 0;
            for (String str3 : split) {
                String trim = str3.trim();
                if (trim.equals("no-cache") || trim.equals("no-store")) {
                    return null;
                }
                if (trim.startsWith("max-age=")) {
                    try {
                        j7 = Long.parseLong(trim.substring(8));
                    } catch (Exception e) {
                    }
                } else if (trim.startsWith("stale-while-revalidate=")) {
                    try {
                        j6 = Long.parseLong(trim.substring(23));
                    } catch (Exception e2) {
                    }
                } else if (trim.equals("must-revalidate") || trim.equals("proxy-revalidate")) {
                    z3 = true;
                }
            }
            j = j7;
            j2 = j6;
            z = true;
            z2 = z3;
        } else {
            j = 0;
            j2 = 0;
            z = false;
            z2 = false;
        }
        String str4 = (String) map.get("Expires");
        long parseDateAsEpoch = str4 != null ? parseDateAsEpoch(str4) : 0;
        String str5 = (String) map.get("Last-Modified");
        long parseDateAsEpoch2 = str5 != null ? parseDateAsEpoch(str5) : 0;
        String str6 = (String) map.get("ETag");
        if (z) {
            long j8 = currentTimeMillis + (1000 * j);
            if (z2) {
                j3 = j8;
                j4 = j8;
            } else {
                j4 = (1000 * j2) + j8;
                j3 = j8;
            }
        } else if (j5 <= 0 || parseDateAsEpoch < j5) {
            j3 = 0;
            j4 = 0;
        } else {
            long j9 = (parseDateAsEpoch - j5) + currentTimeMillis;
            j3 = j9;
            j4 = j9;
        }
        Cache.Entry entry = new Cache.Entry();
        entry.data = networkResponse.data;
        entry.etag = str6;
        entry.softTtl = j3;
        entry.ttl = j4;
        entry.serverDate = j5;
        entry.lastModified = parseDateAsEpoch2;
        entry.responseHeaders = map;
        return entry;
    }

    public static String parseCharset(Map map) {
        return parseCharset(map, "ISO-8859-1");
    }

    public static String parseCharset(Map map, String str) {
        String str2 = (String) map.get("Content-Type");
        if (str2 == null) {
            return str;
        }
        String[] split = str2.split(MessageSender.RECIPIENTS_SEPARATOR);
        for (int i = 1; i < split.length; i++) {
            String[] split2 = split[i].trim().split("=");
            if (split2.length == 2 && split2[0].equals("charset")) {
                return split2[1];
            }
        }
        return str;
    }

    public static long parseDateAsEpoch(String str) {
        try {
            return DateUtils.parseDate(str).getTime();
        } catch (DateParseException e) {
            return 0;
        }
    }
}
