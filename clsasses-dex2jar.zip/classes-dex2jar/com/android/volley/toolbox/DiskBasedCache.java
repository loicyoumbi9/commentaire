package com.android.volley.toolbox;

import android.os.SystemClock;
import com.android.volley.Cache;
import com.android.volley.VolleyLog;
import java.io.EOFException;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

public class DiskBasedCache implements Cache {
    private static final int CACHE_MAGIC = 538247942;
    private static final int DEFAULT_DISK_USAGE_BYTES = 5242880;
    private static final float HYSTERESIS_FACTOR = 0.9f;
    private final Map mEntries;
    private final int mMaxCacheSizeInBytes;
    private final File mRootDirectory;
    private long mTotalSize;

    static class CacheHeader {
        public String etag;
        public String key;
        public long lastModified;
        public Map responseHeaders;
        public long serverDate;
        public long size;
        public long softTtl;
        public long ttl;

        private CacheHeader() {
        }

        public CacheHeader(String str, Cache.Entry entry) {
            this.key = str;
            this.size = (long) entry.data.length;
            this.etag = entry.etag;
            this.serverDate = entry.serverDate;
            this.lastModified = entry.lastModified;
            this.ttl = entry.ttl;
            this.softTtl = entry.softTtl;
            this.responseHeaders = entry.responseHeaders;
        }

        public static CacheHeader readHeader(InputStream inputStream) {
            CacheHeader cacheHeader = new CacheHeader();
            if (DiskBasedCache.readInt(inputStream) != DiskBasedCache.CACHE_MAGIC) {
                throw new IOException();
            }
            cacheHeader.key = DiskBasedCache.readString(inputStream);
            cacheHeader.etag = DiskBasedCache.readString(inputStream);
            if (cacheHeader.etag.equals("")) {
                cacheHeader.etag = null;
            }
            cacheHeader.serverDate = DiskBasedCache.readLong(inputStream);
            cacheHeader.lastModified = DiskBasedCache.readLong(inputStream);
            cacheHeader.ttl = DiskBasedCache.readLong(inputStream);
            cacheHeader.softTtl = DiskBasedCache.readLong(inputStream);
            cacheHeader.responseHeaders = DiskBasedCache.readStringStringMap(inputStream);
            return cacheHeader;
        }

        public Cache.Entry toCacheEntry(byte[] bArr) {
            Cache.Entry entry = new Cache.Entry();
            entry.data = bArr;
            entry.etag = this.etag;
            entry.serverDate = this.serverDate;
            entry.lastModified = this.lastModified;
            entry.ttl = this.ttl;
            entry.softTtl = this.softTtl;
            entry.responseHeaders = this.responseHeaders;
            return entry;
        }

        public boolean writeHeader(OutputStream outputStream) {
            try {
                DiskBasedCache.writeInt(outputStream, DiskBasedCache.CACHE_MAGIC);
                DiskBasedCache.writeString(outputStream, this.key);
                DiskBasedCache.writeString(outputStream, this.etag == null ? "" : this.etag);
                DiskBasedCache.writeLong(outputStream, this.serverDate);
                DiskBasedCache.writeLong(outputStream, this.lastModified);
                DiskBasedCache.writeLong(outputStream, this.ttl);
                DiskBasedCache.writeLong(outputStream, this.softTtl);
                DiskBasedCache.writeStringStringMap(this.responseHeaders, outputStream);
                outputStream.flush();
                return true;
            } catch (IOException e) {
                VolleyLog.d("%s", e.toString());
                return false;
            }
        }
    }

    private static class CountingInputStream extends FilterInputStream {
        /* access modifiers changed from: private */
        public int bytesRead;

        private CountingInputStream(InputStream inputStream) {
            super(inputStream);
            this.bytesRead = 0;
        }

        /* synthetic */ CountingInputStream(InputStream inputStream, CountingInputStream countingInputStream) {
            this(inputStream);
        }

        @Override // java.io.FilterInputStream, java.io.InputStream
        public int read() {
            int read = super.read();
            if (read != -1) {
                this.bytesRead++;
            }
            return read;
        }

        @Override // java.io.FilterInputStream, java.io.InputStream
        public int read(byte[] bArr, int i, int i2) {
            int read = super.read(bArr, i, i2);
            if (read != -1) {
                this.bytesRead += read;
            }
            return read;
        }
    }

    public DiskBasedCache(File file) {
        this(file, DEFAULT_DISK_USAGE_BYTES);
    }

    public DiskBasedCache(File file, int i) {
        this.mEntries = new LinkedHashMap(16, 0.75f, true);
        this.mTotalSize = 0;
        this.mRootDirectory = file;
        this.mMaxCacheSizeInBytes = i;
    }

    private String getFilenameForKey(String str) {
        int length = str.length() / 2;
        return String.valueOf(String.valueOf(str.substring(0, length).hashCode())) + String.valueOf(str.substring(length).hashCode());
    }

    private void pruneIfNeeded(int i) {
        int i2;
        if (this.mTotalSize + ((long) i) >= ((long) this.mMaxCacheSizeInBytes)) {
            if (VolleyLog.DEBUG) {
                VolleyLog.v("Pruning old cache entries.", new Object[0]);
            }
            long j = this.mTotalSize;
            long elapsedRealtime = SystemClock.elapsedRealtime();
            Iterator it = this.mEntries.entrySet().iterator();
            int i3 = 0;
            while (true) {
                if (it.hasNext()) {
                    CacheHeader cacheHeader = (CacheHeader) ((Map.Entry) it.next()).getValue();
                    if (getFileForKey(cacheHeader.key).delete()) {
                        this.mTotalSize -= cacheHeader.size;
                    } else {
                        VolleyLog.d("Could not delete cache entry for key=%s, filename=%s", cacheHeader.key, getFilenameForKey(cacheHeader.key));
                    }
                    it.remove();
                    i2 = i3 + 1;
                    if (((float) (this.mTotalSize + ((long) i))) < ((float) this.mMaxCacheSizeInBytes) * HYSTERESIS_FACTOR) {
                        break;
                    }
                    i3 = i2;
                } else {
                    i2 = i3;
                    break;
                }
            }
            if (VolleyLog.DEBUG) {
                VolleyLog.v("pruned %d files, %d bytes, %d ms", Integer.valueOf(i2), Long.valueOf(this.mTotalSize - j), Long.valueOf(SystemClock.elapsedRealtime() - elapsedRealtime));
            }
        }
    }

    private void putEntry(String str, CacheHeader cacheHeader) {
        if (!this.mEntries.containsKey(str)) {
            this.mTotalSize += cacheHeader.size;
        } else {
            this.mTotalSize = (cacheHeader.size - ((CacheHeader) this.mEntries.get(str)).size) + this.mTotalSize;
        }
        this.mEntries.put(str, cacheHeader);
    }

    private static int read(InputStream inputStream) {
        int read = inputStream.read();
        if (read != -1) {
            return read;
        }
        throw new EOFException();
    }

    static int readInt(InputStream inputStream) {
        return (read(inputStream) << 0) | 0 | (read(inputStream) << 8) | (read(inputStream) << 16) | (read(inputStream) << 24);
    }

    static long readLong(InputStream inputStream) {
        return 0 | ((((long) read(inputStream)) & 255) << 0) | ((((long) read(inputStream)) & 255) << 8) | ((((long) read(inputStream)) & 255) << 16) | ((((long) read(inputStream)) & 255) << 24) | ((((long) read(inputStream)) & 255) << 32) | ((((long) read(inputStream)) & 255) << 40) | ((((long) read(inputStream)) & 255) << 48) | ((((long) read(inputStream)) & 255) << 56);
    }

    static String readString(InputStream inputStream) {
        return new String(streamToBytes(inputStream, (int) readLong(inputStream)), "UTF-8");
    }

    static Map readStringStringMap(InputStream inputStream) {
        int readInt = readInt(inputStream);
        Map emptyMap = readInt == 0 ? Collections.emptyMap() : new HashMap(readInt);
        for (int i = 0; i < readInt; i++) {
            emptyMap.put(readString(inputStream).intern(), readString(inputStream).intern());
        }
        return emptyMap;
    }

    private void removeEntry(String str) {
        CacheHeader cacheHeader = (CacheHeader) this.mEntries.get(str);
        if (cacheHeader != null) {
            this.mTotalSize -= cacheHeader.size;
            this.mEntries.remove(str);
        }
    }

    private static byte[] streamToBytes(InputStream inputStream, int i) {
        byte[] bArr = new byte[i];
        int i2 = 0;
        while (i2 < i) {
            int read = inputStream.read(bArr, i2, i - i2);
            if (read == -1) {
                break;
            }
            i2 += read;
        }
        if (i2 == i) {
            return bArr;
        }
        throw new IOException("Expected " + i + " bytes, read " + i2 + " bytes");
    }

    static void writeInt(OutputStream outputStream, int i) {
        outputStream.write((i >> 0) & 255);
        outputStream.write((i >> 8) & 255);
        outputStream.write((i >> 16) & 255);
        outputStream.write((i >> 24) & 255);
    }

    static void writeLong(OutputStream outputStream, long j) {
        outputStream.write((byte) ((int) (j >>> 0)));
        outputStream.write((byte) ((int) (j >>> 8)));
        outputStream.write((byte) ((int) (j >>> 16)));
        outputStream.write((byte) ((int) (j >>> 24)));
        outputStream.write((byte) ((int) (j >>> 32)));
        outputStream.write((byte) ((int) (j >>> 40)));
        outputStream.write((byte) ((int) (j >>> 48)));
        outputStream.write((byte) ((int) (j >>> 56)));
    }

    static void writeString(OutputStream outputStream, String str) {
        byte[] bytes = str.getBytes("UTF-8");
        writeLong(outputStream, (long) bytes.length);
        outputStream.write(bytes, 0, bytes.length);
    }

    static void writeStringStringMap(Map map, OutputStream outputStream) {
        if (map != null) {
            writeInt(outputStream, map.size());
            for (Map.Entry entry : map.entrySet()) {
                writeString(outputStream, (String) entry.getKey());
                writeString(outputStream, (String) entry.getValue());
            }
            return;
        }
        writeInt(outputStream, 0);
    }

    @Override // com.android.volley.Cache
    public void clear() {
        synchronized (this) {
            File[] listFiles = this.mRootDirectory.listFiles();
            if (listFiles != null) {
                for (File file : listFiles) {
                    file.delete();
                }
            }
            this.mEntries.clear();
            this.mTotalSize = 0;
            VolleyLog.d("Cache cleared.", new Object[0]);
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:36:0x007f A[SYNTHETIC, Splitter:B:36:0x007f] */
    /* JADX WARNING: Removed duplicated region for block: B:44:0x008b A[SYNTHETIC, Splitter:B:44:0x008b] */
    @Override // com.android.volley.Cache
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public com.android.volley.Cache.Entry get(java.lang.String r9) {
        /*
            r8 = this;
            r1 = 0
            monitor-enter(r8)
            java.util.Map r0 = r8.mEntries     // Catch:{ all -> 0x008f }
            java.lang.Object r0 = r0.get(r9)     // Catch:{ all -> 0x008f }
            com.android.volley.toolbox.DiskBasedCache$CacheHeader r0 = (com.android.volley.toolbox.DiskBasedCache.CacheHeader) r0     // Catch:{ all -> 0x008f }
            if (r0 != 0) goto L_0x000f
            r0 = r1
        L_0x000d:
            monitor-exit(r8)
            return r0
        L_0x000f:
            java.io.File r3 = r8.getFileForKey(r9)     // Catch:{ all -> 0x008f }
            com.android.volley.toolbox.DiskBasedCache$CountingInputStream r2 = new com.android.volley.toolbox.DiskBasedCache$CountingInputStream     // Catch:{ IOException -> 0x003d, NegativeArraySizeException -> 0x0062, all -> 0x0087 }
            java.io.FileInputStream r4 = new java.io.FileInputStream     // Catch:{ IOException -> 0x003d, NegativeArraySizeException -> 0x0062, all -> 0x0087 }
            r4.<init>(r3)     // Catch:{ IOException -> 0x003d, NegativeArraySizeException -> 0x0062, all -> 0x0087 }
            r5 = 0
            r2.<init>(r4, r5)     // Catch:{ IOException -> 0x003d, NegativeArraySizeException -> 0x0062, all -> 0x0087 }
            com.android.volley.toolbox.DiskBasedCache.CacheHeader.readHeader(r2)     // Catch:{ IOException -> 0x0096, NegativeArraySizeException -> 0x0098 }
            long r4 = r3.length()     // Catch:{ IOException -> 0x0096, NegativeArraySizeException -> 0x0098 }
            int r6 = r2.bytesRead     // Catch:{ IOException -> 0x0096, NegativeArraySizeException -> 0x0098 }
            long r6 = (long) r6     // Catch:{ IOException -> 0x0096, NegativeArraySizeException -> 0x0098 }
            long r4 = r4 - r6
            int r4 = (int) r4     // Catch:{ IOException -> 0x0096, NegativeArraySizeException -> 0x0098 }
            byte[] r4 = streamToBytes(r2, r4)     // Catch:{ IOException -> 0x0096, NegativeArraySizeException -> 0x0098 }
            com.android.volley.Cache$Entry r0 = r0.toCacheEntry(r4)     // Catch:{ IOException -> 0x0096, NegativeArraySizeException -> 0x0098 }
            if (r2 == 0) goto L_0x000d
            r2.close()     // Catch:{ IOException -> 0x003a }
            goto L_0x000d
        L_0x003a:
            r0 = move-exception
            r0 = r1
            goto L_0x000d
        L_0x003d:
            r0 = move-exception
            r2 = r1
        L_0x003f:
            java.lang.String r4 = "%s: %s"
            r5 = 2
            java.lang.Object[] r5 = new java.lang.Object[r5]     // Catch:{ all -> 0x009a }
            r6 = 0
            java.lang.String r3 = r3.getAbsolutePath()     // Catch:{ all -> 0x009a }
            r5[r6] = r3     // Catch:{ all -> 0x009a }
            r3 = 1
            java.lang.String r0 = r0.toString()     // Catch:{ all -> 0x009a }
            r5[r3] = r0     // Catch:{ all -> 0x009a }
            com.android.volley.VolleyLog.d(r4, r5)     // Catch:{ all -> 0x009a }
            r8.remove(r9)     // Catch:{ all -> 0x009a }
            if (r2 == 0) goto L_0x005d
            r2.close()     // Catch:{ IOException -> 0x005f }
        L_0x005d:
            r0 = r1
            goto L_0x000d
        L_0x005f:
            r0 = move-exception
            r0 = r1
            goto L_0x000d
        L_0x0062:
            r0 = move-exception
            r2 = r1
        L_0x0064:
            java.lang.String r4 = "%s: %s"
            r5 = 2
            java.lang.Object[] r5 = new java.lang.Object[r5]     // Catch:{ all -> 0x009a }
            r6 = 0
            java.lang.String r3 = r3.getAbsolutePath()     // Catch:{ all -> 0x009a }
            r5[r6] = r3     // Catch:{ all -> 0x009a }
            r3 = 1
            java.lang.String r0 = r0.toString()     // Catch:{ all -> 0x009a }
            r5[r3] = r0     // Catch:{ all -> 0x009a }
            com.android.volley.VolleyLog.d(r4, r5)     // Catch:{ all -> 0x009a }
            r8.remove(r9)     // Catch:{ all -> 0x009a }
            if (r2 == 0) goto L_0x0082
            r2.close()     // Catch:{ IOException -> 0x0084 }
        L_0x0082:
            r0 = r1
            goto L_0x000d
        L_0x0084:
            r0 = move-exception
            r0 = r1
            goto L_0x000d
        L_0x0087:
            r0 = move-exception
            r2 = r1
        L_0x0089:
            if (r2 == 0) goto L_0x008e
            r2.close()     // Catch:{ IOException -> 0x0092 }
        L_0x008e:
            throw r0     // Catch:{ all -> 0x008f }
        L_0x008f:
            r0 = move-exception
            monitor-exit(r8)
            throw r0
        L_0x0092:
            r0 = move-exception
            r0 = r1
            goto L_0x000d
        L_0x0096:
            r0 = move-exception
            goto L_0x003f
        L_0x0098:
            r0 = move-exception
            goto L_0x0064
        L_0x009a:
            r0 = move-exception
            goto L_0x0089
        */
        throw new UnsupportedOperationException("Method not decompiled: com.android.volley.toolbox.DiskBasedCache.get(java.lang.String):com.android.volley.Cache$Entry");
    }

    public File getFileForKey(String str) {
        return new File(this.mRootDirectory, getFilenameForKey(str));
    }

    /* JADX WARNING: Removed duplicated region for block: B:27:0x0058 A[SYNTHETIC, Splitter:B:27:0x0058] */
    /* JADX WARNING: Removed duplicated region for block: B:30:0x005d A[SYNTHETIC, Splitter:B:30:0x005d] */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x0067 A[SYNTHETIC, Splitter:B:36:0x0067] */
    /* JADX WARNING: Removed duplicated region for block: B:50:0x0051 A[SYNTHETIC] */
    @Override // com.android.volley.Cache
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void initialize() {
        /*
            r10 = this;
            r2 = 0
            r0 = 0
            monitor-enter(r10)
            java.io.File r1 = r10.mRootDirectory     // Catch:{ all -> 0x006b }
            boolean r1 = r1.exists()     // Catch:{ all -> 0x006b }
            if (r1 != 0) goto L_0x0026
            java.io.File r0 = r10.mRootDirectory     // Catch:{ all -> 0x006b }
            boolean r0 = r0.mkdirs()     // Catch:{ all -> 0x006b }
            if (r0 != 0) goto L_0x0024
            java.lang.String r0 = "Unable to create cache dir %s"
            r1 = 1
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch:{ all -> 0x006b }
            r2 = 0
            java.io.File r3 = r10.mRootDirectory     // Catch:{ all -> 0x006b }
            java.lang.String r3 = r3.getAbsolutePath()     // Catch:{ all -> 0x006b }
            r1[r2] = r3     // Catch:{ all -> 0x006b }
            com.android.volley.VolleyLog.e(r0, r1)     // Catch:{ all -> 0x006b }
        L_0x0024:
            monitor-exit(r10)
            return
        L_0x0026:
            java.io.File r1 = r10.mRootDirectory     // Catch:{ all -> 0x006b }
            java.io.File[] r3 = r1.listFiles()     // Catch:{ all -> 0x006b }
            if (r3 == 0) goto L_0x0024
            int r4 = r3.length     // Catch:{ all -> 0x006b }
        L_0x002f:
            if (r0 >= r4) goto L_0x0024
            r5 = r3[r0]
            java.io.BufferedInputStream r1 = new java.io.BufferedInputStream     // Catch:{ IOException -> 0x0054, all -> 0x0074 }
            java.io.FileInputStream r6 = new java.io.FileInputStream     // Catch:{ IOException -> 0x0054, all -> 0x0074 }
            r6.<init>(r5)     // Catch:{ IOException -> 0x0054, all -> 0x0074 }
            r1.<init>(r6)     // Catch:{ IOException -> 0x0054, all -> 0x0074 }
            com.android.volley.toolbox.DiskBasedCache$CacheHeader r6 = com.android.volley.toolbox.DiskBasedCache.CacheHeader.readHeader(r1)     // Catch:{ IOException -> 0x0072 }
            long r8 = r5.length()     // Catch:{ IOException -> 0x0072 }
            r6.size = r8     // Catch:{ IOException -> 0x0072 }
            java.lang.String r7 = r6.key     // Catch:{ IOException -> 0x0072 }
            r10.putEntry(r7, r6)     // Catch:{ IOException -> 0x0072 }
            if (r1 == 0) goto L_0x0051
            r1.close()     // Catch:{ IOException -> 0x006e }
        L_0x0051:
            int r0 = r0 + 1
            goto L_0x002f
        L_0x0054:
            r1 = move-exception
            r1 = r2
        L_0x0056:
            if (r5 == 0) goto L_0x005b
            r5.delete()     // Catch:{ all -> 0x0063 }
        L_0x005b:
            if (r1 == 0) goto L_0x0051
            r1.close()     // Catch:{ IOException -> 0x0061 }
            goto L_0x0051
        L_0x0061:
            r1 = move-exception
            goto L_0x0051
        L_0x0063:
            r0 = move-exception
            r2 = r1
        L_0x0065:
            if (r2 == 0) goto L_0x006a
            r2.close()     // Catch:{ IOException -> 0x0070 }
        L_0x006a:
            throw r0     // Catch:{ all -> 0x006b }
        L_0x006b:
            r0 = move-exception
            monitor-exit(r10)
            throw r0
        L_0x006e:
            r1 = move-exception
            goto L_0x0051
        L_0x0070:
            r1 = move-exception
            goto L_0x006a
        L_0x0072:
            r6 = move-exception
            goto L_0x0056
        L_0x0074:
            r0 = move-exception
            goto L_0x0065
        */
        throw new UnsupportedOperationException("Method not decompiled: com.android.volley.toolbox.DiskBasedCache.initialize():void");
    }

    @Override // com.android.volley.Cache
    public void invalidate(String str, boolean z) {
        synchronized (this) {
            Cache.Entry entry = get(str);
            if (entry != null) {
                entry.softTtl = 0;
                if (z) {
                    entry.ttl = 0;
                }
                put(str, entry);
            }
        }
    }

    @Override // com.android.volley.Cache
    public void put(String str, Cache.Entry entry) {
        synchronized (this) {
            pruneIfNeeded(entry.data.length);
            File fileForKey = getFileForKey(str);
            try {
                FileOutputStream fileOutputStream = new FileOutputStream(fileForKey);
                CacheHeader cacheHeader = new CacheHeader(str, entry);
                if (!cacheHeader.writeHeader(fileOutputStream)) {
                    fileOutputStream.close();
                    VolleyLog.d("Failed to write header for %s", fileForKey.getAbsolutePath());
                    throw new IOException();
                }
                fileOutputStream.write(entry.data);
                fileOutputStream.close();
                putEntry(str, cacheHeader);
            } catch (IOException e) {
                if (!fileForKey.delete()) {
                    VolleyLog.d("Could not clean up file %s", fileForKey.getAbsolutePath());
                }
            }
        }
    }

    @Override // com.android.volley.Cache
    public void remove(String str) {
        synchronized (this) {
            boolean delete = getFileForKey(str).delete();
            removeEntry(str);
            if (!delete) {
                VolleyLog.d("Could not delete cache entry for key=%s, filename=%s", str, getFilenameForKey(str));
            }
        }
    }
}
