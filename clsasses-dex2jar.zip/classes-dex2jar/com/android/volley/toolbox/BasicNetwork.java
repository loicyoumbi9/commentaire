package com.android.volley.toolbox;

import android.os.SystemClock;
import com.alimama.mobile.csdk.umupdate.a.f;
import com.android.volley.Cache;
import com.android.volley.Network;
import com.android.volley.Request;
import com.android.volley.RetryPolicy;
import com.android.volley.ServerError;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.google.android.gms.games.GamesStatusCodes;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.Map;
import java.util.TreeMap;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.StatusLine;
import org.apache.http.impl.cookie.DateUtils;

public class BasicNetwork implements Network {
    protected static final boolean DEBUG = VolleyLog.DEBUG;
    private static int DEFAULT_POOL_SIZE = 4096;
    private static int SLOW_REQUEST_THRESHOLD_MS = GamesStatusCodes.STATUS_ACHIEVEMENT_UNLOCK_FAILURE;
    protected final HttpStack mHttpStack;
    protected final ByteArrayPool mPool;

    public BasicNetwork(HttpStack httpStack) {
        this(httpStack, new ByteArrayPool(DEFAULT_POOL_SIZE));
    }

    public BasicNetwork(HttpStack httpStack, ByteArrayPool byteArrayPool) {
        this.mHttpStack = httpStack;
        this.mPool = byteArrayPool;
    }

    private void addCacheHeaders(Map map, Cache.Entry entry) {
        if (entry != null) {
            if (entry.etag != null) {
                map.put("If-None-Match", entry.etag);
            }
            if (entry.lastModified > 0) {
                map.put("If-Modified-Since", DateUtils.formatDate(new Date(entry.lastModified)));
            }
        }
    }

    private static void attemptRetryOnException(String str, Request request, VolleyError volleyError) {
        RetryPolicy retryPolicy = request.getRetryPolicy();
        int timeoutMs = request.getTimeoutMs();
        try {
            retryPolicy.retry(volleyError);
            request.addMarker(String.format("%s-retry [timeout=%s]", str, Integer.valueOf(timeoutMs)));
        } catch (VolleyError e) {
            request.addMarker(String.format("%s-timeout-giveup [timeout=%s]", str, Integer.valueOf(timeoutMs)));
            throw e;
        }
    }

    protected static Map convertHeaders(Header[] headerArr) {
        TreeMap treeMap = new TreeMap(String.CASE_INSENSITIVE_ORDER);
        for (int i = 0; i < headerArr.length; i++) {
            treeMap.put(headerArr[i].getName(), headerArr[i].getValue());
        }
        return treeMap;
    }

    private byte[] entityToBytes(HttpEntity httpEntity) {
        PoolingByteArrayOutputStream poolingByteArrayOutputStream = new PoolingByteArrayOutputStream(this.mPool, (int) httpEntity.getContentLength());
        byte[] bArr = null;
        try {
            InputStream content = httpEntity.getContent();
            if (content == null) {
                throw new ServerError();
            }
            bArr = this.mPool.getBuf(1024);
            while (true) {
                int read = content.read(bArr);
                if (read == -1) {
                    break;
                }
                poolingByteArrayOutputStream.write(bArr, 0, read);
            }
            byte[] byteArray = poolingByteArrayOutputStream.toByteArray();
            try {
            } catch (IOException e) {
                VolleyLog.v("Error occured when calling consumingContent", new Object[0]);
            }
            return byteArray;
        } finally {
            try {
                httpEntity.consumeContent();
            } catch (IOException e2) {
                VolleyLog.v("Error occured when calling consumingContent", new Object[0]);
            }
            this.mPool.returnBuf(bArr);
            poolingByteArrayOutputStream.close();
        }
    }

    private void logSlowRequests(long j, Request request, byte[] bArr, StatusLine statusLine) {
        if (DEBUG || j > ((long) SLOW_REQUEST_THRESHOLD_MS)) {
            VolleyLog.d("HTTP response for request=<%s> [lifetime=%d], [size=%s], [rc=%d], [retryCount=%s]", request, Long.valueOf(j), bArr != null ? Integer.valueOf(bArr.length) : f.b, Integer.valueOf(statusLine.getStatusCode()), Integer.valueOf(request.getRetryPolicy().getCurrentRetryCount()));
        }
    }

    /* access modifiers changed from: protected */
    public void logError(String str, String str2, long j) {
        VolleyLog.v("HTTP ERROR(%s) %d ms to fetch %s", str, Long.valueOf(SystemClock.elapsedRealtime() - j), str2);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:27:0x00a5, code lost:
        attemptRetryOnException("socket", r19, new com.android.volley.TimeoutError());
     */
    /* JADX WARNING: Code restructure failed: missing block: B:34:0x00c6, code lost:
        attemptRetryOnException("connection", r19, new com.android.volley.TimeoutError());
     */
    /* JADX WARNING: Code restructure failed: missing block: B:35:0x00d4, code lost:
        r2 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:37:0x00ed, code lost:
        throw new java.lang.RuntimeException("Bad URL " + r19.getUrl(), r2);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:38:0x00ee, code lost:
        r2 = e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:39:0x00ef, code lost:
        r5 = null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:41:0x00f2, code lost:
        r4 = r3.getStatusLine().getStatusCode();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:42:0x00fc, code lost:
        if (r4 == 301) goto L_0x0102;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:45:0x0102, code lost:
        com.android.volley.VolleyLog.e("Request at %s has been redirected to %s", r19.getOriginUrl(), r19.getUrl());
     */
    /* JADX WARNING: Code restructure failed: missing block: B:46:0x0118, code lost:
        if (r5 != null) goto L_0x011a;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:47:0x011a, code lost:
        r3 = new com.android.volley.NetworkResponse(r4, r5, r6, false, android.os.SystemClock.elapsedRealtime() - r16);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:48:0x0128, code lost:
        if (r4 == 401) goto L_0x012e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:51:0x012e, code lost:
        attemptRetryOnException("auth", r19, new com.android.volley.AuthFailureError(r3));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:53:0x0141, code lost:
        throw new com.android.volley.NoConnectionError(r2);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:54:0x0142, code lost:
        com.android.volley.VolleyLog.e("Unexpected response code %d for %s", java.lang.Integer.valueOf(r4), r19.getUrl());
     */
    /* JADX WARNING: Code restructure failed: missing block: B:56:0x015b, code lost:
        if (r4 == 301) goto L_0x0161;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:59:0x0161, code lost:
        attemptRetryOnException("redirect", r19, new com.android.volley.AuthFailureError(r3));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:61:0x0174, code lost:
        throw new com.android.volley.ServerError(r3);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:63:0x017b, code lost:
        throw new com.android.volley.NetworkError((com.android.volley.NetworkResponse) null);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:64:0x017c, code lost:
        r2 = e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:65:0x017d, code lost:
        r5 = null;
        r3 = r14;
     */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Removed duplicated region for block: B:26:0x00a4 A[ExcHandler: SocketTimeoutException (e java.net.SocketTimeoutException), Splitter:B:2:0x0009] */
    /* JADX WARNING: Removed duplicated region for block: B:33:0x00c5 A[ExcHandler: ConnectTimeoutException (e org.apache.http.conn.ConnectTimeoutException), Splitter:B:2:0x0009] */
    /* JADX WARNING: Removed duplicated region for block: B:35:0x00d4 A[ExcHandler: MalformedURLException (r2v15 'e' java.net.MalformedURLException A[CUSTOM_DECLARE]), Splitter:B:2:0x0009] */
    /* JADX WARNING: Removed duplicated region for block: B:41:0x00f2  */
    /* JADX WARNING: Removed duplicated region for block: B:75:0x013c A[SYNTHETIC] */
    @Override // com.android.volley.Network
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public com.android.volley.NetworkResponse performRequest(com.android.volley.Request r19) {
        /*
            r18 = this;
            long r16 = android.os.SystemClock.elapsedRealtime()
        L_0x0004:
            r3 = 0
            java.util.Map r6 = java.util.Collections.emptyMap()
            java.util.HashMap r2 = new java.util.HashMap     // Catch:{ SocketTimeoutException -> 0x00a4, ConnectTimeoutException -> 0x00c5, MalformedURLException -> 0x00d4, IOException -> 0x00ee }
            r2.<init>()     // Catch:{ SocketTimeoutException -> 0x00a4, ConnectTimeoutException -> 0x00c5, MalformedURLException -> 0x00d4, IOException -> 0x00ee }
            com.android.volley.Cache$Entry r4 = r19.getCacheEntry()     // Catch:{ SocketTimeoutException -> 0x00a4, ConnectTimeoutException -> 0x00c5, MalformedURLException -> 0x00d4, IOException -> 0x00ee }
            r0 = r18
            r0.addCacheHeaders(r2, r4)     // Catch:{ SocketTimeoutException -> 0x00a4, ConnectTimeoutException -> 0x00c5, MalformedURLException -> 0x00d4, IOException -> 0x00ee }
            r0 = r18
            com.android.volley.toolbox.HttpStack r4 = r0.mHttpStack     // Catch:{ SocketTimeoutException -> 0x00a4, ConnectTimeoutException -> 0x00c5, MalformedURLException -> 0x00d4, IOException -> 0x00ee }
            r0 = r19
            org.apache.http.HttpResponse r14 = r4.performRequest(r0, r2)     // Catch:{ SocketTimeoutException -> 0x00a4, ConnectTimeoutException -> 0x00c5, MalformedURLException -> 0x00d4, IOException -> 0x00ee }
            org.apache.http.StatusLine r12 = r14.getStatusLine()     // Catch:{ SocketTimeoutException -> 0x00a4, ConnectTimeoutException -> 0x00c5, MalformedURLException -> 0x00d4, IOException -> 0x017c }
            int r4 = r12.getStatusCode()     // Catch:{ SocketTimeoutException -> 0x00a4, ConnectTimeoutException -> 0x00c5, MalformedURLException -> 0x00d4, IOException -> 0x017c }
            org.apache.http.Header[] r2 = r14.getAllHeaders()     // Catch:{ SocketTimeoutException -> 0x00a4, ConnectTimeoutException -> 0x00c5, MalformedURLException -> 0x00d4, IOException -> 0x017c }
            java.util.Map r6 = convertHeaders(r2)     // Catch:{ SocketTimeoutException -> 0x00a4, ConnectTimeoutException -> 0x00c5, MalformedURLException -> 0x00d4, IOException -> 0x017c }
            r2 = 304(0x130, float:4.26E-43)
            if (r4 != r2) goto L_0x0064
            com.android.volley.Cache$Entry r2 = r19.getCacheEntry()     // Catch:{ SocketTimeoutException -> 0x00a4, ConnectTimeoutException -> 0x00c5, MalformedURLException -> 0x00d4, IOException -> 0x017c }
            if (r2 != 0) goto L_0x004b
            com.android.volley.NetworkResponse r3 = new com.android.volley.NetworkResponse     // Catch:{ SocketTimeoutException -> 0x00a4, ConnectTimeoutException -> 0x00c5, MalformedURLException -> 0x00d4, IOException -> 0x017c }
            r4 = 304(0x130, float:4.26E-43)
            r5 = 0
            r7 = 1
            long r8 = android.os.SystemClock.elapsedRealtime()     // Catch:{ SocketTimeoutException -> 0x00a4, ConnectTimeoutException -> 0x00c5, MalformedURLException -> 0x00d4, IOException -> 0x017c }
            long r8 = r8 - r16
            r3.<init>(r4, r5, r6, r7, r8)     // Catch:{ SocketTimeoutException -> 0x00a4, ConnectTimeoutException -> 0x00c5, MalformedURLException -> 0x00d4, IOException -> 0x017c }
        L_0x004a:
            return r3
        L_0x004b:
            java.util.Map r3 = r2.responseHeaders     // Catch:{ SocketTimeoutException -> 0x00a4, ConnectTimeoutException -> 0x00c5, MalformedURLException -> 0x00d4, IOException -> 0x017c }
            r3.putAll(r6)     // Catch:{ SocketTimeoutException -> 0x00a4, ConnectTimeoutException -> 0x00c5, MalformedURLException -> 0x00d4, IOException -> 0x017c }
            com.android.volley.NetworkResponse r7 = new com.android.volley.NetworkResponse     // Catch:{ SocketTimeoutException -> 0x00a4, ConnectTimeoutException -> 0x00c5, MalformedURLException -> 0x00d4, IOException -> 0x017c }
            r8 = 304(0x130, float:4.26E-43)
            byte[] r9 = r2.data     // Catch:{ SocketTimeoutException -> 0x00a4, ConnectTimeoutException -> 0x00c5, MalformedURLException -> 0x00d4, IOException -> 0x017c }
            java.util.Map r10 = r2.responseHeaders     // Catch:{ SocketTimeoutException -> 0x00a4, ConnectTimeoutException -> 0x00c5, MalformedURLException -> 0x00d4, IOException -> 0x017c }
            r11 = 1
            long r2 = android.os.SystemClock.elapsedRealtime()     // Catch:{ SocketTimeoutException -> 0x00a4, ConnectTimeoutException -> 0x00c5, MalformedURLException -> 0x00d4, IOException -> 0x017c }
            long r12 = r2 - r16
            r7.<init>(r8, r9, r10, r11, r12)     // Catch:{ SocketTimeoutException -> 0x00a4, ConnectTimeoutException -> 0x00c5, MalformedURLException -> 0x00d4, IOException -> 0x017c }
            r3 = r7
            goto L_0x004a
        L_0x0064:
            r2 = 301(0x12d, float:4.22E-43)
            if (r4 == r2) goto L_0x006c
            r2 = 302(0x12e, float:4.23E-43)
            if (r4 != r2) goto L_0x0079
        L_0x006c:
            java.lang.String r2 = "Location"
            java.lang.Object r2 = r6.get(r2)     // Catch:{ SocketTimeoutException -> 0x00a4, ConnectTimeoutException -> 0x00c5, MalformedURLException -> 0x00d4, IOException -> 0x017c }
            java.lang.String r2 = (java.lang.String) r2     // Catch:{ SocketTimeoutException -> 0x00a4, ConnectTimeoutException -> 0x00c5, MalformedURLException -> 0x00d4, IOException -> 0x017c }
            r0 = r19
            r0.setRedirectUrl(r2)     // Catch:{ SocketTimeoutException -> 0x00a4, ConnectTimeoutException -> 0x00c5, MalformedURLException -> 0x00d4, IOException -> 0x017c }
        L_0x0079:
            org.apache.http.HttpEntity r2 = r14.getEntity()     // Catch:{ SocketTimeoutException -> 0x00a4, ConnectTimeoutException -> 0x00c5, MalformedURLException -> 0x00d4, IOException -> 0x017c }
            if (r2 == 0) goto L_0x00b3
            org.apache.http.HttpEntity r2 = r14.getEntity()     // Catch:{ SocketTimeoutException -> 0x00a4, ConnectTimeoutException -> 0x00c5, MalformedURLException -> 0x00d4, IOException -> 0x017c }
            r0 = r18
            byte[] r11 = r0.entityToBytes(r2)     // Catch:{ SocketTimeoutException -> 0x00a4, ConnectTimeoutException -> 0x00c5, MalformedURLException -> 0x00d4, IOException -> 0x017c }
        L_0x0089:
            long r2 = android.os.SystemClock.elapsedRealtime()     // Catch:{ SocketTimeoutException -> 0x00a4, ConnectTimeoutException -> 0x00c5, MalformedURLException -> 0x00d4, IOException -> 0x0181 }
            long r8 = r2 - r16
            r7 = r18
            r10 = r19
            r7.logSlowRequests(r8, r10, r11, r12)     // Catch:{ SocketTimeoutException -> 0x00a4, ConnectTimeoutException -> 0x00c5, MalformedURLException -> 0x00d4, IOException -> 0x0181 }
            r2 = 200(0xc8, float:2.8E-43)
            if (r4 < r2) goto L_0x009e
            r2 = 299(0x12b, float:4.19E-43)
            if (r4 <= r2) goto L_0x00b7
        L_0x009e:
            java.io.IOException r2 = new java.io.IOException     // Catch:{ SocketTimeoutException -> 0x00a4, ConnectTimeoutException -> 0x00c5, MalformedURLException -> 0x00d4, IOException -> 0x0181 }
            r2.<init>()     // Catch:{ SocketTimeoutException -> 0x00a4, ConnectTimeoutException -> 0x00c5, MalformedURLException -> 0x00d4, IOException -> 0x0181 }
            throw r2     // Catch:{ SocketTimeoutException -> 0x00a4, ConnectTimeoutException -> 0x00c5, MalformedURLException -> 0x00d4, IOException -> 0x0181 }
        L_0x00a4:
            r2 = move-exception
            java.lang.String r2 = "socket"
            com.android.volley.TimeoutError r3 = new com.android.volley.TimeoutError
            r3.<init>()
            r0 = r19
            attemptRetryOnException(r2, r0, r3)
            goto L_0x0004
        L_0x00b3:
            r2 = 0
            byte[] r11 = new byte[r2]     // Catch:{ SocketTimeoutException -> 0x00a4, ConnectTimeoutException -> 0x00c5, MalformedURLException -> 0x00d4, IOException -> 0x017c }
            goto L_0x0089
        L_0x00b7:
            com.android.volley.NetworkResponse r3 = new com.android.volley.NetworkResponse     // Catch:{ SocketTimeoutException -> 0x00a4, ConnectTimeoutException -> 0x00c5, MalformedURLException -> 0x00d4, IOException -> 0x0181 }
            r7 = 0
            long r8 = android.os.SystemClock.elapsedRealtime()     // Catch:{ SocketTimeoutException -> 0x00a4, ConnectTimeoutException -> 0x00c5, MalformedURLException -> 0x00d4, IOException -> 0x0181 }
            long r8 = r8 - r16
            r5 = r11
            r3.<init>(r4, r5, r6, r7, r8)     // Catch:{ SocketTimeoutException -> 0x00a4, ConnectTimeoutException -> 0x00c5, MalformedURLException -> 0x00d4, IOException -> 0x0181 }
            goto L_0x004a
        L_0x00c5:
            r2 = move-exception
            java.lang.String r2 = "connection"
            com.android.volley.TimeoutError r3 = new com.android.volley.TimeoutError
            r3.<init>()
            r0 = r19
            attemptRetryOnException(r2, r0, r3)
            goto L_0x0004
        L_0x00d4:
            r2 = move-exception
            java.lang.RuntimeException r3 = new java.lang.RuntimeException
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            java.lang.String r5 = "Bad URL "
            r4.<init>(r5)
            java.lang.String r5 = r19.getUrl()
            java.lang.StringBuilder r4 = r4.append(r5)
            java.lang.String r4 = r4.toString()
            r3.<init>(r4, r2)
            throw r3
        L_0x00ee:
            r2 = move-exception
            r5 = 0
        L_0x00f0:
            if (r3 == 0) goto L_0x013c
            org.apache.http.StatusLine r2 = r3.getStatusLine()
            int r4 = r2.getStatusCode()
            r2 = 301(0x12d, float:4.22E-43)
            if (r4 == r2) goto L_0x0102
            r2 = 302(0x12e, float:4.23E-43)
            if (r4 != r2) goto L_0x0142
        L_0x0102:
            java.lang.String r2 = "Request at %s has been redirected to %s"
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r7 = 0
            java.lang.String r8 = r19.getOriginUrl()
            r3[r7] = r8
            r7 = 1
            java.lang.String r8 = r19.getUrl()
            r3[r7] = r8
            com.android.volley.VolleyLog.e(r2, r3)
        L_0x0118:
            if (r5 == 0) goto L_0x0175
            com.android.volley.NetworkResponse r3 = new com.android.volley.NetworkResponse
            r7 = 0
            long r8 = android.os.SystemClock.elapsedRealtime()
            long r8 = r8 - r16
            r3.<init>(r4, r5, r6, r7, r8)
            r2 = 401(0x191, float:5.62E-43)
            if (r4 == r2) goto L_0x012e
            r2 = 403(0x193, float:5.65E-43)
            if (r4 != r2) goto L_0x0159
        L_0x012e:
            java.lang.String r2 = "auth"
            com.android.volley.AuthFailureError r4 = new com.android.volley.AuthFailureError
            r4.<init>(r3)
            r0 = r19
            attemptRetryOnException(r2, r0, r4)
            goto L_0x0004
        L_0x013c:
            com.android.volley.NoConnectionError r3 = new com.android.volley.NoConnectionError
            r3.<init>(r2)
            throw r3
        L_0x0142:
            java.lang.String r2 = "Unexpected response code %d for %s"
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r7 = 0
            java.lang.Integer r8 = java.lang.Integer.valueOf(r4)
            r3[r7] = r8
            r7 = 1
            java.lang.String r8 = r19.getUrl()
            r3[r7] = r8
            com.android.volley.VolleyLog.e(r2, r3)
            goto L_0x0118
        L_0x0159:
            r2 = 301(0x12d, float:4.22E-43)
            if (r4 == r2) goto L_0x0161
            r2 = 302(0x12e, float:4.23E-43)
            if (r4 != r2) goto L_0x016f
        L_0x0161:
            java.lang.String r2 = "redirect"
            com.android.volley.AuthFailureError r4 = new com.android.volley.AuthFailureError
            r4.<init>(r3)
            r0 = r19
            attemptRetryOnException(r2, r0, r4)
            goto L_0x0004
        L_0x016f:
            com.android.volley.ServerError r2 = new com.android.volley.ServerError
            r2.<init>(r3)
            throw r2
        L_0x0175:
            com.android.volley.NetworkError r2 = new com.android.volley.NetworkError
            r3 = 0
            r2.<init>(r3)
            throw r2
        L_0x017c:
            r2 = move-exception
            r5 = 0
            r3 = r14
            goto L_0x00f0
        L_0x0181:
            r2 = move-exception
            r5 = r11
            r3 = r14
            goto L_0x00f0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.android.volley.toolbox.BasicNetwork.performRequest(com.android.volley.Request):com.android.volley.NetworkResponse");
    }
}
