package com.android.volley.toolbox;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public class RequestFuture implements Response.ErrorListener, Response.Listener, Future {
    private VolleyError mException;
    private Request mRequest;
    private Object mResult;
    private boolean mResultReceived = false;

    private RequestFuture() {
    }

    private Object doGet(Long l) {
        Object obj;
        synchronized (this) {
            if (this.mException != null) {
                throw new ExecutionException(this.mException);
            } else if (this.mResultReceived) {
                obj = this.mResult;
            } else {
                if (l == null) {
                    wait(0);
                } else if (l.longValue() > 0) {
                    wait(l.longValue());
                }
                if (this.mException != null) {
                    throw new ExecutionException(this.mException);
                } else if (!this.mResultReceived) {
                    throw new TimeoutException();
                } else {
                    obj = this.mResult;
                }
            }
        }
        return obj;
    }

    public static RequestFuture newFuture() {
        return new RequestFuture();
    }

    public boolean cancel(boolean z) {
        boolean z2 = false;
        synchronized (this) {
            if (this.mRequest != null) {
                if (!isDone()) {
                    this.mRequest.cancel();
                    z2 = true;
                }
            }
        }
        return z2;
    }

    @Override // java.util.concurrent.Future
    public Object get() {
        try {
            return doGet(null);
        } catch (TimeoutException e) {
            throw new AssertionError(e);
        }
    }

    @Override // java.util.concurrent.Future
    public Object get(long j, TimeUnit timeUnit) {
        return doGet(Long.valueOf(TimeUnit.MILLISECONDS.convert(j, timeUnit)));
    }

    public boolean isCancelled() {
        if (this.mRequest == null) {
            return false;
        }
        return this.mRequest.isCanceled();
    }

    public boolean isDone() {
        boolean z;
        synchronized (this) {
            z = this.mResultReceived || this.mException != null || isCancelled();
        }
        return z;
    }

    @Override // com.android.volley.Response.ErrorListener
    public void onErrorResponse(VolleyError volleyError) {
        synchronized (this) {
            this.mException = volleyError;
            notifyAll();
        }
    }

    @Override // com.android.volley.Response.Listener
    public void onResponse(Object obj) {
        synchronized (this) {
            this.mResultReceived = true;
            this.mResult = obj;
            notifyAll();
        }
    }

    public void setRequest(Request request) {
        this.mRequest = request;
    }
}
