package u.aly;

import android.content.Context;

public class bz {
    public static int a(Context context) {
        return bs.a(context).b("umeng_common_progress_text");
    }

    public static int b(Context context) {
        return bs.a(context).b("umeng_common_icon_view");
    }

    public static int c(Context context) {
        return bs.a(context).b("umeng_common_progress_bar");
    }

    public static int d(Context context) {
        return bs.a(context).b("umeng_common_title");
    }

    public static int e(Context context) {
        return bs.a(context).b("umeng_common_rich_notification_continue");
    }

    public static int f(Context context) {
        return bs.a(context).b("umeng_common_rich_notification_pause");
    }

    public static int g(Context context) {
        return bs.a(context).b("umeng_common_rich_notification_cancel");
    }
}
