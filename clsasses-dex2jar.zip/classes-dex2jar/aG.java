package com.ironsource.mobilcore;

import android.annotation.SuppressLint;
import android.util.Pair;
import android.webkit.ConsoleMessage;
import android.webkit.JsPromptResult;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import com.android.common.speech.LoggingEvents;
import com.ironsource.mobilcore.aS;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import org.json.JSONArray;
import org.json.JSONObject;

class aG extends WebChromeClient {
    private WebView a;
    private a b;
    private b c;

    public interface a {
    }

    private final class b extends ArrayList {
        private static final long serialVersionUID = 1;

        private b() {
        }

        /* synthetic */ b(aG aGVar, byte b) {
            this();
        }

        public final void a(Collection collection) {
            Iterator it = collection.iterator();
            while (it.hasNext()) {
                Method method = (Method) it.next();
                ArrayList arrayList = new ArrayList();
                for (Class<?> cls : method.getParameterTypes()) {
                    arrayList.add(cls.getName());
                }
                add(new Pair(method, arrayList));
            }
        }
    }

    public aG(WebView webView) {
        this.a = webView;
    }

    public aG(WebView webView, a aVar) {
        this.a = webView;
        a(aVar);
    }

    public final void a(a aVar) {
        this.b = aVar;
        this.c = new b(this, (byte) 0);
        this.c.a(Arrays.asList(this.b.getClass().getMethods()));
    }

    public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
        if (consoleMessage.messageLevel() == ConsoleMessage.MessageLevel.ERROR) {
            aK.a(aS.b.REPORT_TYPE_ERROR).b("JS error: " + consoleMessage.message() + " -- from line " + consoleMessage.lineNumber() + " in " + consoleMessage.sourceId()).a();
        }
        return super.onConsoleMessage(consoleMessage);
    }

    @SuppressLint({"NewApi"})
    public boolean onJsPrompt(WebView webView, String str, String str2, String str3, JsPromptResult jsPromptResult) {
        Method method;
        jsPromptResult.confirm();
        int i = 0;
        while (true) {
            try {
                if (i >= this.c.size()) {
                    method = null;
                    break;
                } else if (str2.equals(((Method) ((Pair) this.c.get(i)).first).getName())) {
                    method = (Method) ((Pair) this.c.get(i)).first;
                    break;
                } else {
                    i++;
                }
            } catch (Exception e) {
                String str4 = "JSBridge Error: " + e.getLocalizedMessage() + " (Method: " + str2 + ", params: " + str3 + ")";
                B.a(str4, 2);
                aK.a(aS.b.REPORT_TYPE_ERROR).b(str4).a();
                return true;
            }
        }
        JSONObject jSONObject = new JSONObject(str3);
        JSONObject optJSONObject = jSONObject.optJSONObject("callback");
        JSONArray optJSONArray = jSONObject.optJSONArray("params");
        Object[] objArr = new Object[optJSONArray.length()];
        for (int i2 = 0; i2 < optJSONArray.length(); i2++) {
            objArr[i2] = optJSONArray.opt(i2);
        }
        if (method == null) {
            return true;
        }
        Object invoke = method.invoke(this.b, objArr);
        if (optJSONObject == null) {
            return true;
        }
        String optString = optJSONObject.optString(LoggingEvents.VoiceIme.EXTRA_START_METHOD);
        String str5 = "";
        if (invoke != null) {
            str5 = invoke.toString();
        }
        String str6 = optString + "(" + str5 + ");";
        B.a("javascript:" + str6, 55);
        aF.a(this.a, str6);
        return true;
    }
}
