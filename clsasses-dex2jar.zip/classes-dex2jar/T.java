package com.ironsource.mobilcore;

import android.content.Context;
import android.view.KeyEvent;
import android.widget.LinearLayout;

final class T extends LinearLayout {
    private a a;

    public interface a {
        boolean a();
    }

    public T(Context context, a aVar) {
        super(context);
        this.a = aVar;
    }

    public final boolean dispatchKeyEvent(KeyEvent keyEvent) {
        return (keyEvent.getKeyCode() != 4 || this.a == null) ? super.dispatchKeyEvent(keyEvent) : this.a.a();
    }
}
