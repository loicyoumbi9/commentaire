package u.aly;

public class ce {
    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: u.aly.ce.a(int, int, boolean):int
     arg types: [byte, int, boolean]
     candidates:
      u.aly.ce.a(byte, int, boolean):byte
      u.aly.ce.a(long, int, boolean):long
      u.aly.ce.a(short, int, boolean):short
      u.aly.ce.a(int, byte[], int):void
      u.aly.ce.a(int, int, boolean):int */
    public static final byte a(byte b, int i, boolean z) {
        return (byte) a((int) b, i, z);
    }

    public static final int a(int i, int i2, boolean z) {
        return z ? (1 << i2) | i : b(i, i2);
    }

    public static final int a(byte[] bArr) {
        return a(bArr, 0);
    }

    public static final int a(byte[] bArr, int i) {
        return ((bArr[i] & 255) << 24) | ((bArr[i + 1] & 255) << dn.n) | ((bArr[i + 2] & 255) << 8) | (bArr[i + 3] & 255);
    }

    public static final long a(long j, int i, boolean z) {
        return z ? (1 << i) | j : b(j, i);
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: u.aly.ce.a(int, int, boolean):int
     arg types: [short, int, boolean]
     candidates:
      u.aly.ce.a(byte, int, boolean):byte
      u.aly.ce.a(long, int, boolean):long
      u.aly.ce.a(short, int, boolean):short
      u.aly.ce.a(int, byte[], int):void
      u.aly.ce.a(int, int, boolean):int */
    public static final short a(short s, int i, boolean z) {
        return (short) a((int) s, i, z);
    }

    public static final void a(int i, byte[] bArr) {
        a(i, bArr, 0);
    }

    public static final void a(int i, byte[] bArr, int i2) {
        bArr[i2] = (byte) ((i >> 24) & 255);
        bArr[i2 + 1] = (byte) ((i >> 16) & 255);
        bArr[i2 + 2] = (byte) ((i >> 8) & 255);
        bArr[i2 + 3] = (byte) (i & 255);
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: u.aly.ce.a(int, int):boolean
     arg types: [byte, int]
     candidates:
      u.aly.ce.a(byte[], int):int
      u.aly.ce.a(int, byte[]):void
      u.aly.ce.a(byte, int):boolean
      u.aly.ce.a(long, int):boolean
      u.aly.ce.a(short, int):boolean
      u.aly.ce.a(int, int):boolean */
    public static final boolean a(byte b, int i) {
        return a((int) b, i);
    }

    public static final boolean a(int i, int i2) {
        return ((1 << i2) & i) != 0;
    }

    public static final boolean a(long j, int i) {
        return ((1 << i) & j) != 0;
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: u.aly.ce.a(int, int):boolean
     arg types: [short, int]
     candidates:
      u.aly.ce.a(byte[], int):int
      u.aly.ce.a(int, byte[]):void
      u.aly.ce.a(byte, int):boolean
      u.aly.ce.a(long, int):boolean
      u.aly.ce.a(short, int):boolean
      u.aly.ce.a(int, int):boolean */
    public static final boolean a(short s, int i) {
        return a((int) s, i);
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: u.aly.ce.b(int, int):int
     arg types: [byte, int]
     candidates:
      u.aly.ce.b(byte, int):byte
      u.aly.ce.b(long, int):long
      u.aly.ce.b(short, int):short
      u.aly.ce.b(int, int):int */
    public static final byte b(byte b, int i) {
        return (byte) b((int) b, i);
    }

    public static final int b(int i, int i2) {
        return ((1 << i2) ^ -1) & i;
    }

    public static final long b(long j, int i) {
        return ((1 << i) ^ -1) & j;
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: u.aly.ce.b(int, int):int
     arg types: [short, int]
     candidates:
      u.aly.ce.b(byte, int):byte
      u.aly.ce.b(long, int):long
      u.aly.ce.b(short, int):short
      u.aly.ce.b(int, int):int */
    public static final short b(short s, int i) {
        return (short) b((int) s, i);
    }
}
