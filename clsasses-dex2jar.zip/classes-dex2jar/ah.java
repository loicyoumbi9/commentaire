package u.aly;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class ah extends av implements q {
    public ah(String str, Map<String, Object> map) {
        a(str);
        b(System.currentTimeMillis());
        if (map.size() > 0) {
            a(b(map));
        }
        a(this.d > 0 ? this.d : 1);
    }

    private HashMap<String, bh> b(Map<String, Object> map) {
        Iterator<Map.Entry<String, Object>> it = map.entrySet().iterator();
        HashMap<String, bh> hashMap = new HashMap<>();
        int i = 0;
        while (i < 10 && it.hasNext()) {
            Map.Entry<String, Object> next = it.next();
            bh bhVar = new bh();
            Object value = next.getValue();
            if (value instanceof String) {
                bhVar.b((String) value);
            } else if (value instanceof Long) {
                bhVar.b(((Long) value).longValue());
            } else if (value instanceof Integer) {
                bhVar.b(((Integer) value).longValue());
            } else if (value instanceof Float) {
                bhVar.b(((Float) value).longValue());
            } else if (value instanceof Double) {
                bhVar.b(((Double) value).longValue());
            }
            if (bhVar.k()) {
                hashMap.put(next.getKey(), bhVar);
                i++;
            }
        }
        return hashMap;
    }

    @Override // u.aly.q
    public void a(bn bnVar, String str) {
        bc bcVar;
        if (bnVar.s() > 0) {
            Iterator<bc> it = bnVar.u().iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                bcVar = it.next();
                if (str.equals(bcVar.c())) {
                    break;
                }
            }
        }
        bcVar = null;
        if (bcVar == null) {
            bcVar = new bc();
            bcVar.a(str);
            bnVar.a(bcVar);
        }
        bcVar.b(this);
    }
}
