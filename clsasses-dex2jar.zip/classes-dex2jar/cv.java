package u.aly;

public class cv extends cu {
    public final cu a;

    public cv(byte b, cu cuVar) {
        super(b);
        this.a = cuVar;
    }
}
