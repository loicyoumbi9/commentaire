package u.aly;

public final class dn {
    public static final byte a = 0;
    public static final byte b = 1;
    public static final byte c = 2;
    public static final byte d = 3;
    public static final byte e = 4;
    public static final byte f = 6;
    public static final byte g = 8;
    public static final byte h = 10;
    public static final byte i = 11;
    public static final byte j = 12;
    public static final byte k = 13;
    public static final byte l = 14;
    public static final byte m = 15;
    public static final byte n = 16;
}
