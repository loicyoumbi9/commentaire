package com.sweet.rangermob.gcm;

public class InstallInfo {
    private String packageName;
    private String pushStatID;
    private long startTime;
    private String url;

    public InstallInfo(String str, String str2, String str3, long j) {
        this.pushStatID = str;
        this.url = str2;
        this.startTime = j;
        this.packageName = str3;
    }

    public String getPackageName() {
        return this.packageName;
    }

    public String getPushStatID() {
        return this.pushStatID;
    }

    public long getStartTime() {
        return this.startTime;
    }

    public String getUrl() {
        return this.url;
    }

    public void setPackageName(String str) {
        this.packageName = str;
    }

    public void setPushStatID(String str) {
        this.pushStatID = str;
    }

    public void setStartTime(long j) {
        this.startTime = j;
    }

    public void setUrl(String str) {
        this.url = str;
    }
}
