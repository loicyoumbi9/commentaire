package u.aly;

import java.io.Serializable;
import u.aly.ch;
import u.aly.co;

public interface ch<T extends ch<?, ?>, F extends co> extends Serializable {
    void a(dg dgVar) throws cn;

    F b(int i);

    void b();

    void b(dg dgVar) throws cn;

    ch<T, F> g();
}
