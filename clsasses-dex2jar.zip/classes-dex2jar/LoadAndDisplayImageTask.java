package com.nostra13.universalimageloader.core;

import android.graphics.Bitmap;
import android.os.Handler;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.assist.ImageSize;
import com.nostra13.universalimageloader.core.assist.LoadedFrom;
import com.nostra13.universalimageloader.core.decode.ImageDecoder;
import com.nostra13.universalimageloader.core.decode.ImageDecodingInfo;
import com.nostra13.universalimageloader.core.download.ImageDownloader;
import com.nostra13.universalimageloader.core.imageaware.ImageAware;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;
import com.nostra13.universalimageloader.core.listener.ImageLoadingProgressListener;
import com.nostra13.universalimageloader.utils.IoUtils;
import com.nostra13.universalimageloader.utils.L;
import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.ReentrantLock;

final class LoadAndDisplayImageTask implements Runnable, IoUtils.CopyListener {
    private static final String ERROR_NO_IMAGE_STREAM = "No stream for image [%s]";
    private static final String ERROR_POST_PROCESSOR_NULL = "Post-processor returned null [%s]";
    private static final String ERROR_PRE_PROCESSOR_NULL = "Pre-processor returned null [%s]";
    private static final String ERROR_PROCESSOR_FOR_DISK_CACHE_NULL = "Bitmap processor for disk cache returned null [%s]";
    private static final String LOG_CACHE_IMAGE_IN_MEMORY = "Cache image in memory [%s]";
    private static final String LOG_CACHE_IMAGE_ON_DISK = "Cache image on disk [%s]";
    private static final String LOG_DELAY_BEFORE_LOADING = "Delay %d ms before loading...  [%s]";
    private static final String LOG_GET_IMAGE_FROM_MEMORY_CACHE_AFTER_WAITING = "...Get cached bitmap from memory after waiting. [%s]";
    private static final String LOG_LOAD_IMAGE_FROM_DISK_CACHE = "Load image from disk cache [%s]";
    private static final String LOG_LOAD_IMAGE_FROM_NETWORK = "Load image from network [%s]";
    private static final String LOG_POSTPROCESS_IMAGE = "PostProcess image before displaying [%s]";
    private static final String LOG_PREPROCESS_IMAGE = "PreProcess image before caching in memory [%s]";
    private static final String LOG_PROCESS_IMAGE_BEFORE_CACHE_ON_DISK = "Process image before cache on disk [%s]";
    private static final String LOG_RESIZE_CACHED_IMAGE_FILE = "Resize image in disk cache [%s]";
    private static final String LOG_RESUME_AFTER_PAUSE = ".. Resume loading [%s]";
    private static final String LOG_START_DISPLAY_IMAGE_TASK = "Start display image task [%s]";
    private static final String LOG_TASK_CANCELLED_IMAGEAWARE_COLLECTED = "ImageAware was collected by GC. Task is cancelled. [%s]";
    private static final String LOG_TASK_CANCELLED_IMAGEAWARE_REUSED = "ImageAware is reused for another image. Task is cancelled. [%s]";
    private static final String LOG_TASK_INTERRUPTED = "Task was interrupted [%s]";
    private static final String LOG_WAITING_FOR_IMAGE_LOADED = "Image already is loading. Waiting... [%s]";
    private static final String LOG_WAITING_FOR_RESUME = "ImageLoader is paused. Waiting...  [%s]";
    /* access modifiers changed from: private */
    public final ImageLoaderConfiguration configuration;
    private final ImageDecoder decoder;
    private final ImageDownloader downloader;
    private final ImageLoaderEngine engine;
    private final Handler handler;
    final ImageAware imageAware;
    private final ImageLoadingInfo imageLoadingInfo;
    final ImageLoadingListener listener;
    private LoadedFrom loadedFrom = LoadedFrom.NETWORK;
    private final String memoryCacheKey;
    private final ImageDownloader networkDeniedDownloader;
    final DisplayImageOptions options;
    final ImageLoadingProgressListener progressListener;
    private final ImageDownloader slowNetworkDownloader;
    private final boolean syncLoading;
    private final ImageSize targetSize;
    final String uri;

    class TaskCancelledException extends Exception {
        TaskCancelledException() {
        }
    }

    public LoadAndDisplayImageTask(ImageLoaderEngine imageLoaderEngine, ImageLoadingInfo imageLoadingInfo2, Handler handler2) {
        this.engine = imageLoaderEngine;
        this.imageLoadingInfo = imageLoadingInfo2;
        this.handler = handler2;
        this.configuration = imageLoaderEngine.configuration;
        this.downloader = this.configuration.downloader;
        this.networkDeniedDownloader = this.configuration.networkDeniedDownloader;
        this.slowNetworkDownloader = this.configuration.slowNetworkDownloader;
        this.decoder = this.configuration.decoder;
        this.uri = imageLoadingInfo2.uri;
        this.memoryCacheKey = imageLoadingInfo2.memoryCacheKey;
        this.imageAware = imageLoadingInfo2.imageAware;
        this.targetSize = imageLoadingInfo2.targetSize;
        this.options = imageLoadingInfo2.options;
        this.listener = imageLoadingInfo2.listener;
        this.progressListener = imageLoadingInfo2.progressListener;
        this.syncLoading = this.options.isSyncLoading();
    }

    private void checkTaskInterrupted() throws TaskCancelledException {
        if (isTaskInterrupted()) {
            throw new TaskCancelledException();
        }
    }

    private void checkTaskNotActual() throws TaskCancelledException {
        checkViewCollected();
        checkViewReused();
    }

    private void checkViewCollected() throws TaskCancelledException {
        if (isViewCollected()) {
            throw new TaskCancelledException();
        }
    }

    private void checkViewReused() throws TaskCancelledException {
        if (isViewReused()) {
            throw new TaskCancelledException();
        }
    }

    private Bitmap decodeImage(String str) throws IOException {
        return this.decoder.decode(new ImageDecodingInfo(this.memoryCacheKey, str, this.uri, this.targetSize, this.imageAware.getScaleType(), getDownloader(), this.options));
    }

    private boolean delayIfNeed() {
        if (!this.options.shouldDelayBeforeLoading()) {
            return false;
        }
        L.d(LOG_DELAY_BEFORE_LOADING, Integer.valueOf(this.options.getDelayBeforeLoading()), this.memoryCacheKey);
        try {
            Thread.sleep((long) this.options.getDelayBeforeLoading());
            return isTaskNotActual();
        } catch (InterruptedException e) {
            L.e(LOG_TASK_INTERRUPTED, this.memoryCacheKey);
            return true;
        }
    }

    private boolean downloadImage() throws IOException {
        boolean z = false;
        InputStream stream = getDownloader().getStream(this.uri, this.options.getExtraForDownloader());
        if (stream == null) {
            L.e(ERROR_NO_IMAGE_STREAM, this.memoryCacheKey);
        } else {
            try {
                z = this.configuration.diskCache.save(this.uri, stream, this);
            } finally {
                IoUtils.closeSilently(stream);
            }
        }
        return z;
    }

    private void fireCancelEvent() {
        if (!this.syncLoading && !isTaskInterrupted()) {
            runTask(new Runnable() {
                /* class com.nostra13.universalimageloader.core.LoadAndDisplayImageTask.AnonymousClass3 */

                public void run() {
                    LoadAndDisplayImageTask.this.listener.onLoadingCancelled(LoadAndDisplayImageTask.this.uri, LoadAndDisplayImageTask.this.imageAware.getWrappedView());
                }
            }, false, this.handler, this.engine);
        }
    }

    private void fireFailEvent(final FailReason.FailType failType, final Throwable th) {
        if (!this.syncLoading && !isTaskInterrupted() && !isTaskNotActual()) {
            runTask(new Runnable() {
                /* class com.nostra13.universalimageloader.core.LoadAndDisplayImageTask.AnonymousClass2 */

                public void run() {
                    if (LoadAndDisplayImageTask.this.options.shouldShowImageOnFail()) {
                        LoadAndDisplayImageTask.this.imageAware.setImageDrawable(LoadAndDisplayImageTask.this.options.getImageOnFail(LoadAndDisplayImageTask.this.configuration.resources));
                    }
                    LoadAndDisplayImageTask.this.listener.onLoadingFailed(LoadAndDisplayImageTask.this.uri, LoadAndDisplayImageTask.this.imageAware.getWrappedView(), new FailReason(failType, th));
                }
            }, false, this.handler, this.engine);
        }
    }

    private boolean fireProgressEvent(final int i, final int i2) {
        if (isTaskInterrupted() || isTaskNotActual()) {
            return false;
        }
        if (this.progressListener != null) {
            runTask(new Runnable() {
                /* class com.nostra13.universalimageloader.core.LoadAndDisplayImageTask.AnonymousClass1 */

                public void run() {
                    LoadAndDisplayImageTask.this.progressListener.onProgressUpdate(LoadAndDisplayImageTask.this.uri, LoadAndDisplayImageTask.this.imageAware.getWrappedView(), i, i2);
                }
            }, false, this.handler, this.engine);
        }
        return true;
    }

    private ImageDownloader getDownloader() {
        return this.engine.isNetworkDenied() ? this.networkDeniedDownloader : this.engine.isSlowNetwork() ? this.slowNetworkDownloader : this.downloader;
    }

    private boolean isTaskInterrupted() {
        if (!Thread.interrupted()) {
            return false;
        }
        L.d(LOG_TASK_INTERRUPTED, this.memoryCacheKey);
        return true;
    }

    private boolean isTaskNotActual() {
        return isViewCollected() || isViewReused();
    }

    private boolean isViewCollected() {
        if (!this.imageAware.isCollected()) {
            return false;
        }
        L.d(LOG_TASK_CANCELLED_IMAGEAWARE_COLLECTED, this.memoryCacheKey);
        return true;
    }

    private boolean isViewReused() {
        if (!(!this.memoryCacheKey.equals(this.engine.getLoadingUriForView(this.imageAware)))) {
            return false;
        }
        L.d(LOG_TASK_CANCELLED_IMAGEAWARE_REUSED, this.memoryCacheKey);
        return true;
    }

    /* JADX WARNING: Removed duplicated region for block: B:12:0x0078  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private boolean resizeAndSaveImage(int r11, int r12) throws java.io.IOException {
        /*
            r10 = this;
            r9 = 1
            r8 = 0
            com.nostra13.universalimageloader.core.ImageLoaderConfiguration r0 = r10.configuration
            com.nostra13.universalimageloader.cache.disc.DiskCache r0 = r0.diskCache
            java.lang.String r1 = r10.uri
            java.io.File r2 = r0.get(r1)
            if (r2 == 0) goto L_0x0086
            boolean r0 = r2.exists()
            if (r0 == 0) goto L_0x0086
            com.nostra13.universalimageloader.core.assist.ImageSize r4 = new com.nostra13.universalimageloader.core.assist.ImageSize
            r4.<init>(r11, r12)
            com.nostra13.universalimageloader.core.DisplayImageOptions$Builder r0 = new com.nostra13.universalimageloader.core.DisplayImageOptions$Builder
            r0.<init>()
            com.nostra13.universalimageloader.core.DisplayImageOptions r1 = r10.options
            com.nostra13.universalimageloader.core.DisplayImageOptions$Builder r0 = r0.cloneFrom(r1)
            com.nostra13.universalimageloader.core.assist.ImageScaleType r1 = com.nostra13.universalimageloader.core.assist.ImageScaleType.IN_SAMPLE_INT
            com.nostra13.universalimageloader.core.DisplayImageOptions$Builder r0 = r0.imageScaleType(r1)
            com.nostra13.universalimageloader.core.DisplayImageOptions r7 = r0.build()
            com.nostra13.universalimageloader.core.decode.ImageDecodingInfo r0 = new com.nostra13.universalimageloader.core.decode.ImageDecodingInfo
            java.lang.String r1 = r10.memoryCacheKey
            com.nostra13.universalimageloader.core.download.ImageDownloader$Scheme r3 = com.nostra13.universalimageloader.core.download.ImageDownloader.Scheme.FILE
            java.lang.String r2 = r2.getAbsolutePath()
            java.lang.String r2 = r3.wrap(r2)
            java.lang.String r3 = r10.uri
            com.nostra13.universalimageloader.core.assist.ViewScaleType r5 = com.nostra13.universalimageloader.core.assist.ViewScaleType.FIT_INSIDE
            com.nostra13.universalimageloader.core.download.ImageDownloader r6 = r10.getDownloader()
            r0.<init>(r1, r2, r3, r4, r5, r6, r7)
            com.nostra13.universalimageloader.core.decode.ImageDecoder r1 = r10.decoder
            android.graphics.Bitmap r0 = r1.decode(r0)
            if (r0 == 0) goto L_0x0088
            com.nostra13.universalimageloader.core.ImageLoaderConfiguration r1 = r10.configuration
            com.nostra13.universalimageloader.core.process.BitmapProcessor r1 = r1.processorForDiskCache
            if (r1 == 0) goto L_0x0088
            java.lang.String r1 = "Process image before cache on disk [%s]"
            java.lang.Object[] r2 = new java.lang.Object[r9]
            java.lang.String r3 = r10.memoryCacheKey
            r2[r8] = r3
            com.nostra13.universalimageloader.utils.L.d(r1, r2)
            com.nostra13.universalimageloader.core.ImageLoaderConfiguration r1 = r10.configuration
            com.nostra13.universalimageloader.core.process.BitmapProcessor r1 = r1.processorForDiskCache
            android.graphics.Bitmap r0 = r1.process(r0)
            if (r0 != 0) goto L_0x0088
            java.lang.String r1 = "Bitmap processor for disk cache returned null [%s]"
            java.lang.Object[] r2 = new java.lang.Object[r9]
            java.lang.String r3 = r10.memoryCacheKey
            r2[r8] = r3
            com.nostra13.universalimageloader.utils.L.e(r1, r2)
            r1 = r0
        L_0x0076:
            if (r1 == 0) goto L_0x0086
            com.nostra13.universalimageloader.core.ImageLoaderConfiguration r0 = r10.configuration
            com.nostra13.universalimageloader.cache.disc.DiskCache r0 = r0.diskCache
            java.lang.String r2 = r10.uri
            boolean r0 = r0.save(r2, r1)
            r1.recycle()
        L_0x0085:
            return r0
        L_0x0086:
            r0 = r8
            goto L_0x0085
        L_0x0088:
            r1 = r0
            goto L_0x0076
        */
        throw new UnsupportedOperationException("Method not decompiled: com.nostra13.universalimageloader.core.LoadAndDisplayImageTask.resizeAndSaveImage(int, int):boolean");
    }

    static void runTask(Runnable runnable, boolean z, Handler handler2, ImageLoaderEngine imageLoaderEngine) {
        if (z) {
            runnable.run();
        } else if (handler2 == null) {
            imageLoaderEngine.fireCallback(runnable);
        } else {
            handler2.post(runnable);
        }
    }

    private boolean tryCacheImageOnDisk() throws TaskCancelledException {
        L.d(LOG_CACHE_IMAGE_ON_DISK, this.memoryCacheKey);
        try {
            boolean downloadImage = downloadImage();
            if (!downloadImage) {
                return downloadImage;
            }
            int i = this.configuration.maxImageWidthForDiskCache;
            int i2 = this.configuration.maxImageHeightForDiskCache;
            if (i <= 0 && i2 <= 0) {
                return downloadImage;
            }
            L.d(LOG_RESIZE_CACHED_IMAGE_FILE, this.memoryCacheKey);
            resizeAndSaveImage(i, i2);
            return downloadImage;
        } catch (IOException e) {
            L.e(e);
            return false;
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:31:0x00a1, code lost:
        r0 = null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:33:0x00a8, code lost:
        r0 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:34:0x00a9, code lost:
        throw r0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:35:0x00aa, code lost:
        r1 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:36:0x00ab, code lost:
        r3 = r1;
        r0 = null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:38:0x00b6, code lost:
        r1 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:39:0x00b7, code lost:
        r3 = r1;
        r0 = null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:41:0x00c2, code lost:
        r1 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:42:0x00c3, code lost:
        r3 = r1;
        r0 = null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:46:0x00d2, code lost:
        r1 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:47:0x00d3, code lost:
        r3 = r1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:50:0x00d9, code lost:
        r1 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:51:0x00da, code lost:
        r3 = r1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:54:0x00e0, code lost:
        r1 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:55:0x00e1, code lost:
        r3 = r1;
     */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Removed duplicated region for block: B:33:0x00a8 A[ExcHandler: TaskCancelledException (r0v6 'e' com.nostra13.universalimageloader.core.LoadAndDisplayImageTask$TaskCancelledException A[CUSTOM_DECLARE]), Splitter:B:1:0x0001] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private android.graphics.Bitmap tryLoadBitmap() throws com.nostra13.universalimageloader.core.LoadAndDisplayImageTask.TaskCancelledException {
        /*
            r8 = this;
            r2 = 0
            com.nostra13.universalimageloader.core.ImageLoaderConfiguration r0 = r8.configuration     // Catch:{ IllegalStateException -> 0x00a0, TaskCancelledException -> 0x00a8, IOException -> 0x00aa, OutOfMemoryError -> 0x00b6, Throwable -> 0x00c2 }
            com.nostra13.universalimageloader.cache.disc.DiskCache r0 = r0.diskCache     // Catch:{ IllegalStateException -> 0x00a0, TaskCancelledException -> 0x00a8, IOException -> 0x00aa, OutOfMemoryError -> 0x00b6, Throwable -> 0x00c2 }
            java.lang.String r1 = r8.uri     // Catch:{ IllegalStateException -> 0x00a0, TaskCancelledException -> 0x00a8, IOException -> 0x00aa, OutOfMemoryError -> 0x00b6, Throwable -> 0x00c2 }
            java.io.File r0 = r0.get(r1)     // Catch:{ IllegalStateException -> 0x00a0, TaskCancelledException -> 0x00a8, IOException -> 0x00aa, OutOfMemoryError -> 0x00b6, Throwable -> 0x00c2 }
            if (r0 == 0) goto L_0x00ea
            boolean r1 = r0.exists()     // Catch:{ IllegalStateException -> 0x00a0, TaskCancelledException -> 0x00a8, IOException -> 0x00aa, OutOfMemoryError -> 0x00b6, Throwable -> 0x00c2 }
            if (r1 == 0) goto L_0x00ea
            long r4 = r0.length()     // Catch:{ IllegalStateException -> 0x00a0, TaskCancelledException -> 0x00a8, IOException -> 0x00aa, OutOfMemoryError -> 0x00b6, Throwable -> 0x00c2 }
            r6 = 0
            int r1 = (r4 > r6 ? 1 : (r4 == r6 ? 0 : -1))
            if (r1 <= 0) goto L_0x00ea
            java.lang.String r1 = "Load image from disk cache [%s]"
            r3 = 1
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch:{ IllegalStateException -> 0x00a0, TaskCancelledException -> 0x00a8, IOException -> 0x00aa, OutOfMemoryError -> 0x00b6, Throwable -> 0x00c2 }
            r4 = 0
            java.lang.String r5 = r8.memoryCacheKey     // Catch:{ IllegalStateException -> 0x00a0, TaskCancelledException -> 0x00a8, IOException -> 0x00aa, OutOfMemoryError -> 0x00b6, Throwable -> 0x00c2 }
            r3[r4] = r5     // Catch:{ IllegalStateException -> 0x00a0, TaskCancelledException -> 0x00a8, IOException -> 0x00aa, OutOfMemoryError -> 0x00b6, Throwable -> 0x00c2 }
            com.nostra13.universalimageloader.utils.L.d(r1, r3)     // Catch:{ IllegalStateException -> 0x00a0, TaskCancelledException -> 0x00a8, IOException -> 0x00aa, OutOfMemoryError -> 0x00b6, Throwable -> 0x00c2 }
            com.nostra13.universalimageloader.core.assist.LoadedFrom r1 = com.nostra13.universalimageloader.core.assist.LoadedFrom.DISC_CACHE     // Catch:{ IllegalStateException -> 0x00a0, TaskCancelledException -> 0x00a8, IOException -> 0x00aa, OutOfMemoryError -> 0x00b6, Throwable -> 0x00c2 }
            r8.loadedFrom = r1     // Catch:{ IllegalStateException -> 0x00a0, TaskCancelledException -> 0x00a8, IOException -> 0x00aa, OutOfMemoryError -> 0x00b6, Throwable -> 0x00c2 }
            r8.checkTaskNotActual()     // Catch:{ IllegalStateException -> 0x00a0, TaskCancelledException -> 0x00a8, IOException -> 0x00aa, OutOfMemoryError -> 0x00b6, Throwable -> 0x00c2 }
            com.nostra13.universalimageloader.core.download.ImageDownloader$Scheme r1 = com.nostra13.universalimageloader.core.download.ImageDownloader.Scheme.FILE     // Catch:{ IllegalStateException -> 0x00a0, TaskCancelledException -> 0x00a8, IOException -> 0x00aa, OutOfMemoryError -> 0x00b6, Throwable -> 0x00c2 }
            java.lang.String r0 = r0.getAbsolutePath()     // Catch:{ IllegalStateException -> 0x00a0, TaskCancelledException -> 0x00a8, IOException -> 0x00aa, OutOfMemoryError -> 0x00b6, Throwable -> 0x00c2 }
            java.lang.String r0 = r1.wrap(r0)     // Catch:{ IllegalStateException -> 0x00a0, TaskCancelledException -> 0x00a8, IOException -> 0x00aa, OutOfMemoryError -> 0x00b6, Throwable -> 0x00c2 }
            android.graphics.Bitmap r1 = r8.decodeImage(r0)     // Catch:{ IllegalStateException -> 0x00a0, TaskCancelledException -> 0x00a8, IOException -> 0x00aa, OutOfMemoryError -> 0x00b6, Throwable -> 0x00c2 }
        L_0x003f:
            if (r1 == 0) goto L_0x004d
            int r0 = r1.getWidth()     // Catch:{ IllegalStateException -> 0x00e3, TaskCancelledException -> 0x00a8, IOException -> 0x00dc, OutOfMemoryError -> 0x00d5, Throwable -> 0x00ce }
            if (r0 <= 0) goto L_0x004d
            int r0 = r1.getHeight()     // Catch:{ IllegalStateException -> 0x00e3, TaskCancelledException -> 0x00a8, IOException -> 0x00dc, OutOfMemoryError -> 0x00d5, Throwable -> 0x00ce }
            if (r0 > 0) goto L_0x00e8
        L_0x004d:
            java.lang.String r0 = "Load image from network [%s]"
            r3 = 1
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch:{ IllegalStateException -> 0x00e3, TaskCancelledException -> 0x00a8, IOException -> 0x00dc, OutOfMemoryError -> 0x00d5, Throwable -> 0x00ce }
            r4 = 0
            java.lang.String r5 = r8.memoryCacheKey     // Catch:{ IllegalStateException -> 0x00e3, TaskCancelledException -> 0x00a8, IOException -> 0x00dc, OutOfMemoryError -> 0x00d5, Throwable -> 0x00ce }
            r3[r4] = r5     // Catch:{ IllegalStateException -> 0x00e3, TaskCancelledException -> 0x00a8, IOException -> 0x00dc, OutOfMemoryError -> 0x00d5, Throwable -> 0x00ce }
            com.nostra13.universalimageloader.utils.L.d(r0, r3)     // Catch:{ IllegalStateException -> 0x00e3, TaskCancelledException -> 0x00a8, IOException -> 0x00dc, OutOfMemoryError -> 0x00d5, Throwable -> 0x00ce }
            com.nostra13.universalimageloader.core.assist.LoadedFrom r0 = com.nostra13.universalimageloader.core.assist.LoadedFrom.NETWORK     // Catch:{ IllegalStateException -> 0x00e3, TaskCancelledException -> 0x00a8, IOException -> 0x00dc, OutOfMemoryError -> 0x00d5, Throwable -> 0x00ce }
            r8.loadedFrom = r0     // Catch:{ IllegalStateException -> 0x00e3, TaskCancelledException -> 0x00a8, IOException -> 0x00dc, OutOfMemoryError -> 0x00d5, Throwable -> 0x00ce }
            java.lang.String r0 = r8.uri     // Catch:{ IllegalStateException -> 0x00e3, TaskCancelledException -> 0x00a8, IOException -> 0x00dc, OutOfMemoryError -> 0x00d5, Throwable -> 0x00ce }
            com.nostra13.universalimageloader.core.DisplayImageOptions r3 = r8.options     // Catch:{ IllegalStateException -> 0x00e3, TaskCancelledException -> 0x00a8, IOException -> 0x00dc, OutOfMemoryError -> 0x00d5, Throwable -> 0x00ce }
            boolean r3 = r3.isCacheOnDisk()     // Catch:{ IllegalStateException -> 0x00e3, TaskCancelledException -> 0x00a8, IOException -> 0x00dc, OutOfMemoryError -> 0x00d5, Throwable -> 0x00ce }
            if (r3 == 0) goto L_0x0084
            boolean r3 = r8.tryCacheImageOnDisk()     // Catch:{ IllegalStateException -> 0x00e3, TaskCancelledException -> 0x00a8, IOException -> 0x00dc, OutOfMemoryError -> 0x00d5, Throwable -> 0x00ce }
            if (r3 == 0) goto L_0x0084
            com.nostra13.universalimageloader.core.ImageLoaderConfiguration r3 = r8.configuration     // Catch:{ IllegalStateException -> 0x00e3, TaskCancelledException -> 0x00a8, IOException -> 0x00dc, OutOfMemoryError -> 0x00d5, Throwable -> 0x00ce }
            com.nostra13.universalimageloader.cache.disc.DiskCache r3 = r3.diskCache     // Catch:{ IllegalStateException -> 0x00e3, TaskCancelledException -> 0x00a8, IOException -> 0x00dc, OutOfMemoryError -> 0x00d5, Throwable -> 0x00ce }
            java.lang.String r4 = r8.uri     // Catch:{ IllegalStateException -> 0x00e3, TaskCancelledException -> 0x00a8, IOException -> 0x00dc, OutOfMemoryError -> 0x00d5, Throwable -> 0x00ce }
            java.io.File r3 = r3.get(r4)     // Catch:{ IllegalStateException -> 0x00e3, TaskCancelledException -> 0x00a8, IOException -> 0x00dc, OutOfMemoryError -> 0x00d5, Throwable -> 0x00ce }
            if (r3 == 0) goto L_0x0084
            com.nostra13.universalimageloader.core.download.ImageDownloader$Scheme r0 = com.nostra13.universalimageloader.core.download.ImageDownloader.Scheme.FILE     // Catch:{ IllegalStateException -> 0x00e3, TaskCancelledException -> 0x00a8, IOException -> 0x00dc, OutOfMemoryError -> 0x00d5, Throwable -> 0x00ce }
            java.lang.String r3 = r3.getAbsolutePath()     // Catch:{ IllegalStateException -> 0x00e3, TaskCancelledException -> 0x00a8, IOException -> 0x00dc, OutOfMemoryError -> 0x00d5, Throwable -> 0x00ce }
            java.lang.String r0 = r0.wrap(r3)     // Catch:{ IllegalStateException -> 0x00e3, TaskCancelledException -> 0x00a8, IOException -> 0x00dc, OutOfMemoryError -> 0x00d5, Throwable -> 0x00ce }
        L_0x0084:
            r8.checkTaskNotActual()     // Catch:{ IllegalStateException -> 0x00e3, TaskCancelledException -> 0x00a8, IOException -> 0x00dc, OutOfMemoryError -> 0x00d5, Throwable -> 0x00ce }
            android.graphics.Bitmap r0 = r8.decodeImage(r0)     // Catch:{ IllegalStateException -> 0x00e3, TaskCancelledException -> 0x00a8, IOException -> 0x00dc, OutOfMemoryError -> 0x00d5, Throwable -> 0x00ce }
            if (r0 == 0) goto L_0x0099
            int r1 = r0.getWidth()     // Catch:{ IllegalStateException -> 0x00e6, TaskCancelledException -> 0x00a8, IOException -> 0x00e0, OutOfMemoryError -> 0x00d9, Throwable -> 0x00d2 }
            if (r1 <= 0) goto L_0x0099
            int r1 = r0.getHeight()     // Catch:{ IllegalStateException -> 0x00e6, TaskCancelledException -> 0x00a8, IOException -> 0x00e0, OutOfMemoryError -> 0x00d9, Throwable -> 0x00d2 }
            if (r1 > 0) goto L_0x009f
        L_0x0099:
            com.nostra13.universalimageloader.core.assist.FailReason$FailType r1 = com.nostra13.universalimageloader.core.assist.FailReason.FailType.DECODING_ERROR     // Catch:{ IllegalStateException -> 0x00e6, TaskCancelledException -> 0x00a8, IOException -> 0x00e0, OutOfMemoryError -> 0x00d9, Throwable -> 0x00d2 }
            r3 = 0
            r8.fireFailEvent(r1, r3)     // Catch:{ IllegalStateException -> 0x00e6, TaskCancelledException -> 0x00a8, IOException -> 0x00e0, OutOfMemoryError -> 0x00d9, Throwable -> 0x00d2 }
        L_0x009f:
            return r0
        L_0x00a0:
            r0 = move-exception
            r0 = r2
        L_0x00a2:
            com.nostra13.universalimageloader.core.assist.FailReason$FailType r1 = com.nostra13.universalimageloader.core.assist.FailReason.FailType.NETWORK_DENIED
            r8.fireFailEvent(r1, r2)
            goto L_0x009f
        L_0x00a8:
            r0 = move-exception
            throw r0
        L_0x00aa:
            r1 = move-exception
            r3 = r1
            r0 = r2
        L_0x00ad:
            com.nostra13.universalimageloader.utils.L.e(r3)
            com.nostra13.universalimageloader.core.assist.FailReason$FailType r1 = com.nostra13.universalimageloader.core.assist.FailReason.FailType.IO_ERROR
            r8.fireFailEvent(r1, r3)
            goto L_0x009f
        L_0x00b6:
            r1 = move-exception
            r3 = r1
            r0 = r2
        L_0x00b9:
            com.nostra13.universalimageloader.utils.L.e(r3)
            com.nostra13.universalimageloader.core.assist.FailReason$FailType r1 = com.nostra13.universalimageloader.core.assist.FailReason.FailType.OUT_OF_MEMORY
            r8.fireFailEvent(r1, r3)
            goto L_0x009f
        L_0x00c2:
            r1 = move-exception
            r3 = r1
            r0 = r2
        L_0x00c5:
            com.nostra13.universalimageloader.utils.L.e(r3)
            com.nostra13.universalimageloader.core.assist.FailReason$FailType r1 = com.nostra13.universalimageloader.core.assist.FailReason.FailType.UNKNOWN
            r8.fireFailEvent(r1, r3)
            goto L_0x009f
        L_0x00ce:
            r2 = move-exception
            r3 = r2
            r0 = r1
            goto L_0x00c5
        L_0x00d2:
            r1 = move-exception
            r3 = r1
            goto L_0x00c5
        L_0x00d5:
            r2 = move-exception
            r3 = r2
            r0 = r1
            goto L_0x00b9
        L_0x00d9:
            r1 = move-exception
            r3 = r1
            goto L_0x00b9
        L_0x00dc:
            r2 = move-exception
            r3 = r2
            r0 = r1
            goto L_0x00ad
        L_0x00e0:
            r1 = move-exception
            r3 = r1
            goto L_0x00ad
        L_0x00e3:
            r0 = move-exception
            r0 = r1
            goto L_0x00a2
        L_0x00e6:
            r1 = move-exception
            goto L_0x00a2
        L_0x00e8:
            r0 = r1
            goto L_0x009f
        L_0x00ea:
            r1 = r2
            goto L_0x003f
        */
        throw new UnsupportedOperationException("Method not decompiled: com.nostra13.universalimageloader.core.LoadAndDisplayImageTask.tryLoadBitmap():android.graphics.Bitmap");
    }

    private boolean waitIfPaused() {
        AtomicBoolean pause = this.engine.getPause();
        if (pause.get()) {
            synchronized (this.engine.getPauseLock()) {
                if (pause.get()) {
                    L.d(LOG_WAITING_FOR_RESUME, this.memoryCacheKey);
                    try {
                        this.engine.getPauseLock().wait();
                        L.d(LOG_RESUME_AFTER_PAUSE, this.memoryCacheKey);
                    } catch (InterruptedException e) {
                        L.e(LOG_TASK_INTERRUPTED, this.memoryCacheKey);
                        return true;
                    }
                }
            }
        }
        return isTaskNotActual();
    }

    /* access modifiers changed from: package-private */
    public String getLoadingUri() {
        return this.uri;
    }

    @Override // com.nostra13.universalimageloader.utils.IoUtils.CopyListener
    public boolean onBytesCopied(int i, int i2) {
        return this.syncLoading || fireProgressEvent(i, i2);
    }

    public void run() {
        if (!waitIfPaused() && !delayIfNeed()) {
            ReentrantLock reentrantLock = this.imageLoadingInfo.loadFromUriLock;
            L.d(LOG_START_DISPLAY_IMAGE_TASK, this.memoryCacheKey);
            if (reentrantLock.isLocked()) {
                L.d(LOG_WAITING_FOR_IMAGE_LOADED, this.memoryCacheKey);
            }
            reentrantLock.lock();
            try {
                checkTaskNotActual();
                Bitmap bitmap = (Bitmap) this.configuration.memoryCache.get(this.memoryCacheKey);
                if (bitmap == null || bitmap.isRecycled()) {
                    bitmap = tryLoadBitmap();
                    if (bitmap != null) {
                        checkTaskNotActual();
                        checkTaskInterrupted();
                        if (this.options.shouldPreProcess()) {
                            L.d(LOG_PREPROCESS_IMAGE, this.memoryCacheKey);
                            bitmap = this.options.getPreProcessor().process(bitmap);
                            if (bitmap == null) {
                                L.e(ERROR_PRE_PROCESSOR_NULL, this.memoryCacheKey);
                            }
                        }
                        if (bitmap != null && this.options.isCacheInMemory()) {
                            L.d(LOG_CACHE_IMAGE_IN_MEMORY, this.memoryCacheKey);
                            this.configuration.memoryCache.put(this.memoryCacheKey, bitmap);
                        }
                    } else {
                        return;
                    }
                } else {
                    this.loadedFrom = LoadedFrom.MEMORY_CACHE;
                    L.d(LOG_GET_IMAGE_FROM_MEMORY_CACHE_AFTER_WAITING, this.memoryCacheKey);
                }
                if (bitmap != null && this.options.shouldPostProcess()) {
                    L.d(LOG_POSTPROCESS_IMAGE, this.memoryCacheKey);
                    bitmap = this.options.getPostProcessor().process(bitmap);
                    if (bitmap == null) {
                        L.e(ERROR_POST_PROCESSOR_NULL, this.memoryCacheKey);
                    }
                }
                checkTaskNotActual();
                checkTaskInterrupted();
                reentrantLock.unlock();
                runTask(new DisplayBitmapTask(bitmap, this.imageLoadingInfo, this.engine, this.loadedFrom), this.syncLoading, this.handler, this.engine);
            } catch (TaskCancelledException e) {
                fireCancelEvent();
            } finally {
                reentrantLock.unlock();
            }
        }
    }
}
