package com.ironsource.mobilcore;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import org.json.JSONObject;

/* renamed from: com.ironsource.mobilcore.az  reason: case insensitive filesystem */
final class C0263az extends G {
    private Intent a;

    public C0263az(Context context, C0261ax axVar) {
        super(context, axVar);
    }

    @Override // com.ironsource.mobilcore.H, com.ironsource.mobilcore.G
    public final String a() {
        return "ironsourceSocialWidgetShare";
    }

    /* access modifiers changed from: protected */
    @Override // com.ironsource.mobilcore.H, com.ironsource.mobilcore.I
    public final void a(View view) {
        if (this.a != null) {
            this.e.startActivity(this.a);
        }
        super.a(view);
    }

    @Override // com.ironsource.mobilcore.H, com.ironsource.mobilcore.G
    public final void a(JSONObject jSONObject) {
        this.a = aF.a(jSONObject);
        super.a(jSONObject);
    }
}
