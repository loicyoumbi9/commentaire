package com.ironsource.mobilcore;

import android.app.Activity;
import android.graphics.drawable.GradientDrawable;
import android.support.v4.view.ViewCompat;

/* renamed from: com.ironsource.mobilcore.au  reason: case insensitive filesystem */
final class C0258au extends C0256as {
    C0258au(Activity activity, int i) {
        super(activity, i, C0250am.TOP);
    }

    @Override // com.ironsource.mobilcore.C0247aj
    public final void a(int i) {
        this.s = new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, new int[]{ViewCompat.MEASURED_STATE_MASK, 0});
        invalidate();
    }
}
