package com.ironsource.mobilcore;

import android.annotation.SuppressLint;
import android.content.Context;
import android.text.TextUtils;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.ironsource.mobilcore.C0287y;

@SuppressLint({"SetJavaScriptEnabled"})
/* renamed from: com.ironsource.mobilcore.h  reason: case insensitive filesystem */
final class C0270h {
    private Context a = MobileCore.c();
    private A b;
    private A c;
    private String d;

    public C0270h(String str, C0287y.c cVar) {
        this.d = str;
        this.b = new A(this.a);
        this.c = new A(this.a);
        cVar.a(this.b);
        cVar.a(this.c);
        this.b.setContentDescription("offerwall-webview-1");
        this.c.setContentDescription("offerwall-webview-2");
        AnonymousClass1 r0 = new WebViewClient() {
            /* class com.ironsource.mobilcore.C0270h.AnonymousClass1 */

            public final void onPageFinished(WebView webView, String str) {
                String title = webView.getTitle();
                A a2 = (A) webView;
                B.a("AlwaysLoadedWebViewHolder: webview " + a2.getId() + " onPageFinished " + str + " title " + title, 55);
                if (!a2.e().equals(str)) {
                    return;
                }
                if (TextUtils.isEmpty(title) || !title.contains("mobilecore")) {
                    ((A) webView).a();
                }
            }

            public final void onReceivedError(WebView webView, int i, String str, String str2) {
                ((A) webView).a();
                B.a("AlwaysLoadedWebViewHolder: webview " + ((A) webView).getId() + " onReceivedError errorCode:" + i + " , description:" + str + " , failingUrl:" + str2, 55);
            }
        };
        this.b.setWebViewClient(r0);
        this.c.setWebViewClient(r0);
        this.c.a(str);
        B.a("AlwaysLoadedWebViewHolder: loading in mLoadedWebView:" + this.c.getId() + " , url: " + str, 55);
    }

    public final A a() {
        B.a("AlwaysLoadedWebViewHolder: getReadyWebView. new mLoadWebView:" + this.b.getId() + " , isReady: " + this.b.c(), 55);
        if (this.b.c()) {
            A a2 = this.b;
            this.b = this.c;
            this.c = a2;
            B.a("AlwaysLoadedWebViewHolder: swapping webviews. new mLoadWebView:" + this.b.getId() + " , new mLoadedWebView:" + this.c.getId(), 55);
        } else if (this.c.d()) {
            B.a("AlwaysLoadedWebViewHolder: mLoadWebView id" + this.b.getId() + " , mDefaultUrl:" + this.d, 55);
            this.c.loadUrl(this.d);
            return null;
        }
        return this.c;
    }

    public final void a(String str) {
        B.a("AlwaysLoadedWebViewHolder: reset. loading in mLoadedWebView:" + this.c.getId() + " , url: " + str, 55);
        this.b.clearCache(true);
        this.b.b(false);
        this.c.b(false);
        this.c.a(str);
    }

    public final boolean b(String str) {
        B.a("AlwaysLoadedWebViewHolder: loadUrl. new mLoadWebView:" + this.b.getId() + " , url: " + str, 55);
        return this.b.a(str);
    }
}
