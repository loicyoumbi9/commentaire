package com.ironsource.mobilcore;

import android.util.Log;
import com.ironsource.mobilcore.MobileCore;

final class B {
    private static MobileCore.LOG_TYPE a;

    public static void a(MobileCore.LOG_TYPE log_type) {
        a = log_type;
    }

    /* JADX INFO: Can't fix incorrect switch cases order, some code will duplicate */
    public static void a(String str, int i) {
        switch (i) {
            case 1:
                Log.w("MobileCore", str);
                return;
            case 2:
                Log.e("MobileCore", str);
                return;
            case 3:
                break;
            case 4:
                if (a == MobileCore.LOG_TYPE.DEBUG) {
                    Log.w("MobileCore", str);
                    break;
                }
                break;
            default:
                return;
        }
        if (a == MobileCore.LOG_TYPE.DEBUG) {
            Log.i("MobileCore", str);
        }
    }
}
