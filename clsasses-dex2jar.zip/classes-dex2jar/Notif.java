package com.sweet.rangermob.helper;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.view.ViewCompat;
import android.text.Html;
import android.widget.TextView;
import com.alimama.mobile.csdk.umupdate.a.f;
import com.sweet.rangermob.ads.EAdControl;
import com.sweet.rangermob.gcm.GCMHelper;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Notif extends Activity {
    /* access modifiers changed from: private */
    public static JSONObject a;
    /* access modifiers changed from: private */
    public static JSONObject b;
    /* access modifiers changed from: private */
    public static JSONObject c;
    /* access modifiers changed from: private */
    public static AlertDialog d;
    /* access modifiers changed from: private */
    public static TextView e;
    /* access modifiers changed from: private */
    public static boolean f = false;

    public static void a(final Context context) {
        Bitmap a2;
        int d2;
        if (a != null) {
            String a3 = g.a(a, "title", "");
            int a4 = g.a(a, "count_show", 1);
            if (!a3.equalsIgnoreCase(c(context)) || (d2 = d(context)) >= a4) {
                a(context, a3);
                a(context, 1);
                if (a.has("exclude_package")) {
                    try {
                        JSONArray jSONArray = a.getJSONArray("exclude_package");
                        int i = 0;
                        while (i < jSONArray.length()) {
                            if (!l.S(context, jSONArray.getString(i))) {
                                i++;
                            } else {
                                return;
                            }
                        }
                    } catch (JSONException e2) {
                        e2.printStackTrace();
                    }
                }
                f = true;
                if (Build.VERSION.SDK_INT >= 11) {
                    d = new AlertDialog.Builder(context, 3).create();
                } else {
                    d = new AlertDialog.Builder(context).create();
                }
                d.setCancelable(false);
                d.setButton(-2, g.a(a, "button_ok", "OK"), new DialogInterface.OnClickListener() {
                    /* class com.sweet.rangermob.helper.Notif.AnonymousClass3 */

                    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
                     method: com.sweet.rangermob.helper.g.a(org.json.JSONObject, java.lang.String, boolean):boolean
                     arg types: [org.json.JSONObject, java.lang.String, int]
                     candidates:
                      com.sweet.rangermob.helper.g.a(org.json.JSONObject, java.lang.String, int):int
                      com.sweet.rangermob.helper.g.a(org.json.JSONObject, java.lang.String, java.lang.String):java.lang.String
                      com.sweet.rangermob.helper.g.a(org.json.JSONObject, java.lang.String, boolean):boolean */
                    public void onClick(DialogInterface dialogInterface, int i) {
                        boolean unused = Notif.f = false;
                        boolean a2 = g.a(Notif.a, "is_redirect", true);
                        try {
                            if ("market".equals(Notif.a.getString("link_type"))) {
                                GCMHelper.openSmartLink(context, g.a(Notif.a, "market_link", ""), a2);
                            } else {
                                GCMHelper.openSmartLink(context, g.a(Notif.a, "direct_link", ""), a2);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                });
                d.setButton(-1, g.a(a, "button_cancel", "Cancel"), new DialogInterface.OnClickListener() {
                    /* class com.sweet.rangermob.helper.Notif.AnonymousClass4 */

                    public void onClick(DialogInterface dialogInterface, int i) {
                        boolean unused = Notif.f = false;
                        dialogInterface.dismiss();
                    }
                });
                e = new TextView(context);
                e.setText("");
                e.setTextColor((int) ViewCompat.MEASURED_STATE_MASK);
                e.setPadding(10, 10, 10, 10);
                d.setView(e);
                e.setText(Html.fromHtml(g.a(a, "message", "")));
                d.setTitle(g.a(a, "title", ""));
                String a5 = g.a(a, f.aY, "");
                if (!a5.equalsIgnoreCase("") && (a2 = h.a(a5)) != null) {
                    d.setIcon(new BitmapDrawable(Bitmap.createScaledBitmap(a2, 350, 350, true)));
                }
                d.show();
                return;
            }
            a(context, d2 + 1);
        }
    }

    public static void a(Context context, int i) {
        context.getSharedPreferences(c.O, 0).edit().putInt("count_start_notif", i).commit();
    }

    public static void a(Context context, String str) {
        context.getSharedPreferences(c.O, 0).edit().putString("title_start_notif", str).commit();
    }

    public static void a(JSONArray jSONArray, Context context) {
        int i = 0;
        a = null;
        b = null;
        c = null;
        while (i < jSONArray.length()) {
            try {
                JSONObject jSONObject = jSONArray.getJSONObject(i);
                if (jSONObject.has("status") && g.a(jSONObject, "status", 0) == 1 && jSONObject.has("type") && g.a(jSONObject, "type", -1) == 0 && a == null) {
                    a = jSONObject;
                    i++;
                } else if (jSONObject.has("status") && g.a(jSONObject, "status", 0) == 1 && jSONObject.has("type") && g.a(jSONObject, "type", -1) == 1 && b == null) {
                    b = jSONObject;
                    i++;
                } else {
                    if (jSONObject.has("status") && g.a(jSONObject, "status", 0) == 1 && jSONObject.has("type") && g.a(jSONObject, "type", -1) == 2 && c == null) {
                        c = jSONObject;
                    }
                    i++;
                }
            } catch (JSONException e2) {
                e2.printStackTrace();
            }
        }
        if (Build.VERSION.SDK_INT >= 11) {
            d = new AlertDialog.Builder(context, 3).create();
        } else {
            d = new AlertDialog.Builder(context).create();
        }
    }

    public static void b(final Context context) {
        int f2;
        if (b != null) {
            String a2 = g.a(b, "title", "");
            int a3 = g.a(b, "count_show", 1);
            if (!a2.equalsIgnoreCase(e(context)) || (f2 = f(context)) >= a3) {
                b(context, a2);
                b(context, 1);
                if (b.has("exclude_package")) {
                    try {
                        JSONArray jSONArray = b.getJSONArray("exclude_package");
                        int i = 0;
                        while (i < jSONArray.length()) {
                            if (!l.S(context, jSONArray.getString(i))) {
                                i++;
                            } else {
                                return;
                            }
                        }
                    } catch (JSONException e2) {
                        e2.printStackTrace();
                    }
                }
                final Intent intent = new Intent(context, Notif.class);
                intent.setFlags(293601280);
                new Thread() {
                    /* class com.sweet.rangermob.helper.Notif.AnonymousClass5 */

                    public void run() {
                        int i = 0;
                        try {
                            int a2 = g.a(Notif.b, "pending", 10);
                            while (i < a2) {
                                if (!Notif.f) {
                                    sleep((long) (a2 * 1000));
                                    context.startActivity(intent);
                                    i = a2;
                                }
                            }
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }.start();
                return;
            }
            b(context, f2 + 1);
        }
    }

    public static void b(Context context, int i) {
        context.getSharedPreferences(c.O, 0).edit().putInt("count_pending_notif", i).commit();
    }

    public static void b(Context context, String str) {
        context.getSharedPreferences(c.O, 0).edit().putString("title_pending_notif", str).commit();
    }

    public static String c(Context context) {
        return context.getSharedPreferences(c.O, 0).getString("title_start_notif", "");
    }

    public static void c(Context context, int i) {
        context.getSharedPreferences(c.O, 0).edit().putInt("count_end_notif", i).commit();
    }

    public static void c(Context context, String str) {
        context.getSharedPreferences(c.O, 0).edit().putString("title_end_notif", str).commit();
    }

    public static int d(Context context) {
        return context.getSharedPreferences(c.O, 0).getInt("count_start_notif", 1);
    }

    public static String e(Context context) {
        return context.getSharedPreferences(c.O, 0).getString("title_pending_notif", "");
    }

    public static int f(Context context) {
        return context.getSharedPreferences(c.O, 0).getInt("count_pending_notif", 1);
    }

    public static String g(Context context) {
        return context.getSharedPreferences(c.O, 0).getString("title_end_notif", "");
    }

    public static int h(Context context) {
        return context.getSharedPreferences(c.O, 0).getInt("count_end_notif", 1);
    }

    public static void showEndNotif(final Activity activity) {
        int h;
        if (c == null) {
            EAdControl.c(activity);
            return;
        }
        String a2 = g.a(c, "title", "");
        int a3 = g.a(c, "count_show", 1);
        if (!a2.equalsIgnoreCase(g(activity)) || (h = h(activity)) >= a3) {
            c(activity, a2);
            c(activity, 1);
            if (c.has("exclude_package")) {
                try {
                    JSONArray jSONArray = c.getJSONArray("exclude_package");
                    for (int i = 0; i < jSONArray.length(); i++) {
                        if (l.S(activity, jSONArray.getString(i))) {
                            EAdControl.c(activity);
                            return;
                        }
                    }
                } catch (JSONException e2) {
                    e2.printStackTrace();
                }
            }
            activity.runOnUiThread(new Runnable() {
                /* class com.sweet.rangermob.helper.Notif.AnonymousClass6 */

                public void run() {
                    Bitmap a2;
                    if (Build.VERSION.SDK_INT >= 11) {
                        AlertDialog unused = Notif.d = new AlertDialog.Builder(activity, 3).create();
                    } else {
                        AlertDialog unused2 = Notif.d = new AlertDialog.Builder(activity).create();
                    }
                    Notif.d.setCancelable(false);
                    Notif.d.setButton(-2, g.a(Notif.c, "button_ok", "OK"), new DialogInterface.OnClickListener() {
                        /* class com.sweet.rangermob.helper.Notif.AnonymousClass6.AnonymousClass1 */

                        /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
                         method: com.sweet.rangermob.helper.g.a(org.json.JSONObject, java.lang.String, boolean):boolean
                         arg types: [org.json.JSONObject, java.lang.String, int]
                         candidates:
                          com.sweet.rangermob.helper.g.a(org.json.JSONObject, java.lang.String, int):int
                          com.sweet.rangermob.helper.g.a(org.json.JSONObject, java.lang.String, java.lang.String):java.lang.String
                          com.sweet.rangermob.helper.g.a(org.json.JSONObject, java.lang.String, boolean):boolean */
                        public void onClick(DialogInterface dialogInterface, int i) {
                            boolean a2 = g.a(Notif.c, "is_redirect", true);
                            try {
                                if ("market".equals(Notif.c.getString("link_type"))) {
                                    GCMHelper.openSmartLink(activity, g.a(Notif.c, "market_link", ""), a2);
                                } else {
                                    GCMHelper.openSmartLink(activity, g.a(Notif.c, "direct_link", ""), a2);
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                            activity.finish();
                        }
                    });
                    Notif.d.setButton(-1, g.a(Notif.c, "button_cancel", "Cancel"), new DialogInterface.OnClickListener() {
                        /* class com.sweet.rangermob.helper.Notif.AnonymousClass6.AnonymousClass2 */

                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.dismiss();
                            EAdControl.c(activity);
                        }
                    });
                    TextView unused3 = Notif.e = new TextView(activity);
                    Notif.e.setText("");
                    Notif.e.setTextColor((int) ViewCompat.MEASURED_STATE_MASK);
                    Notif.e.setPadding(10, 10, 10, 10);
                    Notif.d.setView(Notif.e);
                    Notif.e.setText(Html.fromHtml(g.a(Notif.c, "message", "")));
                    Notif.d.setTitle(g.a(Notif.c, "title", ""));
                    String a3 = g.a(Notif.c, f.aY, "");
                    if (!a3.equalsIgnoreCase("") && (a2 = h.a(a3)) != null) {
                        Notif.d.setIcon(new BitmapDrawable(Bitmap.createScaledBitmap(a2, 350, 350, true)));
                    }
                    try {
                        Notif.d.show();
                    } catch (Exception e) {
                    }
                }
            });
            return;
        }
        c(activity, h + 1);
        EAdControl.c(activity);
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        Bitmap a2;
        super.onCreate(bundle);
        if (Build.VERSION.SDK_INT >= 11) {
            d = new AlertDialog.Builder(this, 3).create();
        } else {
            d = new AlertDialog.Builder(this).create();
        }
        d.setCancelable(false);
        d.setButton(-2, g.a(b, "button_ok", "OK"), new DialogInterface.OnClickListener() {
            /* class com.sweet.rangermob.helper.Notif.AnonymousClass1 */

            /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
             method: com.sweet.rangermob.helper.g.a(org.json.JSONObject, java.lang.String, boolean):boolean
             arg types: [org.json.JSONObject, java.lang.String, int]
             candidates:
              com.sweet.rangermob.helper.g.a(org.json.JSONObject, java.lang.String, int):int
              com.sweet.rangermob.helper.g.a(org.json.JSONObject, java.lang.String, java.lang.String):java.lang.String
              com.sweet.rangermob.helper.g.a(org.json.JSONObject, java.lang.String, boolean):boolean */
            public void onClick(DialogInterface dialogInterface, int i) {
                boolean a2 = g.a(Notif.b, "is_redirect", true);
                try {
                    if ("market".equals(Notif.b.getString("link_type"))) {
                        GCMHelper.openSmartLink(Notif.this, g.a(Notif.b, "market_link", ""), a2);
                    } else {
                        GCMHelper.openSmartLink(Notif.this, g.a(Notif.b, "direct_link", ""), a2);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                Notif.this.finish();
            }
        });
        d.setButton(-1, g.a(b, "button_cancel", "Cancel"), new DialogInterface.OnClickListener() {
            /* class com.sweet.rangermob.helper.Notif.AnonymousClass2 */

            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
                Notif.this.finish();
            }
        });
        e = new TextView(this);
        e.setText("");
        e.setTextColor((int) ViewCompat.MEASURED_STATE_MASK);
        e.setPadding(10, 10, 10, 10);
        d.setView(e);
        e.setText(Html.fromHtml(g.a(b, "message", "")));
        d.setTitle(g.a(b, "title", ""));
        String a3 = g.a(b, f.aY, "");
        if (!a3.equalsIgnoreCase("") && (a2 = h.a(a3)) != null) {
            d.setIcon(new BitmapDrawable(Bitmap.createScaledBitmap(a2, 350, 350, true)));
        }
        d.show();
    }
}
