package com.ironsource.mobilcore;

import android.text.TextUtils;
import com.android.common.speech.LoggingEvents;
import com.ironsource.mobilcore.aF;
import com.ironsource.mobilcore.aS;
import com.ironsource.mobilcore.aT;
import com.keyboard.common.remotemodule.core.zero.data.ZeroUrlFactory;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.Arrays;
import java.util.HashMap;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* renamed from: com.ironsource.mobilcore.t  reason: case insensitive filesystem */
final class C0282t {
    private static C0282t a;
    private String b;
    private String c;
    private HashMap d = new HashMap();

    /* renamed from: com.ironsource.mobilcore.t$a */
    public interface a {
        void a(JSONObject jSONObject);
    }

    private C0282t() {
        File file = new File(MobileCore.c().getFilesDir().getPath(), "cached_feeds");
        if (!file.exists()) {
            file.mkdirs();
        }
        this.b = file.getAbsolutePath();
        File file2 = new File(MobileCore.c().getFilesDir().getPath(), "cached_media");
        if (!file2.exists()) {
            file2.mkdirs();
        }
        this.c = file2.getAbsolutePath();
    }

    public static C0282t a() {
        if (a == null) {
            a = new C0282t();
        }
        return a;
    }

    private static JSONArray a(JSONObject jSONObject, String... strArr) {
        JSONArray jSONArray = new JSONArray();
        JSONArray optJSONArray = jSONObject.optJSONArray(ZeroUrlFactory.ZERO_API_TYPE_GET_ADS);
        for (int i = 0; i < optJSONArray.length(); i++) {
            JSONObject optJSONObject = optJSONArray.optJSONObject(i);
            String optString = optJSONObject.optString("img");
            if (!TextUtils.isEmpty(optString)) {
                jSONArray.put(aT.a(optString));
            }
            JSONArray optJSONArray2 = optJSONObject.optJSONArray("extra");
            if (optJSONArray2 != null) {
                for (int i2 = 0; i2 < optJSONArray2.length(); i2++) {
                    JSONObject optJSONObject2 = optJSONArray2.optJSONObject(i2);
                    try {
                        String string = optJSONObject2.getString(LoggingEvents.VoiceSearch.EXTRA_QUERY_UPDATED_VALUE);
                        if ("img".equalsIgnoreCase(optJSONObject2.getString("type"))) {
                            if ((strArr == null || strArr.length <= 0) ? true : !Arrays.asList(strArr).contains(optJSONObject2.getString("imgtype"))) {
                                jSONArray.put(aT.a(string));
                            }
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        return jSONArray;
    }

    private static boolean a(JSONObject jSONObject, long j, String str) {
        try {
            return System.currentTimeMillis() - j > jSONObject.getJSONObject("expirations").getLong(str);
        } catch (JSONException e) {
            return false;
        }
    }

    private JSONObject d(String str) {
        B.a(getClass().getName() + "| loadFeedFromCache | " + str, 55);
        try {
            File file = new File(this.b, String.format("cache_%s.json", str));
            FileInputStream fileInputStream = new FileInputStream(file);
            String a2 = aF.a((InputStream) fileInputStream);
            fileInputStream.close();
            JSONObject jSONObject = new JSONObject(a2);
            if (!a(jSONObject, file.lastModified(), "hard_expiration")) {
                return jSONObject;
            }
            B.a(getClass().getName() + "| loadFeedFromCache | feed is expired", 55);
            return null;
        } catch (JSONException e) {
            aK.a(aS.b.REPORT_TYPE_ERROR).a(e).a();
            return null;
        } catch (Exception e2) {
            return null;
        }
    }

    public final void a(String str) {
        this.d.put(str, d(str));
    }

    public final void a(String str, String str2) {
        B.a(getClass().getName() + "| cacheFeed | " + str, 55);
        try {
            aF.a(new ByteArrayInputStream(str2.getBytes(Charset.defaultCharset())), this.b, String.format("cache_%s.json", str));
            this.d.put(str, new JSONObject(str2));
        } catch (IOException e) {
            aK.a(aS.b.REPORT_TYPE_ERROR).a(e).a();
        } catch (JSONException e2) {
            e2.printStackTrace();
        }
    }

    public final void a(JSONObject jSONObject, aF.d dVar, String... strArr) {
        try {
            aT.a aVar = new aT.a(dVar);
            JSONArray a2 = a(jSONObject, strArr);
            String str = this.c;
            for (int i = 0; i < a2.length(); i++) {
                JSONObject jSONObject2 = a2.getJSONObject(i);
                if (!new File(str + "/" + jSONObject2.getString("filename")).exists()) {
                    aVar.a(jSONObject2);
                }
            }
            aVar.b(str);
        } catch (Exception e) {
            aK.a(aS.b.REPORT_TYPE_ERROR).a(e).a();
        }
    }

    public final String b() {
        return this.c;
    }

    public final JSONObject b(String str) {
        return (JSONObject) this.d.get(str);
    }

    public final boolean c(String str) {
        B.a(getClass().getName() + "| loadFeedFromCache | " + str, 55);
        JSONObject jSONObject = (JSONObject) this.d.get(str);
        if (jSONObject == null) {
            return false;
        }
        return !a(jSONObject, new File(this.b, String.format("cache_%s.json", new Object[]{str})).lastModified(), "soft_expiration");
    }
}
