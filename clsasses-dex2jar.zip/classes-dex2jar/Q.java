package com.ironsource.mobilcore;

import android.content.Context;
import android.view.View;

final class Q extends R {
    public Q(Context context, C0261ax axVar) {
        super(context, axVar);
    }

    @Override // com.ironsource.mobilcore.H
    public final String a() {
        return "ironsourceOfferWallOpener";
    }

    /* access modifiers changed from: protected */
    @Override // com.ironsource.mobilcore.H, com.ironsource.mobilcore.I
    public final void a(View view) {
        super.a(view);
        MobileCore.showInterstitial(this.e, null);
    }
}
