package com.ironsource.mobilcore;

import android.content.Context;
import android.view.ViewConfiguration;
import android.view.animation.AnimationUtils;
import android.view.animation.BounceInterpolator;
import android.view.animation.Interpolator;

/* renamed from: com.ironsource.mobilcore.ap  reason: case insensitive filesystem */
final class C0253ap {
    private static final float t = ((float) (Math.log(0.75d) / Math.log(0.9d)));

    /* renamed from: u  reason: collision with root package name */
    private static final float[] f7u = new float[101];
    private static float x = 8.0f;
    private static float y;
    private int a;
    private int b;
    private int c;
    private int d;
    private int e;
    private int f;
    private int g;
    private int h;
    private int i;
    private int j;
    private int k;
    private long l;
    private int m;
    private float n;
    private float o;
    private float p;
    private boolean q;
    private Interpolator r;
    private boolean s;
    private float v;
    private final float w;

    static {
        float f2;
        float f3;
        float f4 = 0.0f;
        int i2 = 0;
        while (i2 <= 100) {
            float f5 = ((float) i2) / 100.0f;
            float f6 = 1.0f;
            float f7 = f4;
            while (true) {
                f2 = ((f6 - f7) / 2.0f) + f7;
                f3 = 3.0f * f2 * (1.0f - f2);
                float f8 = ((((1.0f - f2) * 0.4f) + (0.6f * f2)) * f3) + (f2 * f2 * f2);
                if (((double) Math.abs(f8 - f5)) < 1.0E-5d) {
                    break;
                } else if (f8 > f5) {
                    f6 = f2;
                } else {
                    f7 = f2;
                }
            }
            f7u[i2] = (f2 * f2 * f2) + f3;
            i2++;
            f4 = f7;
        }
        f7u[100] = 1.0f;
        y = 1.0f;
        y = 1.0f / a(1.0f);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public C0253ap(Context context, Interpolator interpolator) {
        this(context, interpolator, context.getApplicationInfo().targetSdkVersion >= 11);
    }

    private C0253ap(Context context, Interpolator interpolator, boolean z) {
        this.q = true;
        this.r = interpolator;
        this.w = context.getResources().getDisplayMetrics().density * 160.0f;
        this.v = ViewConfiguration.getScrollFriction() * 386.0878f * this.w;
        this.s = z;
    }

    private static float a(float f2) {
        float f3 = x * f2;
        return (f3 < 1.0f ? f3 - (1.0f - ((float) Math.exp((double) (-f3)))) : ((1.0f - ((float) Math.exp((double) (1.0f - f3)))) * 0.63212055f) + 0.36787945f) * y;
    }

    public final void a(int i2, int i3, int i4, int i5, int i6) {
        this.a = 0;
        this.q = false;
        this.m = i6;
        this.l = AnimationUtils.currentAnimationTimeMillis();
        this.b = i2;
        this.c = i3;
        this.d = i2 + i4;
        this.e = i3 + i5;
        this.o = (float) i4;
        this.p = (float) i5;
        this.n = 1.0f / ((float) this.m);
    }

    public final boolean a() {
        return this.q;
    }

    public final int b() {
        return this.j;
    }

    public final void b(int i2, int i3, int i4, int i5, int i6) {
        a(i2, 0, i4, 0, 1000);
        this.a = 2;
    }

    public final int c() {
        return this.d;
    }

    public final boolean d() {
        if (this.q) {
            return false;
        }
        int currentAnimationTimeMillis = (int) (AnimationUtils.currentAnimationTimeMillis() - this.l);
        if (currentAnimationTimeMillis < this.m) {
            switch (this.a) {
                case 0:
                    float f2 = ((float) currentAnimationTimeMillis) * this.n;
                    float a2 = this.r == null ? a(f2) : this.r.getInterpolation(f2);
                    this.j = this.b + Math.round(this.o * a2);
                    this.k = Math.round(a2 * this.p) + this.c;
                    break;
                case 1:
                    float f3 = ((float) currentAnimationTimeMillis) / ((float) this.m);
                    int i2 = (int) (100.0f * f3);
                    float f4 = ((float) i2) / 100.0f;
                    float f5 = f7u[i2];
                    float f6 = (((f3 - f4) / ((((float) (i2 + 1)) / 100.0f) - f4)) * (f7u[i2 + 1] - f5)) + f5;
                    this.j = this.b + Math.round(((float) (this.d - this.b)) * f6);
                    this.j = Math.min(this.j, this.g);
                    this.j = Math.max(this.j, this.f);
                    this.k = Math.round(f6 * ((float) (this.e - this.c))) + this.c;
                    this.k = Math.min(this.k, this.i);
                    this.k = Math.max(this.k, this.h);
                    if (this.j == this.d && this.k == this.e) {
                        this.q = true;
                        break;
                    }
                case 2:
                    float interpolation = new BounceInterpolator().getInterpolation(((float) currentAnimationTimeMillis) * this.n);
                    this.j = this.b + Math.round(this.o * interpolation);
                    this.k = Math.round(interpolation * this.p) + this.c;
                    break;
            }
        } else {
            this.j = this.d;
            this.k = this.e;
            this.q = true;
        }
        return true;
    }

    public final void e() {
        this.j = this.d;
        this.k = this.e;
        this.q = true;
    }
}
