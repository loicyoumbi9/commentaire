package com.ironsource.mobilcore;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Build;
import android.text.TextUtils;
import android.widget.Toast;
import com.ironsource.mobilcore.AdUnitEventListener;
import com.ironsource.mobilcore.C0274l;
import com.ironsource.mobilcore.C0276n;
import com.ironsource.mobilcore.C0280r;
import com.ironsource.mobilcore.CallbackResponse;
import com.ironsource.mobilcore.J;
import com.ironsource.mobilcore.MobileCore;
import com.ironsource.mobilcore.aF;
import com.ironsource.mobilcore.aS;
import com.ironsource.mobilcore.aU;
import java.io.File;
import java.net.URLEncoder;
import java.util.Arrays;
import java.util.Comparator;
import org.json.JSONArray;
import org.json.JSONObject;

/* renamed from: com.ironsource.mobilcore.y  reason: case insensitive filesystem */
final class C0287y extends C0274l implements aU.a, C0276n.a {
    private static C0287y r;
    /* access modifiers changed from: private */
    public b g;
    /* access modifiers changed from: private */
    public aU h;
    /* access modifiers changed from: private */
    public boolean i;
    private String j;
    private String k;
    /* access modifiers changed from: private */
    public String l;
    /* access modifiers changed from: private */
    public String m;
    /* access modifiers changed from: private */
    public boolean n;
    private Runnable o;
    /* access modifiers changed from: private */
    public C0270h p;
    /* access modifiers changed from: private */
    public JSONObject q;
    /* access modifiers changed from: private */
    public OnReadyListener s;

    /* renamed from: com.ironsource.mobilcore.y$a */
    private enum a implements C0274l.d {
        INIT("init"),
        SHOW("show"),
        VISIBLE("visible");
        
        private String d;

        private a(String str) {
            this.d = str;
        }

        @Override // com.ironsource.mobilcore.C0274l.d
        public final String a() {
            return this.d;
        }
    }

    /* renamed from: com.ironsource.mobilcore.y$b */
    private enum b {
        NOT_INIT,
        LOADING,
        ERROR,
        READY_TO_SHOW,
        SHOWING
    }

    /* renamed from: com.ironsource.mobilcore.y$c */
    final class c {
        private c() {
        }

        /* synthetic */ c(C0287y yVar, byte b) {
            this();
        }

        public final void a(A a2) {
            a2.a(new e(a2));
        }
    }

    /* renamed from: com.ironsource.mobilcore.y$d */
    private final class d extends C0275m {
        public d() {
        }

        public final void cacheFeed(String str) {
            C0287y.this.a("JSFlowBridge , cacheFeed");
            String unused = C0287y.this.l = str;
        }

        public final void init(String str, String str2) {
            C0287y.this.a("JSFlowBridge , init", "flow:" + str + " , flowName:" + str2);
            C0287y.this.c = str2;
            C0287y.this.b = str;
        }

        public final void loadOfferwallUrl(String str, String str2) {
            String unused = C0287y.this.m = str2;
            C0287y.this.a("JSFlowBridge , loadOfferwallUrl", "check if already loading a url:" + (!C0287y.this.p.b(str)) + " , url:" + str);
        }

        public final void openReport(String str, String str2) {
            C0287y.this.h.b(str, str2);
        }

        public final void openReportOffers(String str, String str2) {
            try {
                aK.a(aS.b.REPORT_TYPE_RES).a(C0287y.this.b, C0287y.this.b).a(str).a(new JSONArray(str2)).a();
            } catch (Exception e) {
                aK.a(aS.b.REPORT_TYPE_ERROR).a(e).a();
            }
        }

        public final void setNotReadyParams(long j, int i, Double d, boolean z) {
            B.a("InterstitialManager | frequency control | JSFlowBridge | setNotReadyParams | secondsBetweenShows=" + j, 55);
            B.a("InterstitialManager | frequency control | JSFlowBridge | setNotReadyParams | maxNumberOfShows=" + i, 55);
            B.a("InterstitialManager | frequency control | JSFlowBridge | setNotReadyParams | daysCooldown=" + d, 55);
            B.a("InterstitialManager | frequency control | JSFlowBridge | setNotReadyParams | selectiveShow=" + z, 55);
            C0284v.a(MobileCore.AD_UNITS.INTERSTITIAL, j);
            C0284v.a(MobileCore.AD_UNITS.INTERSTITIAL, i);
            C0284v.a(MobileCore.AD_UNITS.INTERSTITIAL, d.floatValue());
            C0284v.a(MobileCore.AD_UNITS.INTERSTITIAL, z);
        }

        public final void show() {
            C0287y.this.a("JSFlowBridge , show");
            C0287y.this.h.b();
            C0284v.b(MobileCore.AD_UNITS.INTERSTITIAL);
            C0287y.this.i();
        }
    }

    /* renamed from: com.ironsource.mobilcore.y$e */
    private final class e extends C0276n {
        protected String a;
        private A c;

        public e(A a2) {
            super(C0287y.this);
            this.c = a2;
        }

        /* access modifiers changed from: private */
        public void a(Boolean bool, String str) {
            C0287y.this.a("JSInterstitialBridge , prepareVideo, notifyVideoDone");
            try {
                String string = new JSONObject(str).getString("preparedCallback");
                C0287y.this.a("JSInterstitialBridge , prepareVideo, calling " + string);
                aF.a(this.c, string + "(" + bool.toString() + ");");
            } catch (Exception e) {
                handleErrorState();
                aK.a(aS.b.REPORT_TYPE_ERROR).a(e).a();
            }
        }

        @Override // com.ironsource.mobilcore.C0276n
        public final String getFallbackOfferwallJson() {
            C0287y.this.a("JSInterstitialBridge , getFallbackOfferwallJson");
            return C0287y.this.q == null ? "" : C0287y.this.q.toString();
        }

        @Override // com.ironsource.mobilcore.C0276n
        public final String getOfferwallJson() {
            C0287y.this.a("JSInterstitialBridge, getOfferwallJson json: " + C0287y.this.l);
            return C0287y.this.l;
        }

        @Override // com.ironsource.mobilcore.C0276n
        public final void handleErrorState() {
            this.c.a();
        }

        public final void playVideo(String str, String str2, String str3) {
            if (Build.VERSION.SDK_INT < 14) {
                C0287y.this.a("JSInterstitialBridge , video not supported under 4.0");
                return;
            }
            B.a("JSInterstitialBridge | playVideo " + str, 55);
            File file = new File(this.a + "/" + str);
            if (file.exists()) {
                B.a("JSInterstitialBridge | playVideo is loaded!", 55);
                InterstitialVideoActivity.a(C0287y.this.a, file.getAbsolutePath(), str2, str3);
                return;
            }
            B.a("JSInterstitialBridge | video file not found", 55);
            aK.a(aS.b.REPORT_TYPE_ERROR).b("Video file " + file.getName() + " not found").a();
        }

        /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
         method: com.ironsource.mobilcore.y.e.a(java.lang.Boolean, java.lang.String):void
         arg types: [int, java.lang.String]
         candidates:
          com.ironsource.mobilcore.n.a(java.lang.String, java.lang.String):void
          com.ironsource.mobilcore.y.e.a(java.lang.Boolean, java.lang.String):void */
        public final void prepareVideo(final String str) {
            if (Build.VERSION.SDK_INT < 14) {
                a((Boolean) false, str);
                C0287y.this.a("JSInterstitialBridge , video not supported under 4.0");
                return;
            }
            C0287y.this.a("JSInterstitialBridge , prepareVideo, going to download");
            try {
                final JSONObject jSONObject = new JSONObject(str);
                jSONObject.getJSONArray("data");
                if (this.a == null) {
                    this.a = C0287y.this.d + "/videos";
                    File file = new File(this.a);
                    if (!file.exists()) {
                        file.mkdir();
                    }
                }
                aT.a(jSONObject, this.a, this.a, new aF.d() {
                    /* class com.ironsource.mobilcore.C0287y.e.AnonymousClass1 */

                    @Override // com.ironsource.mobilcore.aF.d
                    public final void a(boolean z) {
                        File[] listFiles;
                        C0287y.this.a("JSInterstitialBridge , prepareVideo, allComplete");
                        if (z) {
                            e.this.a(Boolean.valueOf(z), str);
                            File file = new File(e.this.a);
                            if (file.exists() && (listFiles = file.listFiles()) != null) {
                                C0287y.this.a("JSInterstitialBridge , clearOldVideos, folder " + file + " has " + listFiles.length + " files");
                                Arrays.sort(listFiles, new Comparator() {
                                    /* class com.ironsource.mobilcore.C0287y.e.AnonymousClass1.AnonymousClass1 */

                                    @Override // java.util.Comparator
                                    public final /* synthetic */ int compare(Object obj, Object obj2) {
                                        return Long.valueOf(((File) obj2).lastModified()).compareTo(Long.valueOf(((File) obj).lastModified()));
                                    }
                                });
                                for (int optInt = jSONObject.optInt("cache_num", 3); optInt < listFiles.length; optInt++) {
                                    C0287y.this.a("JSInterstitialBridge , clearOldVideos, deleting " + listFiles[optInt].getName());
                                    listFiles[optInt].delete();
                                }
                                return;
                            }
                            return;
                        }
                        e.this.handleErrorState();
                    }
                });
            } catch (Exception e) {
                C0287y.this.a("JSInterstitialBridge , prepareVideo, failed to download video");
                aK.a(aS.b.REPORT_TYPE_ERROR).a(e).a();
            }
        }

        /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
         method: com.ironsource.mobilcore.y.a(com.ironsource.mobilcore.y, boolean):boolean
         arg types: [com.ironsource.mobilcore.y, int]
         candidates:
          com.ironsource.mobilcore.y.a(com.ironsource.mobilcore.y, com.ironsource.mobilcore.OnReadyListener):com.ironsource.mobilcore.OnReadyListener
          com.ironsource.mobilcore.y.a(com.ironsource.mobilcore.y, java.lang.String):java.lang.String
          com.ironsource.mobilcore.y.a(com.ironsource.mobilcore.CallbackResponse, java.lang.String):void
          com.ironsource.mobilcore.y.a(com.ironsource.mobilcore.y, com.ironsource.mobilcore.y$b):void
          com.ironsource.mobilcore.l.a(com.ironsource.mobilcore.l$d, java.lang.String):void
          com.ironsource.mobilcore.l.a(java.lang.String, java.lang.String):void
          com.ironsource.mobilcore.y.a(com.ironsource.mobilcore.y, boolean):boolean */
        /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
         method: com.ironsource.mobilcore.y.b(com.ironsource.mobilcore.y, boolean):boolean
         arg types: [com.ironsource.mobilcore.y, int]
         candidates:
          com.ironsource.mobilcore.y.b(com.ironsource.mobilcore.y, java.lang.String):java.lang.String
          com.ironsource.mobilcore.l.b(java.lang.String, java.lang.String):void
          com.ironsource.mobilcore.y.b(com.ironsource.mobilcore.y, boolean):boolean */
        @Override // com.ironsource.mobilcore.C0276n
        public final void ready(boolean z) {
            C0287y.this.a("JSInterstitialBridge , ready");
            if (C0287y.this.g == b.LOADING || C0287y.this.g == b.ERROR) {
                C0287y.this.a(b.READY_TO_SHOW);
                if (C0287y.this.n) {
                    boolean unused = C0287y.this.n = false;
                    C0271i.a();
                    if (!C0284v.c(MobileCore.AD_UNITS.INTERSTITIAL)) {
                        C0287y.this.h.b();
                        C0284v.b(MobileCore.AD_UNITS.INTERSTITIAL);
                    }
                    C0287y.this.p();
                }
            }
            if (!z) {
                if (!C0287y.this.i) {
                    C0287y.this.a("JSInterstitialBridge , ready", "setting mReadyToShowFromFlow to true");
                    boolean unused2 = C0287y.this.i = true;
                    C0287y.this.o();
                }
                aR.a(C0280r.a.INTERSTITIAL_TIME_TO_READY, new J.a[0]);
            }
            this.c.clearHistory();
            if (this.c != null) {
                this.c.b(true);
            }
        }
    }

    private C0287y() {
        a(b.NOT_INIT);
    }

    /* access modifiers changed from: private */
    public void a(CallbackResponse callbackResponse, String str) {
        Toast.makeText(this.a, "There was an error", 1).show();
        if (callbackResponse != null) {
            callbackResponse.onConfirmation(CallbackResponse.TYPE.INTERSTITIAL_SHOW_ERROR);
        }
        aK.a(aS.b.REPORT_TYPE_ERROR).b(str).a();
    }

    /* access modifiers changed from: private */
    public void a(b bVar) {
        synchronized (this) {
            a("setState", "from:" + this.g + " , to:" + bVar);
            this.g = bVar;
        }
    }

    public static C0287y j() {
        C0287y yVar;
        synchronized (C0287y.class) {
            try {
                if (r == null) {
                    r = new C0287y();
                }
                yVar = r;
            } catch (Throwable th) {
                throw th;
            }
        }
        return yVar;
    }

    /* access modifiers changed from: private */
    public void o() {
        synchronized (this) {
            long j2 = 0;
            if (C0284v.c(MobileCore.AD_UNITS.INTERSTITIAL)) {
                j2 = C0284v.d(MobileCore.AD_UNITS.INTERSTITIAL);
            }
            MobileCore.b().postDelayed(new Runnable() {
                /* class com.ironsource.mobilcore.C0287y.AnonymousClass1 */

                /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
                 method: com.ironsource.mobilcore.v.b(com.ironsource.mobilcore.MobileCore$AD_UNITS, boolean):boolean
                 arg types: [com.ironsource.mobilcore.MobileCore$AD_UNITS, int]
                 candidates:
                  com.ironsource.mobilcore.v.b(com.ironsource.mobilcore.MobileCore$AD_UNITS, int):void
                  com.ironsource.mobilcore.v.b(com.ironsource.mobilcore.MobileCore$AD_UNITS, boolean):boolean */
                /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
                 method: com.ironsource.mobilcore.aF.a(com.ironsource.mobilcore.MobileCore$AD_UNITS, boolean):void
                 arg types: [com.ironsource.mobilcore.MobileCore$AD_UNITS, int]
                 candidates:
                  com.ironsource.mobilcore.aF.a(float, android.content.Context):int
                  com.ironsource.mobilcore.aF.a(java.lang.String, java.lang.reflect.Method):com.ironsource.mobilcore.aL
                  com.ironsource.mobilcore.aF.a(java.lang.Exception, java.lang.String):java.lang.String
                  com.ironsource.mobilcore.aF.a(java.lang.reflect.Method, boolean):java.lang.String
                  com.ironsource.mobilcore.aF.a(android.os.AsyncTask, java.lang.Object[]):void
                  com.ironsource.mobilcore.aF.a(android.webkit.WebView, android.webkit.WebChromeClient):void
                  com.ironsource.mobilcore.aF.a(android.webkit.WebView, java.lang.String):void
                  com.ironsource.mobilcore.aF.a(java.lang.String, int):void
                  com.ironsource.mobilcore.aF.a(java.lang.String, long):void
                  com.ironsource.mobilcore.aF.a(java.lang.String, boolean):void
                  com.ironsource.mobilcore.aF.a(android.content.Context, java.lang.String):boolean
                  com.ironsource.mobilcore.aF.a(com.ironsource.mobilcore.MobileCore$AD_UNITS, boolean):void */
                public final void run() {
                    B.a("InterstitialManager | notifyReadyToListener | cooldown ended, about to notify listener", 55);
                    if (!C0284v.b(MobileCore.AD_UNITS.INTERSTITIAL, true)) {
                        if (aF.a(MobileCore.AD_UNITS.INTERSTITIAL)) {
                            aF.a(MobileCore.AD_UNITS.INTERSTITIAL, false);
                            MobileCore.a(MobileCore.AD_UNITS.INTERSTITIAL, AdUnitEventListener.EVENT_TYPE.AD_UNIT_READY);
                        }
                        if (C0287y.this.s != null) {
                            C0287y.this.s.onReady(MobileCore.AD_UNITS.INTERSTITIAL);
                            OnReadyListener unused = C0287y.this.s = null;
                            return;
                        }
                        return;
                    }
                    B.a("InterstitialManager | notifyReadyToListener | not notifying listener duo to not ready state", 55);
                }
            }, j2);
        }
    }

    /* access modifiers changed from: private */
    public void p() {
        if (this.o != null) {
            MobileCore.b().removeCallbacks(this.o);
            this.o = null;
        }
    }

    private String q() {
        String string = aF.d().getString("offerwall-cached-url", "");
        if (TextUtils.isEmpty(string)) {
            return "http://os.scmpacdn.com/files/mobile/0.9.2/offerwall_site/fallback/?sdk=1&fallback=1&ts=" + System.currentTimeMillis();
        }
        this.q = C0282t.a().b("offerwall-feed");
        return string + "&fallback=1";
    }

    /* access modifiers changed from: private */
    public void r() {
        if (!n()) {
            a("InterstititalManager", "Setting error state - is ready is false!");
            a(b.ERROR);
            C0271i.a();
        }
    }

    /* JADX INFO: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: com.ironsource.mobilcore.v.b(com.ironsource.mobilcore.MobileCore$AD_UNITS, boolean):boolean
     arg types: [com.ironsource.mobilcore.MobileCore$AD_UNITS, int]
     candidates:
      com.ironsource.mobilcore.v.b(com.ironsource.mobilcore.MobileCore$AD_UNITS, int):void
      com.ironsource.mobilcore.v.b(com.ironsource.mobilcore.MobileCore$AD_UNITS, boolean):boolean */
    public final void a(Activity activity, final CallbackResponse callbackResponse, MobileCore.AD_UNIT_SHOW_TRIGGER ad_unit_show_trigger) {
        MobileCore.AD_UNIT_SHOW_TRIGGER ad_unit_show_trigger2 = ad_unit_show_trigger == null ? MobileCore.AD_UNIT_SHOW_TRIGGER.NOT_SET : ad_unit_show_trigger;
        switch (this.g) {
            case NOT_INIT:
                if (callbackResponse != null) {
                    callbackResponse.onConfirmation(CallbackResponse.TYPE.INTERSTITIAL_NOT_READY);
                }
                a(callbackResponse, "showInterstitial called when in error state");
                b("showInterstitial", "Trying to show interstitial when not init.");
                return;
            case ERROR:
                this.p.a(q());
                b("showInterstitial", "Error showing interstitial. Trying to show again.");
                break;
            case LOADING:
                break;
            case SHOWING:
                if (callbackResponse != null) {
                    callbackResponse.onConfirmation(CallbackResponse.TYPE.INTERSTITIAL_ALREADY_SHOWING);
                    return;
                }
                return;
            case READY_TO_SHOW:
                if (!C0284v.b(MobileCore.AD_UNITS.INTERSTITIAL, true)) {
                    if (this.h != null) {
                        this.h.a();
                    }
                    boolean n2 = n();
                    if (!TextUtils.isEmpty(this.m)) {
                        this.b = this.m;
                        this.m = null;
                    }
                    String str = n2 ? this.b : this.k;
                    String str2 = n2 ? this.c : this.j;
                    A a2 = this.p.a();
                    if (a2 != null) {
                        this.h = new aU(activity, a2, str2, str, callbackResponse, this, ad_unit_show_trigger2);
                        if (n2) {
                            SharedPreferences.Editor edit = aF.d().edit();
                            edit.putString("offerwallPrefFallbackFlowType", this.b);
                            edit.putString("offerwallPrefFallbackFlowName", this.c);
                            edit.putString("offerwall-cached-url", a2.getUrl());
                            edit.commit();
                            if (!TextUtils.isEmpty(this.l)) {
                                C0282t.a().a("offerwall-feed", this.l);
                            }
                            a(a.SHOW);
                            return;
                        }
                        this.h.b();
                        C0284v.b(MobileCore.AD_UNITS.INTERSTITIAL);
                        i();
                        return;
                    } else if (callbackResponse != null) {
                        callbackResponse.onConfirmation(CallbackResponse.TYPE.INTERSTITIAL_SHOW_ERROR);
                        return;
                    } else {
                        return;
                    }
                } else if (callbackResponse != null) {
                    callbackResponse.onConfirmation(CallbackResponse.TYPE.INTERSTITIAL_NOT_READY);
                    return;
                } else {
                    return;
                }
            default:
                return;
        }
        if (!C0284v.b(MobileCore.AD_UNITS.INTERSTITIAL, true)) {
            if (this.h != null) {
                this.h.a();
            }
            A a3 = this.p.a();
            if (a3 != null) {
                this.h = new aU(activity, a3, this.j, this.k, callbackResponse, this, ad_unit_show_trigger2);
                this.n = true;
                C0271i.a(activity);
                p();
                this.o = new Runnable() {
                    /* class com.ironsource.mobilcore.C0287y.AnonymousClass2 */

                    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
                     method: com.ironsource.mobilcore.y.a(com.ironsource.mobilcore.y, boolean):boolean
                     arg types: [com.ironsource.mobilcore.y, int]
                     candidates:
                      com.ironsource.mobilcore.y.a(com.ironsource.mobilcore.y, com.ironsource.mobilcore.OnReadyListener):com.ironsource.mobilcore.OnReadyListener
                      com.ironsource.mobilcore.y.a(com.ironsource.mobilcore.y, java.lang.String):java.lang.String
                      com.ironsource.mobilcore.y.a(com.ironsource.mobilcore.CallbackResponse, java.lang.String):void
                      com.ironsource.mobilcore.y.a(com.ironsource.mobilcore.y, com.ironsource.mobilcore.y$b):void
                      com.ironsource.mobilcore.l.a(com.ironsource.mobilcore.l$d, java.lang.String):void
                      com.ironsource.mobilcore.l.a(java.lang.String, java.lang.String):void
                      com.ironsource.mobilcore.y.a(com.ironsource.mobilcore.y, boolean):boolean */
                    public final void run() {
                        if (C0287y.this.n) {
                            boolean unused = C0287y.this.n = false;
                            C0271i.a();
                            C0287y.this.r();
                            C0287y.this.a(callbackResponse, "Got fallback interstitial timeout");
                        }
                    }
                };
                MobileCore.b().postDelayed(this.o, 10000);
            } else if (callbackResponse != null) {
                callbackResponse.onConfirmation(CallbackResponse.TYPE.INTERSTITIAL_SHOW_ERROR);
            }
        } else if (callbackResponse != null) {
            callbackResponse.onConfirmation(CallbackResponse.TYPE.INTERSTITIAL_NOT_READY);
        }
    }

    public final void a(OnReadyListener onReadyListener) {
        synchronized (this) {
            a("setOnReadyListener");
            this.s = onReadyListener;
        }
    }

    /* access modifiers changed from: protected */
    @Override // com.ironsource.mobilcore.C0274l
    public final boolean a() {
        return this.g == b.NOT_INIT;
    }

    /* access modifiers changed from: protected */
    @Override // com.ironsource.mobilcore.C0274l
    public final C0274l.a b() {
        return new C0274l.a(MobileCore.AD_UNITS.INTERSTITIAL, "offerWall", "offerwall", "offerwall-feed", a.INIT, new d());
    }

    @Override // com.ironsource.mobilcore.aU.a
    public final void b(Activity activity, JSONObject jSONObject, String str, String str2, C0274l.c cVar) {
        a(activity, jSONObject, str, str2, cVar);
    }

    @Override // com.ironsource.mobilcore.aU.a
    public final void b(String str) {
        if (!TextUtils.isEmpty(str)) {
            try {
                a(a.VISIBLE, "appId=" + URLEncoder.encode(str, "UTF-8"));
            } catch (Exception e2) {
                aK.a(aS.b.REPORT_TYPE_ERROR).a(e2).a();
            }
        }
    }

    @Override // com.ironsource.mobilcore.C0276n.a
    public final aU c() {
        return this.h;
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: com.ironsource.mobilcore.aF.a(com.ironsource.mobilcore.MobileCore$AD_UNITS, boolean):void
     arg types: [com.ironsource.mobilcore.MobileCore$AD_UNITS, int]
     candidates:
      com.ironsource.mobilcore.aF.a(float, android.content.Context):int
      com.ironsource.mobilcore.aF.a(java.lang.String, java.lang.reflect.Method):com.ironsource.mobilcore.aL
      com.ironsource.mobilcore.aF.a(java.lang.Exception, java.lang.String):java.lang.String
      com.ironsource.mobilcore.aF.a(java.lang.reflect.Method, boolean):java.lang.String
      com.ironsource.mobilcore.aF.a(android.os.AsyncTask, java.lang.Object[]):void
      com.ironsource.mobilcore.aF.a(android.webkit.WebView, android.webkit.WebChromeClient):void
      com.ironsource.mobilcore.aF.a(android.webkit.WebView, java.lang.String):void
      com.ironsource.mobilcore.aF.a(java.lang.String, int):void
      com.ironsource.mobilcore.aF.a(java.lang.String, long):void
      com.ironsource.mobilcore.aF.a(java.lang.String, boolean):void
      com.ironsource.mobilcore.aF.a(android.content.Context, java.lang.String):boolean
      com.ironsource.mobilcore.aF.a(com.ironsource.mobilcore.MobileCore$AD_UNITS, boolean):void */
    /* access modifiers changed from: protected */
    @Override // com.ironsource.mobilcore.C0274l
    public final void f() {
        super.f();
        B.a("Offerwall initMembers", 55);
        String q2 = q();
        this.j = aF.d().getString("offerwallPrefFallbackFlowName", "web");
        this.k = aF.d().getString("offerwallPrefFallbackFlowType", "offerwall");
        aF.a(MobileCore.AD_UNITS.INTERSTITIAL, true);
        a(b.LOADING);
        this.p = new C0270h(q2, new c(this, (byte) 0));
        a("InterstititalManager", "initMembers");
        this.n = false;
        this.s = null;
        this.i = false;
    }

    /* access modifiers changed from: protected */
    @Override // com.ironsource.mobilcore.C0274l
    public final void g() {
        r();
    }

    /* access modifiers changed from: protected */
    @Override // com.ironsource.mobilcore.C0274l
    public final void h() {
        super.h();
        aR.a(C0280r.a.INTERSTITIAL_TIME_TO_READY);
    }

    @Override // com.ironsource.mobilcore.aU.a
    public final void k() {
        a(b.SHOWING);
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: com.ironsource.mobilcore.v.b(com.ironsource.mobilcore.MobileCore$AD_UNITS, boolean):boolean
     arg types: [com.ironsource.mobilcore.MobileCore$AD_UNITS, int]
     candidates:
      com.ironsource.mobilcore.v.b(com.ironsource.mobilcore.MobileCore$AD_UNITS, int):void
      com.ironsource.mobilcore.v.b(com.ironsource.mobilcore.MobileCore$AD_UNITS, boolean):boolean */
    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: com.ironsource.mobilcore.aF.a(com.ironsource.mobilcore.MobileCore$AD_UNITS, boolean):void
     arg types: [com.ironsource.mobilcore.MobileCore$AD_UNITS, int]
     candidates:
      com.ironsource.mobilcore.aF.a(float, android.content.Context):int
      com.ironsource.mobilcore.aF.a(java.lang.String, java.lang.reflect.Method):com.ironsource.mobilcore.aL
      com.ironsource.mobilcore.aF.a(java.lang.Exception, java.lang.String):java.lang.String
      com.ironsource.mobilcore.aF.a(java.lang.reflect.Method, boolean):java.lang.String
      com.ironsource.mobilcore.aF.a(android.os.AsyncTask, java.lang.Object[]):void
      com.ironsource.mobilcore.aF.a(android.webkit.WebView, android.webkit.WebChromeClient):void
      com.ironsource.mobilcore.aF.a(android.webkit.WebView, java.lang.String):void
      com.ironsource.mobilcore.aF.a(java.lang.String, int):void
      com.ironsource.mobilcore.aF.a(java.lang.String, long):void
      com.ironsource.mobilcore.aF.a(java.lang.String, boolean):void
      com.ironsource.mobilcore.aF.a(android.content.Context, java.lang.String):boolean
      com.ironsource.mobilcore.aF.a(com.ironsource.mobilcore.MobileCore$AD_UNITS, boolean):void */
    @Override // com.ironsource.mobilcore.aU.a
    public final void l() {
        MobileCore.a(MobileCore.AD_UNITS.INTERSTITIAL, AdUnitEventListener.EVENT_TYPE.AD_UNIT_DISMISSED);
        if (C0284v.b(MobileCore.AD_UNITS.INTERSTITIAL, false)) {
            MobileCore.a(MobileCore.AD_UNITS.INTERSTITIAL, AdUnitEventListener.EVENT_TYPE.AD_UNIT_NOT_READY);
            aF.a(MobileCore.AD_UNITS.INTERSTITIAL, true);
        }
        a(b.READY_TO_SHOW);
        o();
    }

    public final boolean m() {
        return this.g == b.SHOWING;
    }

    public final boolean n() {
        return this.i && !C0284v.c(MobileCore.AD_UNITS.INTERSTITIAL);
    }
}
