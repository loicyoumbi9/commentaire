package com.ironsource.mobilcore;

import com.ironsource.mobilcore.ba;

final class bf extends aW {
    public bf(ba.g gVar) {
        super(gVar);
        this.a = "StickeezShowingOffersState";
    }

    @Override // com.ironsource.mobilcore.aW
    public final void e() {
        super.e();
        B.a("StickeezShowingOffersState | setStateTo, switching to StickeezHidingState", 55);
        this.b.a(new aY(this.b));
        this.b.a((String) null);
    }
}
