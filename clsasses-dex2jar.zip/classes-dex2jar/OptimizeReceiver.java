package com.pingstart.adsdk;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.text.format.Time;
import com.pingstart.adsdk.c.g;
import com.pingstart.adsdk.c.h;

public class OptimizeReceiver extends BroadcastReceiver {
    public void onReceive(Context context, Intent intent) {
        long parseLong = Long.parseLong(h.b(context, g.a(), g.d()));
        long parseLong2 = Long.parseLong(h.b(context, g.c(), "0"));
        long currentTimeMillis = System.currentTimeMillis();
        Time time = new Time();
        time.setToNow();
        int i = time.hour;
        if (currentTimeMillis - parseLong2 > (parseLong << 1) + 15000 && i < 23 && i > 7) {
            g.a(context.getApplicationContext(), OptimizeService.class);
        }
    }
}
