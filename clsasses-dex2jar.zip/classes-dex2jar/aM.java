package com.ironsource.mobilcore;

import android.text.TextUtils;
import com.android.common.speech.LoggingEvents;
import com.ironsource.mobilcore.aO;
import com.ironsource.mobilcore.aS;
import org.json.JSONArray;
import org.json.JSONObject;

final class aM {
    private int a;
    private JSONObject b;
    private aO.e c;
    private boolean d;
    private String e;
    private String f;
    private String g;
    private String h;
    private String i;

    public aM(int i2, JSONObject jSONObject, aO.e eVar) {
        this.a = i2;
        this.b = jSONObject;
        this.c = eVar;
        i();
    }

    private static String a(String str) {
        return str.indexOf("file://") == 0 ? str.substring(7) : str;
    }

    private void i() {
        try {
            this.e = this.b.getString("title");
            this.f = this.b.getString("desc");
            String b2 = C0282t.a().b();
            this.g = a(aT.a(b2, this.b.getString("img")));
            JSONArray optJSONArray = this.b.optJSONArray("extra");
            if (optJSONArray != null && optJSONArray.length() > 0) {
                int i2 = 0;
                while (true) {
                    if (i2 >= optJSONArray.length()) {
                        break;
                    }
                    if (optJSONArray.getJSONObject(i2).getString("name").equals("cover_img")) {
                        String optString = optJSONArray.getJSONObject(i2).optString(LoggingEvents.VoiceSearch.EXTRA_QUERY_UPDATED_VALUE, null);
                        if (!TextUtils.isEmpty(optString)) {
                            this.h = aT.a(b2, optString);
                            this.h = a(this.h);
                            break;
                        }
                    }
                    i2++;
                }
            }
            this.i = this.b.getString("click");
            this.d = true;
        } catch (Exception e2) {
            this.d = false;
            aK.a(aS.b.REPORT_TYPE_ERROR).b("got an invalid native ad feed item").a();
        }
    }

    public final boolean a() {
        return this.d;
    }

    public final int b() {
        return this.a;
    }

    public final JSONObject c() {
        return this.b;
    }

    public final String d() {
        return this.e;
    }

    public final String e() {
        return this.f;
    }

    public final String f() {
        return this.g;
    }

    public final String g() {
        return this.h;
    }

    public final aO.e h() {
        return this.c;
    }
}
