package com.sweet.rangermob.helper;

import android.content.Context;
import com.google.android.gms.analytics.GoogleAnalytics;
import com.google.android.gms.analytics.HitBuilders;
import com.google.android.gms.analytics.Tracker;

public class GATracker {
    private static GoogleAnalytics analytics;
    private static Tracker tracker;

    public GATracker(Context context) {
        analytics = GoogleAnalytics.getInstance(context);
        tracker = analytics.newTracker(l.j(context));
    }

    public static GoogleAnalytics getAnalytics() {
        return analytics;
    }

    public static Tracker getTracker(Context context) {
        if (tracker == null) {
            new GATracker(context);
        }
        return tracker;
    }

    public static void trackAppView(Context context) {
        if (!l.j(context).equalsIgnoreCase("")) {
            getTracker(context).send(new HitBuilders.AppViewBuilder().build());
        }
    }

    public static void trackEvent(Context context, String str, String str2, String str3, String str4) {
        if (!l.j(context).equalsIgnoreCase("")) {
            getTracker(context).setScreenName(str);
            getTracker(context).send(new HitBuilders.EventBuilder().setCategory(str2).setAction(str3).setLabel(str4).build());
        }
    }

    public static void trackScreenView(Context context, String str) {
        if (!l.j(context).equalsIgnoreCase("")) {
            getTracker(context).setScreenName(str);
            getTracker(context).send(new HitBuilders.ScreenViewBuilder().build());
        }
    }

    public static void tracker(Context context, String str, String str2, String str3, String str4) {
        if (!str.equalsIgnoreCase("")) {
            GoogleAnalytics.getInstance(context).newTracker(str).send(new HitBuilders.EventBuilder().setCategory(str2).setAction(str3).setLabel(str4).build());
        }
    }

    public static void tracker(Context context, String str, String str2, String str3, String str4, String str5) {
        if (!str2.equalsIgnoreCase("")) {
            Tracker newTracker = GoogleAnalytics.getInstance(context).newTracker(str2);
            newTracker.setScreenName(str);
            newTracker.send(new HitBuilders.EventBuilder().setCategory(str3).setAction(str4).setLabel(str5).build());
        }
    }
}
