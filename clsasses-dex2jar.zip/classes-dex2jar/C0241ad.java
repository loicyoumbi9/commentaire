package com.ironsource.mobilcore;

import android.content.Context;
import android.graphics.Canvas;
import android.widget.FrameLayout;

/* renamed from: com.ironsource.mobilcore.ad  reason: case insensitive filesystem */
class C0241ad extends FrameLayout {
    /* access modifiers changed from: private */
    public boolean a;
    private boolean b = true;
    /* access modifiers changed from: private */
    public boolean c;
    /* access modifiers changed from: private */
    public boolean d = true;

    public C0241ad(Context context) {
        super(context);
        if (C0247aj.p) {
            setLayerType(2, null);
        }
    }

    /* access modifiers changed from: protected */
    public void dispatchDraw(Canvas canvas) {
        super.dispatchDraw(canvas);
        if (this.a && C0247aj.p) {
            post(new Runnable() {
                /* class com.ironsource.mobilcore.C0241ad.AnonymousClass2 */

                public final void run() {
                    if (!C0241ad.this.c) {
                        return;
                    }
                    if (C0241ad.this.getLayerType() != 2 || C0241ad.this.d) {
                        boolean unused = C0241ad.this.d = false;
                        C0241ad.this.setLayerType(2, null);
                        C0241ad.this.buildLayer();
                        C0241ad.this.setLayerType(0, null);
                    }
                }
            });
            this.a = false;
        }
    }

    /* access modifiers changed from: protected */
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.c = true;
    }

    /* access modifiers changed from: protected */
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        this.c = false;
    }

    /* access modifiers changed from: protected */
    public void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        if (C0247aj.p && this.b) {
            post(new Runnable() {
                /* class com.ironsource.mobilcore.C0241ad.AnonymousClass1 */

                public final void run() {
                    boolean unused = C0241ad.this.a = true;
                    C0241ad.this.invalidate();
                }
            });
        }
    }
}
