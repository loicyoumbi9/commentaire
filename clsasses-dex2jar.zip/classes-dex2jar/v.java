package u.aly;

public interface v {
    void a(Throwable th);
}
