package com.keyboard.common.utilsmodule;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.List;

public final class BitmapUtils {
    private static final String TAG = BitmapUtils.class.getSimpleName();

    private static boolean checkFileDirExists(String str) {
        String parentDir = getParentDir(str);
        if (parentDir == null) {
            return false;
        }
        File file = new File(parentDir);
        try {
            if (!file.exists() && !file.mkdirs()) {
                Log.e(TAG, "create folder " + parentDir + " failed");
            }
            return true;
        } catch (SecurityException e) {
            Log.e(TAG, "create folder " + parentDir + " failed: " + e.toString());
            return false;
        }
    }

    public static final int computeSampleSize(int i, int i2, int i3, int i4) {
        int pow;
        if ((i > i4 || i2 > i3) && (pow = (int) Math.pow(2.0d, (double) ((int) Math.round(Math.log(((double) i3) / ((double) Math.max(i, i2))) / Math.log(0.5d))))) > 0) {
            return pow;
        }
        return 1;
    }

    public static final int computeSampleSize(BitmapFactory.Options options, int i, int i2) {
        return computeSampleSize(options.outWidth, options.outHeight, i, i2);
    }

    public static final Bitmap createBitmap(int i, int i2, Bitmap.Config config) {
        Bitmap bitmap;
        if (i <= 0 || i2 <= 0) {
            Log.d(TAG, "specific bitmap size invalid !");
            bitmap = null;
        } else {
            try {
                bitmap = Bitmap.createBitmap(i, i2, config);
                if (bitmap.isRecycled()) {
                    return null;
                }
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            } catch (OutOfMemoryError e2) {
                e2.printStackTrace();
                return null;
            }
        }
        return bitmap;
    }

    public static final Bitmap decodeBitmapLocal(File file, int i, int i2) {
        try {
            return decodeBitmapLocal(new FileInputStream(file), i, i2);
        } catch (Exception e) {
            Log.e(TAG, e.toString());
            return null;
        }
    }

    public static final Bitmap decodeBitmapLocal(InputStream inputStream, int i, int i2) {
        int i3 = 1;
        Bitmap bitmap = null;
        if (inputStream == null) {
            Log.d(TAG, "InputStream is null!");
        } else {
            if (i > 0 || i2 > 0) {
                try {
                    BitmapFactory.Options options = new BitmapFactory.Options();
                    options.inJustDecodeBounds = true;
                    BitmapFactory.decodeStream(inputStream, null, options);
                    i3 = computeSampleSize(options, i, i2);
                } catch (Exception e) {
                    e.printStackTrace();
                    try {
                        inputStream.close();
                    } catch (Exception e2) {
                    }
                } catch (OutOfMemoryError e3) {
                    e3.printStackTrace();
                    try {
                        inputStream.close();
                    } catch (Exception e4) {
                    }
                } catch (Throwable th) {
                    try {
                        inputStream.close();
                    } catch (Exception e5) {
                    }
                    throw th;
                }
            }
            BitmapFactory.Options options2 = new BitmapFactory.Options();
            options2.inSampleSize = i3;
            options2.inPurgeable = true;
            Bitmap decodeStream = BitmapFactory.decodeStream(inputStream, null, options2);
            if (decodeStream == null || decodeStream.getWidth() <= 0 || decodeStream.getHeight() <= 0) {
                Log.d(TAG, "Optimize decode bitmap failed, try to use origin decode!");
                bitmap = BitmapFactory.decodeStream(inputStream);
            } else {
                bitmap = decodeStream;
            }
            try {
                inputStream.close();
            } catch (Exception e6) {
            }
            if (bitmap == null) {
                Log.d(TAG, "==============> " + inputStream.toString() + " : decode bitmap failed!");
            }
        }
        return bitmap;
    }

    public static final Bitmap decodeBitmapLocal(byte[] bArr, int i, int i2, int i3, int i4) {
        if (bArr == null || i2 <= 0 || i >= i2) {
            Log.d(TAG, "params is invalid !");
            return null;
        }
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(bArr, i, i2, options);
        return decodeBitmapLocal(bArr, i, i2, options.outWidth, options.outHeight, i3, i4);
    }

    public static final Bitmap decodeBitmapLocal(byte[] bArr, int i, int i2, int i3, int i4, int i5, int i6) {
        int i7 = 1;
        Bitmap bitmap = null;
        if (bArr == null || i2 <= 0 || i >= i2 || i3 <= 0 || i4 <= 0) {
            Log.d(TAG, "params is invalid !");
        } else {
            if (i5 > 0 || i6 > 0) {
                try {
                    i7 = computeSampleSize(i3, i4, i5, i6);
                } catch (Exception e) {
                    e.printStackTrace();
                } catch (OutOfMemoryError e2) {
                    e2.printStackTrace();
                }
            }
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = i7;
            options.inPurgeable = true;
            Bitmap decodeByteArray = BitmapFactory.decodeByteArray(bArr, i, i2, options);
            if (decodeByteArray == null || decodeByteArray.getWidth() <= 0 || decodeByteArray.getHeight() <= 0) {
                Log.d(TAG, "Optimize decode bitmap failed, try to use origin decode!");
                bitmap = BitmapFactory.decodeByteArray(bArr, i, i2);
            } else {
                bitmap = decodeByteArray;
            }
            if (bitmap == null) {
                Log.d(TAG, "==============> length: " + i2 + "srcW: " + i3 + " srcH: " + i4 + " tagW: " + i5 + " tagH: " + i6 + "decode bitmap failed !");
            }
        }
        return bitmap;
    }

    public static final Bitmap decodeBitmapOnline(InputStream inputStream, int i, int i2) {
        Bitmap bitmap = null;
        if (inputStream == null) {
            Log.e(TAG, "InputStream is null!");
        } else {
            try {
                bitmap = BitmapFactory.decodeStream(inputStream);
                try {
                    inputStream.close();
                } catch (Exception e) {
                }
            } catch (Exception e2) {
                e2.printStackTrace();
                try {
                    inputStream.close();
                } catch (Exception e3) {
                }
            } catch (OutOfMemoryError e4) {
                e4.printStackTrace();
                try {
                    inputStream.close();
                } catch (Exception e5) {
                }
            } catch (Throwable th) {
                try {
                    inputStream.close();
                } catch (Exception e6) {
                }
                throw th;
            }
            if (bitmap == null) {
                Log.d(TAG, "==============> " + inputStream.toString() + " : decode bitmap failed!");
            }
        }
        return bitmap;
    }

    public static final void freeBitmap(Bitmap bitmap) {
        if (isBmpValid(bitmap)) {
            bitmap.recycle();
        }
    }

    public static final void freeBitmapList(List<Bitmap> list) {
        if (list != null) {
            for (Bitmap bitmap : list) {
                if (isBmpValid(bitmap)) {
                    bitmap.recycle();
                }
            }
            list.clear();
        }
    }

    private static String getParentDir(String str) {
        if (str == null) {
            return null;
        }
        try {
            int lastIndexOf = str.lastIndexOf("/");
            if (lastIndexOf > -1) {
                return str.substring(0, lastIndexOf);
            }
            return null;
        } catch (Exception e) {
            Log.e(TAG, e.toString());
            return null;
        }
    }

    public static boolean isBmpValid(Bitmap bitmap) {
        return bitmap != null && !bitmap.isRecycled();
    }

    /* JADX WARNING: Removed duplicated region for block: B:14:0x0028  */
    /* JADX WARNING: Removed duplicated region for block: B:22:0x0051 A[SYNTHETIC, Splitter:B:22:0x0051] */
    /* JADX WARNING: Removed duplicated region for block: B:30:0x005d A[SYNTHETIC, Splitter:B:30:0x005d] */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x0066 A[SYNTHETIC, Splitter:B:36:0x0066] */
    /* JADX WARNING: Removed duplicated region for block: B:52:? A[RETURN, SYNTHETIC] */
    /* JADX WARNING: Unknown top exception splitter block from list: {B:27:0x0058=Splitter:B:27:0x0058, B:19:0x004c=Splitter:B:19:0x004c} */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final boolean saveBitmapToFile(android.graphics.Bitmap r5, android.graphics.Bitmap.CompressFormat r6, java.lang.String r7) {
        /*
            r2 = 0
            r3 = 0
            r4 = 1
            boolean r0 = checkFileDirExists(r7)
            if (r0 != 0) goto L_0x000b
            r0 = r3
        L_0x000a:
            return r0
        L_0x000b:
            java.io.File r0 = new java.io.File
            r0.<init>(r7)
            r0.createNewFile()     // Catch:{ Exception -> 0x004a, OutOfMemoryError -> 0x0056, all -> 0x0062 }
            java.io.FileOutputStream r1 = new java.io.FileOutputStream     // Catch:{ Exception -> 0x004a, OutOfMemoryError -> 0x0056, all -> 0x0062 }
            r1.<init>(r0)     // Catch:{ Exception -> 0x004a, OutOfMemoryError -> 0x0056, all -> 0x0062 }
            r0 = 100
            r5.compress(r6, r0, r1)     // Catch:{ Exception -> 0x0074, OutOfMemoryError -> 0x0076, all -> 0x0078 }
            r1.flush()     // Catch:{ Exception -> 0x0074, OutOfMemoryError -> 0x0076, all -> 0x0078 }
            if (r1 == 0) goto L_0x0070
            r1.close()     // Catch:{ IOException -> 0x0047 }
            r0 = r4
        L_0x0026:
            if (r0 != 0) goto L_0x000a
            java.lang.String r1 = com.keyboard.common.utilsmodule.BitmapUtils.TAG
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>()
            java.lang.String r3 = "==============> "
            java.lang.StringBuilder r2 = r2.append(r3)
            java.lang.StringBuilder r2 = r2.append(r7)
            java.lang.String r3 = " : cache image failed!"
            java.lang.StringBuilder r2 = r2.append(r3)
            java.lang.String r2 = r2.toString()
            android.util.Log.d(r1, r2)
            goto L_0x000a
        L_0x0047:
            r0 = move-exception
            r0 = r4
            goto L_0x0026
        L_0x004a:
            r0 = move-exception
            r1 = r2
        L_0x004c:
            r0.printStackTrace()     // Catch:{ all -> 0x007a }
            if (r1 == 0) goto L_0x007d
            r1.close()     // Catch:{ IOException -> 0x006a }
            r0 = r4
            goto L_0x0026
        L_0x0056:
            r0 = move-exception
            r1 = r2
        L_0x0058:
            r0.printStackTrace()     // Catch:{ all -> 0x007a }
            if (r1 == 0) goto L_0x007d
            r1.close()     // Catch:{ IOException -> 0x006d }
            r0 = r4
            goto L_0x0026
        L_0x0062:
            r0 = move-exception
        L_0x0063:
            r1 = r2
        L_0x0064:
            if (r1 == 0) goto L_0x0069
            r1.close()     // Catch:{ IOException -> 0x0072 }
        L_0x0069:
            throw r0
        L_0x006a:
            r0 = move-exception
            r0 = r3
            goto L_0x0026
        L_0x006d:
            r0 = move-exception
            r0 = r3
            goto L_0x0026
        L_0x0070:
            r0 = r4
            goto L_0x0026
        L_0x0072:
            r1 = move-exception
            goto L_0x0069
        L_0x0074:
            r0 = move-exception
            goto L_0x004c
        L_0x0076:
            r0 = move-exception
            goto L_0x0058
        L_0x0078:
            r0 = move-exception
            goto L_0x0064
        L_0x007a:
            r0 = move-exception
            r2 = r1
            goto L_0x0063
        L_0x007d:
            r0 = r3
            goto L_0x0026
        */
        throw new UnsupportedOperationException("Method not decompiled: com.keyboard.common.utilsmodule.BitmapUtils.saveBitmapToFile(android.graphics.Bitmap, android.graphics.Bitmap$CompressFormat, java.lang.String):boolean");
    }

    public static final Bitmap scaleBitmap(Bitmap bitmap, int i, int i2, boolean z) {
        if (!isBmpValid(bitmap) || i <= 0 || i2 <= 0) {
            return bitmap;
        }
        try {
            if (i == bitmap.getWidth() && i2 == bitmap.getHeight()) {
                return bitmap;
            }
            Bitmap createScaledBitmap = Bitmap.createScaledBitmap(bitmap, i, i2, true);
            if (isBmpValid(createScaledBitmap)) {
                if (!z && !bitmap.isRecycled()) {
                    bitmap.recycle();
                }
                return createScaledBitmap;
            }
            Log.d(TAG, "==============> " + bitmap.toString() + " : scale image failed!");
            return bitmap;
        } catch (Exception e) {
            e.printStackTrace();
            return bitmap;
        } catch (OutOfMemoryError e2) {
            e2.printStackTrace();
            return bitmap;
        }
    }

    public static final Bitmap scaleBitmap(InputStream inputStream, int i, int i2) {
        return scaleBitmap(decodeBitmapLocal(inputStream, i, i2), i, i2, false);
    }
}
