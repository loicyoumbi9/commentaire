package com.keyboard.common.uimodule.tipmanager;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.View;

public class TipItem {
    public String mOnlineState = null;
    public String mSaveName = null;
    public TipView mTipView = null;
    public boolean mTipWhenUpdate = false;

    public TipItem(Context context, View view, String str, boolean z, Drawable drawable, String str2) {
        this.mSaveName = str;
        this.mTipWhenUpdate = z;
        this.mOnlineState = str2;
        this.mTipView = new TipView(context);
        this.mTipView.setImageDrawable(drawable);
        this.mTipView.addToHostView(view);
    }

    public String toString() {
        return "name=" + this.mSaveName + ", update=" + this.mTipWhenUpdate + ", online=" + this.mOnlineState + ", tipView=" + this.mTipView;
    }
}
