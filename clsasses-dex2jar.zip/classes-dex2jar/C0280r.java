package com.ironsource.mobilcore;

/* renamed from: com.ironsource.mobilcore.r  reason: case insensitive filesystem */
final class C0280r {

    /* renamed from: com.ironsource.mobilcore.r$a */
    public enum a {
        INTERSTITIAL_TIME_TO_READY("offerwall", "time_to_ready"),
        STICKEEZ_TIME_TO_READY("stickeez", "time_to_ready"),
        SLIDER_TIME_TO_READY("slider", "time_to_ready"),
        DIRECT_TO_MARKET_TIME_TO_READY("direct_to_market", "time_to_ready"),
        INTERSTITIAL_IMPRESSION_TO_CLICK("offerwall", "impression_to_click"),
        INTERSTITIAL_CLICK_TO_START("offerwall", "click_to_start");
        
        private String g;
        private String h;

        private a(String str, String str2) {
            this.g = str;
            this.h = str2;
        }

        public final String a() {
            return this.g;
        }

        public final String b() {
            return this.h;
        }
    }
}
