package com.ironsource.mobilcore;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import com.alimama.mobile.csdk.umupdate.a.f;
import com.ironsource.mobilcore.J;
import com.ironsource.mobilcore.aS;
import org.json.JSONObject;

abstract class H {
    private int a;
    /* access modifiers changed from: private */
    public String b;
    protected Context c;
    protected C0261ax d;
    protected Activity e;
    protected int f;
    protected View g;
    protected View h;
    protected Y i;
    protected String j;
    protected boolean k;
    private a l = a.HIDDEN;

    public enum a {
        VISIBLE,
        HIDDEN,
        SHOWING
    }

    public H(Context context, C0261ax axVar) {
        this.c = context;
        this.d = axVar;
        this.a = 1;
        this.f = -1;
        c();
        this.g = new LinearLayout(this.c);
        LinearLayout linearLayout = (LinearLayout) this.g;
        linearLayout.setLayoutParams(new RelativeLayout.LayoutParams(-1, -2));
        linearLayout.setOrientation(1);
        linearLayout.addView(this.h);
        if (b()) {
            this.d.a(linearLayout);
        }
    }

    public abstract String a();

    public void a(int i2) {
        this.f = i2;
    }

    public void a(Activity activity) {
        this.e = activity;
    }

    /* access modifiers changed from: protected */
    public void a(View view) {
    }

    public void a(a aVar) {
        this.l = aVar;
    }

    public final void a(Y y) {
        this.i = y;
        if (this.i != null) {
            if (!(this.g.getVisibility() == 0)) {
                this.i.a(false);
            }
        }
    }

    /* access modifiers changed from: protected */
    public final void a(String str) {
        Intent intent = new Intent(MCISliderAPI.ACTION_WIDGET_CALLBACK);
        intent.putExtra(MCISliderAPI.EXTRA_CALLBACK_ID, str);
        this.c.sendBroadcast(intent);
    }

    public abstract void a(JSONObject jSONObject);

    /* access modifiers changed from: protected */
    public void a(JSONObject jSONObject, boolean z) {
        this.j = jSONObject.optString(f.bu, "");
        this.k = jSONObject.optBoolean("closeSliderOnClick", true);
        JSONObject optJSONObject = jSONObject.optJSONObject("events");
        if (optJSONObject != null) {
            this.b = optJSONObject.optString("onClick", "");
        }
        this.h.setOnClickListener(new View.OnClickListener() {
            /* class com.ironsource.mobilcore.H.AnonymousClass1 */

            public final void onClick(View view) {
                H.this.a(view);
                if (!TextUtils.isEmpty(H.this.b)) {
                    H.this.a(H.this.b);
                }
                H.this.a(new J.a("type", H.this.a()), new J.a("position", H.this.f >= 0 ? String.valueOf(H.this.f) : null));
            }
        });
        if (z) {
            d();
            if (this instanceof M) {
                ((M) this).g();
            }
            e();
        }
    }

    public final void a(boolean z) {
        while (true) {
            this.g.setVisibility(z ? 0 : 8);
            if (this.i != null) {
                this = this.i;
            } else {
                return;
            }
        }
    }

    /* access modifiers changed from: protected */
    public void a(J.a... aVarArr) {
        aK.a(aS.b.REPORT_TYPE_EVENT).a("slider", "widget", "click").a(aVarArr).a();
    }

    /* access modifiers changed from: protected */
    public boolean b() {
        return true;
    }

    /* access modifiers changed from: protected */
    public abstract void c();

    /* access modifiers changed from: protected */
    public abstract void d();

    /* access modifiers changed from: protected */
    public abstract void e();

    public final String h() {
        return this.j;
    }

    public final View i() {
        return this.g;
    }

    /* access modifiers changed from: protected */
    public final int j() {
        int i2 = this.a;
        this.a = i2 + 1;
        return i2;
    }

    /* access modifiers changed from: protected */
    public final void k() {
        if (this.k) {
            aV.j().closeSliderMenu(true);
        }
    }

    /* access modifiers changed from: protected */
    public final a l() {
        return this.l;
    }
}
