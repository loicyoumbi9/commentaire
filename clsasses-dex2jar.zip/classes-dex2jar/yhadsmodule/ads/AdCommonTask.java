package com.keyboard.yhadsmodule.ads;

import android.util.Log;
import java.util.List;
import org.apache.http.client.methods.HttpGet;

public final class AdCommonTask extends AbsAdTask {
    /* access modifiers changed from: protected */
    public List<AdResponse> doInBackground(String... strArr) {
        HttpGet httpGet = new HttpGet(strArr[0]);
        if (isStateValid()) {
            try {
                this.mHttpClient.execute(httpGet);
            } catch (Exception e) {
                e.printStackTrace();
                Log.d(Config.YM_LOG_TAG, "Exception caught while loading ad: " + e);
            } finally {
                shutdownHttpClient();
            }
        }
        return null;
    }
}
