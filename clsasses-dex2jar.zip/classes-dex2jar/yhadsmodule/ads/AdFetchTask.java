package com.keyboard.yhadsmodule.ads;

import android.util.Log;
import com.alimama.mobile.csdk.umupdate.a.f;
import com.keyboard.common.remotemodule.core.zero.data.ZeroUrlFactory;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class AdFetchTask extends AbsAdTask {
    WeakReference<AdManager> mWeakAdManagerController;

    public AdFetchTask(AdManager adManager) {
        this.mWeakAdManagerController = new WeakReference<>(adManager);
    }

    private void handleSingleJson(JSONObject jSONObject, List<AdResponse> list) throws JSONException {
        AdResponse adResponse = new AdResponse();
        adResponse.setTitle(jSONObject.has("title") ? jSONObject.getString("title") : "");
        adResponse.setMainContent(jSONObject.has("main_content") ? jSONObject.getString("main_content") : "");
        adResponse.setMainImageUrl(jSONObject.has("main_image_url") ? jSONObject.getString("main_image_url") : "");
        adResponse.setIconImageUrl(jSONObject.has("icon_image_url") ? jSONObject.getString("icon_image_url") : "");
        adResponse.setImpressionTrackUrl(jSONObject.has("impression_track_url") ? jSONObject.getString("impression_track_url") : "");
        adResponse.setClickTrackUrl(jSONObject.has("click_track_url") ? jSONObject.getString("click_track_url") : "");
        adResponse.setClickRecordUrl(jSONObject.has("click_record_url") ? jSONObject.getString("click_record_url") : "");
        adResponse.setConversionTrackUrl(jSONObject.has("conversion_track_url") ? jSONObject.getString("conversion_track_url") : "");
        adResponse.setTargetUrl(jSONObject.has("target_url") ? jSONObject.getString("target_url") : "");
        adResponse.setChargeType(jSONObject.has("charge_type") ? jSONObject.getInt("charge_type") : 0);
        adResponse.setHtmlSnippet(jSONObject.has("html_snippet") ? jSONObject.getString("html_snippet") : "");
        adResponse.setPackageName(jSONObject.has(f.bm) ? jSONObject.getString(f.bm) : "");
        adResponse.setPreload(jSONObject.has(f.q) ? jSONObject.getString(f.q) : "");
        adResponse.setBid(jSONObject.has(f.aZ) ? jSONObject.getString(f.aZ) : "");
        adResponse.setAdsId(jSONObject.has("ad_id") ? jSONObject.getString("ad_id") : "");
        list.add(adResponse);
    }

    private List<AdResponse> parseResponseBody(String str) throws Exception {
        JSONArray jSONArray = new JSONObject(str).getJSONArray(ZeroUrlFactory.ZERO_API_TYPE_GET_ADS);
        int length = jSONArray.length();
        ArrayList arrayList = new ArrayList(length);
        for (int i = 0; i < length; i++) {
            handleSingleJson(jSONArray.getJSONObject(i), arrayList);
        }
        return arrayList;
    }

    /* access modifiers changed from: protected */
    public List<AdResponse> doInBackground(String... strArr) {
        List<AdResponse> list = null;
        try {
            HttpGet httpGet = new HttpGet(strArr[0]);
            if (isStateValid()) {
                HttpResponse execute = this.mHttpClient.execute(httpGet);
                if (!isResponseValid(execute)) {
                    shutdownHttpClient();
                } else {
                    HttpEntity entity = execute.getEntity();
                    list = parseResponseBody(entity != null ? readFromStream(entity.getContent()) : "");
                    shutdownHttpClient();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            Log.d(Config.YM_LOG_TAG, "Exception caught while loading ad: " + e);
        } finally {
            shutdownHttpClient();
        }
        return list;
    }

    /* access modifiers changed from: protected */
    public void onPostExecute(List<AdResponse> list) {
        AdManager adManager = this.mWeakAdManagerController.get();
        if (adManager == null) {
            Log.i(Config.YM_LOG_TAG, "adManager is null!");
        } else if (list == null || list.size() <= 0) {
            Log.i(Config.YM_LOG_TAG, "adResponse is null or size error!");
        } else {
            adManager.setAdResponses(list);
        }
    }
}
