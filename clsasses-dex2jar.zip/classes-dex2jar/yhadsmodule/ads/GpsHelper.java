package com.keyboard.yhadsmodule.ads;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.util.Log;
import com.keyboard.yhadsmodule.utils.MethodBuilderFactory;
import com.keyboard.yhadsmodule.utils.Reflection;
import java.lang.ref.WeakReference;

public class GpsHelper {
    public static final String ADVERTISING_ID_KEY = "advertisingId";
    public static final int GOOGLE_PLAY_SUCCESS_CODE = 0;
    public static final String IS_LIMIT_AD_TRACKING_ENABLED_KEY = "isLimitAdTrackingEnabled";
    /* access modifiers changed from: private */
    public static String sAdvertisingIdClientClassName = "com.google.android.gms.ads.identifier.AdvertisingIdClient";
    private static String sPlayServicesUtilClassName = "com.google.android.gms.common.GooglePlayServicesUtil";

    private static class FetchAdvertisingInfoTask extends AsyncTask<Void, Void, Void> {
        private WeakReference<Context> mContextWeakReference;
        private WeakReference<GpsHelperListener> mGpsHelperListenerWeakReference;

        public FetchAdvertisingInfoTask(Context context, GpsHelperListener gpsHelperListener) {
            this.mContextWeakReference = new WeakReference<>(context);
            this.mGpsHelperListenerWeakReference = new WeakReference<>(gpsHelperListener);
        }

        /* access modifiers changed from: protected */
        public Void doInBackground(Void... voidArr) {
            Object execute;
            try {
                Context context = this.mContextWeakReference.get();
                if (!(context == null || (execute = MethodBuilderFactory.create(null, "getAdvertisingIdInfo").setStatic(Class.forName(GpsHelper.sAdvertisingIdClientClassName)).addParam(Context.class, context).execute()) == null)) {
                    GpsHelper.updateSharedPreferences(context, execute);
                }
            } catch (Exception e) {
                Log.d(Config.YM_LOG_TAG, "Unable to obtain AdvertisingIdClient.getAdvertisingIdInfo()");
            }
            return null;
        }

        /* access modifiers changed from: protected */
        public void onPostExecute(Void voidR) {
            GpsHelperListener gpsHelperListener = this.mGpsHelperListenerWeakReference.get();
            if (gpsHelperListener != null) {
                gpsHelperListener.onFetchAdInfoCompleted();
            }
        }
    }

    public interface GpsHelperListener {
        void onFetchAdInfoCompleted();
    }

    public static void asyncFetchAdvertisingInfo(Context context) {
        asyncFetchAdvertisingInfo(context, null);
    }

    public static void asyncFetchAdvertisingInfo(Context context, GpsHelperListener gpsHelperListener) {
        if (Reflection.classFound(sAdvertisingIdClientClassName)) {
            try {
                AsyncTasks.safeExecuteOnExecutor(new FetchAdvertisingInfoTask(context, gpsHelperListener), new Void[0]);
            } catch (Exception e) {
                Log.d(Config.YM_LOG_TAG, "Error executing FetchAdvertisingInfoTask", e);
                if (gpsHelperListener != null) {
                    gpsHelperListener.onFetchAdInfoCompleted();
                }
            }
        } else if (gpsHelperListener != null) {
            gpsHelperListener.onFetchAdInfoCompleted();
        }
    }

    public static void asyncFetchAdvertisingInfoIfNotCached(Context context, GpsHelperListener gpsHelperListener) {
        if (!isGpsAvailable(context) || isSharedPreferencesPopluated(context)) {
            gpsHelperListener.onFetchAdInfoCompleted();
        } else {
            asyncFetchAdvertisingInfo(context, gpsHelperListener);
        }
    }

    public static String getAdvertisingId(Context context) {
        if (isGpsAvailable(context)) {
            return SharedPreferencesHelper.getSharedPreferences(context).getString(ADVERTISING_ID_KEY, null);
        }
        return null;
    }

    static boolean isGpsAvailable(Context context) {
        try {
            Object execute = MethodBuilderFactory.create(null, "isGooglePlayServicesAvailable").setStatic(Class.forName(sPlayServicesUtilClassName)).addParam(Context.class, context).execute();
            return execute != null && ((Integer) execute).intValue() == 0;
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean isLimitAdTrackingEnabled(Context context) {
        if (isGpsAvailable(context)) {
            return SharedPreferencesHelper.getSharedPreferences(context).getBoolean(IS_LIMIT_AD_TRACKING_ENABLED_KEY, false);
        }
        return false;
    }

    static boolean isSharedPreferencesPopluated(Context context) {
        SharedPreferences sharedPreferences = SharedPreferencesHelper.getSharedPreferences(context);
        return sharedPreferences.contains(ADVERTISING_ID_KEY) && sharedPreferences.contains(IS_LIMIT_AD_TRACKING_ENABLED_KEY);
    }

    static String reflectedGetAdvertisingId(Object obj, String str) {
        try {
            return (String) MethodBuilderFactory.create(obj, "getId").execute();
        } catch (Exception e) {
            return str;
        }
    }

    static boolean reflectedIsLimitAdTrackingEnabled(Object obj, boolean z) {
        try {
            Boolean bool = (Boolean) MethodBuilderFactory.create(obj, IS_LIMIT_AD_TRACKING_ENABLED_KEY).execute();
            return bool != null ? bool.booleanValue() : z;
        } catch (Exception e) {
            return z;
        }
    }

    @Deprecated
    public static void setClassNamesForTesting() {
        sPlayServicesUtilClassName = "java.lang.Class";
        sAdvertisingIdClientClassName = "java.lang.Class";
    }

    static void updateSharedPreferences(Context context, Object obj) {
        String reflectedGetAdvertisingId = reflectedGetAdvertisingId(obj, null);
        SharedPreferencesHelper.getSharedPreferences(context).edit().putString(ADVERTISING_ID_KEY, reflectedGetAdvertisingId).putBoolean(IS_LIMIT_AD_TRACKING_ENABLED_KEY, reflectedIsLimitAdTrackingEnabled(obj, false)).commit();
    }
}
