package com.keyboard.yhadsmodule.ads;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import com.alimama.mobile.csdk.umupdate.a.f;
import com.keyboard.yhadsmodule.YhAdsEntry;
import com.keyboard.yhadsmodule.install.TrackUtil;
import com.keyboard.yhadsmodule.utils.DeviceUtils;
import com.keyboard.yhadsmodule.utils.IntentUtils;
import com.keyboard.yhadsmodule.utils.UpdateVersion;

public class AdClickHandler {
    public static final String GOOGLE_PLAY_PACKAGENAME = "com.android.vending";
    private int TIME_OUT = 15;
    private WebView clickWebView;
    /* access modifiers changed from: private */
    public boolean findDest;
    private RelativeLayout jumpView;
    private IAdInfo mAdInfo;
    /* access modifiers changed from: private */
    public final Context mContext;
    private ProgressBar mProgressBar;
    private Handler timeoutHandler;
    private Runnable timeoutRunnable;
    private WindowManager wManager;
    private boolean webViewShow;

    public AdClickHandler(Context context) {
        this.mContext = context;
        this.findDest = false;
        this.jumpView = new RelativeLayout(context);
        this.jumpView.setGravity(16);
        try {
            this.clickWebView = new WebView(context);
            this.clickWebView.setLayoutParams(new RelativeLayout.LayoutParams(-1, -1));
            this.clickWebView.setOnKeyListener(new View.OnKeyListener() {
                /* class com.keyboard.yhadsmodule.ads.AdClickHandler.AnonymousClass1 */

                public boolean onKey(View view, int i, KeyEvent keyEvent) {
                    switch (i) {
                        case 4:
                            AdClickHandler.this.onFailGetTargetUrl();
                            return true;
                        default:
                            return false;
                    }
                }
            });
            this.jumpView.addView(this.clickWebView);
            RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
            layoutParams.addRule(13);
            this.mProgressBar = new ProgressBar(context);
            this.mProgressBar.setLayoutParams(layoutParams);
            this.jumpView.addView(this.mProgressBar);
            try {
                this.clickWebView.getSettings().setJavaScriptEnabled(true);
                this.clickWebView.setWebViewClient(new WebViewClient() {
                    /* class com.keyboard.yhadsmodule.ads.AdClickHandler.AnonymousClass2 */

                    public void onPageFinished(WebView webView, String str) {
                        super.onPageFinished(webView, str);
                    }

                    public void onPageStarted(WebView webView, String str, Bitmap bitmap) {
                        super.onPageStarted(webView, str, bitmap);
                    }

                    public void onReceivedError(WebView webView, int i, String str, String str2) {
                        AdClickHandler.this.onFailGetTargetUrl();
                    }

                    @Override // android.webkit.WebViewClient
                    public boolean shouldOverrideUrlLoading(WebView webView, String str) {
                        if (str == null) {
                            return false;
                        }
                        boolean unused = AdClickHandler.this.findDest = IntentUtils.isAppStoreUrl(str) || IntentUtils.isDeepLink(str);
                        if (AdClickHandler.this.findDest) {
                            AdClickHandler.this.onSuccessGetTargetUrl(str, "onstart");
                            Log.e("FINAL", "url:" + str);
                            return true;
                        } else if (webView == null) {
                            return false;
                        } else {
                            webView.loadUrl(str);
                            Log.e("NOT FINAL", "url:" + str);
                            return false;
                        }
                    }
                });
            } catch (Exception e) {
            }
            this.timeoutRunnable = new Runnable() {
                /* class com.keyboard.yhadsmodule.ads.AdClickHandler.AnonymousClass3 */

                public void run() {
                    AdClickHandler.this.onFailGetTargetUrl();
                }
            };
        } catch (Exception e2) {
        }
    }

    private void jumpToTargetUrlPreload(String str, String str2) {
        if (!TextUtils.isEmpty(str)) {
            if (!(IntentUtils.isAppStoreUrl(str2) || IntentUtils.isDeepLink(str2)) || str2 == null || str2.length() <= 10 || !IntentUtils.isAppStoreUrl(str2)) {
                jumpToTargetUrl(str);
            } else {
                onSuccessGetTargetUrl(str2, f.q);
            }
        }
    }

    /* access modifiers changed from: private */
    public void onFailGetTargetUrl() {
        if (!(this.jumpView == null || this.jumpView.getParent() == null)) {
            this.wManager.removeView(this.jumpView);
        }
        if (this.clickWebView != null) {
            this.clickWebView.stopLoading();
        }
    }

    /* access modifiers changed from: private */
    public void onSuccessGetTargetUrl(String str, String str2) {
        String str3;
        if (TextUtils.isEmpty(str)) {
            str3 = "empty:" + str2;
            str2 = "godefault";
        } else {
            str3 = str;
        }
        UpdateVersion.onEventLoadFinalYhAds(this.mContext, str3, YhAdsEntry.getShortUrl(str3), str.contains("referrer") + "", str2);
        if (TextUtils.isEmpty(str) || !IntentUtils.isAppStoreUrl(str) || this.clickWebView == null) {
            String goDefaultKeyboard = YhAdsEntry.goDefaultKeyboard(this.mContext);
            if (this.mContext != null) {
                setInstallRecord(this.mContext, goDefaultKeyboard);
                return;
            }
            return;
        }
        visitUrl(str);
    }

    private void setInstallRecord(Context context, String str) {
        String[] split;
        String[] split2;
        String[] split3;
        if (!TextUtils.isEmpty(str) && (split = str.split("&")) != null && split.length > 1) {
            String str2 = "";
            String str3 = "";
            if (!TextUtils.isEmpty(split[0]) && (split3 = split[0].split("=")) != null && split3.length > 1) {
                str2 = split3[1];
            }
            if (!TextUtils.isEmpty(split[1]) && (split2 = split[1].split("=")) != null && split2.length > 1) {
                str3 = split2[1];
            }
            if (!TextUtils.isEmpty(str2) && !TextUtils.isEmpty(str3)) {
                TrackUtil.getInstance().setContext(context);
                TrackUtil.getInstance().saveKayValue(str2, str3);
            }
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:21:0x007f  */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x009b  */
    /* JADX WARNING: Removed duplicated region for block: B:37:? A[ADDED_TO_REGION, RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void visitUrl(java.lang.String r9) {
        /*
            r8 = this;
            r7 = 268435456(0x10000000, float:2.5243549E-29)
            r5 = 65536(0x10000, float:9.18355E-41)
            r2 = 1
            r0 = 0
            boolean r1 = com.keyboard.yhadsmodule.utils.IntentUtils.isAppStoreUrl(r9)
            if (r1 == 0) goto L_0x00b2
            android.content.Intent r3 = new android.content.Intent
            java.lang.String r1 = "android.intent.action.VIEW"
            android.net.Uri r4 = android.net.Uri.parse(r9)
            r3.<init>(r1, r4)
            r1 = 8388608(0x800000, float:1.17549435E-38)
            r3.addFlags(r1)
            r3.addFlags(r7)
            r1 = 1073741824(0x40000000, float:2.0)
            r3.addFlags(r1)
            r3.addFlags(r5)
            android.content.Context r1 = r8.mContext     // Catch:{ Exception -> 0x0076 }
            android.content.pm.PackageManager r1 = r1.getPackageManager()     // Catch:{ Exception -> 0x0076 }
            r4 = 65536(0x10000, float:9.18355E-41)
            java.util.List r1 = r1.queryIntentActivities(r3, r4)     // Catch:{ Exception -> 0x0076 }
            java.util.Iterator r4 = r1.iterator()     // Catch:{ Exception -> 0x0076 }
            r1 = r0
        L_0x0038:
            boolean r0 = r4.hasNext()     // Catch:{ Exception -> 0x00ab }
            if (r0 == 0) goto L_0x007d
            java.lang.Object r0 = r4.next()     // Catch:{ Exception -> 0x00ab }
            android.content.pm.ResolveInfo r0 = (android.content.pm.ResolveInfo) r0     // Catch:{ Exception -> 0x00ab }
            android.content.pm.ActivityInfo r5 = r0.activityInfo     // Catch:{ Exception -> 0x00ab }
            java.lang.String r5 = r5.packageName     // Catch:{ Exception -> 0x00ab }
            java.lang.String r6 = "com.android.vending"
            boolean r5 = r5.equals(r6)     // Catch:{ Exception -> 0x00ab }
            if (r5 == 0) goto L_0x0038
            android.content.pm.ActivityInfo r5 = r0.activityInfo     // Catch:{ Exception -> 0x00ab }
            java.lang.String r5 = r5.packageName     // Catch:{ Exception -> 0x00ab }
            android.content.pm.ActivityInfo r0 = r0.activityInfo     // Catch:{ Exception -> 0x00ab }
            java.lang.String r0 = r0.name     // Catch:{ Exception -> 0x00ab }
            r3.setClassName(r5, r0)     // Catch:{ Exception -> 0x00ab }
            android.content.Context r0 = r8.mContext     // Catch:{ Exception -> 0x00ab }
            r0.startActivity(r3)     // Catch:{ Exception -> 0x00ab }
            android.content.Context r0 = r8.mContext     // Catch:{ Exception -> 0x00ab }
            boolean r0 = r0 instanceof android.app.Activity     // Catch:{ Exception -> 0x00ab }
            if (r0 == 0) goto L_0x006f
            android.content.Context r0 = r8.mContext     // Catch:{ Exception -> 0x00ab }
            android.app.Activity r0 = (android.app.Activity) r0     // Catch:{ Exception -> 0x00ab }
            r5 = 0
            r6 = 0
            r0.overridePendingTransition(r5, r6)     // Catch:{ Exception -> 0x00ab }
        L_0x006f:
            android.content.Context r0 = r8.mContext     // Catch:{ Exception -> 0x00af }
            r8.setInstallRecord(r0, r9)     // Catch:{ Exception -> 0x00af }
            r1 = r2
            goto L_0x0038
        L_0x0076:
            r1 = move-exception
            r3 = r1
            r2 = r0
        L_0x0079:
            r3.printStackTrace()
            r1 = r2
        L_0x007d:
            if (r1 != 0) goto L_0x0097
            android.content.Intent r0 = new android.content.Intent
            java.lang.String r1 = "android.intent.action.VIEW"
            android.net.Uri r2 = android.net.Uri.parse(r9)
            r0.<init>(r1, r2)
            r0.addFlags(r7)
            android.content.Context r1 = r8.mContext
            r8.setInstallRecord(r1, r9)
            android.content.Context r1 = r8.mContext
            r1.startActivity(r0)
        L_0x0097:
            boolean r0 = r8.webViewShow
            if (r0 == 0) goto L_0x00aa
            android.widget.RelativeLayout r0 = r8.jumpView
            android.view.ViewParent r0 = r0.getParent()
            if (r0 == 0) goto L_0x00aa
            android.view.WindowManager r0 = r8.wManager
            android.widget.RelativeLayout r1 = r8.jumpView
            r0.removeView(r1)
        L_0x00aa:
            return
        L_0x00ab:
            r0 = move-exception
            r3 = r0
            r2 = r1
            goto L_0x0079
        L_0x00af:
            r0 = move-exception
            r3 = r0
            goto L_0x0079
        L_0x00b2:
            r1 = r0
            goto L_0x007d
        */
        throw new UnsupportedOperationException("Method not decompiled: com.keyboard.yhadsmodule.ads.AdClickHandler.visitUrl(java.lang.String):void");
    }

    public void getTargetUrl(String str, final UpdateVersion.onLoadOverAds onloadoverads) {
        if (!TextUtils.isEmpty(str) && this.clickWebView != null) {
            this.clickWebView.setWebViewClient(new WebViewClient() {
                /* class com.keyboard.yhadsmodule.ads.AdClickHandler.AnonymousClass4 */

                public void onPageFinished(WebView webView, String str) {
                    super.onPageFinished(webView, str);
                }

                public void onPageStarted(WebView webView, String str, Bitmap bitmap) {
                    super.onPageStarted(webView, str, bitmap);
                }

                public void onReceivedError(WebView webView, int i, String str, String str2) {
                    AdClickHandler.this.onFailGetTargetUrl();
                }

                @Override // android.webkit.WebViewClient
                public boolean shouldOverrideUrlLoading(WebView webView, String str) {
                    if (str == null) {
                        return false;
                    }
                    boolean unused = AdClickHandler.this.findDest = IntentUtils.isAppStoreUrl(str) || IntentUtils.isDeepLink(str);
                    if (AdClickHandler.this.getmAdInfo() != null) {
                        UpdateVersion.onEventLoadingYhAds(AdClickHandler.this.mContext, AdClickHandler.this.getmAdInfo().getPackageName());
                    }
                    if (AdClickHandler.this.findDest) {
                        if (AdClickHandler.this.getmAdInfo() != null) {
                            AdClickHandler.this.getmAdInfo().setFinalUrl(str);
                        }
                        if (onloadoverads != null) {
                            onloadoverads.onFinish(null);
                        }
                        return true;
                    } else if (webView == null) {
                        return false;
                    } else {
                        webView.loadUrl(str);
                        Log.e("NOT FINAL", "url:" + str);
                        return false;
                    }
                }
            });
            this.clickWebView.loadUrl(str);
        }
    }

    public IAdInfo getmAdInfo() {
        return this.mAdInfo;
    }

    public boolean isWebViewShow() {
        return this.webViewShow;
    }

    public void jumpToClickDestinationUrl() {
        if (this.mAdInfo == null || this.mContext == null) {
            String goDefaultKeyboard = YhAdsEntry.goDefaultKeyboard(this.mContext);
            if (this.mContext != null) {
                setInstallRecord(this.mContext, goDefaultKeyboard);
                return;
            }
            return;
        }
        this.timeoutHandler = new Handler();
        this.timeoutHandler.postDelayed(this.timeoutRunnable, (long) (this.TIME_OUT * 1000));
        if (!TextUtils.isEmpty(this.mAdInfo.getClickRecordUrl())) {
            sendEventToTrackUrl(this.mAdInfo.getClickRecordUrl());
        }
        if (!TextUtils.isEmpty(this.mAdInfo.getClickDestinationUrl())) {
            jumpToTargetUrl(this.mAdInfo.getClickDestinationUrl());
        }
    }

    public void jumpToClickDestinationUrlPreload(String str, String str2, String str3) {
        if (!TextUtils.isEmpty(str)) {
            sendEventToTrackUrl(str);
        }
        if (!TextUtils.isEmpty(str2)) {
            jumpToTargetUrlPreload(str2, str3);
        }
    }

    public void jumpToTargetUrl(String str) {
        if (!TextUtils.isEmpty(str) && this.clickWebView != null) {
            if (this.webViewShow) {
                WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
                layoutParams.height = -1;
                layoutParams.width = -1;
                layoutParams.gravity = 17;
                this.wManager = (WindowManager) this.mContext.getSystemService("window");
                this.wManager.addView(this.jumpView, layoutParams);
                this.clickWebView.setVisibility(0);
                this.mProgressBar.setVisibility(0);
            }
            this.clickWebView.setWebViewClient(new WebViewClient() {
                /* class com.keyboard.yhadsmodule.ads.AdClickHandler.AnonymousClass5 */

                public void onPageFinished(WebView webView, String str) {
                    super.onPageFinished(webView, str);
                }

                public void onPageStarted(WebView webView, String str, Bitmap bitmap) {
                    super.onPageStarted(webView, str, bitmap);
                }

                public void onReceivedError(WebView webView, int i, String str, String str2) {
                    AdClickHandler.this.onFailGetTargetUrl();
                }

                @Override // android.webkit.WebViewClient
                public boolean shouldOverrideUrlLoading(WebView webView, String str) {
                    if (str == null) {
                        return false;
                    }
                    boolean unused = AdClickHandler.this.findDest = IntentUtils.isAppStoreUrl(str) || IntentUtils.isDeepLink(str);
                    if (AdClickHandler.this.findDest) {
                        AdClickHandler.this.onSuccessGetTargetUrl(str, "direct_goads");
                        Log.e("FINAL", "url:" + str);
                        return true;
                    } else if (webView == null) {
                        return false;
                    } else {
                        webView.loadUrl(str);
                        Log.e("NOT FINAL", "url:" + str);
                        return false;
                    }
                }
            });
            this.clickWebView.loadUrl(str);
        }
    }

    public void preloadGetUrl(UpdateVersion.onLoadOverAds onloadoverads) {
        if (this.mAdInfo != null && this.mContext != null) {
            getTargetUrl(this.mAdInfo.getClickDestinationUrl(), onloadoverads);
        }
    }

    public void sendConversionTrack() {
        if (this.mAdInfo != null && !"".equals(this.mAdInfo.getConversionTrackUrl())) {
            sendEventToTrackUrl(this.mAdInfo.getConversionTrackUrl());
        }
    }

    public void sendEventToTrackUrl(String str) {
        Log.d("AdViewController", "Track for:" + str);
        if (!DeviceUtils.isNetworkAvailable(this.mContext)) {
            Log.i("AdClickHandler", "Network not available,cancel sendEventToTrackUrl");
            return;
        }
        try {
            AsyncTasks.safeExecuteOnExecutor(new AdCommonTask(), str);
        } catch (Exception e) {
            Log.d("AdClickHandler", "Error executing sendEventToTrackUrl", e);
        }
    }

    public void sendImpressionTrack() {
        if (this.mAdInfo != null && !"".equals(this.mAdInfo.getImpressionTrackUrl())) {
            sendEventToTrackUrl(this.mAdInfo.getImpressionTrackUrl());
        }
    }

    public void setAdInfo(IAdInfo iAdInfo) {
        this.mAdInfo = iAdInfo;
    }

    public void setWebViewShow(boolean z) {
        this.webViewShow = z;
    }

    public void updateAdInfo(String str, String str2) {
    }
}
