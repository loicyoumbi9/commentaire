package com.keyboard.yhadsmodule.ads;

import java.util.List;

public interface OnAdReceiveListener {
    void onAdFail(String str);

    void onAdReceive(List<AdResponse> list);
}
