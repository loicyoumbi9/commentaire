package com.keyboard.yhadsmodule.ads;

import java.util.Date;
import java.util.TimeZone;

public class DateAndTime {
    private static final String FORMAT = "yyyy-MM-dd HH:mm:ss";
    private static final int JUDGE_CONVERSION_TIME = 30;
    private static final int TIME_HOURSES = 24;
    private static final int TIME_MILLISECONDS = 1000;
    private static final int TIME_NUMBERS = 60;
    protected static DateAndTime instance = new DateAndTime();

    public static TimeZone localTimeZone() {
        return instance.internalLocalTimeZone();
    }

    public static Date now() {
        return instance.internalNow();
    }

    @Deprecated
    public static void setInstance(DateAndTime dateAndTime) {
        instance = dateAndTime;
    }

    public static boolean withinHalfHour(long j) {
        return ((int) ((Math.abs(new Date().getTime() - j) / 1000) / 60)) < 30;
    }

    public TimeZone internalLocalTimeZone() {
        return TimeZone.getDefault();
    }

    public Date internalNow() {
        return new Date();
    }
}
