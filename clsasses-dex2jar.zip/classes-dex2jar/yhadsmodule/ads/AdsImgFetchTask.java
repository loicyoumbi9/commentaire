package com.keyboard.yhadsmodule.ads;

import android.text.TextUtils;
import android.util.Log;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.List;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;

public final class AdsImgFetchTask extends AbsAdTask {
    private IAdInfo mAdInfo = null;
    private OnGetFinishListener mGetFinishLister = null;
    private InputStream mInputStream = null;
    private String mPath = null;

    public interface OnGetFinishListener {
        void onFinish(IAdInfo iAdInfo);
    }

    public AdsImgFetchTask(IAdInfo iAdInfo, String str) {
        this.mAdInfo = iAdInfo;
        this.mPath = str;
    }

    private void copyInputStreamToFile(InputStream inputStream, File file) {
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(file);
            byte[] bArr = new byte[1024];
            while (true) {
                int read = inputStream.read(bArr);
                if (read > 0) {
                    fileOutputStream.write(bArr, 0, read);
                } else {
                    fileOutputStream.close();
                    inputStream.close();
                    return;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static boolean isFileExist(String str) {
        File file = new File(str);
        return file != null && file.exists();
    }

    public static void writeSDFile(String str, String str2) {
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(str);
            fileOutputStream.write(str2.getBytes());
            fileOutputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /* access modifiers changed from: protected */
    public List<AdResponse> doInBackground(String... strArr) {
        try {
            HttpGet httpGet = new HttpGet(strArr[0]);
            if (isStateValid()) {
                HttpResponse execute = this.mHttpClient.execute(httpGet);
                if (!isResponseValid(execute)) {
                    shutdownHttpClient();
                } else {
                    execute.getEntity();
                    InputStream content = execute.getEntity().getContent();
                    if (this.mAdInfo == null || TextUtils.isEmpty(this.mPath)) {
                        writeSDFileEx("adsicon.png", content);
                    } else {
                        writeSDFileEx(this.mPath + this.mAdInfo.getPackageName() + ".png", content);
                    }
                    shutdownHttpClient();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            Log.d(Config.YM_LOG_TAG, "Exception caught while loading ad: " + e);
        } finally {
            shutdownHttpClient();
        }
        return null;
    }

    /* access modifiers changed from: protected */
    public void onPostExecute(List<AdResponse> list) {
        if (this.mGetFinishLister != null) {
            this.mGetFinishLister.onFinish(this.mAdInfo);
        }
        Log.i(Config.YM_LOG_TAG, "adResponse is null or size error!");
    }

    public void setOnFinsh(OnGetFinishListener onGetFinishListener) {
        this.mGetFinishLister = onGetFinishListener;
    }

    public void writeSDFileEx(String str, InputStream inputStream) {
        FileOutputStream fileOutputStream;
        try {
            try {
                fileOutputStream = new FileOutputStream(new File(str));
                byte[] bArr = new byte[1024];
                while (true) {
                    int read = inputStream.read(bArr);
                    if (read == -1) {
                        break;
                    }
                    fileOutputStream.write(bArr, 0, read);
                }
                fileOutputStream.flush();
                fileOutputStream.close();
            } catch (Exception e) {
                e.printStackTrace();
            } catch (Throwable th) {
                fileOutputStream.close();
                throw th;
            }
        } finally {
            try {
                inputStream.close();
            } catch (Exception e2) {
            }
        }
    }
}
