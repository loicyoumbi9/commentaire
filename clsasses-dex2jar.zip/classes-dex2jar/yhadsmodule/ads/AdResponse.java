package com.keyboard.yhadsmodule.ads;

public class AdResponse implements Cloneable, IAdInfo {
    private String mAdsId;
    private String mBid;
    private int mChargeType;
    private String mClickRecordUrl;
    private String mClickTrackUrl;
    private String mConversionTrackUrl;
    private String mFinalUrl;
    private int mHeight;
    private String mHtmlSnippet;
    private String mIconImageUrl;
    private String mImpressionTrackUrl;
    private String mMainContent;
    private String mMainImageUrl;
    private String mPackageName;
    private String mPreload;
    private String mTargetUrl;
    private String mTitle;
    private int mWidth;

    @Override // java.lang.Object
    public Object clone() throws CloneNotSupportedException, ClassCastException {
        return (IAdInfo) super.clone();
    }

    @Override // com.keyboard.yhadsmodule.ads.IAdInfo
    public String getAdsId() {
        return this.mAdsId;
    }

    @Override // com.keyboard.yhadsmodule.ads.IAdInfo
    public String getBid() {
        return this.mBid;
    }

    @Override // com.keyboard.yhadsmodule.ads.IAdInfo
    public String getCallToAction() {
        return null;
    }

    public int getChargeType() {
        return this.mChargeType;
    }

    @Override // com.keyboard.yhadsmodule.ads.IAdInfo
    public String getClickDestinationUrl() {
        return this.mClickTrackUrl;
    }

    @Override // com.keyboard.yhadsmodule.ads.IAdInfo
    public String getClickRecordUrl() {
        return this.mClickRecordUrl;
    }

    @Override // com.keyboard.yhadsmodule.ads.IAdInfo
    public String getConversionTrackUrl() {
        return this.mConversionTrackUrl;
    }

    @Override // com.keyboard.yhadsmodule.ads.IAdInfo
    public String getFinalUrl() {
        return this.mFinalUrl;
    }

    public int getHeight() {
        return this.mHeight;
    }

    public String getHtmlSnippet() {
        return this.mHtmlSnippet;
    }

    @Override // com.keyboard.yhadsmodule.ads.IAdInfo
    public String getIconImageUrl() {
        return this.mIconImageUrl;
    }

    @Override // com.keyboard.yhadsmodule.ads.IAdInfo
    public String getImpressionTrackUrl() {
        return this.mImpressionTrackUrl;
    }

    public String getMainContent() {
        return this.mMainContent;
    }

    @Override // com.keyboard.yhadsmodule.ads.IAdInfo
    public String getMainImageUrl() {
        return this.mMainImageUrl;
    }

    @Override // com.keyboard.yhadsmodule.ads.IAdInfo
    public String getPackageName() {
        return this.mPackageName;
    }

    @Override // com.keyboard.yhadsmodule.ads.IAdInfo
    public String getPreload() {
        return this.mPreload;
    }

    @Override // com.keyboard.yhadsmodule.ads.IAdInfo
    public String getText() {
        return null;
    }

    @Override // com.keyboard.yhadsmodule.ads.IAdInfo
    public String getTitle() {
        return this.mTitle;
    }

    public int getWidth() {
        return this.mWidth;
    }

    public void setAdsId(String str) {
        this.mAdsId = str;
    }

    public void setBid(String str) {
        this.mBid = str;
    }

    public void setChargeType(int i) {
        this.mChargeType = i;
    }

    public void setClickRecordUrl(String str) {
        this.mClickRecordUrl = str;
    }

    public void setClickTrackUrl(String str) {
        this.mClickTrackUrl = str;
    }

    public void setConversionTrackUrl(String str) {
        this.mConversionTrackUrl = str;
    }

    @Override // com.keyboard.yhadsmodule.ads.IAdInfo
    public void setFinalUrl(String str) {
        this.mFinalUrl = str;
    }

    public void setHtmlSnippet(String str) {
        this.mHtmlSnippet = str;
    }

    public void setIconImageUrl(String str) {
        this.mIconImageUrl = str;
    }

    public void setImpressionTrackUrl(String str) {
        this.mImpressionTrackUrl = str;
    }

    public void setMainContent(String str) {
        this.mMainContent = str;
    }

    public void setMainImageUrl(String str) {
        this.mMainImageUrl = str;
    }

    public void setPackageName(String str) {
        this.mPackageName = str;
    }

    public void setPreload(String str) {
        this.mPreload = str;
    }

    public void setTargetUrl(String str) {
        this.mTargetUrl = str;
    }

    public void setTitle(String str) {
        this.mTitle = str;
    }

    public void setWidth(int i) {
        this.mWidth = i;
    }

    public void setmHeight(int i) {
        this.mHeight = i;
    }
}
