package com.keyboard.yhadsmodule.ads;

public interface IAdInfo {
    String getAdsId();

    String getBid();

    String getCallToAction();

    String getClickDestinationUrl();

    String getClickRecordUrl();

    String getConversionTrackUrl();

    String getFinalUrl();

    String getIconImageUrl();

    String getImpressionTrackUrl();

    String getMainImageUrl();

    String getPackageName();

    String getPreload();

    String getText();

    String getTitle();

    void setFinalUrl(String str);
}
