package com.keyboard.yhadsmodule.ads;

import android.os.AsyncTask;
import android.os.Looper;
import com.keyboard.yhadsmodule.utils.Reflection;
import com.keyboard.yhadsmodule.utils.VersionCode;
import java.util.concurrent.Executor;

public class AsyncTasks {
    public static <P> void safeExecuteOnExecutor(AsyncTask<P, ?, ?> asyncTask, P... pArr) throws IllegalArgumentException, IllegalStateException {
        if (asyncTask == null) {
            throw new IllegalArgumentException("Unable to execute null AsyncTask.");
        } else if (Looper.myLooper() != Looper.getMainLooper()) {
            throw new IllegalStateException("AsyncTask must be executed on the main thread");
        } else if (VersionCode.currentApiLevel().isAtLeast(VersionCode.ICE_CREAM_SANDWICH)) {
            try {
                new Reflection.MethodBuilder(asyncTask, "executeOnExecutor").addParam(Executor.class, (Executor) AsyncTask.class.getField("THREAD_POOL_EXECUTOR").get(AsyncTask.class)).addParam(Object[].class, pArr).execute();
            } catch (Exception e) {
                asyncTask.execute(pArr);
            }
        } else {
            asyncTask.execute(pArr);
        }
    }
}
