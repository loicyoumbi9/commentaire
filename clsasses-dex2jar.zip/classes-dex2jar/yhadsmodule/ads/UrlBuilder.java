package com.keyboard.yhadsmodule.ads;

import android.content.Context;
import android.location.Location;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import com.alimama.mobile.csdk.umupdate.a.f;
import com.keyboard.yhadsmodule.utils.LocationService;
import com.keyboard.yhadsmodule.utils.Utils;
import com.umeng.update.UpdateConfig;
import java.text.SimpleDateFormat;

public class UrlBuilder {
    private int mAdNum = 1;
    private long mAppId;
    private ConnectivityManager mConnectivityManager;
    private Context mContext;
    private String mIcc;
    private boolean mIsDebug = false;
    private boolean mIsFirstParam;
    private boolean mIsNGP = false;
    private Location mLocation;
    private LocationService.LocationAwareness mLocationAwareness = LocationService.LocationAwareness.NORMAL;
    private int mLocationPrecision = 6;
    private String mPackageName;
    private long mSlotId;
    private StringBuilder mStringBuilder;
    private TelephonyManager mTelephonyManager;

    public UrlBuilder(Context context) {
        this.mContext = context;
        this.mTelephonyManager = (TelephonyManager) this.mContext.getSystemService("phone");
        this.mConnectivityManager = (ConnectivityManager) this.mContext.getSystemService("connectivity");
        this.mSlotId = 0;
        this.mAppId = 0;
    }

    private void addParam(String str, String str2) {
        if (str != null && str.length() != 0 && str2 != null && str2.length() != 0) {
            if (this.mIsFirstParam) {
                this.mIsFirstParam = false;
                this.mStringBuilder.append("?");
            } else {
                this.mStringBuilder.append("&");
            }
            this.mStringBuilder.append(str);
            this.mStringBuilder.append("=");
            this.mStringBuilder.append(Uri.encode(str2));
        }
    }

    private String getNetworkOperator() {
        String networkOperator = this.mTelephonyManager.getNetworkOperator();
        return (this.mTelephonyManager.getPhoneType() == 2 && this.mTelephonyManager.getSimState() == 5) ? this.mTelephonyManager.getSimOperator() : networkOperator;
    }

    private String getUdidFromContext(Context context) {
        String advertisingId = GpsHelper.getAdvertisingId(context);
        if (advertisingId != null) {
            return Config.IFA_PREFIX + advertisingId;
        }
        String string = Settings.Secure.getString(context.getContentResolver(), "android_id");
        return string == null ? "" : Utils.sha1(string);
    }

    public String buildUrlString() {
        String str;
        String str2;
        int i;
        this.mStringBuilder = new StringBuilder(Config.SERVER_SEARCH_URL_PREFIX);
        this.mIsFirstParam = true;
        addParam("av", Config.API_VERSION);
        addParam(f.o, String.valueOf(this.mSlotId));
        addParam("aid", String.valueOf(this.mAppId));
        if (this.mIsDebug) {
            addParam("dg", "1");
        } else {
            addParam("dg", "0");
        }
        addParam("sv", Config.SDK_VERSION);
        addParam("udid", getUdidFromContext(this.mContext));
        if (GpsHelper.isLimitAdTrackingEnabled(this.mContext)) {
            addParam("ilat", "1");
        } else {
            addParam("ilat", "0");
        }
        addParam(f.F, String.valueOf(1));
        addParam("osv", String.valueOf(Build.VERSION.SDK));
        addParam("dmf", Build.MANUFACTURER);
        addParam("dml", Build.MODEL);
        addParam("dpd", Build.PRODUCT);
        addParam("so", String.valueOf(this.mContext.getResources().getConfiguration().orientation));
        addParam("ds", String.valueOf(this.mContext.getResources().getDisplayMetrics().density));
        String networkOperator = getNetworkOperator();
        if (networkOperator == null || TextUtils.isEmpty(networkOperator)) {
            str = "";
            str2 = "";
        } else {
            int min = Math.min(3, networkOperator.length());
            str = networkOperator == null ? "" : networkOperator.substring(0, min);
            str2 = networkOperator == null ? "" : networkOperator.substring(min);
        }
        addParam("mcc", str);
        addParam("mnc", str2);
        String networkCountryIso = this.mTelephonyManager.getNetworkCountryIso();
        if (this.mIcc != null) {
            addParam("icc", this.mIcc);
        } else {
            addParam("icc", networkCountryIso);
        }
        if (this.mContext.checkCallingOrSelfPermission(UpdateConfig.g) == 0) {
            NetworkInfo activeNetworkInfo = this.mConnectivityManager.getActiveNetworkInfo();
            i = activeNetworkInfo != null ? activeNetworkInfo.getType() : 8;
        } else {
            i = 8;
        }
        addParam("nt", String.valueOf(i));
        this.mLocation = LocationService.getLastKnownLocation(this.mContext, this.mLocationPrecision, this.mLocationAwareness);
        if (this.mLocation != null) {
            addParam(f.M, String.valueOf(this.mLocation.getLatitude()));
            addParam("lot", String.valueOf(this.mLocation.getLongitude()));
            addParam("lac", "" + ((int) this.mLocation.getAccuracy()));
        }
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("Z");
        simpleDateFormat.setTimeZone(DateAndTime.localTimeZone());
        addParam("z", simpleDateFormat.format(DateAndTime.now()));
        addParam("adnum", String.valueOf(this.mAdNum));
        if (this.mPackageName != null) {
            addParam("pkg", this.mPackageName);
        }
        if (this.mIsNGP) {
            addParam("ngp", "1");
        }
        return this.mStringBuilder.toString();
    }

    public int getAdNum() {
        return this.mAdNum;
    }

    public long getAppId() {
        return this.mAppId;
    }

    public String getIcc() {
        return this.mIcc;
    }

    public String getPackageName() {
        return this.mPackageName;
    }

    public long getSlotId() {
        return this.mSlotId;
    }

    public boolean isDebug() {
        return this.mIsDebug;
    }

    public boolean isNGP() {
        return this.mIsNGP;
    }

    public void setAdNum(int i) {
        this.mAdNum = i;
    }

    public UrlBuilder setAppId(long j) {
        this.mAppId = j;
        return this;
    }

    public void setIcc(String str) {
        this.mIcc = str;
    }

    public void setIsDebug(boolean z) {
        this.mIsDebug = z;
    }

    public void setIsNGP(boolean z) {
        this.mIsNGP = z;
    }

    public void setPackageName(String str) {
        this.mPackageName = str;
    }

    public UrlBuilder setSlotId(long j) {
        this.mSlotId = j;
        return this;
    }
}
