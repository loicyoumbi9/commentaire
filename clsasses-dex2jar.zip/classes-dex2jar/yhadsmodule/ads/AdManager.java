package com.keyboard.yhadsmodule.ads;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Log;
import com.keyboard.yhadsmodule.ads.GpsHelper;
import com.umeng.update.UpdateConfig;
import java.lang.ref.WeakReference;
import java.util.List;

public class AdManager {
    private final AdClickHandler mAdClickHandler;
    /* access modifiers changed from: private */
    public AbsAdTask mAdFetchTask;
    OnAdReceiveListener mAdReceiveListener;
    private List<AdResponse> mAdResponses;
    private final Context mContext;
    private final GpsHelper.GpsHelperListener mGpsHelperListener = new AdManagerGpsHelperListener(this);
    /* access modifiers changed from: private */
    public UrlBuilder mUrlBuilder;

    protected static final class AdManagerGpsHelperListener implements GpsHelper.GpsHelperListener {
        private final WeakReference<AdManager> mControl;

        public AdManagerGpsHelperListener(AdManager adManager) {
            this.mControl = new WeakReference<>(adManager);
        }

        @Override // com.keyboard.yhadsmodule.ads.GpsHelper.GpsHelperListener
        public void onFetchAdInfoCompleted() {
            String buildUrlString = this.mControl.get().mUrlBuilder.buildUrlString();
            Log.d(Config.YM_LOG_TAG, "start to load ad url=" + buildUrlString);
            if (this.mControl.get().mAdFetchTask != null) {
                this.mControl.get().mAdFetchTask.cancel(true);
            }
            AbsAdTask unused = this.mControl.get().mAdFetchTask = new AdFetchTask(this.mControl.get());
            try {
                AsyncTasks.safeExecuteOnExecutor(this.mControl.get().mAdFetchTask, buildUrlString);
            } catch (Exception e) {
                Log.d("AdViewController", "Error executing AdFetchTask", e);
            }
        }
    }

    public AdManager(Context context) {
        this.mContext = context;
        this.mUrlBuilder = new UrlBuilder(context);
        this.mAdClickHandler = new AdClickHandler(context);
    }

    public static boolean checkExistApp(Context context, String str) {
        for (PackageInfo packageInfo : context.getPackageManager().getInstalledPackages(0)) {
            if (str.equalsIgnoreCase(packageInfo.packageName)) {
                return true;
            }
        }
        return false;
    }

    private boolean isNetworkAvailable() {
        NetworkInfo activeNetworkInfo;
        return this.mContext.checkCallingPermission(UpdateConfig.g) == -1 || ((activeNetworkInfo = ((ConnectivityManager) this.mContext.getSystemService("connectivity")).getActiveNetworkInfo()) != null && activeNetworkInfo.isConnected());
    }

    public int getAdNum() {
        return this.mUrlBuilder.getAdNum();
    }

    public List<AdResponse> getAdResponses() {
        return this.mAdResponses;
    }

    public long getAppId() {
        return this.mUrlBuilder.getAppId();
    }

    public String getIcc() {
        return this.mUrlBuilder.getIcc();
    }

    public String getPackageName() {
        return this.mUrlBuilder.getPackageName();
    }

    public long getSlotId() {
        return this.mUrlBuilder.getSlotId();
    }

    public boolean isDebug() {
        return this.mUrlBuilder.isDebug();
    }

    public boolean isNGP() {
        return this.mUrlBuilder.isNGP();
    }

    public void loadAd() {
        if (0 == this.mUrlBuilder.getSlotId() || 0 == this.mUrlBuilder.getAppId()) {
            Log.d(Config.YM_LOG_TAG, "cannot load yeahmobi ads, because you forget set slotId or appId");
        } else if (!isNetworkAvailable()) {
            Log.d(Config.YM_LOG_TAG, "Can't load an ad because there is no network connectivity.");
        } else {
            GpsHelper.asyncFetchAdvertisingInfoIfNotCached(this.mContext, this.mGpsHelperListener);
        }
    }

    public void setAdNum(int i) {
        this.mUrlBuilder.setAdNum(i);
    }

    public void setAdReceiveListener(OnAdReceiveListener onAdReceiveListener) {
        this.mAdReceiveListener = onAdReceiveListener;
    }

    public void setAdResponses(List<AdResponse> list) {
        if (list == null) {
            Log.i(Config.YM_LOG_TAG, "adResponse is null in setAdResponse of AdViewController");
        }
        this.mAdResponses = list;
        if (this.mAdReceiveListener != null) {
            this.mAdReceiveListener.onAdReceive(list);
        }
    }

    public void setAppId(long j) {
        this.mUrlBuilder.setAppId(j);
    }

    public void setIcc(String str) {
        this.mUrlBuilder.setIcc(str);
    }

    public void setIsDebug(boolean z) {
        this.mUrlBuilder.setIsDebug(z);
    }

    public void setIsNGP(boolean z) {
        this.mUrlBuilder.setIsNGP(z);
    }

    public void setPackageName(String str) {
        this.mUrlBuilder.setPackageName(str);
    }

    public void setSlotId(long j) {
        this.mUrlBuilder.setSlotId(j);
    }
}
