package com.keyboard.yhadsmodule.ads;

public class Config {
    public static final String API_VERSION = "1.0.0";
    public static final int CHARGE_CPA = 0;
    public static final int CHARGE_CPC = 0;
    public static final int CHARGE_CPM = 0;
    public static final int DEFAULT_LOCATION_PRECISION = 6;
    public static final String IFA_PREFIX = "ifa:";
    public static final int OS_ANDROID = 1;
    public static final String SDK_VERSION = "1.5.0";
    public static final String SERVER_SEARCH_URL_PREFIX = "http://adsnative.ymtrack.com/search.php";
    public static final String SERVER_STATIC_URL_PREFIX = "http://adsnative.ymtrack.com/";
    public static final String SHA_PREFIX = "sha:";
    public static final String YM_LOG_TAG = "YeahMobi";
}
