package com.keyboard.yhadsmodule.ads;

import android.os.AsyncTask;
import android.util.Log;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.impl.client.DefaultHttpClient;

public abstract class AbsAdTask extends AsyncTask<String, Void, List<AdResponse>> {
    protected HttpClient mHttpClient = new DefaultHttpClient();

    /* access modifiers changed from: protected */
    public boolean isResponseValid(HttpResponse httpResponse) {
        if (httpResponse == null || httpResponse.getEntity() == null) {
            Log.d(Config.YM_LOG_TAG, "MoPub server returned null response.");
            return false;
        }
        int statusCode = httpResponse.getStatusLine().getStatusCode();
        if (statusCode >= 400) {
            Log.d(Config.YM_LOG_TAG, "Server error: returned HTTP status code " + Integer.toString(statusCode) + ". Please try again.");
            return false;
        } else if (statusCode == 200) {
            return true;
        } else {
            Log.d(Config.YM_LOG_TAG, "MoPub server returned invalid response: HTTP status code " + Integer.toString(statusCode) + ".");
            return false;
        }
    }

    /* access modifiers changed from: protected */
    public boolean isStateValid() {
        return !isCancelled();
    }

    /* access modifiers changed from: protected */
    public String readFromStream(InputStream inputStream) throws IOException {
        StringBuffer stringBuffer = new StringBuffer();
        byte[] bArr = new byte[4096];
        int i = 0;
        while (i != -1) {
            stringBuffer.append(new String(bArr, 0, i));
            i = inputStream.read(bArr);
        }
        inputStream.close();
        return stringBuffer.toString();
    }

    /* access modifiers changed from: protected */
    public void shutdownHttpClient() {
        if (this.mHttpClient != null) {
            ClientConnectionManager connectionManager = this.mHttpClient.getConnectionManager();
            if (connectionManager != null) {
                connectionManager.shutdown();
            }
            this.mHttpClient = null;
        }
    }
}
