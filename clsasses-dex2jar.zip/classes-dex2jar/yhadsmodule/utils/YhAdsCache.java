package com.keyboard.yhadsmodule.utils;

import android.content.Context;
import com.iphonestyle.mms.ConstSetting;
import com.keyboard.yhadsmodule.ads.AdResponse;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Random;

public class YhAdsCache {
    private static Hashtable<String, AdsCacheItem> adsCache = new Hashtable<>();
    private static Random random = new Random();
    private static Hashtable<String, AdResponse> rawAdsCache = new Hashtable<>();

    public static AdsCacheItem get(Context context, String str) {
        AdsCacheItem adsCacheItem = adsCache.get(str);
        String onlineKeyValue = UpdateVersion.getOnlineKeyValue(context, "yhads_force_getcache");
        if (adsCacheItem == null && onlineKeyValue.equalsIgnoreCase(ConstSetting.IOS7_ENABLE)) {
            Enumeration<String> keys = adsCache.keys();
            if (keys.hasMoreElements()) {
                int size = adsCache.size();
                int nextInt = size > 1 ? random.nextInt(size) : 0;
                do {
                    adsCacheItem = adsCache.get(keys.nextElement());
                    nextInt--;
                } while (nextInt >= 0);
            }
        }
        return adsCacheItem;
    }

    public static AdResponse getRawAds(String str) {
        AdResponse adResponse = rawAdsCache.get(str);
        if (adResponse == null) {
            Enumeration<String> keys = rawAdsCache.keys();
            if (keys.hasMoreElements()) {
                int size = rawAdsCache.size();
                int nextInt = size > 1 ? random.nextInt(size) : 0;
                do {
                    adResponse = rawAdsCache.get(keys.nextElement());
                    nextInt--;
                } while (nextInt >= 0);
            }
        }
        return adResponse;
    }

    public static void put(String str, AdsCacheItem adsCacheItem) {
        if (adsCacheItem != null && str != null && str.length() > 0) {
            adsCache.put(str, adsCacheItem);
        }
    }

    public static void putRawAds(String str, AdResponse adResponse) {
        if (adResponse != null && str != null && str.length() > 0) {
            rawAdsCache.put(str, adResponse);
        }
    }
}
