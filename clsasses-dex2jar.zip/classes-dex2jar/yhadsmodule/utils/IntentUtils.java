package com.keyboard.yhadsmodule.utils;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import com.google.android.gms.drive.DriveFile;

public class IntentUtils {
    private static final String HIAPK = "com.hiapk.marketpho";
    private static final String HTTP = "http";
    private static final String HTTPS = "https";
    private static final String MARKET = "market";
    private static final String MARKET_ANDROID_COM = "market.android.com";
    private static final String PLAY_GOOGLE_COM = "play.google.com";
    private static final String TWITTER_APPLICATION_DEEPLINK_URL = "twitter://timeline";

    private IntentUtils() {
    }

    public static boolean canHandleApplicationUrl(Context context, String str) {
        return canHandleApplicationUrl(context, str, true);
    }

    public static boolean canHandleApplicationUrl(Context context, String str, boolean z) {
        if (deviceCanHandleIntent(context, new Intent("android.intent.action.VIEW", Uri.parse(str)))) {
            return true;
        }
        if (z) {
            Log.w("MoPub", "Could not handle application specific action: " + str + ". " + "You may be running in the emulator or another device which does not " + "have the required application.");
        }
        return false;
    }

    public static boolean canHandleTwitterUrl(Context context) {
        return canHandleApplicationUrl(context, TWITTER_APPLICATION_DEEPLINK_URL, false);
    }

    public static boolean deviceCanHandleIntent(Context context, Intent intent) {
        try {
            return !context.getPackageManager().queryIntentActivities(intent, 0).isEmpty();
        } catch (NullPointerException e) {
            return false;
        }
    }

    public static Intent getStartActivityIntent(Context context, Class cls, Bundle bundle) {
        Intent intent = new Intent(context, cls);
        if (!(context instanceof Activity)) {
            intent.addFlags(DriveFile.MODE_READ_ONLY);
        }
        if (bundle != null) {
            intent.putExtras(bundle);
        }
        return intent;
    }

    public static boolean isAppStoreUrl(String str) {
        if (str != null) {
            Uri parse = Uri.parse(str);
            String scheme = parse.getScheme();
            String host = parse.getHost();
            if (PLAY_GOOGLE_COM.equals(host) || MARKET_ANDROID_COM.equals(host) || MARKET.equals(scheme)) {
                return true;
            }
        }
        return false;
    }

    public static boolean isDeepLink(String str) {
        return !isHttpUrl(str);
    }

    public static boolean isHiapkUrl(String str) {
        if (str != null) {
            Uri parse = Uri.parse(str);
            parse.getScheme();
            if (HIAPK.equals(parse.getHost())) {
                return true;
            }
        }
        return false;
    }

    public static boolean isHttpUrl(String str) {
        if (str != null) {
            String scheme = Uri.parse(str).getScheme();
            if (HTTP.equals(scheme) || HTTPS.equals(scheme)) {
                return true;
            }
        }
        return false;
    }

    public static boolean shouldJumpHiapkLink(String str) {
        return isHiapkUrl(str);
    }
}
