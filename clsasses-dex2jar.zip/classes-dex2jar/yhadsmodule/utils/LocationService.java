package com.keyboard.yhadsmodule.utils;

import android.content.Context;
import android.location.Location;
import android.location.LocationManager;
import android.util.Log;
import com.alimama.mobile.csdk.umupdate.a.f;
import com.keyboard.yhadsmodule.ads.Config;
import java.math.BigDecimal;

public class LocationService {

    public enum LocationAwareness {
        NORMAL,
        TRUNCATED,
        DISABLED
    }

    public static Location getLastKnownLocation(Context context, int i, LocationAwareness locationAwareness) {
        Location location;
        Location location2;
        if (locationAwareness == LocationAwareness.DISABLED) {
            return null;
        }
        LocationManager locationManager = (LocationManager) context.getSystemService(f.al);
        try {
            location = locationManager.getLastKnownLocation("gps");
        } catch (SecurityException e) {
            Log.d(Config.YM_LOG_TAG, "Failed to retrieve GPS location: access appears to be disabled.");
            location = null;
        } catch (IllegalArgumentException e2) {
            Log.d(Config.YM_LOG_TAG, "Failed to retrieve GPS location: device has no GPS provider.");
            location = null;
        }
        try {
            location2 = locationManager.getLastKnownLocation("network");
        } catch (SecurityException e3) {
            Log.d(Config.YM_LOG_TAG, "Failed to retrieve network location: access appears to be disabled.");
            location2 = null;
        } catch (IllegalArgumentException e4) {
            Log.d(Config.YM_LOG_TAG, "Failed to retrieve network location: device has no network provider.");
            location2 = null;
        }
        if (location == null && location2 == null) {
            return null;
        }
        if (location == null || location2 == null) {
            if (location == null) {
                location = location2;
            }
        } else if (location.getTime() <= location2.getTime()) {
            location = location2;
        }
        if (locationAwareness != LocationAwareness.TRUNCATED) {
            return location;
        }
        location.setLatitude(BigDecimal.valueOf(location.getLatitude()).setScale(i, 5).doubleValue());
        location.setLongitude(BigDecimal.valueOf(location.getLongitude()).setScale(i, 5).doubleValue());
        return location;
    }
}
