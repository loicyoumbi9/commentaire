package com.keyboard.yhadsmodule.utils;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

public class Reflection {

    public static class MethodBuilder {
        private Class<?> mClass;
        private final Object mInstance;
        private boolean mIsAccessible;
        private boolean mIsStatic;
        private final String mMethodName;
        private List<Class<?>> mParameterClasses = new ArrayList();
        private List<Object> mParameters = new ArrayList();

        public MethodBuilder(Object obj, String str) {
            this.mInstance = obj;
            this.mMethodName = str;
            this.mClass = obj != null ? obj.getClass() : null;
        }

        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v0, resolved type: java.util.List<java.lang.Class<?>>} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v1, resolved type: java.util.List<java.lang.Object>} */
        /* JADX WARNING: Multi-variable type inference failed */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public <T> com.keyboard.yhadsmodule.utils.Reflection.MethodBuilder addParam(java.lang.Class<T> r2, T r3) {
            /*
                r1 = this;
                java.util.List<java.lang.Class<?>> r0 = r1.mParameterClasses
                r0.add(r2)
                java.util.List<java.lang.Object> r0 = r1.mParameters
                r0.add(r3)
                return r1
            */
            throw new UnsupportedOperationException("Method not decompiled: com.keyboard.yhadsmodule.utils.Reflection.MethodBuilder.addParam(java.lang.Class, java.lang.Object):com.keyboard.yhadsmodule.utils.Reflection$MethodBuilder");
        }

        public Object execute() throws Exception {
            Method declaredMethodWithTraversal = Reflection.getDeclaredMethodWithTraversal(this.mClass, this.mMethodName, (Class[]) this.mParameterClasses.toArray(new Class[this.mParameterClasses.size()]));
            if (this.mIsAccessible) {
                declaredMethodWithTraversal.setAccessible(true);
            }
            Object[] array = this.mParameters.toArray();
            return this.mIsStatic ? declaredMethodWithTraversal.invoke(null, array) : declaredMethodWithTraversal.invoke(this.mInstance, array);
        }

        public MethodBuilder setAccessible() {
            this.mIsAccessible = true;
            return this;
        }

        public MethodBuilder setStatic(Class<?> cls) {
            this.mIsStatic = true;
            this.mClass = cls;
            return this;
        }
    }

    public static boolean classFound(String str) {
        try {
            Class.forName(str);
            return true;
        } catch (ClassNotFoundException e) {
            return false;
        }
    }

    /* JADX WARN: Failed to insert an additional move for type inference into block B:10:? */
    /* JADX INFO: additional move instructions added (1) to help type inference */
    public static Method getDeclaredMethodWithTraversal(Class<?> cls, String str, Class<?>... clsArr) throws NoSuchMethodException {
        while (cls != null) {
            try {
                return cls.getDeclaredMethod(str, clsArr);
            } catch (NoSuchMethodException e) {
                cls = cls.getSuperclass();
            }
        }
        throw new NoSuchMethodException();
    }
}
