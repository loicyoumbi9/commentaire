package com.keyboard.yhadsmodule.utils;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.preference.PreferenceManager;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.Toast;
import com.alimama.mobile.csdk.umupdate.a.f;
import com.google.android.gms.drive.DriveFile;
import com.google.iphonestyle.mms.ContentType;
import com.keyboard.yhadsmodule.R;
import com.umeng.analytics.MobclickAgent;
import com.umeng.update.UmengUpdateAgent;
import com.umeng.update.UmengUpdateListener;
import com.umeng.update.UpdateResponse;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONStringer;

public class UpdateVersion {
    private static final String ADS_SHOW_EMOJIADS_DETAIL = "show_emojiads_detail";
    private static final String ADS_SHOW_FULLADS_DETAIL = "show_fullads_detail";
    private static final String ADS_SHOW_WITHOUTPLAY = "showads_withoutplay";
    private static final String BUBBLE_CHANGE = "bubble_change";
    private static final String BUY_PRO = "buy_pro";
    public static String CHECKFILE = "/sdcard/.emojikeyboard6_check.log";
    private static final String CHECK_LICENSE = "check_license";
    private static final String CLICK_BUY_PRO = "click_buy_pro";
    private static final String CLICK_COLORTHEME_SWITCH = "click_colortheme";
    private static final String CLICK_EMOJI_SWITCH = "click_emoji_switch";
    private static final String CLICK_FONT_SWITCH = "click_font";
    private static final String CLICK_QUICKENTRY = "click_quickentry";
    private static final String CLICK_SETTING_ITEM = "click_setting_item";
    private static final String CLICK_SUGGEST = "click_suggest";
    private static final String CLICK_SUGGEST_MORE = "click_suggest_more";
    private static final String CLICK_THEME = "click_theme";
    private static final String CLICK_THEME_SWITCH = "click_theme";
    private static final String CLICK_TREEITEM = "click_treeitem";
    private static final String CLICK_WALLPAPER_SWITCH = "click_wallpaper";
    private static final String CLICK_YHADS_DETAIL = "click_yhads_detail";
    private static final int DICT_DAYS = 5;
    private static final String GOT_YHADS_DETAIL = "got_yhads_detail";
    private static final String IDJSON_FILE = "/sdcard/adscache_array.txt";
    private static final String LOADING_YHADS_DETAIL = "loading_yhads_detail";
    private static final String LOAD_YHADS_DETAIL = "load_yhads_detail";
    private static final String LOAD_YHADS_FINALURL = "load_yhads_finalurl";
    private static final String NO_LICENSED = "no_licensed";
    private static final String ONCREATE_YHADS_DETAIL = "oncreate_yhads_detail";
    public static final long ONEDAY = 86400000;
    private static final String OPEN_EMOJI = "open_emoji_keyboard";
    private static final String OPEN_SETTING = "open_setting_activity";
    private static final String OPEN_THEME = "open_theme";
    private static final String POPUP_ALERT = "popup_license_alert";
    private static final String POPUP_NEWS = "popup_news";
    private static final int RATE_DAYS = 5;
    private static final String RECHOOSE_YHADS = "yh_rechoose_ads";
    private static final String UPDATE_CHECK_IGNORE = "pref_update_check_ignore_";
    private static final String YHADS_CLICK_REFRESH = "click_refresh_yhads";
    private static String androidId = null;

    public interface onLoadOverAds {
        void onFinish(View view);
    }

    public static boolean checkApkExist(Context context, String str) {
        Context context2 = null;
        try {
            context2 = context.createPackageContext(str, 2);
        } catch (Exception e) {
        }
        return context2 != null;
    }

    public static void checkEmojiDict(Context context) {
        if (!checkEmojiDictExist(context)) {
            int buyDays = getBuyDays(context);
            PreferenceManager.getDefaultSharedPreferences(context);
            String str = "pref_key_dict_emoji_app_" + (buyDays / 5);
            String onlineKeyValue = getOnlineKeyValue(context, "emojidict_plugin_check");
            if (onlineKeyValue == null || !onlineKeyValue.equalsIgnoreCase("false")) {
                installDictEmoji(context);
            }
        }
    }

    public static boolean checkEmojiDictExist(Context context) {
        String emojiName = getEmojiName(context);
        boolean checkApkExist = checkApkExist(context, emojiName);
        if (!checkApkExist) {
            return checkApkExist;
        }
        try {
            Context createPackageContext = context.createPackageContext(emojiName, 2);
            if (createPackageContext == null || getAppVersionCode(createPackageContext) >= 14) {
                return checkApkExist;
            }
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            return checkApkExist;
        }
    }

    public static boolean checkGooglePlay(Context context) {
        Context context2;
        try {
            context2 = context.createPackageContext("com.android.vending", 2);
        } catch (Exception e) {
            e.printStackTrace();
            context2 = null;
        }
        return context2 != null;
    }

    public static boolean checkOldUser(Context context) {
        getAndroidIdString(context);
        return checkUserLog(context);
    }

    public static void checkPopupRate(Context context) {
        int buyDays = getBuyDays(context);
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        String str = "pref_key_rate_app_" + (buyDays / 5);
        if (!defaultSharedPreferences.contains(str)) {
            defaultSharedPreferences.edit().putBoolean(str, true).commit();
            rateMe(context);
        }
    }

    public static void checkPopupRate(Context context, int i) {
        int buyDays = getBuyDays(context);
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        String str = "pref_key_rate_app_" + (buyDays / i);
        if (!defaultSharedPreferences.contains(str)) {
            defaultSharedPreferences.edit().putBoolean(str, true).commit();
            rateMe(context);
        }
    }

    public static void checkUpdate(final Context context, final boolean z) {
        UmengUpdateAgent.setUpdateOnlyWifi(false);
        UmengUpdateAgent.setUpdateAutoPopup(false);
        UmengUpdateAgent.setUpdateListener(new UmengUpdateListener() {
            /* class com.keyboard.yhadsmodule.utils.UpdateVersion.AnonymousClass1 */

            @Override // com.umeng.update.UmengUpdateListener
            public void onUpdateReturned(int i, UpdateResponse updateResponse) {
                switch (i) {
                    case 0:
                        if (!z) {
                            UmengUpdateAgent.showUpdateDialog(context, updateResponse);
                            return;
                        }
                        return;
                    case 1:
                        if (UpdateVersion.hasUpdate(context)) {
                            UpdateVersion.checkUpdateWhenStart(context);
                            return;
                        }
                        return;
                    case 2:
                    default:
                        return;
                    case 3:
                        UpdateVersion.showTipNow(context, "Timeout!");
                        return;
                }
            }
        });
        UmengUpdateAgent.update(context);
    }

    public static void checkUpdateStart(Context context, boolean z) {
        try {
            int appVersionCode = getAppVersionCode(context);
            String configParams = MobclickAgent.getConfigParams(context, "lastest_version");
            if (configParams.length() > 0) {
                int parseInt = Integer.parseInt(configParams);
                if (parseInt > appVersionCode) {
                    showUpdateDialog(context, z);
                } else if (parseInt <= appVersionCode && z) {
                    showTipNow(context, "No update!");
                }
            } else if (z) {
                showTipNow(context, "Timeout!");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void checkUpdateWhenStart(Context context) {
        checkUpdateStart(context, false);
    }

    public static boolean checkUserLog(Context context) {
        return isFileExist(CHECKFILE) && readSDFile(context, CHECKFILE).equalsIgnoreCase(getAndroidIdString(context));
    }

    public static String getAndroidIdString(Context context) {
        if (androidId == null) {
            try {
                androidId = Settings.System.getString(context.getContentResolver(), "android_id");
            } catch (Exception e) {
            }
        }
        return androidId;
    }

    private static long getAppInstallDate(Context context) {
        File file = new File(context.getFilesDir().getParentFile().getPath() + "/" + "lib/");
        File file2 = new File(context.getFilesDir().getParentFile().getPath() + "/" + "files/");
        File file3 = new File(context.getFilesDir().getParentFile().getPath() + "/" + "cache/");
        long lastModified = file.lastModified();
        long lastModified2 = file2.lastModified();
        long lastModified3 = file3.lastModified();
        if (lastModified2 == 0 || lastModified2 >= lastModified) {
            lastModified2 = lastModified;
        }
        return (lastModified3 == 0 || lastModified3 >= lastModified2) ? lastModified2 : lastModified3;
    }

    public static int getAppVersionCode(Context context) {
        try {
            return context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionCode;
        } catch (Exception e) {
            Log.e("VersionInfo", "Exception", e);
            return 0;
        }
    }

    public static String getAppVersionName(Context context) {
        try {
            return context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionName;
        } catch (Exception e) {
            Log.e("VersionInfo", "Exception", e);
            return "";
        }
    }

    public static boolean getBooleanValue(Context context, String str, boolean z) {
        return PreferenceManager.getDefaultSharedPreferences(context).getBoolean(str, z);
    }

    public static long getBuyDate(Context context) {
        return PreferenceManager.getDefaultSharedPreferences(context).getLong("pref_key_first_install_date", System.currentTimeMillis());
    }

    public static int getBuyDays(Context context) {
        return (int) ((System.currentTimeMillis() - PreferenceManager.getDefaultSharedPreferences(context).getLong("pref_key_first_install_date", System.currentTimeMillis())) / 86400000);
    }

    public static String getEmojiName(Context context) {
        String onlineKeyValue = getOnlineKeyValue(context, "emojidict_plugin_pkg_name");
        return (onlineKeyValue == null || onlineKeyValue.length() <= 0) ? "com.crazystudio.inputmethod.inputdict" : onlineKeyValue;
    }

    public static boolean getKeyContain(Context context, String str) {
        return PreferenceManager.getDefaultSharedPreferences(context).contains(str);
    }

    public static String getLanguage(Context context) {
        try {
            return context.getResources().getConfiguration().locale.getLanguage();
        } catch (Exception e) {
            return "";
        }
    }

    public static boolean getOnceAction(Context context, String str) {
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        if (defaultSharedPreferences.contains(str)) {
            return false;
        }
        defaultSharedPreferences.edit().putBoolean(str, true).commit();
        return true;
    }

    public static String getOnlineKeyValue(Context context, String str) {
        MobclickAgent.updateOnlineConfig(context);
        return MobclickAgent.getConfigParams(context, str);
    }

    public static boolean getStatus(Context context) {
        return PreferenceManager.getDefaultSharedPreferences(context).getBoolean("pref_key_buy_status", false);
    }

    public static boolean getStatusEx(Context context) {
        boolean z = PreferenceManager.getDefaultSharedPreferences(context).getBoolean("pref_key_buy_status", false) | checkOldUser(context);
        if (z) {
            writeOldUser(context);
        }
        return z;
    }

    /* access modifiers changed from: private */
    public static void getUpadte(Context context) {
        rate(context);
    }

    public static boolean hasUpdate(Context context) {
        int appVersionCode = getAppVersionCode(context);
        String configParams = MobclickAgent.getConfigParams(context, "lastest_version");
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        String configParams2 = MobclickAgent.getConfigParams(context, "lastest_version");
        MobclickAgent.getConfigParams(context, "lastest_desc");
        return configParams.length() > 0 && Integer.parseInt(configParams) > appVersionCode && !defaultSharedPreferences.getBoolean(new StringBuilder().append(UPDATE_CHECK_IGNORE).append(configParams2).toString(), false);
    }

    public static void initInstallDate(Context context, String str) {
        try {
            if (!new File(str).exists()) {
                long appInstallDate = getAppInstallDate(context);
                if (appInstallDate == 0) {
                    appInstallDate = getBuyDate(context);
                }
                if (appInstallDate == 0) {
                    appInstallDate = System.currentTimeMillis();
                }
                writeSDFile(str, appInstallDate + "");
            }
        } catch (Exception e) {
        }
    }

    public static void install(Context context, String str) {
        try {
            if (checkGooglePlay(context)) {
                rateMarket(context, str);
            } else {
                rateBrowser(context, str);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void installDictEmoji(final Context context) {
        new AlertDialog.Builder(context).setTitle("Dict,Emoji Plugin").setIcon(17301659).setMessage("Do you want to install dictionary and color emoji plugin?").setPositiveButton("Install", new DialogInterface.OnClickListener() {
            /* class com.keyboard.yhadsmodule.utils.UpdateVersion.AnonymousClass6 */

            public void onClick(DialogInterface dialogInterface, int i) {
                UpdateVersion.install(context, UpdateVersion.getEmojiName(context));
            }
        }).setNegativeButton("No, Thanks!", (DialogInterface.OnClickListener) null).show();
    }

    public static void installTheme(final Context context, String str, final String str2) {
        new AlertDialog.Builder(context).setTitle(str).setIcon(17301659).setMessage("Do you want to install " + str).setPositiveButton("Install", new DialogInterface.OnClickListener() {
            /* class com.keyboard.yhadsmodule.utils.UpdateVersion.AnonymousClass5 */

            public void onClick(DialogInterface dialogInterface, int i) {
                UpdateVersion.install(context, str2);
            }
        }).setNegativeButton("No, Thanks!", (DialogInterface.OnClickListener) null).show();
    }

    private static boolean isFileExist(String str) {
        try {
            return new File(str).exists();
        } catch (Exception e) {
        }
    }

    public static void onEventBuyPro(Context context, String str, String str2) {
        HashMap hashMap = new HashMap();
        hashMap.put("status", str);
        hashMap.put("where", str2);
        hashMap.put("version", getAppVersionName(context));
        MobclickAgent.onEvent(context, BUY_PRO, hashMap);
    }

    public static void onEventBuyProEx(Context context, String str, String str2, String str3) {
        HashMap hashMap = new HashMap();
        hashMap.put("status", str);
        hashMap.put("where", str2);
        hashMap.put(f.bl, str3);
        hashMap.put("version", getAppVersionName(context));
        MobclickAgent.onEvent(context, BUY_PRO, hashMap);
    }

    public static void onEventChangeBubble(Context context, String str) {
        HashMap hashMap = new HashMap();
        hashMap.put("userid", getAndroidIdString(context));
        hashMap.put("status", str);
    }

    public static void onEventCheckLicense(Context context, String str) {
        HashMap hashMap = new HashMap();
        hashMap.put("userid", getAndroidIdString(context));
        hashMap.put("status", str);
        MobclickAgent.onEvent(context, CHECK_LICENSE, hashMap);
    }

    public static void onEventClickBuyPro(Context context, String str) {
        HashMap hashMap = new HashMap();
        hashMap.put("userid", getAndroidIdString(context));
        hashMap.put("status", str);
        MobclickAgent.onEvent(context, CLICK_BUY_PRO, hashMap);
    }

    public static void onEventClickColorThemeSwitch(Context context, String str) {
        HashMap hashMap = new HashMap();
        hashMap.put("themename", str);
        hashMap.put("usedays", getBuyDays(context) + "");
        MobclickAgent.onEvent(context, CLICK_COLORTHEME_SWITCH, hashMap);
    }

    public static void onEventClickColorThemeSwitchEx(Context context, String str) {
        HashMap hashMap = new HashMap();
        hashMap.put("customitem", str);
        hashMap.put("usedays", getBuyDays(context) + "");
        MobclickAgent.onEvent(context, CLICK_COLORTHEME_SWITCH, hashMap);
    }

    public static void onEventClickEmojiSwitch(Context context, String str, String str2, String str3, String str4) {
        HashMap hashMap = new HashMap();
        hashMap.put("theme", str);
        hashMap.put("emojistyle", str2);
        hashMap.put("status", str3);
        hashMap.put("days", str4);
        MobclickAgent.onEvent(context, CLICK_EMOJI_SWITCH, hashMap);
    }

    public static void onEventClickFontSwitch(Context context, String str) {
        HashMap hashMap = new HashMap();
        hashMap.put("font", str);
        hashMap.put("usedays", getBuyDays(context) + "");
        MobclickAgent.onEvent(context, CLICK_FONT_SWITCH, hashMap);
    }

    public static void onEventClickSettingEntry(Context context) {
        HashMap hashMap = new HashMap();
        hashMap.put("usedays", getBuyDays(context) + "");
        MobclickAgent.onEvent(context, CLICK_QUICKENTRY, hashMap);
    }

    public static void onEventClickSuggest(Context context, String str, String str2) {
        HashMap hashMap = new HashMap();
        hashMap.put("where", str2);
        hashMap.put("status", str);
        MobclickAgent.onEvent(context, CLICK_SUGGEST, hashMap);
    }

    public static void onEventClickSuggestMore(Context context, String str, String str2) {
        HashMap hashMap = new HashMap();
        hashMap.put("position", str);
        if (str2.length() > 0) {
            hashMap.put("pkg", str2);
        }
        MobclickAgent.onEvent(context, CLICK_SUGGEST_MORE, hashMap);
    }

    public static void onEventClickTheme(Context context, String str) {
        HashMap hashMap = new HashMap();
        hashMap.put("where", str);
        hashMap.put("usedays", getBuyDays(context) + "");
        MobclickAgent.onEvent(context, "click_theme", hashMap);
    }

    public static void onEventClickThemeSwitch(Context context, String str, String str2) {
        HashMap hashMap = new HashMap();
        hashMap.put("theme", str);
        hashMap.put("type", str2);
        hashMap.put("usedays", getBuyDays(context) + "");
        MobclickAgent.onEvent(context, "click_theme", hashMap);
    }

    public static void onEventClickTreeItem(Context context, String str) {
        HashMap hashMap = new HashMap();
        hashMap.put("title", str);
        hashMap.put("usedays", getBuyDays(context) + "");
        MobclickAgent.onEvent(context, CLICK_TREEITEM, hashMap);
    }

    public static void onEventClickTreeItemEx(Context context, String str, String str2) {
        HashMap hashMap = new HashMap();
        hashMap.put("title", str);
        hashMap.put(f.bk, str2);
        MobclickAgent.onEvent(context, CLICK_TREEITEM, hashMap);
    }

    public static void onEventClickTreeItemEx2(Context context, String str, String str2) {
        HashMap hashMap = new HashMap();
        hashMap.put("titleother", str);
        hashMap.put(f.bk, str2);
        MobclickAgent.onEvent(context, CLICK_TREEITEM, hashMap);
    }

    public static void onEventClickWallpaperSwitch(Context context, String str) {
        HashMap hashMap = new HashMap();
        hashMap.put("usedays", getBuyDays(context) + "");
        hashMap.put("key", str);
        MobclickAgent.onEvent(context, CLICK_WALLPAPER_SWITCH, hashMap);
    }

    public static void onEventClickYhAds(Context context, String str, String str2, String str3, String str4, String str5, String str6, String str7) {
        HashMap hashMap = new HashMap();
        hashMap.put("pkg", str);
        hashMap.put("sec", str2);
        hashMap.put(f.aZ, str3);
        hashMap.put("status", str4);
        hashMap.put(f.bj, str5);
        hashMap.put("url", str6);
        if (!TextUtils.isEmpty(str7)) {
            hashMap.put("position", str7);
        }
        Log.e("onEventClickYhAds", "pkg:" + str + "\n" + "sec:" + str2 + "\n" + "bid:" + str3 + "\n" + "cc:" + str5 + "\n" + "status:" + str4 + "\n");
        MobclickAgent.onEvent(context, CLICK_YHADS_DETAIL, hashMap);
    }

    public static void onEventCustom(Context context, String str, String str2) {
        HashMap hashMap = new HashMap();
        hashMap.put("version", getAppVersionName(context));
        hashMap.put("extra", str2);
        MobclickAgent.onEvent(context, str, hashMap);
    }

    public static void onEventGotAdsOver(Context context, String str, String str2, String str3, String str4, String str5, String str6) {
        HashMap hashMap = new HashMap();
        hashMap.put("pkg", str);
        hashMap.put(f.aZ, str2);
        hashMap.put("sec", str3);
        hashMap.put(f.q, str4);
        hashMap.put(f.bj, str5);
        if (!TextUtils.isEmpty(str6)) {
            hashMap.put("position", str6);
        }
        Log.e("onEventGotAdsOver", "pkg:" + str + "\n" + "sec:" + str3 + "\n" + "bid:" + str2 + "\n" + "preload:" + str4 + "\n");
        MobclickAgent.onEvent(context, GOT_YHADS_DETAIL, hashMap);
    }

    public static void onEventLoadFinalYhAds(Context context, String str, String str2, String str3, String str4) {
        HashMap hashMap = new HashMap();
        hashMap.put("newurl", str);
        hashMap.put("newshorturl", str2);
        hashMap.put("referrer", str3);
        hashMap.put("type", str4);
        MobclickAgent.onEvent(context, LOAD_YHADS_FINALURL, hashMap);
    }

    public static void onEventLoadYhAds(Context context, String str, String str2, String str3, String str4, String str5, String str6, String str7) {
        HashMap hashMap = new HashMap();
        hashMap.put("seconds", str2);
        hashMap.put("marketurl", str);
        hashMap.put("pkg", str3);
        hashMap.put(f.aZ, str4);
        hashMap.put("status", str5);
        if (!TextUtils.isEmpty(str7)) {
            hashMap.put("position", str7);
        }
        Log.e("onEventLoadYhAds", "pkg:" + str3 + "\n" + "marketurl:" + str + "\n" + "sec:" + str2 + "\n" + "bid:" + str4 + "\n" + "status:" + str5 + "\n");
        MobclickAgent.onEvent(context, LOAD_YHADS_DETAIL + str6, hashMap);
    }

    public static void onEventLoadingYhAds(Context context, String str) {
        HashMap hashMap = new HashMap();
        hashMap.put("pkg", str);
        MobclickAgent.onEvent(context, LOADING_YHADS_DETAIL, hashMap);
    }

    public static void onEventNotlicense(Context context) {
        HashMap hashMap = new HashMap();
        hashMap.put("userid", getAndroidIdString(context));
        MobclickAgent.onEvent(context, NO_LICENSED, hashMap);
    }

    public static void onEventOnCreate(Context context, String str, String str2) {
        HashMap hashMap = new HashMap();
        hashMap.put(f.bj, str);
        if (!TextUtils.isEmpty(str2)) {
            hashMap.put("position", str2);
        }
        MobclickAgent.onEvent(context, ONCREATE_YHADS_DETAIL, hashMap);
    }

    public static void onEventOnRefresh(Context context, String str, String str2) {
        HashMap hashMap = new HashMap();
        hashMap.put(f.bj, str);
        if (!TextUtils.isEmpty(str2)) {
            hashMap.put("position", str2);
        }
        MobclickAgent.onEvent(context, YHADS_CLICK_REFRESH, hashMap);
    }

    public static void onEventOpenEmoji(Context context, String str) {
        HashMap hashMap = new HashMap();
        hashMap.put("status", str);
        MobclickAgent.onEvent(context, OPEN_EMOJI, hashMap);
    }

    public static void onEventOpenSetting(Context context, String str) {
        HashMap hashMap = new HashMap();
        hashMap.put("useddays", str);
        MobclickAgent.onEvent(context, OPEN_SETTING, hashMap);
    }

    public static void onEventOpenTheme(Context context, String str) {
        HashMap hashMap = new HashMap();
        hashMap.put("where", str);
        MobclickAgent.onEvent(context, OPEN_THEME, hashMap);
    }

    public static void onEventPopupAlert(Context context) {
        HashMap hashMap = new HashMap();
        hashMap.put("userid", getAndroidIdString(context));
        MobclickAgent.onEvent(context, POPUP_ALERT, hashMap);
    }

    public static void onEventPopupNews(Context context) {
        HashMap hashMap = new HashMap();
        hashMap.put("userid", getAndroidIdString(context));
        MobclickAgent.onEvent(context, POPUP_NEWS, hashMap);
    }

    public static void onEventRechoose(Context context, String str, String str2, String str3, String str4, String str5, String str6) {
        HashMap hashMap = new HashMap();
        hashMap.put("pkg", str);
        hashMap.put(f.aZ, str2);
        hashMap.put("sec", str3);
        hashMap.put(f.q, str4);
        hashMap.put(f.bj, str5);
        if (!TextUtils.isEmpty(str6)) {
            hashMap.put("position", str6);
        }
        MobclickAgent.onEvent(context, RECHOOSE_YHADS, hashMap);
    }

    public static void onEventSettingsClick(Context context, String str) {
        HashMap hashMap = new HashMap();
        String language = context.getResources().getConfiguration().locale.getLanguage();
        hashMap.put(f.bk, language);
        if (language.contains("en")) {
            hashMap.put("title", str);
        }
        hashMap.put("usedays", getBuyDays(context) + "");
        MobclickAgent.onEvent(context, CLICK_SETTING_ITEM, hashMap);
    }

    public static void onEventShowEmojiAdsDetail(Context context, String str) {
        HashMap hashMap = new HashMap();
        hashMap.put("useddays", str);
        MobclickAgent.onEvent(context, ADS_SHOW_EMOJIADS_DETAIL, hashMap);
    }

    public static void onEventShowadsDetail(Context context, String str, String str2) {
        HashMap hashMap = new HashMap();
        hashMap.put("useddays", str);
        hashMap.put("position", str2);
        MobclickAgent.onEvent(context, ADS_SHOW_FULLADS_DETAIL, hashMap);
    }

    public static void onEventShowadsWithoutPlay(Context context, String str) {
        HashMap hashMap = new HashMap();
        hashMap.put("googleplay", str);
        MobclickAgent.onEvent(context, ADS_SHOW_WITHOUTPLAY, hashMap);
    }

    public static void onEventUpload(Context context, String str, String str2) {
        HashMap hashMap = new HashMap();
        hashMap.put("status", str2);
        MobclickAgent.onEvent(context, str, hashMap);
    }

    public static void onEventUploadEx(Context context, String str, String str2, String str3, String str4, String str5) {
        HashMap hashMap = new HashMap();
        if (str2.length() > 0) {
            hashMap.put(str2, str4);
        }
        if (str3.length() > 0) {
            hashMap.put(str3, str5);
        }
        MobclickAgent.onEvent(context, str, hashMap);
    }

    public static void onEventUploadEx1(Context context, String str, String str2, String str3) {
        HashMap hashMap = new HashMap();
        hashMap.put(str2, str3);
        MobclickAgent.onEvent(context, str, hashMap);
    }

    public static void rate(Context context) {
        try {
            if (checkGooglePlay(context)) {
                rateMarket(context);
            } else {
                rateBrowser(context);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void rateBrowser(Context context) {
        Uri parse = Uri.parse("http://adsmarket.android.com/details?id=" + context.getPackageName());
        String configParams = MobclickAgent.getConfigParams(context, "lastest_http");
        if (!TextUtils.isEmpty(configParams) && !configParams.equalsIgnoreCase(f.b)) {
            parse = Uri.parse(configParams);
        }
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.setData(parse);
        context.startActivity(intent);
    }

    private static void rateBrowser(Context context, String str) {
        Uri parse = Uri.parse("http://adsmarket.android.com/details?id=" + str);
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.setData(parse);
        intent.addFlags(DriveFile.MODE_READ_ONLY);
        context.startActivity(intent);
    }

    public static void rateDirectBrowser(Context context, String str) {
        Uri parse = Uri.parse(str);
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.setData(parse);
        intent.addFlags(DriveFile.MODE_READ_ONLY);
        intent.setPackage("com.android.vending");
        context.startActivity(intent);
    }

    private static void rateMarket(Context context) {
        Uri parse = Uri.parse("market://details?id=" + context.getPackageName());
        String configParams = MobclickAgent.getConfigParams(context, "lastest_url");
        if (!TextUtils.isEmpty(configParams) && !configParams.equalsIgnoreCase(f.b)) {
            parse = Uri.parse(configParams);
        }
        Intent intent = new Intent();
        intent.setData(parse);
        intent.setPackage("com.android.vending");
        context.startActivity(intent);
    }

    private static void rateMarket(Context context, String str) {
        Uri parse = Uri.parse("market://details?id=" + str + "&feature=top-free");
        Intent intent = new Intent();
        intent.setData(parse);
        intent.addFlags(DriveFile.MODE_READ_ONLY);
        intent.setPackage("com.android.vending");
        context.startActivity(intent);
    }

    private static void rateMarketChoose(Context context, String str) {
        Uri parse = Uri.parse("market://details?id=" + str);
        Intent intent = new Intent();
        intent.setData(parse);
        intent.setFlags(DriveFile.MODE_READ_ONLY);
        context.startActivity(intent);
    }

    private static void rateMarketDirect(Context context, String str) {
        Uri parse = Uri.parse("market://details?id=" + str);
        Intent intent = new Intent();
        intent.setData(parse);
        intent.setPackage("com.android.vending");
        intent.setFlags(DriveFile.MODE_READ_ONLY);
        context.startActivity(intent);
    }

    private static void rateMe(final Context context) {
        new AlertDialog.Builder(context).setTitle("Rate me:").setIcon(17301659).setMessage("Could you help rate star or give suggestion for me to make grow better?").setPositiveButton("Rate", new DialogInterface.OnClickListener() {
            /* class com.keyboard.yhadsmodule.utils.UpdateVersion.AnonymousClass7 */

            public void onClick(DialogInterface dialogInterface, int i) {
                UpdateVersion.install(context, context.getPackageName());
            }
        }).setNegativeButton("No, Thanks!", (DialogInterface.OnClickListener) null).show();
    }

    public static long readInstallDate(Context context, String str) {
        try {
            if (!new File(str).exists()) {
                return 0;
            }
            String readSDFile = readSDFile(context, str);
            if (readSDFile.length() > 0) {
                return Long.parseLong(readSDFile);
            }
            return 0;
        } catch (Exception e) {
            return 0;
        }
    }

    private static String readSDFile(Context context, String str) {
        try {
            FileInputStream fileInputStream = new FileInputStream(str);
            byte[] bArr = new byte[fileInputStream.available()];
            if (fileInputStream.read(bArr) > 0) {
                return new String(bArr);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    private void saveColorThemeJsonArray(Context context, List<String> list) {
        try {
            JSONArray jSONArray = new JSONArray();
            for (int i = 0; i < list.size(); i++) {
                JSONObject jSONObject = new JSONObject();
                jSONObject.put("name", "name");
                jSONObject.put("keyboardbgcolor", "bgcolor");
                jSONArray.put(jSONObject);
            }
            String jSONStringer = new JSONStringer().object().key("adscache").value(jSONArray).endObject().toString();
            System.out.println(jSONStringer);
            writeSDFile(IDJSON_FILE, jSONStringer);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void saveStatus(Context context, boolean z) {
        SharedPreferences.Editor edit = PreferenceManager.getDefaultSharedPreferences(context).edit();
        edit.putBoolean("pref_key_buy_status", z);
        edit.commit();
    }

    public static void sendFeedback(Context context, String str, String str2, String str3) {
        try {
            Intent intent = new Intent("android.intent.action.SEND");
            intent.putExtra("subject", "Feedback");
            intent.putExtra("body", "Feedback to  " + str + " " + str2 + ":\n\n");
            intent.putExtra("android.intent.extra.EMAIL", new String[]{"" + str3});
            intent.setType(ContentType.TEXT_PLAIN);
            context.startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void setBooleanValue(Context context, String str, boolean z) {
        PreferenceManager.getDefaultSharedPreferences(context).edit().putBoolean(str, z).commit();
    }

    public static void setFirstInstall(Context context, String str) {
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        if (!defaultSharedPreferences.contains(str) || !defaultSharedPreferences.contains("pref_key_first_install_date")) {
            defaultSharedPreferences.edit().putLong("pref_key_first_install_date", System.currentTimeMillis()).commit();
        }
    }

    public static void showTipNow(Context context, String str) {
        try {
            Toast.makeText(context, str, 0).show();
        } catch (Exception e) {
        }
    }

    public static void showUpdateDialog(final Context context, boolean z) {
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        final SharedPreferences.Editor edit = defaultSharedPreferences.edit();
        final String configParams = MobclickAgent.getConfigParams(context, "lastest_version");
        String configParams2 = MobclickAgent.getConfigParams(context, "lastest_desc");
        if (!defaultSharedPreferences.getBoolean(UPDATE_CHECK_IGNORE + configParams, false) || z) {
            int i = R.layout.update_layout;
            if (context instanceof Activity) {
                View inflate = ((Activity) context).getLayoutInflater().inflate(i, (ViewGroup) null);
                if (configParams2.length() <= 0) {
                    context.getString(R.string.update_tip);
                } else {
                    TextView textView = (TextView) inflate.findViewById(R.id.update_tip_info);
                    if (textView != null) {
                        textView.setText(configParams2);
                    }
                }
                CheckBox checkBox = (CheckBox) inflate.findViewById(R.id.update_ignore);
                if (checkBox != null) {
                    checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                        /* class com.keyboard.yhadsmodule.utils.UpdateVersion.AnonymousClass2 */

                        public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                            edit.putBoolean(UpdateVersion.UPDATE_CHECK_IGNORE + configParams, z);
                            edit.commit();
                        }
                    });
                }
                new AlertDialog.Builder(context).setTitle("Found new update!").setView(inflate).setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    /* class com.keyboard.yhadsmodule.utils.UpdateVersion.AnonymousClass4 */

                    public void onClick(DialogInterface dialogInterface, int i) {
                        UpdateVersion.getUpadte(context);
                    }
                }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    /* class com.keyboard.yhadsmodule.utils.UpdateVersion.AnonymousClass3 */

                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                }).show().setCancelable(false);
            }
        }
    }

    private static void writeData(Context context, String str, String str2) {
        try {
            FileOutputStream openFileOutput = context.openFileOutput(str2, 0);
            openFileOutput.write(str.getBytes());
            openFileOutput.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void writeOldUser(Context context) {
        String androidIdString = getAndroidIdString(context);
        if (!isFileExist(CHECKFILE)) {
            writeSDFile(CHECKFILE, androidIdString);
        }
    }

    public static void writeSDFile(String str, String str2) {
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(str);
            fileOutputStream.write(str2.getBytes());
            fileOutputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
