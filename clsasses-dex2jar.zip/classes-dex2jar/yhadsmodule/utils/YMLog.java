package com.keyboard.yhadsmodule.utils;

import android.util.Log;

public class YMLog {
    private static final String LOGTAG = "MyLog";

    public static int d(String str) {
        return d(str, null);
    }

    public static int d(String str, Throwable th) {
        return Log.d(LOGTAG, str, th);
    }

    public static int e(String str) {
        return e(str, null);
    }

    public static int e(String str, Throwable th) {
        return Log.e(LOGTAG, str, th);
    }

    public static int w(String str) {
        return w(str, null);
    }

    public static int w(String str, Throwable th) {
        return Log.w(LOGTAG, str, th);
    }
}
