package com.keyboard.yhadsmodule.utils;

public class AdsRecordItem {
    public String bid;
    public String finalurl;
    public String pkg;
    String recordurl;
    public String status;
    public String title;
    String trackurl;

    public AdsRecordItem() {
    }

    public AdsRecordItem(String str, String str2, String str3, String str4) {
        this.finalurl = str;
        this.bid = str2;
        this.pkg = str3;
        this.status = str4;
    }

    public AdsRecordItem(String str, String str2, String str3, String str4, String str5, String str6) {
        this.recordurl = str;
        this.trackurl = str2;
        this.finalurl = str3;
        this.bid = str4;
        this.pkg = str5;
        this.status = str6;
    }
}
