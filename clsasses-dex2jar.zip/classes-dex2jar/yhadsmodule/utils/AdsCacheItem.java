package com.keyboard.yhadsmodule.utils;

public class AdsCacheItem {
    String bid;
    String finalurl;
    String pkg;
    String recordurl;
    String title;
    String trackurl;

    public AdsCacheItem(String str, String str2, String str3, String str4, String str5, String str6) {
        this.recordurl = str;
        this.trackurl = str2;
        this.finalurl = str3;
        this.bid = str4;
        this.pkg = str5;
        this.title = str6;
    }

    public String getBid() {
        return this.bid;
    }

    public String getFinaUrl() {
        return this.finalurl;
    }

    public String getPkg() {
        return this.pkg;
    }

    public String getRecordUrl() {
        return this.recordurl;
    }

    public String getTitle() {
        return this.title;
    }

    public String getTrackUrl() {
        return this.trackurl;
    }

    public void setBid(String str) {
        this.bid = str;
    }

    public void setFinaUrl(String str) {
        this.finalurl = str;
    }

    public void setRecordUrl(String str) {
        this.recordurl = str;
    }

    public void setTitle(String str) {
        this.title = str;
    }

    public void setTrackUrl(String str) {
        this.trackurl = str;
    }

    public void update(AdsCacheItem adsCacheItem) {
        if (adsCacheItem != null) {
            this.trackurl = adsCacheItem.trackurl;
            this.recordurl = adsCacheItem.recordurl;
        }
    }
}
