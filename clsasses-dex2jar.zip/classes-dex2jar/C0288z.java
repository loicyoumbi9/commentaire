package com.ironsource.mobilcore;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Build;
import android.view.KeyEvent;
import android.webkit.ConsoleMessage;
import android.webkit.WebSettings;
import android.webkit.WebView;
import com.ironsource.mobilcore.aG;

/* renamed from: com.ironsource.mobilcore.z  reason: case insensitive filesystem */
class C0288z extends WebView {
    protected static int a = 0;
    private b b;
    /* access modifiers changed from: private */
    public a c;

    /* renamed from: com.ironsource.mobilcore.z$a */
    public interface a {
        boolean a();

        void b();
    }

    /* renamed from: com.ironsource.mobilcore.z$b */
    private final class b extends aG {
        public b(WebView webView) {
            super(webView);
        }

        @Override // com.ironsource.mobilcore.aG
        public final boolean onConsoleMessage(ConsoleMessage consoleMessage) {
            if (consoleMessage.messageLevel() == ConsoleMessage.MessageLevel.ERROR) {
                if (C0288z.this.c != null) {
                    a unused = C0288z.this.c;
                }
                B.a("WebViewWithLoadState , id:" + C0288z.this.getId() + " | onConsoleMessage() " + consoleMessage.messageLevel(), 55);
                C0288z.this.a();
            }
            return super.onConsoleMessage(consoleMessage);
        }
    }

    public C0288z(Context context) {
        super(context);
        b();
    }

    public void a() {
    }

    public final void a(aG.a aVar) {
        this.b.a(aVar);
    }

    public final void a(a aVar) {
        this.c = aVar;
    }

    @SuppressLint({"NewApi"})
    public final void a(boolean z) {
        if (Build.VERSION.SDK_INT >= 11 && Build.VERSION.SDK_INT < 19) {
            setLayerType(1, null);
        }
    }

    /* access modifiers changed from: protected */
    @SuppressLint({"SetJavaScriptEnabled", "InlinedApi", "NewApi"})
    public void b() {
        int i = a;
        a = i + 1;
        setId(i);
        String str = getContext().getCacheDir().getAbsolutePath() + "/mobilecore";
        setBackgroundColor(0);
        getSettings().setJavaScriptEnabled(true);
        getSettings().setSupportMultipleWindows(false);
        getSettings().setNeedInitialFocus(false);
        getSettings().setSupportZoom(false);
        getSettings().setAllowFileAccess(true);
        getSettings().setAppCacheEnabled(true);
        getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
        if (Build.VERSION.SDK_INT < 18) {
            getSettings().setRenderPriority(WebSettings.RenderPriority.HIGH);
            getSettings().setPluginState(WebSettings.PluginState.ON);
        }
        getSettings().setCacheMode(-1);
        getSettings().setAppCachePath(str);
        setHorizontalScrollBarEnabled(false);
        setInitialScale(100);
        if (Build.VERSION.SDK_INT >= 17) {
            getSettings().setMediaPlaybackRequiresUserGesture(false);
        }
        a(true);
        setScrollBarStyle(33554432);
        this.b = new b(this);
        setWebChromeClient(this.b);
        aF.a((WebView) this);
    }

    /* access modifiers changed from: protected */
    public void onDetachedFromWindow() {
        if (this.c != null) {
            B.a("WebViewWithLoadState , id:" + getId() + " | onDetachedFromWindow() ", 55);
            this.c.b();
        }
        super.onDetachedFromWindow();
    }

    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        if (i != 4 || this.c == null) {
            return super.onKeyDown(i, keyEvent);
        }
        B.a("WebViewWithLoadState , id:" + getId() + " | onKeyDown | back ", 55);
        this.c.a();
        return true;
    }
}
