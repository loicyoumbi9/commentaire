package com.ironsource.mobilcore;

/* renamed from: com.ironsource.mobilcore.am  reason: case insensitive filesystem */
enum C0250am {
    LEFT,
    TOP,
    RIGHT,
    BOTTOM
}
