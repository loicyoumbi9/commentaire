package com.ironsource.mobilcore;

/* renamed from: com.ironsource.mobilcore.w  reason: case insensitive filesystem */
final class C0285w {
    protected static String a(String str) {
        String str2 = "";
        for (int i = 0; i < str.length(); i++) {
            if (str.charAt(i) < 'k') {
                str2 = str2.concat(String.valueOf(str.charAt(i))).concat("g#s");
            } else if (str.charAt(i) >= 'k') {
                str2 = str2.concat(String.valueOf(str.charAt(i))).concat("d%1");
            }
        }
        return c(str2);
    }

    protected static String b(String str) {
        return c(str).replaceAll("g#s", "").replaceAll("d%1", "");
    }

    private static String c(String str) {
        char[] charArray = str.toCharArray();
        int i = 0;
        for (int length = charArray.length - 1; i < length; length--) {
            char c = charArray[i];
            charArray[i] = charArray[length];
            charArray[length] = c;
            i++;
        }
        return new String(charArray);
    }
}
