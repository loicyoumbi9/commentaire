package com.nostra13.universalimageloader.core.process;

import android.graphics.Bitmap;

public interface BitmapProcessor {
    Bitmap process(Bitmap bitmap);
}
