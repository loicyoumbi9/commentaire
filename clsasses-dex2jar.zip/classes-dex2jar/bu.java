package u.aly;

public abstract class bu extends bx {
    public bu() {
        super("");
    }
}
