package u.aly;

import org.json.JSONObject;

public class bv extends by {
    public a a;

    public enum a {
        SUCCESS,
        FAIL
    }

    public bv(JSONObject jSONObject) {
        super(jSONObject);
        if ("ok".equalsIgnoreCase(jSONObject.optString("status")) || "ok".equalsIgnoreCase(jSONObject.optString("success"))) {
            this.a = a.SUCCESS;
        } else {
            this.a = a.FAIL;
        }
    }
}
