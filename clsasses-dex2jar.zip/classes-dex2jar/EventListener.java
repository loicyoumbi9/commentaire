package org.w3c.dom.events;

public interface EventListener {
    void handleEvent(Event event);
}
