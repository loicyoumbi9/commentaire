package com.ironsource.mobilcore;

import com.ironsource.mobilcore.ba;

final class bd extends aW {
    public bd(ba.g gVar) {
        super(gVar);
        this.a = "StickeezReadyToShowState";
    }

    @Override // com.ironsource.mobilcore.aW
    public final void c() {
        super.c();
        B.a("StickeezReadyToShowState | setStateTo, switching to StickeezShowingHandleState", 55);
        this.b.a(new be(this.b));
        ba.v(ba.this);
    }

    @Override // com.ironsource.mobilcore.aW
    public final void f() {
        super.f();
        B.a("StickeezReadyToShowState | setStateTo, switching to StickeezSwitchingAnimationsState", 55);
        bh bhVar = new bh(this.b);
        this.b.a(bhVar);
        bhVar.h();
    }

    @Override // com.ironsource.mobilcore.aW
    public final void g() {
        super.g();
        B.a("StickeezReadyToShowState | setStateTo, switching to StickeezWaitingForLayoutState", 55);
        this.b.a(new bi(this.b));
    }
}
