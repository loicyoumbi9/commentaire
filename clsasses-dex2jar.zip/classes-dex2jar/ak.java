package u.aly;

import android.content.Context;
import java.util.Arrays;
import java.util.List;

public class ak {
    private static final int a = 0;
    private static final int b = 1;
    private static final int c = 2;
    private static final int d = 3;
    private static final long e = 14400000;
    private static final long f = 28800000;
    private static final long g = 86400000;
    private int h = 0;
    private final long i = 60000;

    public long a() {
        switch (this.h) {
            case 1:
                return e;
            case 2:
                return f;
            case 3:
                return 86400000;
            default:
                return 0;
        }
    }

    public bl a(Context context) {
        long currentTimeMillis = System.currentTimeMillis();
        bl blVar = new bl();
        blVar.a(z.g(context));
        blVar.a(currentTimeMillis);
        blVar.b(currentTimeMillis + 60000);
        blVar.c(60000);
        return blVar;
    }

    public bn a(Context context, bn bnVar) {
        if (bnVar == null) {
            return null;
        }
        if (this.h == 1) {
            bnVar.a((List<bc>) null);
            return bnVar;
        } else if (this.h == 2) {
            bnVar.b(Arrays.asList(a(context)));
            bnVar.a((List<bc>) null);
            return bnVar;
        } else if (this.h != 3) {
            return bnVar;
        } else {
            bnVar.b((List<bl>) null);
            bnVar.a((List<bc>) null);
            return bnVar;
        }
    }

    public void a(int i2) {
        if (i2 >= 0 && i2 <= 3) {
            this.h = i2;
        }
    }

    public long b() {
        return this.h == 0 ? 0 : 300000;
    }

    public boolean c() {
        return this.h != 0;
    }
}
