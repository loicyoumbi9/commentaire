package u.aly;

import u.aly.da;

public class dj {
    private static int a = Integer.MAX_VALUE;

    public static di a(byte[] bArr, di diVar) {
        return bArr[0] > 16 ? new da.a() : (bArr.length <= 1 || (bArr[1] & 128) == 0) ? diVar : new da.a();
    }

    public static void a(int i) {
        a = i;
    }

    public static void a(dg dgVar, byte b) throws cn {
        a(dgVar, b, a);
    }

    public static void a(dg dgVar, byte b, int i) throws cn {
        int i2 = 0;
        if (i <= 0) {
            throw new cn("Maximum skip depth exceeded");
        }
        switch (b) {
            case 2:
                dgVar.t();
                return;
            case 3:
                dgVar.u();
                return;
            case 4:
                dgVar.y();
                return;
            case 5:
            case 7:
            case 9:
            default:
                return;
            case 6:
                dgVar.v();
                return;
            case 8:
                dgVar.w();
                return;
            case 10:
                dgVar.x();
                return;
            case 11:
                dgVar.A();
                return;
            case 12:
                dgVar.j();
                while (true) {
                    db l = dgVar.l();
                    if (l.b == 0) {
                        dgVar.k();
                        return;
                    } else {
                        a(dgVar, l.b, i - 1);
                        dgVar.m();
                    }
                }
            case 13:
                dd n = dgVar.n();
                while (i2 < n.c) {
                    a(dgVar, n.a, i - 1);
                    a(dgVar, n.b, i - 1);
                    i2++;
                }
                dgVar.o();
                return;
            case 14:
                dk r = dgVar.r();
                while (i2 < r.b) {
                    a(dgVar, r.a, i - 1);
                    i2++;
                }
                dgVar.s();
                return;
            case 15:
                dc p = dgVar.p();
                while (i2 < p.b) {
                    a(dgVar, p.a, i - 1);
                    i2++;
                }
                dgVar.q();
                return;
        }
    }
}
