package com.ironsource.mobilcore;

import android.content.Context;
import android.text.TextUtils;
import android.view.View;
import org.json.JSONObject;

final class aE extends R {
    private String a;
    private boolean b;

    public aE(Context context, C0261ax axVar) {
        super(context, axVar);
    }

    @Override // com.ironsource.mobilcore.H
    public final String a() {
        return "ironsourceUrl";
    }

    /* access modifiers changed from: protected */
    @Override // com.ironsource.mobilcore.H, com.ironsource.mobilcore.I
    public final void a(View view) {
        super.a(view);
        if (!TextUtils.isEmpty(this.a)) {
            aF.a(this.e, this.a, this.b);
        }
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: com.ironsource.mobilcore.I.a(org.json.JSONObject, boolean):void
     arg types: [org.json.JSONObject, int]
     candidates:
      com.ironsource.mobilcore.I.a(com.ironsource.mobilcore.MCEWidgetTextProperties, java.lang.String):void
      com.ironsource.mobilcore.I.a(org.json.JSONObject, boolean):void */
    @Override // com.ironsource.mobilcore.R, com.ironsource.mobilcore.H
    public final void a(JSONObject jSONObject) {
        this.a = jSONObject.optString("url", "");
        this.b = jSONObject.optBoolean("openInternaly", true);
        super.a(jSONObject, true);
    }
}
