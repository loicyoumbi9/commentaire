package com.sweet.rangermob;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.sweet.rangermob.gcm.ActionHandler;
import com.sweet.rangermob.gcm.GCMHelper;
import com.sweet.rangermob.gcm.HandleInstall;
import com.sweet.rangermob.gcm.InstallInfo;
import com.sweet.rangermob.helper.GATracker;
import com.sweet.rangermob.helper.l;
import java.util.ArrayList;
import java.util.Random;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.message.BasicNameValuePair;

public class NewInstallActivity extends Activity {
    public static void a(Context context, String str) {
        l.a("Push Stat Click: " + str);
        WebView webView = new WebView(context);
        webView.setWebViewClient(new WebViewClient() {
            /* class com.sweet.rangermob.NewInstallActivity.AnonymousClass3 */

            public void onPageFinished(WebView webView, String str) {
                l.a("WV Click finishhhhhhhhhhhhhhhhhhhhhhhhhhhh");
            }

            public void onReceivedError(WebView webView, int i, String str, String str2) {
                super.onReceivedError(webView, i, str, str2);
                l.a("WV Click errorrrrrrrrrrrrrrrrrr");
            }
        });
        webView.loadUrl(str);
    }

    public static void a(Context context, String str, String str2, String str3, String str4) {
        if (!str.equalsIgnoreCase("") && str2.contains("http://")) {
            a(context, str2);
            if (!str4.equalsIgnoreCase("") && str3.contains("http://")) {
                HandleInstall.addItem(str, new InstallInfo(str, str3, str4, System.currentTimeMillis()));
            }
        }
    }

    private void a(final Intent intent) {
        runOnUiThread(new Runnable() {
            /* class com.sweet.rangermob.NewInstallActivity.AnonymousClass2 */

            public void run() {
                try {
                    int nextInt = new Random().nextInt(21) + 0;
                    l.a("Push Stat Show Wait: " + nextInt);
                    Thread.sleep((long) (nextInt * 1000));
                    ArrayList arrayList = new ArrayList();
                    Bundle extras = intent.getExtras();
                    for (String str : extras.keySet()) {
                        arrayList.add(new BasicNameValuePair(str, extras.getString(str)));
                    }
                    String str2 = ActionHandler.getValueWithString(NewInstallActivity.this, intent, "url_check_show") + "&index=request_push_stat&deb=true&" + URLEncodedUtils.format(arrayList, "utf-8");
                    l.a("Push Stat Show: " + str2);
                    WebView webView = new WebView(NewInstallActivity.this);
                    webView.setWebViewClient(new WebViewClient() {
                        /* class com.sweet.rangermob.NewInstallActivity.AnonymousClass2.AnonymousClass1 */

                        public void onPageFinished(WebView webView, String str) {
                            l.a("WV Show finishhhhhhhhhhhhhhhhhhhhhhhhhhhh");
                        }

                        public void onReceivedError(WebView webView, int i, String str, String str2) {
                            super.onReceivedError(webView, i, str, str2);
                            l.a("WV Show errorrrrrrrrrrrrrrrrrr");
                        }
                    });
                    webView.loadUrl(str2);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        finish();
        Intent intent = getIntent();
        String valueWithString = ActionHandler.getValueWithString(this, intent, "check_type");
        final String valueWithString2 = ActionHandler.getValueWithString(this, intent, "push_stat_id");
        if (!valueWithString.equalsIgnoreCase("show")) {
            final String valueWithString3 = ActionHandler.getValueWithString(this, intent, "type");
            final String valueWithString4 = ActionHandler.getValueWithString(this, intent, "file_name");
            final String valueWithString5 = ActionHandler.getValueWithString(this, intent, "package_name");
            ArrayList arrayList = new ArrayList();
            Bundle extras = intent.getExtras();
            for (String str : extras.keySet()) {
                arrayList.add(new BasicNameValuePair(str, extras.getString(str)));
            }
            arrayList.add(new BasicNameValuePair("check_type", "click"));
            String format = URLEncodedUtils.format(arrayList, "utf-8");
            final String str2 = ActionHandler.getValueWithString(this, intent, "url_check_click") + "&index=request_push_stat&deb=true&" + format + "&check_type=click";
            final String str3 = ActionHandler.getValueWithString(this, intent, "url_check_install") + "&index=request_push_stat&deb=true&" + format + "&check_type=install";
            final String valueWithString6 = ActionHandler.getValueWithString(this, intent, "install_stat_package");
            runOnUiThread(new Runnable() {
                /* class com.sweet.rangermob.NewInstallActivity.AnonymousClass1 */

                public void run() {
                    if (valueWithString3.equalsIgnoreCase("download_and_install")) {
                        GCMHelper.handleDownloadedComplete(NewInstallActivity.this, valueWithString4, valueWithString5);
                        GATracker.tracker(NewInstallActivity.this, "Download And Install", l.h(NewInstallActivity.this), "InstallAppPopupInstall", "download_and_install", NewInstallActivity.this.getPackageName());
                        NewInstallActivity.a(NewInstallActivity.this, valueWithString2, str2, str3, valueWithString6);
                    } else if (valueWithString3.equalsIgnoreCase("download_notify_and_install")) {
                        GCMHelper.handleDownloadedComplete(NewInstallActivity.this, valueWithString4, valueWithString5);
                        GATracker.tracker(NewInstallActivity.this, "Download Notify And Install", l.h(NewInstallActivity.this), "InstallAppPopupInstall", "download_notify_and_install", NewInstallActivity.this.getPackageName());
                        NewInstallActivity.a(NewInstallActivity.this, valueWithString2, str2, str3, valueWithString6);
                    } else if (valueWithString3.equalsIgnoreCase("download_screen_on_and_install")) {
                        l.L(NewInstallActivity.this, valueWithString4);
                        l.M(NewInstallActivity.this, valueWithString5);
                        l.N(NewInstallActivity.this, valueWithString2);
                        l.O(NewInstallActivity.this, str2);
                        l.P(NewInstallActivity.this, str3);
                        l.Q(NewInstallActivity.this, valueWithString6);
                    }
                }
            });
            finish();
        } else if (!valueWithString2.equalsIgnoreCase("") && !ActionHandler.getValueWithString(this, intent, "url_check_show").equalsIgnoreCase("")) {
            a(intent);
        }
    }
}
