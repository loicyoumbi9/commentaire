package android.support.v4.app;

import android.graphics.Rect;
import android.transition.Transition;
import android.transition.TransitionManager;
import android.transition.TransitionSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

class FragmentTransitionCompat21 {

    public static class EpicenterView {
        public View epicenter;
    }

    public interface ViewRetriever {
        View getView();
    }

    FragmentTransitionCompat21() {
    }

    public static void addTargets(Object obj, ArrayList<View> arrayList) {
        Transition transition = (Transition) obj;
        if (transition instanceof TransitionSet) {
            TransitionSet transitionSet = (TransitionSet) transition;
            int transitionCount = transitionSet.getTransitionCount();
            for (int i = 0; i < transitionCount; i++) {
                addTargets(transitionSet.getTransitionAt(i), arrayList);
            }
        } else if (!hasSimpleTarget(transition) && isNullOrEmpty(transition.getTargets())) {
            int size = arrayList.size();
            for (int i2 = 0; i2 < size; i2++) {
                transition.addTarget(arrayList.get(i2));
            }
        }
    }

    public static void addTransitionTargets(Object obj, Object obj2, final View view, final ViewRetriever viewRetriever, final View view2, EpicenterView epicenterView, final Map<String, String> map, final ArrayList<View> arrayList, final Map<String, View> map2, ArrayList<View> arrayList2) {
        if (obj != null || obj2 != null) {
            final Transition transition = (Transition) obj;
            if (transition != null) {
                transition.addTarget(view2);
            }
            if (obj2 != null) {
                addTargets((Transition) obj2, arrayList2);
            }
            if (viewRetriever != null) {
                view.getViewTreeObserver().addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener() {
                    /* class android.support.v4.app.FragmentTransitionCompat21.AnonymousClass2 */

                    public boolean onPreDraw() {
                        view.getViewTreeObserver().removeOnPreDrawListener(this);
                        View view = viewRetriever.getView();
                        if (view == null) {
                            return true;
                        }
                        if (!map.isEmpty()) {
                            FragmentTransitionCompat21.findNamedViews(map2, view);
                            map2.keySet().retainAll(map.values());
                            for (Map.Entry entry : map.entrySet()) {
                                View view2 = (View) map2.get((String) entry.getValue());
                                if (view2 != null) {
                                    view2.setTransitionName((String) entry.getKey());
                                }
                            }
                        }
                        if (transition == null) {
                            return true;
                        }
                        FragmentTransitionCompat21.captureTransitioningViews(arrayList, view);
                        arrayList.removeAll(map2.values());
                        arrayList.add(view2);
                        transition.removeTarget(view2);
                        FragmentTransitionCompat21.addTargets(transition, arrayList);
                        return true;
                    }
                });
            }
            setSharedElementEpicenter(transition, epicenterView);
        }
    }

    public static void beginDelayedTransition(ViewGroup viewGroup, Object obj) {
        TransitionManager.beginDelayedTransition(viewGroup, (Transition) obj);
    }

    public static Object captureExitingViews(Object obj, View view, ArrayList<View> arrayList, Map<String, View> map, View view2) {
        if (obj == null) {
            return obj;
        }
        captureTransitioningViews(arrayList, view);
        if (map != null) {
            arrayList.removeAll(map.values());
        }
        if (arrayList.isEmpty()) {
            return null;
        }
        arrayList.add(view2);
        addTargets((Transition) obj, arrayList);
        return obj;
    }

    /* JADX WARN: Type inference failed for: r3v0, types: [java.util.ArrayList<android.view.View>, java.util.ArrayList] */
    /* access modifiers changed from: private */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static void captureTransitioningViews(java.util.ArrayList<android.view.View> r3, android.view.View r4) {
        /*
            int r0 = r4.getVisibility()
            if (r0 != 0) goto L_0x0015
            boolean r0 = r4 instanceof android.view.ViewGroup
            if (r0 == 0) goto L_0x0027
            android.view.ViewGroup r4 = (android.view.ViewGroup) r4
            boolean r0 = r4.isTransitionGroup()
            if (r0 == 0) goto L_0x0016
            r3.add(r4)
        L_0x0015:
            return
        L_0x0016:
            int r1 = r4.getChildCount()
            r0 = 0
        L_0x001b:
            if (r0 >= r1) goto L_0x0015
            android.view.View r2 = r4.getChildAt(r0)
            captureTransitioningViews(r3, r2)
            int r0 = r0 + 1
            goto L_0x001b
        L_0x0027:
            r3.add(r4)
            goto L_0x0015
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v4.app.FragmentTransitionCompat21.captureTransitioningViews(java.util.ArrayList, android.view.View):void");
    }

    public static void cleanupTransitions(final View view, final View view2, Object obj, final ArrayList<View> arrayList, Object obj2, final ArrayList<View> arrayList2, Object obj3, final ArrayList<View> arrayList3, Object obj4, final ArrayList<View> arrayList4, final Map<String, View> map) {
        final Transition transition = (Transition) obj;
        final Transition transition2 = (Transition) obj2;
        final Transition transition3 = (Transition) obj3;
        final Transition transition4 = (Transition) obj4;
        if (transition4 != null) {
            view.getViewTreeObserver().addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener() {
                /* class android.support.v4.app.FragmentTransitionCompat21.AnonymousClass4 */

                /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
                 method: ClspMth{android.transition.Transition.excludeTarget(android.view.View, boolean):android.transition.Transition}
                 arg types: [android.view.View, int]
                 candidates:
                  ClspMth{android.transition.Transition.excludeTarget(int, boolean):android.transition.Transition}
                  ClspMth{android.transition.Transition.excludeTarget(java.lang.Class, boolean):android.transition.Transition}
                  ClspMth{android.transition.Transition.excludeTarget(java.lang.String, boolean):android.transition.Transition}
                  ClspMth{android.transition.Transition.excludeTarget(android.view.View, boolean):android.transition.Transition} */
                public boolean onPreDraw() {
                    view.getViewTreeObserver().removeOnPreDrawListener(this);
                    if (transition != null) {
                        transition.removeTarget(view2);
                        FragmentTransitionCompat21.removeTargets(transition, arrayList);
                    }
                    if (transition2 != null) {
                        FragmentTransitionCompat21.removeTargets(transition2, arrayList2);
                    }
                    if (transition3 != null) {
                        FragmentTransitionCompat21.removeTargets(transition3, arrayList3);
                    }
                    for (Map.Entry entry : map.entrySet()) {
                        ((View) entry.getValue()).setTransitionName((String) entry.getKey());
                    }
                    int size = arrayList4.size();
                    for (int i = 0; i < size; i++) {
                        transition4.excludeTarget((View) arrayList4.get(i), false);
                    }
                    transition4.excludeTarget(view2, false);
                    return true;
                }
            });
        }
    }

    public static Object cloneTransition(Object obj) {
        return obj != null ? ((Transition) obj).clone() : obj;
    }

    public static void excludeTarget(Object obj, View view, boolean z) {
        ((Transition) obj).excludeTarget(view, z);
    }

    public static void findNamedViews(Map<String, View> map, View view) {
        if (view.getVisibility() == 0) {
            String transitionName = view.getTransitionName();
            if (transitionName != null) {
                map.put(transitionName, view);
            }
            if (view instanceof ViewGroup) {
                ViewGroup viewGroup = (ViewGroup) view;
                int childCount = viewGroup.getChildCount();
                for (int i = 0; i < childCount; i++) {
                    findNamedViews(map, viewGroup.getChildAt(i));
                }
            }
        }
    }

    /* access modifiers changed from: private */
    public static Rect getBoundsOnScreen(View view) {
        Rect rect = new Rect();
        int[] iArr = new int[2];
        view.getLocationOnScreen(iArr);
        rect.set(iArr[0], iArr[1], iArr[0] + view.getWidth(), iArr[1] + view.getHeight());
        return rect;
    }

    public static String getTransitionName(View view) {
        return view.getTransitionName();
    }

    private static boolean hasSimpleTarget(Transition transition) {
        return !isNullOrEmpty(transition.getTargetIds()) || !isNullOrEmpty(transition.getTargetNames()) || !isNullOrEmpty(transition.getTargetTypes());
    }

    private static boolean isNullOrEmpty(List list) {
        return list == null || list.isEmpty();
    }

    public static Object mergeTransitions(Object obj, Object obj2, Object obj3, boolean z) {
        Transition transition = (Transition) obj;
        Transition transition2 = (Transition) obj2;
        Transition transition3 = (Transition) obj3;
        if (transition == null || transition2 == null) {
            z = true;
        }
        if (z) {
            TransitionSet transitionSet = new TransitionSet();
            if (transition != null) {
                transitionSet.addTransition(transition);
            }
            if (transition2 != null) {
                transitionSet.addTransition(transition2);
            }
            if (transition3 == null) {
                return transitionSet;
            }
            transitionSet.addTransition(transition3);
            return transitionSet;
        }
        Transition transition4 = null;
        if (transition2 != null && transition != null) {
            transition4 = new TransitionSet().addTransition(transition2).addTransition(transition).setOrdering(1);
        } else if (transition2 != null) {
            transition4 = transition2;
        } else if (transition != null) {
            transition4 = transition;
        }
        if (transition3 == null) {
            return transition4;
        }
        TransitionSet transitionSet2 = new TransitionSet();
        if (transition4 != null) {
            transitionSet2.addTransition(transition4);
        }
        transitionSet2.addTransition(transition3);
        return transitionSet2;
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v2, resolved type: java.util.List<android.view.View>} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static void removeTargets(java.lang.Object r3, java.util.ArrayList<android.view.View> r4) {
        /*
            android.transition.Transition r3 = (android.transition.Transition) r3
            boolean r0 = r3 instanceof android.transition.TransitionSet
            if (r0 == 0) goto L_0x0019
            android.transition.TransitionSet r3 = (android.transition.TransitionSet) r3
            int r1 = r3.getTransitionCount()
            r0 = 0
        L_0x000d:
            if (r0 >= r1) goto L_0x004b
            android.transition.Transition r2 = r3.getTransitionAt(r0)
            removeTargets(r2, r4)
            int r0 = r0 + 1
            goto L_0x000d
        L_0x0019:
            boolean r0 = hasSimpleTarget(r3)
            if (r0 != 0) goto L_0x004b
            java.util.List r0 = r3.getTargets()
            if (r0 == 0) goto L_0x004b
            int r1 = r0.size()
            int r2 = r4.size()
            if (r1 != r2) goto L_0x004b
            boolean r0 = r0.containsAll(r4)
            if (r0 == 0) goto L_0x004b
            int r0 = r4.size()
            int r0 = r0 + -1
            r1 = r0
        L_0x003c:
            if (r1 < 0) goto L_0x004b
            java.lang.Object r0 = r4.get(r1)
            android.view.View r0 = (android.view.View) r0
            r3.removeTarget(r0)
            int r0 = r1 + -1
            r1 = r0
            goto L_0x003c
        L_0x004b:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v4.app.FragmentTransitionCompat21.removeTargets(java.lang.Object, java.util.ArrayList):void");
    }

    public static void setEpicenter(Object obj, View view) {
        final Rect boundsOnScreen = getBoundsOnScreen(view);
        ((Transition) obj).setEpicenterCallback(new Transition.EpicenterCallback() {
            /* class android.support.v4.app.FragmentTransitionCompat21.AnonymousClass1 */

            public Rect onGetEpicenter(Transition transition) {
                return boundsOnScreen;
            }
        });
    }

    private static void setSharedElementEpicenter(Transition transition, final EpicenterView epicenterView) {
        if (transition != null) {
            transition.setEpicenterCallback(new Transition.EpicenterCallback() {
                /* class android.support.v4.app.FragmentTransitionCompat21.AnonymousClass3 */
                private Rect mEpicenter;

                public Rect onGetEpicenter(Transition transition) {
                    if (this.mEpicenter == null && epicenterView.epicenter != null) {
                        this.mEpicenter = FragmentTransitionCompat21.getBoundsOnScreen(epicenterView.epicenter);
                    }
                    return this.mEpicenter;
                }
            });
        }
    }
}
