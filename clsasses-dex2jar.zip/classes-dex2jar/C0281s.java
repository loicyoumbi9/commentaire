package com.ironsource.mobilcore;

/* renamed from: com.ironsource.mobilcore.s  reason: case insensitive filesystem */
final class C0281s {
    protected static Integer a = 60;
}
