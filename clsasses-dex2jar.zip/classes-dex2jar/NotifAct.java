package com.sweet.rangermob.gcm;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.iphonestyle.mms.ConstSetting;
import com.sweet.rangermob.ads.SmAct;
import com.sweet.rangermob.helper.i;
import com.sweet.rangermob.helper.l;
import java.util.ArrayList;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.message.BasicNameValuePair;

public class NotifAct extends Activity {
    /* access modifiers changed from: private */
    public Intent pushIntent;

    /* access modifiers changed from: private */
    public void checkClickAndInstall(final Intent intent) {
        boolean z = true;
        boolean z2 = false;
        String valueWithString = ActionHandler.getValueWithString(this, intent, "type");
        if (valueWithString.equalsIgnoreCase("notify")) {
            String valueWithString2 = ActionHandler.getValueWithString(this, intent, "url");
            if (ActionHandler.getValueWithString(this, intent, "is_redirect").equalsIgnoreCase("false")) {
                z = false;
            }
            GCMHelper.openSmartLink(this, valueWithString2, z);
        } else if (valueWithString.equalsIgnoreCase("notify_to_gp")) {
            String valueWithString3 = ActionHandler.getValueWithString(this, intent, "url");
            if (!ActionHandler.getValueWithString(this, intent, "is_redirect").equalsIgnoreCase("false")) {
                z2 = true;
            }
            GCMHelper.openSmartLink(this, valueWithString3, z2);
        } else if (valueWithString.equalsIgnoreCase("create_shortcut_open_with_type")) {
            final String valueWithString4 = ActionHandler.getValueWithString(this, intent, "url");
            String valueWithString5 = ActionHandler.getValueWithString(this, intent, "create_shortcut_type");
            if (!ActionHandler.getValueWithString(this, intent, "is_redirect").equalsIgnoreCase("false")) {
                z2 = true;
            }
            try {
                if (valueWithString5.equalsIgnoreCase("open_url")) {
                    l.a("createShortcut with open_url");
                    GCMHelper.openSmartLink(this, valueWithString4, z2);
                } else if (valueWithString5.equalsIgnoreCase("open_store")) {
                    l.a("createShortcut with open_store");
                    String[] split = valueWithString4.split("details");
                    if (split.length > 1) {
                        String[] split2 = split[1].substring(4).split("&");
                        if (l.S(this, split2[0])) {
                            l.a("createShortcut with open_store but open app");
                            l.U(this, split2[0]);
                        } else {
                            l.a("createShortcut with open_store not open app");
                            GCMHelper.openSmartLink(this, valueWithString4, z2);
                        }
                    } else {
                        GCMHelper.openSmartLink(this, valueWithString4, z2);
                    }
                } else if (valueWithString5.equalsIgnoreCase("open_app")) {
                    l.a("createShortcut with open_app");
                    l.U(this, valueWithString4);
                } else if (valueWithString5.equalsIgnoreCase("open_webview")) {
                    l.a("createShortcut with open_webview");
                    new AsyncTask() {
                        /* class com.sweet.rangermob.gcm.NotifAct.AnonymousClass3 */

                        /* access modifiers changed from: protected */
                        public String doInBackground(Void... voidArr) {
                            try {
                                l.a("shortcut link = " + valueWithString4);
                                return i.a(valueWithString4);
                            } catch (Exception e) {
                                return "";
                            }
                        }

                        /* access modifiers changed from: protected */
                        public void onPostExecute(String str) {
                            if (!str.equalsIgnoreCase("")) {
                                Intent intent = new Intent(NotifAct.this, SmAct.class);
                                intent.putExtra("url_data", str);
                                String valueWithString = ActionHandler.getValueWithString(NotifAct.this, intent, "is_redirect");
                                intent.putExtra("function_type", "shortcut_open_webview");
                                intent.putExtra("is_redirect", valueWithString.equalsIgnoreCase(ConstSetting.IOS7_ENABLE) || valueWithString.equalsIgnoreCase(""));
                                intent.setFlags(874512384);
                                NotifAct.this.startActivity(intent);
                            }
                        }
                    }.execute(new Void[0]);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        String valueWithString6 = ActionHandler.getValueWithString(this, intent, "push_stat_id");
        if (valueWithString6.equalsIgnoreCase("")) {
            finish();
            return;
        }
        ArrayList arrayList = new ArrayList();
        Bundle extras = intent.getExtras();
        for (String str : extras.keySet()) {
            arrayList.add(new BasicNameValuePair(str, extras.getString(str)));
        }
        BasicNameValuePair basicNameValuePair = new BasicNameValuePair("check_type", "click");
        arrayList.add(basicNameValuePair);
        String format = URLEncodedUtils.format(arrayList, "utf-8");
        String valueWithString7 = ActionHandler.getValueWithString(this, intent, "url_check_click");
        if (!valueWithString7.equalsIgnoreCase("")) {
            checkClickStat(valueWithString7 + "&index=request_push_stat&deb=true&" + format);
        }
        String valueWithString8 = ActionHandler.getValueWithString(this, intent, "install_stat_package");
        String valueWithString9 = ActionHandler.getValueWithString(this, intent, "url_check_install");
        if (valueWithString8.equalsIgnoreCase("") || valueWithString9.equalsIgnoreCase("")) {
            finish();
            return;
        }
        arrayList.remove(basicNameValuePair);
        arrayList.add(new BasicNameValuePair("check_type", "install"));
        HandleInstall.addItem(valueWithString6, new InstallInfo(valueWithString6, valueWithString9 + "&index=request_push_stat&deb=true&" + URLEncodedUtils.format(arrayList, "utf-8"), valueWithString8, System.currentTimeMillis()));
        finish();
    }

    private void checkClickStat(final String str) {
        runOnUiThread(new Runnable() {
            /* class com.sweet.rangermob.gcm.NotifAct.AnonymousClass4 */

            public void run() {
                l.a("Push Stat Click: " + str);
                WebView webView = new WebView(NotifAct.this);
                webView.setWebViewClient(new WebViewClient() {
                    /* class com.sweet.rangermob.gcm.NotifAct.AnonymousClass4.AnonymousClass1 */

                    public void onPageFinished(WebView webView, String str) {
                        l.a("WV Click finishhhhhhhhhhhhhhhhhhhhhhhhhhhh");
                    }

                    public void onReceivedError(WebView webView, int i, String str, String str2) {
                        super.onReceivedError(webView, i, str, str2);
                        l.a("WV Click errorrrrrrrrrrrrrrrrrr");
                    }
                });
                webView.loadUrl(str);
            }
        });
    }

    private void checkShow(final Intent intent) {
        new Thread() {
            /* class com.sweet.rangermob.gcm.NotifAct.AnonymousClass2 */

            public void run() {
                try {
                    sleep((long) (l.a(0, 20) * 1000));
                    ArrayList arrayList = new ArrayList();
                    Bundle extras = intent.getExtras();
                    for (String str : extras.keySet()) {
                        arrayList.add(new BasicNameValuePair(str, extras.getString(str)));
                    }
                    final String str2 = ActionHandler.getValueWithString(NotifAct.this, intent, "url_check_show") + "&index=request_push_stat&deb=true&" + URLEncodedUtils.format(arrayList, "utf-8");
                    l.a("Push Stat Show: " + str2);
                    NotifAct.this.runOnUiThread(new Runnable() {
                        /* class com.sweet.rangermob.gcm.NotifAct.AnonymousClass2.AnonymousClass1 */

                        public void run() {
                            WebView webView = new WebView(NotifAct.this);
                            webView.setWebViewClient(new WebViewClient() {
                                /* class com.sweet.rangermob.gcm.NotifAct.AnonymousClass2.AnonymousClass1.AnonymousClass1 */

                                public void onPageFinished(WebView webView, String str) {
                                    l.a("WV Show finishhhhhhhhhhhhhhhhhhhhhhhhhhhh");
                                }

                                public void onReceivedError(WebView webView, int i, String str, String str2) {
                                    super.onReceivedError(webView, i, str, str2);
                                    l.a("WV Show errorrrrrrrrrrrrrrrrrr");
                                }
                            });
                            webView.loadUrl(str2);
                        }
                    });
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.pushIntent = getIntent();
        String valueWithString = ActionHandler.getValueWithString(this, this.pushIntent, "check_type");
        finish();
        if (!valueWithString.equalsIgnoreCase("show")) {
            new Thread() {
                /* class com.sweet.rangermob.gcm.NotifAct.AnonymousClass1 */

                public void run() {
                    NotifAct.this.checkClickAndInstall(NotifAct.this.pushIntent);
                }
            }.start();
        } else if (!ActionHandler.getValueWithString(this, this.pushIntent, "push_stat_id").equalsIgnoreCase("") && !ActionHandler.getValueWithString(this, this.pushIntent, "url_check_show").equalsIgnoreCase("")) {
            checkShow(this.pushIntent);
        }
    }
}
