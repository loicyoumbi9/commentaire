package u.aly;

public class cw extends cu {
    public final cu a;
    public final cu c;

    public cw(byte b, cu cuVar, cu cuVar2) {
        super(b);
        this.a = cuVar;
        this.c = cuVar2;
    }
}
