package u.aly;

public final class dc {
    public final byte a;
    public final int b;

    public dc() {
        this((byte) 0, 0);
    }

    public dc(byte b2, int i) {
        this.a = b2;
        this.b = i;
    }
}
