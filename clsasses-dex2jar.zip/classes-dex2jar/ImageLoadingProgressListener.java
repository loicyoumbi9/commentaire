package com.nostra13.universalimageloader.core.listener;

import android.view.View;

public interface ImageLoadingProgressListener {
    void onProgressUpdate(String str, View view, int i, int i2);
}
