package com.nostra13.universalimageloader.cache.disc.naming;

public interface FileNameGenerator {
    String generate(String str);
}
