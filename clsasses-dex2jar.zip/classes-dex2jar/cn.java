package u.aly;

public class cn extends Exception {
    private static final long a = 1;

    public cn() {
    }

    public cn(String str) {
        super(str);
    }

    public cn(String str, Throwable th) {
        super(str, th);
    }

    public cn(Throwable th) {
        super(th);
    }
}
