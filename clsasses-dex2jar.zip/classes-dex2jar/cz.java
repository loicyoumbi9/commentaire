package u.aly;

import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;

public class cz extends dg {
    protected static final int a = -65536;
    protected static final int b = -2147418112;
    private static final dl h = new dl();
    protected boolean c;
    protected boolean d;
    protected int e;
    protected boolean f;
    private byte[] i;
    private byte[] j;
    private byte[] k;
    private byte[] l;
    private byte[] m;
    private byte[] n;
    private byte[] o;
    private byte[] p;

    public static class a implements di {
        protected boolean a;
        protected boolean b;
        protected int c;

        public a() {
            this(false, true);
        }

        public a(boolean z, boolean z2) {
            this(z, z2, 0);
        }

        public a(boolean z, boolean z2, int i) {
            this.a = false;
            this.b = true;
            this.a = z;
            this.b = z2;
            this.c = i;
        }

        @Override // u.aly.di
        public dg a(du duVar) {
            cz czVar = new cz(duVar, this.a, this.b);
            if (this.c != 0) {
                czVar.c(this.c);
            }
            return czVar;
        }
    }

    public cz(du duVar) {
        this(duVar, false, true);
    }

    public cz(du duVar, boolean z, boolean z2) {
        super(duVar);
        this.c = false;
        this.d = true;
        this.f = false;
        this.i = new byte[1];
        this.j = new byte[2];
        this.k = new byte[4];
        this.l = new byte[8];
        this.m = new byte[1];
        this.n = new byte[2];
        this.o = new byte[4];
        this.p = new byte[8];
        this.c = z;
        this.d = z2;
    }

    private int a(byte[] bArr, int i2, int i3) throws cn {
        d(i3);
        return this.g.d(bArr, i2, i3);
    }

    @Override // u.aly.dg
    public ByteBuffer A() throws cn {
        int w = w();
        d(w);
        if (this.g.h() >= w) {
            ByteBuffer wrap = ByteBuffer.wrap(this.g.f(), this.g.g(), w);
            this.g.a(w);
            return wrap;
        }
        byte[] bArr = new byte[w];
        this.g.d(bArr, 0, w);
        return ByteBuffer.wrap(bArr);
    }

    @Override // u.aly.dg
    public void a() {
    }

    @Override // u.aly.dg
    public void a(byte b2) throws cn {
        this.i[0] = b2;
        this.g.b(this.i, 0, 1);
    }

    @Override // u.aly.dg
    public void a(double d2) throws cn {
        a(Double.doubleToLongBits(d2));
    }

    @Override // u.aly.dg
    public void a(int i2) throws cn {
        this.k[0] = (byte) ((i2 >> 24) & 255);
        this.k[1] = (byte) ((i2 >> 16) & 255);
        this.k[2] = (byte) ((i2 >> 8) & 255);
        this.k[3] = (byte) (i2 & 255);
        this.g.b(this.k, 0, 4);
    }

    @Override // u.aly.dg
    public void a(long j2) throws cn {
        this.l[0] = (byte) ((int) ((j2 >> 56) & 255));
        this.l[1] = (byte) ((int) ((j2 >> 48) & 255));
        this.l[2] = (byte) ((int) ((j2 >> 40) & 255));
        this.l[3] = (byte) ((int) ((j2 >> 32) & 255));
        this.l[4] = (byte) ((int) ((j2 >> 24) & 255));
        this.l[5] = (byte) ((int) ((j2 >> 16) & 255));
        this.l[6] = (byte) ((int) ((j2 >> 8) & 255));
        this.l[7] = (byte) ((int) (255 & j2));
        this.g.b(this.l, 0, 8);
    }

    @Override // u.aly.dg
    public void a(String str) throws cn {
        try {
            byte[] bytes = str.getBytes("UTF-8");
            a(bytes.length);
            this.g.b(bytes, 0, bytes.length);
        } catch (UnsupportedEncodingException e2) {
            throw new cn("JVM DOES NOT SUPPORT UTF-8");
        }
    }

    @Override // u.aly.dg
    public void a(ByteBuffer byteBuffer) throws cn {
        int limit = byteBuffer.limit() - byteBuffer.position();
        a(limit);
        this.g.b(byteBuffer.array(), byteBuffer.position() + byteBuffer.arrayOffset(), limit);
    }

    @Override // u.aly.dg
    public void a(db dbVar) throws cn {
        a(dbVar.b);
        a(dbVar.c);
    }

    @Override // u.aly.dg
    public void a(dc dcVar) throws cn {
        a(dcVar.a);
        a(dcVar.b);
    }

    @Override // u.aly.dg
    public void a(dd ddVar) throws cn {
        a(ddVar.a);
        a(ddVar.b);
        a(ddVar.c);
    }

    @Override // u.aly.dg
    public void a(de deVar) throws cn {
        if (this.d) {
            a((int) (b | deVar.b));
            a(deVar.a);
            a(deVar.c);
            return;
        }
        a(deVar.a);
        a(deVar.b);
        a(deVar.c);
    }

    @Override // u.aly.dg
    public void a(dk dkVar) throws cn {
        a(dkVar.a);
        a(dkVar.b);
    }

    @Override // u.aly.dg
    public void a(dl dlVar) {
    }

    @Override // u.aly.dg
    public void a(short s) throws cn {
        this.j[0] = (byte) ((s >> 8) & 255);
        this.j[1] = (byte) (s & 255);
        this.g.b(this.j, 0, 2);
    }

    @Override // u.aly.dg
    public void a(boolean z) throws cn {
        a(z ? (byte) 1 : 0);
    }

    public String b(int i2) throws cn {
        try {
            d(i2);
            byte[] bArr = new byte[i2];
            this.g.d(bArr, 0, i2);
            return new String(bArr, "UTF-8");
        } catch (UnsupportedEncodingException e2) {
            throw new cn("JVM DOES NOT SUPPORT UTF-8");
        }
    }

    @Override // u.aly.dg
    public void b() {
    }

    @Override // u.aly.dg
    public void c() {
    }

    public void c(int i2) {
        this.e = i2;
        this.f = true;
    }

    @Override // u.aly.dg
    public void d() throws cn {
        a((byte) 0);
    }

    /* access modifiers changed from: protected */
    public void d(int i2) throws cn {
        if (i2 < 0) {
            throw new dh("Negative length: " + i2);
        } else if (this.f) {
            this.e -= i2;
            if (this.e < 0) {
                throw new dh("Message length exceeded: " + i2);
            }
        }
    }

    @Override // u.aly.dg
    public void e() {
    }

    @Override // u.aly.dg
    public void f() {
    }

    @Override // u.aly.dg
    public void g() {
    }

    @Override // u.aly.dg
    public de h() throws cn {
        int w = w();
        if (w < 0) {
            if ((-65536 & w) == b) {
                return new de(z(), (byte) (w & 255), w());
            }
            throw new dh(4, "Bad version in readMessageBegin");
        } else if (!this.c) {
            return new de(b(w), u(), w());
        } else {
            throw new dh(4, "Missing version in readMessageBegin, old client?");
        }
    }

    @Override // u.aly.dg
    public void i() {
    }

    @Override // u.aly.dg
    public dl j() {
        return h;
    }

    @Override // u.aly.dg
    public void k() {
    }

    @Override // u.aly.dg
    public db l() throws cn {
        byte u2 = u();
        return new db("", u2, u2 == 0 ? 0 : v());
    }

    @Override // u.aly.dg
    public void m() {
    }

    @Override // u.aly.dg
    public dd n() throws cn {
        return new dd(u(), u(), w());
    }

    @Override // u.aly.dg
    public void o() {
    }

    @Override // u.aly.dg
    public dc p() throws cn {
        return new dc(u(), w());
    }

    @Override // u.aly.dg
    public void q() {
    }

    @Override // u.aly.dg
    public dk r() throws cn {
        return new dk(u(), w());
    }

    @Override // u.aly.dg
    public void s() {
    }

    @Override // u.aly.dg
    public boolean t() throws cn {
        return u() == 1;
    }

    @Override // u.aly.dg
    public byte u() throws cn {
        if (this.g.h() >= 1) {
            byte b2 = this.g.f()[this.g.g()];
            this.g.a(1);
            return b2;
        }
        a(this.m, 0, 1);
        return this.m[0];
    }

    @Override // u.aly.dg
    public short v() throws cn {
        int i2 = 0;
        byte[] bArr = this.n;
        if (this.g.h() >= 2) {
            bArr = this.g.f();
            i2 = this.g.g();
            this.g.a(2);
        } else {
            a(this.n, 0, 2);
        }
        return (short) ((bArr[i2 + 1] & 255) | ((bArr[i2] & 255) << 8));
    }

    @Override // u.aly.dg
    public int w() throws cn {
        int i2 = 0;
        byte[] bArr = this.o;
        if (this.g.h() >= 4) {
            bArr = this.g.f();
            i2 = this.g.g();
            this.g.a(4);
        } else {
            a(this.o, 0, 4);
        }
        return (bArr[i2 + 3] & 255) | ((bArr[i2] & 255) << 24) | ((bArr[i2 + 1] & 255) << dn.n) | ((bArr[i2 + 2] & 255) << 8);
    }

    @Override // u.aly.dg
    public long x() throws cn {
        int i2 = 0;
        byte[] bArr = this.p;
        if (this.g.h() >= 8) {
            bArr = this.g.f();
            i2 = this.g.g();
            this.g.a(8);
        } else {
            a(this.p, 0, 8);
        }
        return ((long) (bArr[i2 + 7] & 255)) | (((long) (bArr[i2] & 255)) << 56) | (((long) (bArr[i2 + 1] & 255)) << 48) | (((long) (bArr[i2 + 2] & 255)) << 40) | (((long) (bArr[i2 + 3] & 255)) << 32) | (((long) (bArr[i2 + 4] & 255)) << 24) | (((long) (bArr[i2 + 5] & 255)) << 16) | (((long) (bArr[i2 + 6] & 255)) << 8);
    }

    @Override // u.aly.dg
    public double y() throws cn {
        return Double.longBitsToDouble(x());
    }

    @Override // u.aly.dg
    public String z() throws cn {
        int w = w();
        if (this.g.h() < w) {
            return b(w);
        }
        try {
            String str = new String(this.g.f(), this.g.g(), w, "UTF-8");
            this.g.a(w);
            return str;
        } catch (UnsupportedEncodingException e2) {
            throw new cn("JVM DOES NOT SUPPORT UTF-8");
        }
    }
}
