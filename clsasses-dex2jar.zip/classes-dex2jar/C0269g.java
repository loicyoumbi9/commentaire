package com.ironsource.mobilcore;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.RemoteException;
import android.util.Log;
import com.ironsource.mobilcore.C0237a;
import java.io.IOException;

/* renamed from: com.ironsource.mobilcore.g  reason: case insensitive filesystem */
final class C0269g {

    /* renamed from: com.ironsource.mobilcore.g$a */
    public static final class a {
        private final String a;
        private final boolean b;

        a(String str, boolean z) {
            this.a = str;
            this.b = z;
        }

        public final String a() {
            return this.a;
        }

        public final boolean b() {
            return this.b;
        }
    }

    public static a a(Context context) {
        C0267e b = b(context);
        try {
            C0237a a2 = C0237a.C0231a.a(b.a());
            a aVar = new a(a2.a(), a2.a(true));
            context.unbindService(b);
            return aVar;
        } catch (RemoteException e) {
            Log.i("AdvertisingIdClient", "GMS remote exception ", e);
            throw new IOException("Remote exception");
        } catch (InterruptedException e2) {
            throw new IOException("Interrupted exception");
        } catch (Throwable th) {
            context.unbindService(b);
            throw th;
        }
    }

    private static C0267e b(Context context) {
        try {
            context.getPackageManager().getPackageInfo("com.android.vending", 0);
            C0267e eVar = new C0267e();
            Intent intent = new Intent("com.google.android.gms.ads.identifier.service.START");
            intent.setPackage("com.google.android.gms");
            if (context.bindService(intent, eVar, 1)) {
                return eVar;
            }
            throw new IOException("Connection failure");
        } catch (PackageManager.NameNotFoundException e) {
            throw new C0265c(9);
        }
    }
}
