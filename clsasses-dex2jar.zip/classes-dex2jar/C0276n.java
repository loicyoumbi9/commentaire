package com.ironsource.mobilcore;

import android.os.AsyncTask;
import android.text.TextUtils;
import com.ironsource.mobilcore.C0280r;
import com.ironsource.mobilcore.CallbackResponse;
import com.ironsource.mobilcore.J;
import com.ironsource.mobilcore.aG;
import com.ironsource.mobilcore.aS;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* renamed from: com.ironsource.mobilcore.n  reason: case insensitive filesystem */
abstract class C0276n implements aG.a {
    private a a;

    /* renamed from: com.ironsource.mobilcore.n$a */
    public interface a {
        aU c();
    }

    public C0276n(a aVar) {
        this.a = aVar;
    }

    private void a(String str, String str2) {
        B.a(getClass().getSimpleName() + " , " + str + " | " + str2, 55);
    }

    public abstract String getFallbackOfferwallJson();

    public String getMobileParams() {
        a("BaseJSInterstitialBridge , getMobileParams", "called");
        return aF.h(MobileCore.c());
    }

    public abstract String getOfferwallJson();

    public double getScreenSize() {
        return aF.d(MobileCore.c());
    }

    public void handleClickedOffer(String str) {
        a("BaseJSInterstitialBridge , handleClickedOffer", "offerJsonStr:" + str);
        try {
            JSONObject jSONObject = new JSONObject(str);
            this.a.c().a(jSONObject);
            aR.a(C0280r.a.INTERSTITIAL_IMPRESSION_TO_CLICK, new J.a("offer", aR.a(jSONObject)));
            aR.a(C0280r.a.INTERSTITIAL_CLICK_TO_START);
        } catch (JSONException e) {
        }
    }

    public abstract void handleErrorState();

    public void handleFeedFailure() {
        a("BaseJSInterstitialBridge , handleFeedFailure", "called");
        handleErrorState();
        aK.a(MobileCore.c(), aS.b.REPORT_TYPE_ERROR).b("Failed to handle feed").a();
    }

    public void handleResourceFailure(String str) {
        a("BaseJSInterstitialBridge , handleResourceFailure, " + str, "called");
        handleErrorState();
        aK.a(MobileCore.c(), aS.b.REPORT_TYPE_ERROR).b("Failed to load url: " + str).a();
    }

    public void hide(String str) {
        a("BaseJSInterstitialBridge , hide", "called");
        this.a.c().a(aS.a.REPORT_ACTION_NO_THANKS, str);
        this.a.c().a(CallbackResponse.TYPE.INTERSTITIAL_QUIT);
    }

    public void openReport(String str, String str2) {
        this.a.c().b(str, str2);
    }

    public void playMedia(String str) {
        a("BaseJSInterstitialBridge , playMedia elementId: " + str, "called");
        this.a.c().a("(function() { try { document.getElementById('" + str + "').play(); } catch (e) {} })()");
    }

    public abstract void ready(boolean z);

    public void reportBack(String str) {
        this.a.c().a(aS.a.REPORT_ACTION_QUIT, str);
    }

    public void reportImpressions(String str) {
        a("BaseJSInterstitialBridge , reportImpressions", "called");
        aF.a(new AsyncTask() {
            /* class com.ironsource.mobilcore.aU.AnonymousClass2 */

            private static JSONArray a(String... strArr) {
                JSONArray jSONArray;
                int i = 0;
                try {
                    jSONArray = new JSONArray(strArr[0]);
                    while (i < jSONArray.length()) {
                        try {
                            try {
                                aR.b(jSONArray.getJSONObject(i));
                            } catch (Exception e) {
                            }
                            i++;
                        } catch (JSONException e2) {
                            e = e2;
                        }
                    }
                } catch (JSONException e3) {
                    e = e3;
                    jSONArray = null;
                    e.printStackTrace();
                    return jSONArray;
                }
                return jSONArray;
            }

            @Override // android.os.AsyncTask
            public final /* synthetic */ Object doInBackground(Object[] objArr) {
                return a((String[]) objArr);
            }

            @Override // android.os.AsyncTask
            public final /* synthetic */ void onPostExecute(Object obj) {
                JSONArray jSONArray = (JSONArray) obj;
                if (jSONArray != null) {
                    try {
                        ArrayList arrayList = new ArrayList();
                        for (int i = 0; i < jSONArray.length(); i++) {
                            arrayList.add(jSONArray.getJSONObject(i).optString("appId"));
                        }
                        aU.this.g.b(TextUtils.join(",", arrayList));
                    } catch (Exception e) {
                        aK.a(aS.b.REPORT_TYPE_ERROR).a(e).a();
                    }
                    aK.a(aS.b.REPORT_TYPE_RES).a(aU.this.e, aU.this.d).a(aS.a.REPORT_ACTION_IMPRESSION).a(jSONArray).b("showTrigger", aU.this.h == null ? null : aU.this.h.getReportValue()).a();
                }
            }
        }, str);
        aR.a(C0280r.a.INTERSTITIAL_IMPRESSION_TO_CLICK);
    }

    public void reportOfferwallShow(String str, String str2) {
        this.a.c().a(str, str2);
    }
}
