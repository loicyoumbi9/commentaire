package u.aly;

public enum aw implements cl {
    MALE(0),
    FEMALE(1),
    UNKNOWN(2);
    
    private final int d;

    private aw(int i) {
        this.d = i;
    }

    public static aw a(int i) {
        switch (i) {
            case 0:
                return MALE;
            case 1:
                return FEMALE;
            case 2:
                return UNKNOWN;
            default:
                return null;
        }
    }

    @Override // u.aly.cl
    public int a() {
        return this.d;
    }
}
