package com.ironsource.mobilcore;

import android.graphics.drawable.Drawable;
import org.json.JSONObject;

final class bc {

    /* renamed from: com.ironsource.mobilcore.bc$1  reason: invalid class name */
    static final /* synthetic */ class AnonymousClass1 {
        static final /* synthetic */ int[] a = new int[b.values().length];

        static {
            try {
                a[b.SIMPLE_BANNER.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
        }
    }

    public static final class a {
        private b a;
        private Drawable b;
        private Drawable c;
        private JSONObject d;

        public a(b bVar, Drawable drawable, Drawable drawable2, JSONObject jSONObject) {
            this.a = bVar;
            this.b = drawable;
            this.c = drawable2;
            this.d = jSONObject;
        }

        public final b a() {
            return this.a;
        }

        public final Drawable b() {
            return this.b;
        }

        public final Drawable c() {
            return this.c;
        }

        public final JSONObject d() {
            return this.d;
        }
    }

    protected enum b {
        SIMPLE_BANNER
    }
}
