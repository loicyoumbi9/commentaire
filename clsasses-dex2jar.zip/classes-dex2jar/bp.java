package u.aly;

import com.alimama.mobile.csdk.umupdate.a.f;
import com.android.common.speech.LoggingEvents;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.nio.ByteBuffer;
import java.util.BitSet;
import java.util.Collections;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class bp implements Serializable, Cloneable, ch<bp, e> {
    private static final int A = 3;
    public static final Map<e, ct> k;
    /* access modifiers changed from: private */
    public static final dl l = new dl("UMEnvelope");
    /* access modifiers changed from: private */
    public static final db m = new db("version", (byte) 11, 1);
    /* access modifiers changed from: private */
    public static final db n = new db("address", (byte) 11, 2);
    /* access modifiers changed from: private */
    public static final db o = new db("signature", (byte) 11, 3);
    /* access modifiers changed from: private */
    public static final db p = new db("serial_num", (byte) 8, 4);
    /* access modifiers changed from: private */
    public static final db q = new db("ts_secs", (byte) 8, 5);
    /* access modifiers changed from: private */
    public static final db r = new db(LoggingEvents.VoiceIme.EXTRA_TEXT_MODIFIED_LENGTH, (byte) 8, 6);
    /* access modifiers changed from: private */
    public static final db s = new db("entity", (byte) 11, 7);
    /* access modifiers changed from: private */
    public static final db t = new db("guid", (byte) 11, 8);
    /* access modifiers changed from: private */

    /* renamed from: u  reason: collision with root package name */
    public static final db f21u = new db("checksum", (byte) 11, 9);
    /* access modifiers changed from: private */
    public static final db v = new db("codex", (byte) 8, 10);
    private static final Map<Class<? extends Cdo>, dp> w = new HashMap();
    private static final int x = 0;
    private static final int y = 1;
    private static final int z = 2;
    private byte B;
    private e[] C;
    public String a;
    public String b;
    public String c;
    public int d;
    public int e;
    public int f;
    public ByteBuffer g;
    public String h;
    public String i;
    public int j;

    private static class a extends dq<bp> {
        private a() {
        }

        /* renamed from: a */
        public void b(dg dgVar, bp bpVar) throws cn {
            dgVar.j();
            while (true) {
                db l = dgVar.l();
                if (l.b == 0) {
                    dgVar.k();
                    if (!bpVar.o()) {
                        throw new dh("Required field 'serial_num' was not found in serialized data! Struct: " + toString());
                    } else if (!bpVar.r()) {
                        throw new dh("Required field 'ts_secs' was not found in serialized data! Struct: " + toString());
                    } else if (!bpVar.u()) {
                        throw new dh("Required field 'length' was not found in serialized data! Struct: " + toString());
                    } else {
                        bpVar.I();
                        return;
                    }
                } else {
                    switch (l.c) {
                        case 1:
                            if (l.b != 11) {
                                dj.a(dgVar, l.b);
                                break;
                            } else {
                                bpVar.a = dgVar.z();
                                bpVar.a(true);
                                break;
                            }
                        case 2:
                            if (l.b != 11) {
                                dj.a(dgVar, l.b);
                                break;
                            } else {
                                bpVar.b = dgVar.z();
                                bpVar.b(true);
                                break;
                            }
                        case 3:
                            if (l.b != 11) {
                                dj.a(dgVar, l.b);
                                break;
                            } else {
                                bpVar.c = dgVar.z();
                                bpVar.c(true);
                                break;
                            }
                        case 4:
                            if (l.b != 8) {
                                dj.a(dgVar, l.b);
                                break;
                            } else {
                                bpVar.d = dgVar.w();
                                bpVar.d(true);
                                break;
                            }
                        case 5:
                            if (l.b != 8) {
                                dj.a(dgVar, l.b);
                                break;
                            } else {
                                bpVar.e = dgVar.w();
                                bpVar.e(true);
                                break;
                            }
                        case 6:
                            if (l.b != 8) {
                                dj.a(dgVar, l.b);
                                break;
                            } else {
                                bpVar.f = dgVar.w();
                                bpVar.f(true);
                                break;
                            }
                        case 7:
                            if (l.b != 11) {
                                dj.a(dgVar, l.b);
                                break;
                            } else {
                                bpVar.g = dgVar.A();
                                bpVar.g(true);
                                break;
                            }
                        case 8:
                            if (l.b != 11) {
                                dj.a(dgVar, l.b);
                                break;
                            } else {
                                bpVar.h = dgVar.z();
                                bpVar.h(true);
                                break;
                            }
                        case 9:
                            if (l.b != 11) {
                                dj.a(dgVar, l.b);
                                break;
                            } else {
                                bpVar.i = dgVar.z();
                                bpVar.i(true);
                                break;
                            }
                        case 10:
                            if (l.b != 8) {
                                dj.a(dgVar, l.b);
                                break;
                            } else {
                                bpVar.j = dgVar.w();
                                bpVar.j(true);
                                break;
                            }
                        default:
                            dj.a(dgVar, l.b);
                            break;
                    }
                    dgVar.m();
                }
            }
        }

        /* renamed from: b */
        public void a(dg dgVar, bp bpVar) throws cn {
            bpVar.I();
            dgVar.a(bp.l);
            if (bpVar.a != null) {
                dgVar.a(bp.m);
                dgVar.a(bpVar.a);
                dgVar.c();
            }
            if (bpVar.b != null) {
                dgVar.a(bp.n);
                dgVar.a(bpVar.b);
                dgVar.c();
            }
            if (bpVar.c != null) {
                dgVar.a(bp.o);
                dgVar.a(bpVar.c);
                dgVar.c();
            }
            dgVar.a(bp.p);
            dgVar.a(bpVar.d);
            dgVar.c();
            dgVar.a(bp.q);
            dgVar.a(bpVar.e);
            dgVar.c();
            dgVar.a(bp.r);
            dgVar.a(bpVar.f);
            dgVar.c();
            if (bpVar.g != null) {
                dgVar.a(bp.s);
                dgVar.a(bpVar.g);
                dgVar.c();
            }
            if (bpVar.h != null) {
                dgVar.a(bp.t);
                dgVar.a(bpVar.h);
                dgVar.c();
            }
            if (bpVar.i != null) {
                dgVar.a(bp.f21u);
                dgVar.a(bpVar.i);
                dgVar.c();
            }
            if (bpVar.H()) {
                dgVar.a(bp.v);
                dgVar.a(bpVar.j);
                dgVar.c();
            }
            dgVar.d();
            dgVar.b();
        }
    }

    private static class b implements dp {
        private b() {
        }

        /* renamed from: a */
        public a b() {
            return new a();
        }
    }

    private static class c extends dr<bp> {
        private c() {
        }

        public void a(dg dgVar, bp bpVar) throws cn {
            dm dmVar = (dm) dgVar;
            dmVar.a(bpVar.a);
            dmVar.a(bpVar.b);
            dmVar.a(bpVar.c);
            dmVar.a(bpVar.d);
            dmVar.a(bpVar.e);
            dmVar.a(bpVar.f);
            dmVar.a(bpVar.g);
            dmVar.a(bpVar.h);
            dmVar.a(bpVar.i);
            BitSet bitSet = new BitSet();
            if (bpVar.H()) {
                bitSet.set(0);
            }
            dmVar.a(bitSet, 1);
            if (bpVar.H()) {
                dmVar.a(bpVar.j);
            }
        }

        public void b(dg dgVar, bp bpVar) throws cn {
            dm dmVar = (dm) dgVar;
            bpVar.a = dmVar.z();
            bpVar.a(true);
            bpVar.b = dmVar.z();
            bpVar.b(true);
            bpVar.c = dmVar.z();
            bpVar.c(true);
            bpVar.d = dmVar.w();
            bpVar.d(true);
            bpVar.e = dmVar.w();
            bpVar.e(true);
            bpVar.f = dmVar.w();
            bpVar.f(true);
            bpVar.g = dmVar.A();
            bpVar.g(true);
            bpVar.h = dmVar.z();
            bpVar.h(true);
            bpVar.i = dmVar.z();
            bpVar.i(true);
            if (dmVar.b(1).get(0)) {
                bpVar.j = dmVar.w();
                bpVar.j(true);
            }
        }
    }

    private static class d implements dp {
        private d() {
        }

        /* renamed from: a */
        public c b() {
            return new c();
        }
    }

    public enum e implements co {
        VERSION(1, "version"),
        ADDRESS(2, "address"),
        SIGNATURE(3, "signature"),
        SERIAL_NUM(4, "serial_num"),
        TS_SECS(5, "ts_secs"),
        LENGTH(6, LoggingEvents.VoiceIme.EXTRA_TEXT_MODIFIED_LENGTH),
        ENTITY(7, "entity"),
        GUID(8, "guid"),
        CHECKSUM(9, "checksum"),
        CODEX(10, "codex");
        
        private static final Map<String, e> k = new HashMap();
        private final short l;
        private final String m;

        static {
            Iterator it = EnumSet.allOf(e.class).iterator();
            while (it.hasNext()) {
                e eVar = (e) it.next();
                k.put(eVar.b(), eVar);
            }
        }

        private e(short s, String str) {
            this.l = s;
            this.m = str;
        }

        public static e a(int i) {
            switch (i) {
                case 1:
                    return VERSION;
                case 2:
                    return ADDRESS;
                case 3:
                    return SIGNATURE;
                case 4:
                    return SERIAL_NUM;
                case 5:
                    return TS_SECS;
                case 6:
                    return LENGTH;
                case 7:
                    return ENTITY;
                case 8:
                    return GUID;
                case 9:
                    return CHECKSUM;
                case 10:
                    return CODEX;
                default:
                    return null;
            }
        }

        public static e a(String str) {
            return k.get(str);
        }

        public static e b(int i) {
            e a = a(i);
            if (a != null) {
                return a;
            }
            throw new IllegalArgumentException("Field " + i + " doesn't exist!");
        }

        @Override // u.aly.co
        public short a() {
            return this.l;
        }

        @Override // u.aly.co
        public String b() {
            return this.m;
        }
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: MutableMD:(java.lang.Object, java.lang.Object):java.lang.Object
     arg types: [u.aly.bp$e, u.aly.ct]
     candidates:
      MutableMD:(java.lang.Enum, java.lang.Object):java.lang.Object
      MutableMD:(java.lang.Object, java.lang.Object):java.lang.Object */
    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: u.aly.cu.<init>(byte, boolean):void
     arg types: [byte, int]
     candidates:
      u.aly.cu.<init>(byte, java.lang.String):void
      u.aly.cu.<init>(byte, boolean):void */
    static {
        w.put(dq.class, new b());
        w.put(dr.class, new d());
        EnumMap enumMap = new EnumMap(e.class);
        enumMap.put((Object) e.VERSION, (Object) new ct("version", (byte) 1, new cu((byte) 11)));
        enumMap.put((Object) e.ADDRESS, (Object) new ct("address", (byte) 1, new cu((byte) 11)));
        enumMap.put((Object) e.SIGNATURE, (Object) new ct("signature", (byte) 1, new cu((byte) 11)));
        enumMap.put((Object) e.SERIAL_NUM, (Object) new ct("serial_num", (byte) 1, new cu((byte) 8)));
        enumMap.put((Object) e.TS_SECS, (Object) new ct("ts_secs", (byte) 1, new cu((byte) 8)));
        enumMap.put((Object) e.LENGTH, (Object) new ct(LoggingEvents.VoiceIme.EXTRA_TEXT_MODIFIED_LENGTH, (byte) 1, new cu((byte) 8)));
        enumMap.put((Object) e.ENTITY, (Object) new ct("entity", (byte) 1, new cu((byte) 11, true)));
        enumMap.put((Object) e.GUID, (Object) new ct("guid", (byte) 1, new cu((byte) 11)));
        enumMap.put((Object) e.CHECKSUM, (Object) new ct("checksum", (byte) 1, new cu((byte) 11)));
        enumMap.put((Object) e.CODEX, (Object) new ct("codex", (byte) 2, new cu((byte) 8)));
        k = Collections.unmodifiableMap(enumMap);
        ct.a(bp.class, k);
    }

    public bp() {
        this.B = 0;
        this.C = new e[]{e.CODEX};
    }

    public bp(String str, String str2, String str3, int i2, int i3, int i4, ByteBuffer byteBuffer, String str4, String str5) {
        this();
        this.a = str;
        this.b = str2;
        this.c = str3;
        this.d = i2;
        d(true);
        this.e = i3;
        e(true);
        this.f = i4;
        f(true);
        this.g = byteBuffer;
        this.h = str4;
        this.i = str5;
    }

    public bp(bp bpVar) {
        this.B = 0;
        this.C = new e[]{e.CODEX};
        this.B = bpVar.B;
        if (bpVar.e()) {
            this.a = bpVar.a;
        }
        if (bpVar.i()) {
            this.b = bpVar.b;
        }
        if (bpVar.l()) {
            this.c = bpVar.c;
        }
        this.d = bpVar.d;
        this.e = bpVar.e;
        this.f = bpVar.f;
        if (bpVar.y()) {
            this.g = ci.d(bpVar.g);
        }
        if (bpVar.B()) {
            this.h = bpVar.h;
        }
        if (bpVar.E()) {
            this.i = bpVar.i;
        }
        this.j = bpVar.j;
    }

    private void a(ObjectInputStream objectInputStream) throws IOException, ClassNotFoundException {
        try {
            this.B = 0;
            a(new da(new ds(objectInputStream)));
        } catch (cn e2) {
            throw new IOException(e2.getMessage());
        }
    }

    private void a(ObjectOutputStream objectOutputStream) throws IOException {
        try {
            b(new da(new ds(objectOutputStream)));
        } catch (cn e2) {
            throw new IOException(e2.getMessage());
        }
    }

    public void A() {
        this.h = null;
    }

    public boolean B() {
        return this.h != null;
    }

    public String C() {
        return this.i;
    }

    public void D() {
        this.i = null;
    }

    public boolean E() {
        return this.i != null;
    }

    public int F() {
        return this.j;
    }

    public void G() {
        this.B = ce.b(this.B, 3);
    }

    public boolean H() {
        return ce.a(this.B, 3);
    }

    public void I() throws cn {
        if (this.a == null) {
            throw new dh("Required field 'version' was not present! Struct: " + toString());
        } else if (this.b == null) {
            throw new dh("Required field 'address' was not present! Struct: " + toString());
        } else if (this.c == null) {
            throw new dh("Required field 'signature' was not present! Struct: " + toString());
        } else if (this.g == null) {
            throw new dh("Required field 'entity' was not present! Struct: " + toString());
        } else if (this.h == null) {
            throw new dh("Required field 'guid' was not present! Struct: " + toString());
        } else if (this.i == null) {
            throw new dh("Required field 'checksum' was not present! Struct: " + toString());
        }
    }

    /* renamed from: a */
    public bp g() {
        return new bp(this);
    }

    public bp a(int i2) {
        this.d = i2;
        d(true);
        return this;
    }

    public bp a(String str) {
        this.a = str;
        return this;
    }

    public bp a(ByteBuffer byteBuffer) {
        this.g = byteBuffer;
        return this;
    }

    public bp a(byte[] bArr) {
        a(bArr == null ? null : ByteBuffer.wrap(bArr));
        return this;
    }

    @Override // u.aly.ch
    public void a(dg dgVar) throws cn {
        w.get(dgVar.D()).b().b(dgVar, this);
    }

    public void a(boolean z2) {
        if (!z2) {
            this.a = null;
        }
    }

    public bp b(String str) {
        this.b = str;
        return this;
    }

    @Override // u.aly.ch
    public void b() {
        this.a = null;
        this.b = null;
        this.c = null;
        d(false);
        this.d = 0;
        e(false);
        this.e = 0;
        f(false);
        this.f = 0;
        this.g = null;
        this.h = null;
        this.i = null;
        j(false);
        this.j = 0;
    }

    @Override // u.aly.ch
    public void b(dg dgVar) throws cn {
        w.get(dgVar.D()).b().a(dgVar, this);
    }

    public void b(boolean z2) {
        if (!z2) {
            this.b = null;
        }
    }

    public String c() {
        return this.a;
    }

    public bp c(int i2) {
        this.e = i2;
        e(true);
        return this;
    }

    public bp c(String str) {
        this.c = str;
        return this;
    }

    public void c(boolean z2) {
        if (!z2) {
            this.c = null;
        }
    }

    public bp d(int i2) {
        this.f = i2;
        f(true);
        return this;
    }

    public bp d(String str) {
        this.h = str;
        return this;
    }

    public void d() {
        this.a = null;
    }

    public void d(boolean z2) {
        this.B = ce.a(this.B, 0, z2);
    }

    public bp e(int i2) {
        this.j = i2;
        j(true);
        return this;
    }

    public bp e(String str) {
        this.i = str;
        return this;
    }

    public void e(boolean z2) {
        this.B = ce.a(this.B, 1, z2);
    }

    public boolean e() {
        return this.a != null;
    }

    public String f() {
        return this.b;
    }

    /* renamed from: f */
    public e b(int i2) {
        return e.a(i2);
    }

    public void f(boolean z2) {
        this.B = ce.a(this.B, 2, z2);
    }

    public void g(boolean z2) {
        if (!z2) {
            this.g = null;
        }
    }

    public void h() {
        this.b = null;
    }

    public void h(boolean z2) {
        if (!z2) {
            this.h = null;
        }
    }

    public void i(boolean z2) {
        if (!z2) {
            this.i = null;
        }
    }

    public boolean i() {
        return this.b != null;
    }

    public String j() {
        return this.c;
    }

    public void j(boolean z2) {
        this.B = ce.a(this.B, 3, z2);
    }

    public void k() {
        this.c = null;
    }

    public boolean l() {
        return this.c != null;
    }

    public int m() {
        return this.d;
    }

    public void n() {
        this.B = ce.b(this.B, 0);
    }

    public boolean o() {
        return ce.a(this.B, 0);
    }

    public int p() {
        return this.e;
    }

    public void q() {
        this.B = ce.b(this.B, 1);
    }

    public boolean r() {
        return ce.a(this.B, 1);
    }

    public int s() {
        return this.f;
    }

    public void t() {
        this.B = ce.b(this.B, 2);
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("UMEnvelope(");
        sb.append("version:");
        if (this.a == null) {
            sb.append(f.b);
        } else {
            sb.append(this.a);
        }
        sb.append(", ");
        sb.append("address:");
        if (this.b == null) {
            sb.append(f.b);
        } else {
            sb.append(this.b);
        }
        sb.append(", ");
        sb.append("signature:");
        if (this.c == null) {
            sb.append(f.b);
        } else {
            sb.append(this.c);
        }
        sb.append(", ");
        sb.append("serial_num:");
        sb.append(this.d);
        sb.append(", ");
        sb.append("ts_secs:");
        sb.append(this.e);
        sb.append(", ");
        sb.append("length:");
        sb.append(this.f);
        sb.append(", ");
        sb.append("entity:");
        if (this.g == null) {
            sb.append(f.b);
        } else {
            ci.a(this.g, sb);
        }
        sb.append(", ");
        sb.append("guid:");
        if (this.h == null) {
            sb.append(f.b);
        } else {
            sb.append(this.h);
        }
        sb.append(", ");
        sb.append("checksum:");
        if (this.i == null) {
            sb.append(f.b);
        } else {
            sb.append(this.i);
        }
        if (H()) {
            sb.append(", ");
            sb.append("codex:");
            sb.append(this.j);
        }
        sb.append(")");
        return sb.toString();
    }

    public boolean u() {
        return ce.a(this.B, 2);
    }

    public byte[] v() {
        a(ci.c(this.g));
        if (this.g == null) {
            return null;
        }
        return this.g.array();
    }

    public ByteBuffer w() {
        return this.g;
    }

    public void x() {
        this.g = null;
    }

    public boolean y() {
        return this.g != null;
    }

    public String z() {
        return this.h;
    }
}
