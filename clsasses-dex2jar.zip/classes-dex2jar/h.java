package u.upd;

import org.json.JSONObject;

public abstract class h {
    protected static String GET = "GET";
    protected static String POST = "POST";
    protected String baseUrl;

    public h(String str) {
        this.baseUrl = str;
    }

    public String getBaseUrl() {
        return this.baseUrl;
    }

    /* access modifiers changed from: protected */
    public String getHttpMethod() {
        return POST;
    }

    public void setBaseUrl(String str) {
        this.baseUrl = str;
    }

    public abstract String toGetUrl();

    public abstract JSONObject toJson();
}
