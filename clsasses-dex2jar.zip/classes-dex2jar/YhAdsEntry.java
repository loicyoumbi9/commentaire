package com.keyboard.yhadsmodule;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Toast;
import com.google.android.gms.drive.MetadataChangeSet;
import com.iphonestyle.mms.ConstSetting;
import com.keyboard.yhadsmodule.ads.AdClickHandler;
import com.keyboard.yhadsmodule.ads.AdManager;
import com.keyboard.yhadsmodule.ads.AdResponse;
import com.keyboard.yhadsmodule.ads.AdsImgFetchTask;
import com.keyboard.yhadsmodule.ads.AsyncTasks;
import com.keyboard.yhadsmodule.ads.IAdInfo;
import com.keyboard.yhadsmodule.ads.OnAdReceiveListener;
import com.keyboard.yhadsmodule.utils.AdsCacheItem;
import com.keyboard.yhadsmodule.utils.AdsRecordItem;
import com.keyboard.yhadsmodule.utils.IntentUtils;
import com.keyboard.yhadsmodule.utils.UpdateVersion;
import com.keyboard.yhadsmodule.utils.YhAdsCache;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.util.List;
import java.util.Random;

public class YhAdsEntry {
    private static String DEFAULT_PKG = "com.crazystudio.emoji.kitkat";
    private static String DEFAULT_TITLE = "";
    private static final String MARKET_PREFIX = "market://details?id=";
    private static final int MAX_TRY = 2;
    private static final int MAX_UMENG_LEN = 125;
    public static final String URL_ABOUT = "about:";
    private AdManager adManager;
    private AdClickHandler mAdClickHandler;
    private List<AdResponse> mAdsList = null;
    private UpdateVersion.onLoadOverAds mAdsLoadOverListener;
    private WeakReference<AdClickHandler> mClickHandler;
    /* access modifiers changed from: private */
    public Context mContext = null;
    private AdsImgFetchTask.OnGetFinishListener mFetchAdsIconListner = null;
    private String mIconPath = "";
    private String mPosition;
    private Random mRandom = new Random();
    private int mRetryCount = 0;
    private long mStartTime = 0;

    private String adsClickNoEmtpy(IAdInfo iAdInfo, AdsRecordItem adsRecordItem) {
        String str;
        if (!TextUtils.isEmpty(iAdInfo.getFinalUrl())) {
            preloadGoAds(iAdInfo);
            str = "preloadover_goads";
            adsRecordItem.finalurl = iAdInfo.getFinalUrl();
            adsRecordItem.pkg = iAdInfo.getPackageName();
            adsRecordItem.bid = iAdInfo.getBid();
        } else {
            AdsCacheItem historyPreload = getHistoryPreload(iAdInfo);
            if (historyPreload == null) {
                directGoAds(iAdInfo);
                str = "direct_goads";
                adsRecordItem.finalurl = "empty:direct_goads";
                adsRecordItem.pkg = iAdInfo.getPackageName();
                adsRecordItem.bid = iAdInfo.getBid();
            } else {
                goHistoryPreload(historyPreload);
                str = "preloadhistory_goads";
                adsRecordItem.finalurl = historyPreload.getFinaUrl();
                adsRecordItem.bid = historyPreload.getBid();
                adsRecordItem.pkg = historyPreload.getPkg();
            }
        }
        adsRecordItem.status = str;
        return str;
    }

    private String adsNoEmtpyTitle(IAdInfo iAdInfo, AdsRecordItem adsRecordItem) {
        String title;
        if (!TextUtils.isEmpty(iAdInfo.getFinalUrl())) {
            title = iAdInfo.getTitle();
            adsRecordItem.pkg = iAdInfo.getPackageName();
        } else {
            AdsCacheItem historyPreload = getHistoryPreload(iAdInfo);
            if (historyPreload == null) {
                title = iAdInfo.getTitle();
                adsRecordItem.pkg = iAdInfo.getPackageName();
            } else {
                title = historyPreload.getTitle();
                adsRecordItem.pkg = historyPreload.getPkg();
            }
        }
        adsRecordItem.title = title;
        return title;
    }

    private void cacheAds(IAdInfo iAdInfo) {
        YhAdsCache.put(iAdInfo.getPackageName(), new AdsCacheItem(iAdInfo.getClickRecordUrl(), iAdInfo.getClickDestinationUrl(), iAdInfo.getFinalUrl(), iAdInfo.getBid(), iAdInfo.getPackageName(), iAdInfo.getTitle()));
    }

    private void cacheRawAds(IAdInfo iAdInfo) {
        if (iAdInfo instanceof AdResponse) {
            YhAdsCache.putRawAds(iAdInfo.getPackageName(), (AdResponse) iAdInfo);
        }
    }

    private IAdInfo chooseAds() {
        if (this.mAdClickHandler != null) {
            return this.mAdClickHandler.getmAdInfo();
        }
        return null;
    }

    private IAdInfo chooseAdsFromCache() {
        return YhAdsCache.getRawAds("");
    }

    private IAdInfo chooseAdsMethod(List<AdResponse> list) {
        if (list == null) {
            return null;
        }
        IAdInfo iAdInfo = this.mRandom.nextInt(3) == 0 ? list.get(0) : list.get(this.mRandom.nextInt(list.size()));
        this.mClickHandler.get().setAdInfo(iAdInfo);
        preadAdsCheck(iAdInfo);
        cacheRawAds(iAdInfo);
        saveAdsIcon(iAdInfo);
        return iAdInfo;
    }

    private IAdInfo chooseAdsMethodEqual(List<AdResponse> list) {
        if (list == null) {
            return null;
        }
        IAdInfo iAdInfo = list.get(this.mRandom.nextInt(list.size()));
        this.mClickHandler.get().setAdInfo(iAdInfo);
        preadAdsCheck(iAdInfo);
        cacheRawAds(iAdInfo);
        return iAdInfo;
    }

    private void directGoAds(IAdInfo iAdInfo) {
        this.mClickHandler.get().jumpToClickDestinationUrl();
    }

    private int getAdNum() {
        String onlineKeyValue = UpdateVersion.getOnlineKeyValue(this.mContext, "yh_adnum");
        if (!TextUtils.isEmpty(onlineKeyValue)) {
            try {
                return Integer.parseInt(onlineKeyValue);
            } catch (Exception e) {
            }
        }
        return 8;
    }

    private String getBid(String str) {
        if (!TextUtils.isEmpty(str) && str.length() > 3) {
            str = str.substring(0, 3);
        }
        Log.e("BID", "bid:" + str);
        return str;
    }

    private String getCountry(Context context) {
        TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService("phone");
        String networkCountryIso = telephonyManager != null ? telephonyManager.getNetworkCountryIso() : "default";
        return TextUtils.isEmpty(networkCountryIso) ? "default" : networkCountryIso;
    }

    private Drawable getDrawable(Context context, String str) {
        BitmapDrawable bitmapDrawable;
        try {
            File file = new File(str);
            if (!file.exists()) {
                return null;
            }
            if (file.length() <= 0) {
                file.delete();
                return null;
            }
            int dimensionPixelSize = context.getResources().getDimensionPixelSize(R.dimen.gift_icon_size);
            Bitmap decodeSampledBitmapFromResource = decodeSampledBitmapFromResource(str, dimensionPixelSize, dimensionPixelSize);
            bitmapDrawable = decodeSampledBitmapFromResource != null ? new BitmapDrawable(decodeSampledBitmapFromResource) : null;
            return bitmapDrawable;
        } catch (Exception e) {
            e.printStackTrace();
            bitmapDrawable = null;
        }
    }

    private AdsCacheItem getHistoryPreload(IAdInfo iAdInfo) {
        return iAdInfo == null ? YhAdsCache.get(this.mContext, "") : YhAdsCache.get(this.mContext, iAdInfo.getPackageName());
    }

    public static String getShortUrl(String str) {
        return str.length() > MAX_UMENG_LEN ? str.contains(MARKET_PREFIX) ? str.substring(MARKET_PREFIX.length(), MetadataChangeSet.CUSTOM_PROPERTY_SIZE_LIMIT_BYTES) : str.substring(0, MetadataChangeSet.CUSTOM_PROPERTY_SIZE_LIMIT_BYTES) : str;
    }

    public static String goDefaultKeyboard(Context context) {
        UpdateVersion.install(context, DEFAULT_PKG);
        return DEFAULT_PKG;
    }

    private void goHistoryPreload(AdsCacheItem adsCacheItem) {
        if (adsCacheItem != null) {
            this.mAdClickHandler.jumpToClickDestinationUrlPreload(adsCacheItem.getRecordUrl(), adsCacheItem.getTrackUrl(), adsCacheItem.getFinaUrl());
        }
    }

    /* access modifiers changed from: private */
    public void onGetAds(List<AdResponse> list) {
        if (list.size() > 0) {
            this.mAdsList = list;
            recordGotAdsEvent(reChooseAds(chooseAdsMethod(list), list));
        }
    }

    /* access modifiers changed from: private */
    public void onPreloadAdsOver() {
        IAdInfo iAdInfo = this.mAdClickHandler.getmAdInfo();
        recoardAdsLoadOver(iAdInfo);
        cacheAds(iAdInfo);
    }

    private void preadAdsCheck(IAdInfo iAdInfo) {
        String preload = iAdInfo.getPreload();
        String onlineKeyValue = UpdateVersion.getOnlineKeyValue(this.mContext, "yh_ads_preload_force");
        if (!TextUtils.isEmpty(onlineKeyValue) && onlineKeyValue.equalsIgnoreCase(ConstSetting.IOS7_ENABLE)) {
            this.mClickHandler.get().preloadGetUrl(this.mAdsLoadOverListener);
        } else if (preload.equalsIgnoreCase("1")) {
            this.mClickHandler.get().preloadGetUrl(this.mAdsLoadOverListener);
        }
    }

    private void preloadGoAds(IAdInfo iAdInfo) {
        this.mClickHandler.get().jumpToClickDestinationUrlPreload(iAdInfo.getClickRecordUrl(), iAdInfo.getClickDestinationUrl(), iAdInfo.getFinalUrl());
    }

    private IAdInfo reChooseAds(IAdInfo iAdInfo, List<AdResponse> list) {
        if (iAdInfo != null && this.mContext != null && UpdateVersion.checkApkExist(this.mContext, iAdInfo.getPackageName())) {
            UpdateVersion.onEventRechoose(this.mContext, iAdInfo.getPackageName(), iAdInfo.getBid(), "0", iAdInfo.getPreload(), getCountry(this.mContext), this.mPosition);
            int i = 0;
            while (true) {
                int i2 = i;
                if (i2 >= 2) {
                    break;
                }
                iAdInfo = chooseAdsMethodEqual(list);
                UpdateVersion.onEventRechoose(this.mContext, iAdInfo.getPackageName(), iAdInfo.getBid(), "0", iAdInfo.getPreload(), getCountry(this.mContext), this.mPosition);
                if (iAdInfo != null && this.mContext != null && !UpdateVersion.checkApkExist(this.mContext, iAdInfo.getPackageName())) {
                    break;
                }
                i = i2 + 1;
            }
        }
        return iAdInfo;
    }

    private void recoardAdsLoadOver(IAdInfo iAdInfo) {
        String finalUrl = iAdInfo.getFinalUrl();
        String packageName = iAdInfo.getPackageName();
        iAdInfo.getBid();
        String onlineKeyValue = UpdateVersion.getOnlineKeyValue(this.mContext, "yh_loadads_index");
        String str = "success";
        if (!TextUtils.isEmpty(finalUrl) && finalUrl.length() >= 20) {
            finalUrl = getShortUrl(finalUrl);
            if (!IntentUtils.isAppStoreUrl(finalUrl)) {
                str = "failed";
            }
        } else if (TextUtils.isEmpty(finalUrl)) {
            finalUrl = "empty";
            str = "failed:empty";
        } else if (!TextUtils.isEmpty(finalUrl) && finalUrl.length() < 20) {
            str = "failed:" + finalUrl;
        }
        String bid = getBid(iAdInfo.getBid());
        if (!finalUrl.equalsIgnoreCase(URL_ABOUT) || this.mRandom.nextInt(50) % 50 < 2) {
            UpdateVersion.onEventLoadYhAds(this.mContext, finalUrl, ((System.currentTimeMillis() - this.mStartTime) / 1000) + "", packageName, bid, str, onlineKeyValue, this.mPosition);
        }
    }

    private void recordClickAds(IAdInfo iAdInfo, AdsRecordItem adsRecordItem) {
        long currentTimeMillis = (System.currentTimeMillis() - this.mStartTime) / 100;
        if (currentTimeMillis > 100) {
            currentTimeMillis = 100;
        }
        UpdateVersion.onEventClickYhAds(this.mContext, adsRecordItem.pkg, currentTimeMillis + "", adsRecordItem.bid, adsRecordItem.status, getCountry(this.mContext), adsRecordItem.finalurl, this.mPosition);
    }

    /* access modifiers changed from: private */
    public void recordCreateEvent(Context context) {
        UpdateVersion.onEventOnCreate(this.mContext, getCountry(context), this.mPosition);
    }

    private void recordGotAdsEvent(IAdInfo iAdInfo) {
        if (iAdInfo != null) {
            getBid(iAdInfo.getBid());
            UpdateVersion.onEventGotAdsOver(this.mContext, iAdInfo.getPackageName(), iAdInfo.getBid(), ((System.currentTimeMillis() - this.mStartTime) / 1000) + "", iAdInfo.getPreload(), getCountry(this.mContext), this.mPosition);
        }
    }

    private void saveAdsIcon() {
    }

    public static void writeData(Context context, String str, String str2) {
        try {
            FileOutputStream openFileOutput = context.openFileOutput(str2, 0);
            openFileOutput.write(str.getBytes());
            openFileOutput.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void writeSDFile(String str, String str2) {
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(str);
            fileOutputStream.write(str2.getBytes());
            fileOutputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String adsEmptyTitle(AdsRecordItem adsRecordItem) {
        String title;
        AdsCacheItem historyPreload = getHistoryPreload(null);
        if (historyPreload == null) {
            IAdInfo chooseAdsFromCache = chooseAdsFromCache();
            if (chooseAdsFromCache != null) {
                title = adsNoEmtpyTitle(chooseAdsFromCache, adsRecordItem);
            } else {
                title = DEFAULT_TITLE;
                adsRecordItem.pkg = DEFAULT_PKG;
            }
        } else {
            title = historyPreload.getTitle();
            adsRecordItem.pkg = historyPreload.getPkg();
        }
        adsRecordItem.title = title;
        return title;
    }

    public int calculateInSampleSize(BitmapFactory.Options options, int i, int i2) {
        int i3 = options.outHeight;
        int i4 = options.outWidth;
        if (i3 <= i2 && i4 <= i) {
            return 1;
        }
        int round = Math.round(((float) i3) / ((float) i2));
        int round2 = Math.round(((float) i4) / ((float) i));
        return round < round2 ? round : round2;
    }

    public void clickAds(IAdInfo iAdInfo) {
        if (iAdInfo != null) {
            adsClickNoEmtpy(iAdInfo, new AdsRecordItem());
        }
    }

    public Bitmap decodeSampledBitmapFromResource(String str, int i, int i2) {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(str, options);
        options.inSampleSize = calculateInSampleSize(options, i, i2);
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeFile(str, options);
    }

    public Drawable getAdsIcon(IAdInfo iAdInfo) {
        if (iAdInfo != null) {
            return getDrawable(this.mContext, this.mIconPath + iAdInfo.getPackageName() + ".png");
        }
        return null;
    }

    public String getAdsIconPath() {
        return this.mIconPath;
    }

    public String getAdsTitle(AdsRecordItem adsRecordItem) {
        IAdInfo chooseAds = chooseAds();
        return chooseAds != null ? adsNoEmtpyTitle(chooseAds, adsRecordItem) : adsEmptyTitle(adsRecordItem);
    }

    public IAdInfo getCurrentAds() {
        IAdInfo chooseAds = chooseAds();
        return chooseAds == null ? chooseAdsFromCache() : chooseAds;
    }

    public long getLoadTime() {
        return this.mStartTime;
    }

    public void initYhAds(Context context, int i, int i2, String str) {
        this.mContext = context;
        this.adManager = new AdManager(context);
        this.adManager.setAppId((long) i);
        this.adManager.setSlotId((long) i2);
        this.adManager.setAdNum(getAdNum());
        new Handler().post(new Runnable() {
            /* class com.keyboard.yhadsmodule.YhAdsEntry.AnonymousClass1 */

            public void run() {
                YhAdsEntry.this.recordCreateEvent(YhAdsEntry.this.mContext);
            }
        });
        this.mAdClickHandler = new AdClickHandler(context);
        this.mClickHandler = new WeakReference<>(this.mAdClickHandler);
        this.mAdClickHandler.setWebViewShow(false);
        this.mAdsLoadOverListener = new UpdateVersion.onLoadOverAds() {
            /* class com.keyboard.yhadsmodule.YhAdsEntry.AnonymousClass2 */

            @Override // com.keyboard.yhadsmodule.utils.UpdateVersion.onLoadOverAds
            public void onFinish(View view) {
                YhAdsEntry.this.onPreloadAdsOver();
            }
        };
        this.adManager.setAdReceiveListener(new OnAdReceiveListener() {
            /* class com.keyboard.yhadsmodule.YhAdsEntry.AnonymousClass3 */

            @Override // com.keyboard.yhadsmodule.ads.OnAdReceiveListener
            public void onAdFail(String str) {
                Log.e("AdFail:", str);
            }

            @Override // com.keyboard.yhadsmodule.ads.OnAdReceiveListener
            public void onAdReceive(List<AdResponse> list) {
                YhAdsEntry.this.onGetAds(list);
            }
        });
        if (str.length() > 0) {
            this.adManager.setIcc(str);
        }
        this.adManager.loadAd();
        this.mStartTime = System.currentTimeMillis();
    }

    public void loadAds() {
        this.adManager.loadAd();
        this.mStartTime = System.currentTimeMillis();
    }

    public boolean needRefresh(String str) {
        if (System.currentTimeMillis() - this.mStartTime <= 300000) {
            return false;
        }
        UpdateVersion.onEventOnRefresh(this.mContext, getCountry(this.mContext), str);
        return true;
    }

    public void onClickAds() {
        IAdInfo chooseAds = chooseAds();
        AdsRecordItem adsRecordItem = new AdsRecordItem();
        if (this.mContext != null) {
            Toast.makeText(this.mContext, "Market is opening...", 1).show();
        }
        if (chooseAds != null) {
            adsClickNoEmtpy(chooseAds, adsRecordItem);
        } else {
            AdsCacheItem historyPreload = getHistoryPreload(chooseAds);
            if (historyPreload == null) {
                IAdInfo chooseAdsFromCache = chooseAdsFromCache();
                if (chooseAdsFromCache != null) {
                    adsClickNoEmtpy(chooseAdsFromCache, adsRecordItem);
                } else {
                    goDefaultKeyboard(this.mContext);
                    adsRecordItem.pkg = DEFAULT_PKG;
                    adsRecordItem.finalurl = "empty:default_goads";
                    adsRecordItem.bid = "0";
                    adsRecordItem.status = "default_goads";
                }
            } else {
                goHistoryPreload(historyPreload);
                adsRecordItem.pkg = historyPreload.getPkg();
                adsRecordItem.finalurl = historyPreload.getFinaUrl();
                adsRecordItem.bid = historyPreload.getBid();
                adsRecordItem.status = "preloadhistory_goads";
            }
        }
        recordClickAds(chooseAds, adsRecordItem);
        reChooseAds(chooseAdsMethodEqual(this.mAdsList), this.mAdsList);
        loadAds();
    }

    public void saveAdsIcon(IAdInfo iAdInfo) {
        if (iAdInfo != null && !TextUtils.isEmpty(this.mIconPath)) {
            if (!AdsImgFetchTask.isFileExist(this.mIconPath + iAdInfo.getPackageName() + ".png")) {
                AdsImgFetchTask adsImgFetchTask = new AdsImgFetchTask(iAdInfo, this.mIconPath);
                String iconImageUrl = iAdInfo.getIconImageUrl();
                adsImgFetchTask.setOnFinsh(this.mFetchAdsIconListner);
                try {
                    AsyncTasks.safeExecuteOnExecutor(adsImgFetchTask, iconImageUrl);
                } catch (Exception e) {
                    Log.d("AdViewController", "Error executing AdsImgFetchTask", e);
                }
            } else {
                this.mFetchAdsIconListner.onFinish(iAdInfo);
            }
        }
    }

    public void setAdsIconPath(String str) {
        this.mIconPath = str;
    }

    public void setDefaultPkg(String str) {
        DEFAULT_PKG = str;
    }

    public void setDefaultTitle(String str) {
        DEFAULT_TITLE = str;
    }

    public void setFetchAdsIconCb(AdsImgFetchTask.OnGetFinishListener onGetFinishListener) {
        this.mFetchAdsIconListner = onGetFinishListener;
    }

    public void setPosition(String str) {
        this.mPosition = str;
    }
}
