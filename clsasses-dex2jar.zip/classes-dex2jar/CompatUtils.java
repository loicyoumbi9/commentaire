package com.keyboard.common.utilsmodule;

import android.widget.GridView;

public final class CompatUtils {
    private static final String TAG = CompatUtils.class.getSimpleName();

    public static int gridview_getHorizontalSpacing(GridView gridView) {
        Integer num;
        if (gridView == null || (num = (Integer) ReflectUtils.getFieldObject(GridView.class, gridView, "mHorizontalSpacing")) == null) {
            return 0;
        }
        return num.intValue();
    }

    public static int gridview_getVerticalSpacing(GridView gridView) {
        Integer num;
        if (gridView == null || (num = (Integer) ReflectUtils.getFieldObject(GridView.class, gridView, "mVerticalSpacing")) == null) {
            return 0;
        }
        return num.intValue();
    }
}
