package com.ironsource.mobilcore;

import android.content.Context;
import com.alimama.mobile.csdk.umupdate.a.f;
import org.json.JSONArray;
import org.json.JSONObject;

/* renamed from: com.ironsource.mobilcore.aa  reason: case insensitive filesystem */
final class C0238aa {
    private boolean a;
    private String b;
    private boolean c;
    private boolean d;
    private JSONArray e;
    private C0261ax f;

    public C0238aa(Context context, JSONObject jSONObject) {
        this.a = jSONObject.optBoolean("enabled", true);
        this.b = jSONObject.optString("position", "left");
        this.c = jSONObject.optBoolean("showSliderHandle", true);
        this.d = jSONObject.optBoolean("ftue", false);
        this.e = jSONObject.getJSONArray(f.bt);
        this.f = new C0261ax(context, jSONObject.getJSONObject("style"));
    }

    public final boolean a() {
        return this.c;
    }

    public final boolean b() {
        return this.d;
    }

    public final JSONArray c() {
        return this.e;
    }

    public final C0261ax d() {
        return this.f;
    }
}
