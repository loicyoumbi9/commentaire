package u.aly;

import android.content.Context;
import android.content.SharedPreferences;
import com.umeng.analytics.h;

public class aa implements r {
    private static final String h = "successful_request";
    private static final String i = "failed_requests ";
    private static final String j = "last_request_spent_ms";
    private static final String k = "last_request_time";
    private static final String l = "first_activate_time";
    private static final String m = "last_req";
    public int a;
    public int b;
    public long c;
    private final int d = 3600000;
    private int e;
    private long f = 0;
    private long g = 0;
    private Context n;

    public aa(Context context) {
        b(context);
    }

    public static ap a(Context context) {
        SharedPreferences a2 = x.a(context);
        ap apVar = new ap();
        apVar.c(a2.getInt(i, 0));
        apVar.d(a2.getInt(j, 0));
        apVar.a(a2.getInt(h, 0));
        return apVar;
    }

    private void b(Context context) {
        this.n = context.getApplicationContext();
        SharedPreferences a2 = x.a(context);
        this.a = a2.getInt(h, 0);
        this.b = a2.getInt(i, 0);
        this.e = a2.getInt(j, 0);
        this.c = a2.getLong(k, 0);
        this.f = a2.getLong(m, 0);
    }

    @Override // u.aly.r
    public void a() {
        i();
    }

    @Override // u.aly.r
    public void b() {
        j();
    }

    @Override // u.aly.r
    public void c() {
        g();
    }

    @Override // u.aly.r
    public void d() {
        h();
    }

    public int e() {
        if (this.e > 3600000) {
            return 3600000;
        }
        return this.e;
    }

    public boolean f() {
        return ((this.c > 0 ? 1 : (this.c == 0 ? 0 : -1)) == 0) && (!h.a(this.n).h());
    }

    public void g() {
        this.a++;
        this.c = this.f;
    }

    public void h() {
        this.b++;
    }

    public void i() {
        this.f = System.currentTimeMillis();
    }

    public void j() {
        this.e = (int) (System.currentTimeMillis() - this.f);
    }

    public void k() {
        x.a(this.n).edit().putInt(h, this.a).putInt(i, this.b).putInt(j, this.e).putLong(k, this.c).putLong(m, this.f).commit();
    }

    public void l() {
        x.a(this.n).edit().putLong(l, System.currentTimeMillis()).commit();
    }

    public boolean m() {
        if (this.g == 0) {
            this.g = x.a(this.n).getLong(l, 0);
        }
        return this.g == 0;
    }

    public long n() {
        return m() ? System.currentTimeMillis() : this.g;
    }

    public long o() {
        return this.f;
    }
}
