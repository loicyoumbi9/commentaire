package com.umeng.update;

public interface UmengUpdateListener {
    void onUpdateReturned(int i, UpdateResponse updateResponse);
}
