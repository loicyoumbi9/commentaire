package com.ironsource.mobilcore;

import android.content.Context;
import android.view.View;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.MessageFormat;
import org.json.JSONObject;

/* renamed from: com.ironsource.mobilcore.ay  reason: case insensitive filesystem */
final class C0262ay extends G {
    private String a;
    private String b;
    private String t;

    /* renamed from: u  reason: collision with root package name */
    private String f9u;
    private String v;

    public C0262ay(Context context, C0261ax axVar) {
        super(context, axVar);
    }

    @Override // com.ironsource.mobilcore.H, com.ironsource.mobilcore.G
    public final String a() {
        return "ironsourceSocialWidgetFacebookWallPost";
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: com.ironsource.mobilcore.aF.a(android.app.Activity, java.lang.String, boolean):void
     arg types: [android.app.Activity, java.lang.String, int]
     candidates:
      com.ironsource.mobilcore.aF.a(java.io.InputStream, java.lang.String, java.lang.String):java.io.File
      com.ironsource.mobilcore.aF.a(android.content.Context, java.lang.String, java.lang.String):java.lang.String
      com.ironsource.mobilcore.aF.a(android.app.Activity, java.lang.String, boolean):void */
    /* access modifiers changed from: protected */
    @Override // com.ironsource.mobilcore.H, com.ironsource.mobilcore.I
    public final void a(View view) {
        try {
            aF.a(this.e, MessageFormat.format("https://m.facebook.com/dialog/feed?app_id={0}&link={1}&picture={2}&name={3}&description={4}&redirect_uri={5}", URLEncoder.encode(this.a, "UTF-8"), URLEncoder.encode(aF.g(this.c), "UTF-8"), URLEncoder.encode(this.t, "UTF-8"), URLEncoder.encode(this.f9u, "UTF-8"), URLEncoder.encode(this.v, "UTF-8"), URLEncoder.encode(this.b, "UTF-8")), true);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        super.a(view);
    }

    @Override // com.ironsource.mobilcore.H, com.ironsource.mobilcore.G
    public final void a(JSONObject jSONObject) {
        this.a = jSONObject.optString("facebookAppId", "");
        this.b = jSONObject.optString("facebookRedirectURI", "");
        this.t = jSONObject.optString("appPictureUrl", "");
        this.f9u = jSONObject.optString("appName", "");
        this.v = jSONObject.optString("postText", "");
        super.a(jSONObject);
    }
}
