package u.aly;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class ct implements Serializable {
    private static Map<Class<? extends ch>, Map<? extends co, ct>> d = new HashMap();
    public final String a;
    public final byte b;
    public final cu c;

    public ct(String str, byte b2, cu cuVar) {
        this.a = str;
        this.b = b2;
        this.c = cuVar;
    }

    public static Map<? extends co, ct> a(Class<? extends ch> cls) {
        if (!d.containsKey(cls)) {
            try {
                cls.newInstance();
            } catch (InstantiationException e) {
                throw new RuntimeException("InstantiationException for TBase class: " + cls.getName() + ", message: " + e.getMessage());
            } catch (IllegalAccessException e2) {
                throw new RuntimeException("IllegalAccessException for TBase class: " + cls.getName() + ", message: " + e2.getMessage());
            }
        }
        return d.get(cls);
    }

    public static void a(Class<? extends ch> cls, Map<? extends co, ct> map) {
        d.put(cls, map);
    }
}
