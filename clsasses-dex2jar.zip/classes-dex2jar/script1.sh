#!/bin/bash
a=`ls`
dossier_courant=${PWD##*/} 
touch "$dossier_courant".txt
for file in $a
do
	if [ -f "$file" ]; then
		if [  "${file##*.}" == "java" ];then
			cat "$file" >> "$dossier_courant".txt
		fi
	elif [ -d "$file" ]; then
		cp script.sh "$file"
		cd "$file"
		if [ "$(ls -A "$file")" != "" ]; then
			sudo ./script.sh
		fi
	fi
done
