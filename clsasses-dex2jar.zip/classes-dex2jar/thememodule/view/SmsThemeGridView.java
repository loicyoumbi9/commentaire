package com.sms.common.thememodule.view;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.RatingBar;
import android.widget.TextView;
import com.keyboard.common.remotemodule.core.network.ImageLoaderWrapper;
import com.keyboard.common.utilsmodule.CompatUtils;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;
import com.nostra13.universalimageloader.core.listener.ImageLoadingProgressListener;
import com.sms.common.thememodule.R;
import com.sms.common.thememodule.data.SmsThemeInfo;
import java.util.ArrayList;

public class SmsThemeGridView extends GridView implements ImageLoadingListener, AbsListView.RecyclerListener {
    private Context mContext;
    private String mCurrentTheme = null;
    /* access modifiers changed from: private */
    public LayoutInflater mInflater;
    /* access modifiers changed from: private */
    public ItemClickListener mItemClickListener;
    /* access modifiers changed from: private */
    public int mItemHeight;
    /* access modifiers changed from: private */
    public int mItemWidth;
    private Drawable mMoreAppImgFailIc;
    private Drawable mMoreAppImgLoadingIc;
    private SmsThemeAdapter mSmsAdapter;
    /* access modifiers changed from: private */
    public ArrayList<SmsThemeInfo> mSmsThemeInfo = new ArrayList<>();
    private float mWidthHeightRatio = 0.69f;

    public interface ItemClickListener {
        void onItemClick(SmsThemeInfo smsThemeInfo);
    }

    public class SmsThemeAdapter extends BaseAdapter implements View.OnClickListener {
        public SmsThemeAdapter() {
        }

        public int getCount() {
            return SmsThemeGridView.this.mSmsThemeInfo.size();
        }

        public Object getItem(int i) {
            if (i < 0 || i >= SmsThemeGridView.this.mSmsThemeInfo.size()) {
                return null;
            }
            return SmsThemeGridView.this.mSmsThemeInfo.get(i);
        }

        public long getItemId(int i) {
            return (long) i;
        }

        public View getView(int i, View view, ViewGroup viewGroup) {
            if (view == null) {
                view = SmsThemeGridView.this.mInflater.inflate(R.layout.sms_theme_gride_item, (ViewGroup) null);
            }
            view.setOnClickListener(this);
            view.setTag(R.id.tag_position, Integer.valueOf(i));
            SmsThemeInfo smsThemeInfo = (i < 0 || i >= SmsThemeGridView.this.mSmsThemeInfo.size()) ? null : (SmsThemeInfo) SmsThemeGridView.this.mSmsThemeInfo.get(i);
            if (smsThemeInfo != null) {
                ImageView imageView = (ImageView) view.findViewById(R.id.sms_theme_poster);
                if (SmsThemeGridView.this.mSmsThemeInfo != null) {
                    String str = (String) imageView.getTag(R.id.tag_url);
                    if (str == null || !str.equals(smsThemeInfo.mSmallPreview)) {
                        ImageLoaderWrapper.postDisplayTask(smsThemeInfo.mSmallPreview, imageView, SmsThemeGridView.this, (ImageLoadingProgressListener) null);
                    }
                    ImageView imageView2 = (ImageView) view.findViewById(R.id.sms_theme_selected_img);
                    ((TextView) view.findViewById(R.id.sms_theme_title)).setText(smsThemeInfo.mTitle);
                    ((TextView) view.findViewById(R.id.sms_theme_downloads)).setText(smsThemeInfo.mDownload);
                    RatingBar ratingBar = (RatingBar) view.findViewById(R.id.sms_theme_ratingbar);
                    if (smsThemeInfo.mRate != null) {
                        double parseDouble = Double.parseDouble(smsThemeInfo.mRate);
                        if (parseDouble == 0.0d) {
                            ratingBar.setRating(0.0f);
                        } else if (parseDouble > 0.0d && parseDouble < 2.0d) {
                            ratingBar.setRating(1.0f);
                        } else if (parseDouble >= 2.0d && parseDouble < 3.0d) {
                            ratingBar.setRating(2.0f);
                        } else if (parseDouble >= 3.0d && parseDouble < 4.0d) {
                            ratingBar.setRating(3.0f);
                        } else if (parseDouble < 4.0d || parseDouble >= 5.0d) {
                            ratingBar.setRating(5.0f);
                        } else {
                            ratingBar.setRating(4.0f);
                        }
                    }
                    if (!(smsThemeInfo.mPkg == null || imageView2 == null)) {
                        if (smsThemeInfo.mSelected) {
                            imageView2.setVisibility(0);
                        } else {
                            imageView2.setVisibility(8);
                        }
                    }
                }
                ViewGroup.LayoutParams layoutParams = imageView.getLayoutParams();
                if (layoutParams == null) {
                    layoutParams = new LinearLayout.LayoutParams(SmsThemeGridView.this.mItemWidth, SmsThemeGridView.this.mItemHeight);
                } else {
                    layoutParams.width = SmsThemeGridView.this.mItemWidth;
                    layoutParams.height = SmsThemeGridView.this.mItemHeight;
                }
                imageView.setLayoutParams(layoutParams);
            }
            return view;
        }

        public void onClick(View view) {
            if (view.getTag(R.id.tag_position) != null) {
                int intValue = ((Integer) view.getTag(R.id.tag_position)).intValue();
                if (SmsThemeGridView.this.mItemClickListener != null && SmsThemeGridView.this.mSmsThemeInfo != null && intValue >= 0 && intValue < SmsThemeGridView.this.mSmsThemeInfo.size()) {
                    SmsThemeGridView.this.mItemClickListener.onItemClick((SmsThemeInfo) SmsThemeGridView.this.mSmsThemeInfo.get(intValue));
                }
            }
        }
    }

    public SmsThemeGridView(Context context) {
        super(context);
        init(context);
    }

    public SmsThemeGridView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        init(context);
    }

    public SmsThemeGridView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        init(context);
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: ClspMth{android.content.res.Resources.getValue(int, android.util.TypedValue, boolean):void throws android.content.res.Resources$NotFoundException}
     arg types: [int, android.util.TypedValue, int]
     candidates:
      ClspMth{android.content.res.Resources.getValue(java.lang.String, android.util.TypedValue, boolean):void throws android.content.res.Resources$NotFoundException}
      ClspMth{android.content.res.Resources.getValue(int, android.util.TypedValue, boolean):void throws android.content.res.Resources$NotFoundException} */
    private void init(Context context) {
        this.mContext = context.getApplicationContext();
        this.mInflater = LayoutInflater.from(this.mContext);
        this.mSmsThemeInfo = new ArrayList<>();
        Resources resources = this.mContext.getResources();
        TypedValue typedValue = new TypedValue();
        resources.getValue(R.dimen.sms_theme_width_height_ratio, typedValue, true);
        this.mWidthHeightRatio = typedValue.getFloat();
        this.mSmsAdapter = new SmsThemeAdapter();
        setAdapter((ListAdapter) this.mSmsAdapter);
        setRecyclerListener(this);
    }

    private int mathMeasure(int i) {
        int mode = View.MeasureSpec.getMode(i);
        int size = View.MeasureSpec.getSize(i);
        if (mode == 1073741824) {
            return size;
        }
        if (mode == Integer.MIN_VALUE) {
            return Math.min(0, size);
        }
        return 0;
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v2, resolved type: java.util.ArrayList<com.sms.common.thememodule.data.SmsThemeInfo>} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void addThemeInfo(java.util.ArrayList<com.sms.common.thememodule.data.SmsThemeInfo> r2) {
        /*
            r1 = this;
            if (r2 == 0) goto L_0x000c
            boolean r0 = r2.isEmpty()
            if (r0 != 0) goto L_0x000c
            java.util.ArrayList<com.sms.common.thememodule.data.SmsThemeInfo> r0 = r1.mSmsThemeInfo
            if (r0 != 0) goto L_0x000d
        L_0x000c:
            return
        L_0x000d:
            java.util.ArrayList<com.sms.common.thememodule.data.SmsThemeInfo> r0 = r1.mSmsThemeInfo
            r0.addAll(r2)
            java.lang.String r0 = r1.mCurrentTheme
            r1.setCurrentTheme(r0)
            com.sms.common.thememodule.view.SmsThemeGridView$SmsThemeAdapter r0 = r1.mSmsAdapter
            r0.notifyDataSetChanged()
            goto L_0x000c
        */
        throw new UnsupportedOperationException("Method not decompiled: com.sms.common.thememodule.view.SmsThemeGridView.addThemeInfo(java.util.ArrayList):void");
    }

    public void destroy() {
        if (this.mSmsThemeInfo != null) {
            this.mSmsThemeInfo.clear();
        }
    }

    public int getItemCount() {
        if (this.mSmsThemeInfo == null) {
            return 0;
        }
        return this.mSmsThemeInfo.size();
    }

    @Override // com.nostra13.universalimageloader.core.listener.ImageLoadingListener
    public void onLoadingCancelled(String str, View view) {
    }

    @Override // com.nostra13.universalimageloader.core.listener.ImageLoadingListener
    public void onLoadingComplete(String str, View view, Bitmap bitmap) {
        if (view instanceof ImageView) {
            ImageView imageView = (ImageView) view;
            if (bitmap != null) {
                imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
                imageView.setImageBitmap(bitmap);
                imageView.setTag(R.id.tag_url, str);
            }
        }
    }

    @Override // com.nostra13.universalimageloader.core.listener.ImageLoadingListener
    public void onLoadingFailed(String str, View view, FailReason failReason) {
        if (view instanceof ImageView) {
            ImageView imageView = (ImageView) view;
            if (this.mMoreAppImgFailIc != null) {
                imageView.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
                imageView.setImageDrawable(this.mMoreAppImgFailIc);
                imageView.setTag(R.id.tag_url, null);
            }
        }
    }

    @Override // com.nostra13.universalimageloader.core.listener.ImageLoadingListener
    public void onLoadingStarted(String str, View view) {
        if (view instanceof ImageView) {
            ImageView imageView = (ImageView) view;
            if (this.mMoreAppImgLoadingIc != null) {
                imageView.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
                imageView.setImageDrawable(this.mMoreAppImgLoadingIc);
                imageView.setTag(R.id.tag_url, null);
            }
        }
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        this.mItemWidth = (((mathMeasure(i) / 2) - CompatUtils.gridview_getHorizontalSpacing(this)) - getPaddingLeft()) - getPaddingRight();
        this.mItemHeight = (int) (((float) this.mItemWidth) / this.mWidthHeightRatio);
    }

    public void onMovedToScrapHeap(View view) {
        ImageView imageView = (ImageView) view.findViewById(R.id.sms_theme_poster);
        if (imageView != null) {
            ImageLoaderWrapper.cancelLoadTask(imageView);
        }
    }

    public void setCurrentTheme(String str) {
        this.mCurrentTheme = str;
        if (this.mSmsThemeInfo != null) {
            for (int i = 0; i < this.mSmsThemeInfo.size(); i++) {
                SmsThemeInfo smsThemeInfo = this.mSmsThemeInfo.get(i);
                if (!(smsThemeInfo == null || smsThemeInfo.mPkg == null)) {
                    smsThemeInfo.mSelected = false;
                    if (smsThemeInfo.mPkg.equals(str)) {
                        smsThemeInfo.mSelected = true;
                    }
                }
            }
        }
    }

    public void setItemClickListener(ItemClickListener itemClickListener) {
        this.mItemClickListener = itemClickListener;
    }

    public void setLoadingRes(Drawable drawable, Drawable drawable2) {
        this.mMoreAppImgLoadingIc = drawable;
        this.mMoreAppImgFailIc = drawable2;
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v3, resolved type: java.util.ArrayList<com.sms.common.thememodule.data.SmsThemeInfo>} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void setThemeInfo(java.util.ArrayList<com.sms.common.thememodule.data.SmsThemeInfo> r2) {
        /*
            r1 = this;
            java.util.ArrayList<com.sms.common.thememodule.data.SmsThemeInfo> r0 = r1.mSmsThemeInfo
            r0.clear()
            if (r2 == 0) goto L_0x000c
            java.util.ArrayList<com.sms.common.thememodule.data.SmsThemeInfo> r0 = r1.mSmsThemeInfo
            r0.addAll(r2)
        L_0x000c:
            java.lang.String r0 = r1.mCurrentTheme
            r1.setCurrentTheme(r0)
            com.sms.common.thememodule.view.SmsThemeGridView$SmsThemeAdapter r0 = r1.mSmsAdapter
            r0.notifyDataSetChanged()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.sms.common.thememodule.view.SmsThemeGridView.setThemeInfo(java.util.ArrayList):void");
    }

    public void updateView() {
        if (this.mSmsAdapter != null) {
            this.mSmsAdapter.notifyDataSetChanged();
        }
    }
}
