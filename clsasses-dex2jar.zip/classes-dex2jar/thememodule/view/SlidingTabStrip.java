package com.sms.common.thememodule.view;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.widget.LinearLayout;
import com.sms.common.thememodule.view.SlidingTabLayout;

class SlidingTabStrip extends LinearLayout {
    private static final byte DEFAULT_BOTTOM_BORDER_COLOR_ALPHA = 38;
    private static final int DEFAULT_BOTTOM_BORDER_THICKNESS_DIPS = 0;
    private static final int DEFAULT_SELECTED_INDICATOR_COLOR = -13388315;
    private static final int SELECTED_INDICATOR_THICKNESS_DIPS = 3;
    private final Paint mBottomBorderPaint;
    private final int mBottomBorderThickness;
    private SlidingTabLayout.TabColorizer mCustomTabColorizer;
    private final int mDefaultBottomBorderColor;
    private final SimpleTabColorizer mDefaultTabColorizer;
    private final Paint mSelectedIndicatorPaint;
    private final int mSelectedIndicatorThickness;
    private int mSelectedPosition;
    private float mSelectionOffset;

    private static class SimpleTabColorizer implements SlidingTabLayout.TabColorizer {
        private int[] mIndicatorColors;

        private SimpleTabColorizer() {
        }

        @Override // com.sms.common.thememodule.view.SlidingTabLayout.TabColorizer
        public final int getIndicatorColor(int i) {
            return this.mIndicatorColors[i % this.mIndicatorColors.length];
        }

        /* access modifiers changed from: package-private */
        public void setIndicatorColors(int... iArr) {
            this.mIndicatorColors = iArr;
        }
    }

    SlidingTabStrip(Context context) {
        this(context, null);
    }

    SlidingTabStrip(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setWillNotDraw(false);
        float f = getResources().getDisplayMetrics().density;
        TypedValue typedValue = new TypedValue();
        context.getTheme().resolveAttribute(16842800, typedValue, true);
        this.mDefaultBottomBorderColor = setColorAlpha(typedValue.data, DEFAULT_BOTTOM_BORDER_COLOR_ALPHA);
        this.mDefaultTabColorizer = new SimpleTabColorizer();
        this.mDefaultTabColorizer.setIndicatorColors(DEFAULT_SELECTED_INDICATOR_COLOR);
        this.mBottomBorderThickness = (int) (0.0f * f);
        this.mBottomBorderPaint = new Paint();
        this.mBottomBorderPaint.setColor(this.mDefaultBottomBorderColor);
        this.mSelectedIndicatorThickness = (int) (f * 3.0f);
        this.mSelectedIndicatorPaint = new Paint();
    }

    private static int blendColors(int i, int i2, float f) {
        float f2 = 1.0f - f;
        return Color.rgb((int) ((((float) Color.red(i)) * f) + (((float) Color.red(i2)) * f2)), (int) ((((float) Color.green(i)) * f) + (((float) Color.green(i2)) * f2)), (int) ((f2 * ((float) Color.blue(i2))) + (((float) Color.blue(i)) * f)));
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: ClspMth{android.graphics.Color.argb(int, int, int, int):int}
     arg types: [byte, int, int, int]
     candidates:
      ClspMth{android.graphics.Color.argb(float, float, float, float):int}
      ClspMth{android.graphics.Color.argb(int, int, int, int):int} */
    private static int setColorAlpha(int i, byte b) {
        return Color.argb((int) b, Color.red(i), Color.green(i), Color.blue(i));
    }

    /* JADX WARN: Type inference failed for: r0v16, types: [com.sms.common.thememodule.view.SlidingTabLayout$TabColorizer] */
    /* access modifiers changed from: protected */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onDraw(android.graphics.Canvas r10) {
        /*
            r9 = this;
            r8 = 1065353216(0x3f800000, float:1.0)
            r7 = 0
            int r6 = r9.getHeight()
            int r1 = r9.getChildCount()
            com.sms.common.thememodule.view.SlidingTabLayout$TabColorizer r0 = r9.mCustomTabColorizer
            if (r0 == 0) goto L_0x0097
            com.sms.common.thememodule.view.SlidingTabLayout$TabColorizer r0 = r9.mCustomTabColorizer
            r3 = r0
        L_0x0012:
            if (r1 <= 0) goto L_0x0084
            int r0 = r9.mSelectedPosition
            android.view.View r1 = r9.getChildAt(r0)
            int r0 = r1.getLeft()
            int r1 = r1.getRight()
            int r2 = r9.mSelectedPosition
            int r2 = r3.getIndicatorColor(r2)
            float r4 = r9.mSelectionOffset
            int r4 = (r4 > r7 ? 1 : (r4 == r7 ? 0 : -1))
            if (r4 <= 0) goto L_0x009c
            int r4 = r9.mSelectedPosition
            int r5 = r9.getChildCount()
            int r5 = r5 + -1
            if (r4 >= r5) goto L_0x009c
            int r4 = r9.mSelectedPosition
            int r4 = r4 + 1
            int r3 = r3.getIndicatorColor(r4)
            if (r2 == r3) goto L_0x0048
            float r4 = r9.mSelectionOffset
            int r2 = blendColors(r3, r2, r4)
        L_0x0048:
            int r3 = r9.mSelectedPosition
            int r3 = r3 + 1
            android.view.View r3 = r9.getChildAt(r3)
            float r4 = r9.mSelectionOffset
            int r5 = r3.getLeft()
            float r5 = (float) r5
            float r4 = r4 * r5
            float r5 = r9.mSelectionOffset
            float r5 = r8 - r5
            float r0 = (float) r0
            float r0 = r0 * r5
            float r0 = r0 + r4
            int r0 = (int) r0
            float r4 = r9.mSelectionOffset
            int r3 = r3.getRight()
            float r3 = (float) r3
            float r3 = r3 * r4
            float r4 = r9.mSelectionOffset
            float r4 = r8 - r4
            float r1 = (float) r1
            float r1 = r1 * r4
            float r1 = r1 + r3
            int r1 = (int) r1
            r3 = r1
        L_0x0071:
            android.graphics.Paint r1 = r9.mSelectedIndicatorPaint
            r1.setColor(r2)
            float r1 = (float) r0
            int r0 = r9.mSelectedIndicatorThickness
            int r0 = r6 - r0
            float r2 = (float) r0
            float r3 = (float) r3
            float r4 = (float) r6
            android.graphics.Paint r5 = r9.mSelectedIndicatorPaint
            r0 = r10
            r0.drawRect(r1, r2, r3, r4, r5)
        L_0x0084:
            int r0 = r9.mBottomBorderThickness
            int r0 = r6 - r0
            float r2 = (float) r0
            int r0 = r9.getWidth()
            float r3 = (float) r0
            float r4 = (float) r6
            android.graphics.Paint r5 = r9.mBottomBorderPaint
            r0 = r10
            r1 = r7
            r0.drawRect(r1, r2, r3, r4, r5)
            return
        L_0x0097:
            com.sms.common.thememodule.view.SlidingTabStrip$SimpleTabColorizer r0 = r9.mDefaultTabColorizer
            r3 = r0
            goto L_0x0012
        L_0x009c:
            r3 = r1
            goto L_0x0071
        */
        throw new UnsupportedOperationException("Method not decompiled: com.sms.common.thememodule.view.SlidingTabStrip.onDraw(android.graphics.Canvas):void");
    }

    /* access modifiers changed from: package-private */
    public void onViewPagerPageChanged(int i, float f) {
        this.mSelectedPosition = i;
        this.mSelectionOffset = f;
        invalidate();
    }

    /* access modifiers changed from: package-private */
    public void setCustomTabColorizer(SlidingTabLayout.TabColorizer tabColorizer) {
        this.mCustomTabColorizer = tabColorizer;
        invalidate();
    }

    /* access modifiers changed from: package-private */
    public void setSelectedIndicatorColors(int... iArr) {
        this.mCustomTabColorizer = null;
        this.mDefaultTabColorizer.setIndicatorColors(iArr);
        invalidate();
    }
}
