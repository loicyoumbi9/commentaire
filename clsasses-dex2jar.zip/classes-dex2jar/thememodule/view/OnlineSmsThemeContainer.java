package com.sms.common.thememodule.view;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;
import com.android.volley.VolleyError;
import com.keyboard.common.remotemodule.core.network.ImageLoaderWrapper;
import com.keyboard.common.remotemodule.core.network.RemoteInteractor;
import com.keyboard.common.remotemodule.core.network.RemoteUrlFactory;
import com.keyboard.common.remotemodule.core.utils.SuggestInfoUtils;
import com.keyboard.common.remotemodule.core.zero.ZeroClient;
import com.keyboard.common.uimodule.swiperefreshlayout.SwipeRefreshLayout;
import com.nostra13.universalimageloader.cache.memory.MemoryCache;
import com.sms.common.thememodule.R;
import com.sms.common.thememodule.data.SmsRemoteDecoder;
import com.sms.common.thememodule.data.SmsThemeInfo;
import com.sms.common.thememodule.view.SmsThemeGridView;
import java.util.ArrayList;
import java.util.Iterator;
import org.json.JSONObject;

public class OnlineSmsThemeContainer extends TabContainer implements RemoteInteractor.RemoteResponseListener, SwipeRefreshLayout.OnRefreshListener, SmsThemeGridView.ItemClickListener {
    private static final String DEFAULT_VALUE = "default";
    private static final String KEY_SMS_THEME = "SMS_THEME_APPID";
    private static final int MSG_SHOW_REFRESH = 100;
    private static final long SHOW_REFRESH_DELAY = 500;
    private static final String TAG = OnlineSmsThemeContainer.class.getSimpleName();
    private static final int UI_LOADING = 1;
    private static final int UI_NORMAL = 0;
    private static final int UI_NO_DATA = 2;
    private int mColumnsNum = 0;
    private Context mContext = null;
    private int mCurrentPage = 0;
    private String mOldSmsThemeListUrl;
    private ArrayList<SmsThemeInfo> mOnlineBuildInThemeList;
    private int mPageItemNum = 0;
    private String mPkgName = null;
    private SwipeRefreshLayout mRefreshLayout = null;
    private SmsThemeGridView mSmsGridView = null;
    private String mSmsThemeAppId;
    private ArrayList<SmsThemeInfo> mSmsThemeBuffer;
    private String mSmsThemeListUrl;
    private ImageView mSmsThemeNoData = null;
    private Handler mUIHandler = null;

    public OnlineSmsThemeContainer(Context context) {
        super(context);
        init(context);
    }

    public OnlineSmsThemeContainer(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        init(context);
    }

    public OnlineSmsThemeContainer(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        init(context);
    }

    private void cancelDelayShowRefresh() {
        if (this.mUIHandler != null) {
            this.mUIHandler.removeMessages(100);
        }
    }

    private void delayShowRefresh() {
        if (this.mUIHandler != null) {
            this.mUIHandler.removeMessages(100);
            this.mUIHandler.sendEmptyMessageDelayed(100, SHOW_REFRESH_DELAY);
        }
    }

    @Override // com.sms.common.thememodule.view.TabContainer
    private void init(Context context) {
        this.mContext = context;
        Resources resources = this.mContext.getResources();
        this.mPkgName = this.mContext.getPackageName();
        this.mColumnsNum = resources.getInteger(R.integer.sms_theme_gridview_colnum);
    }

    private void initData() {
        this.mSmsThemeBuffer = new ArrayList<>();
        Resources resources = getResources();
        Drawable drawable = resources.getDrawable(R.drawable.sms_theme_ic_loading);
        Drawable drawable2 = resources.getDrawable(R.drawable.sms_theme_ic_load_error);
        this.mSmsGridView = (SmsThemeGridView) findViewById(R.id.sms_online_theme_gridview);
        this.mSmsGridView.setNumColumns(this.mColumnsNum);
        this.mSmsGridView.setLoadingRes(drawable, drawable2);
        this.mSmsGridView.setItemClickListener(this);
        this.mRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.sms_theme_refresh_layout);
        this.mRefreshLayout.setColorScheme(R.color.sms_theme_activity_refresh_color1, R.color.sms_theme_activity_refresh_color2, R.color.sms_theme_activity_refresh_color3, R.color.sms_theme_activity_refresh_color4);
        this.mRefreshLayout.setRefreshMode(1);
        this.mRefreshLayout.setOnRefreshListener(this);
        this.mSmsThemeNoData = (ImageView) findViewById(R.id.sms_theme_no_data);
        RemoteInteractor.getInstance(this.mContext).addListener(this);
        initHandler();
    }

    private void initHandler() {
        this.mUIHandler = new Handler(Looper.getMainLooper(), new Handler.Callback() {
            /* class com.sms.common.thememodule.view.OnlineSmsThemeContainer.AnonymousClass1 */

            public boolean handleMessage(Message message) {
                switch (message.what) {
                    case 100:
                        OnlineSmsThemeContainer.this.switchThemeUI(1, true);
                        return true;
                    default:
                        return false;
                }
            }
        });
    }

    private void nextPage() {
        this.mOldSmsThemeListUrl = RemoteUrlFactory.assembleGetThemeListUrl(this.mSmsThemeAppId, this.mCurrentPage, this.mPageItemNum);
        this.mCurrentPage++;
        this.mSmsThemeListUrl = RemoteUrlFactory.assembleGetThemeListUrl(this.mSmsThemeAppId, this.mCurrentPage, this.mPageItemNum);
    }

    private void onGetSmsThemeResponse(JSONObject jSONObject, boolean z) {
        boolean z2;
        boolean z3;
        if (this.mSmsGridView != null) {
            this.mSmsThemeBuffer.clear();
            SmsRemoteDecoder.decodeSmsThemeRaw(this.mSmsThemeBuffer, jSONObject);
            if (z) {
                if (!(this.mOnlineBuildInThemeList == null || this.mSmsThemeBuffer == null || this.mOnlineBuildInThemeList == null)) {
                    for (int i = 0; i < this.mOnlineBuildInThemeList.size(); i++) {
                        int i2 = 0;
                        while (true) {
                            if (i2 >= this.mSmsThemeBuffer.size()) {
                                z3 = false;
                                break;
                            } else if (this.mOnlineBuildInThemeList.get(i).mPkg.equals(this.mSmsThemeBuffer.get(i2).mPkg)) {
                                z3 = true;
                                break;
                            } else {
                                i2++;
                            }
                        }
                        if (!z3) {
                            this.mSmsThemeBuffer.add(0, this.mOnlineBuildInThemeList.get(i));
                        }
                    }
                }
                this.mSmsGridView.setThemeInfo(this.mSmsThemeBuffer);
                postFetchSmsThemeData();
                delayShowRefresh();
            } else {
                if (this.mSmsThemeBuffer.isEmpty()) {
                    if (this.mCurrentPage > 1) {
                        this.mCurrentPage--;
                    }
                    showTip(R.string.no_more_sms_theme);
                } else if (1 == this.mCurrentPage) {
                    RemoteInteractor.getInstance(this.mContext).postCacheJson(this.mSmsThemeListUrl, jSONObject);
                    if (this.mOnlineBuildInThemeList != null) {
                        for (int i3 = 0; i3 < this.mOnlineBuildInThemeList.size(); i3++) {
                            int i4 = 0;
                            while (true) {
                                if (i4 >= this.mSmsThemeBuffer.size()) {
                                    z2 = false;
                                    break;
                                } else if (this.mOnlineBuildInThemeList.get(i3).mPkg.equals(this.mSmsThemeBuffer.get(i4).mPkg)) {
                                    z2 = true;
                                    break;
                                } else {
                                    i4++;
                                }
                            }
                            if (!z2) {
                                this.mSmsThemeBuffer.add(0, this.mOnlineBuildInThemeList.get(i3));
                            }
                        }
                    }
                    this.mSmsGridView.setThemeInfo(this.mSmsThemeBuffer);
                } else {
                    this.mSmsGridView.addThemeInfo(this.mSmsThemeBuffer);
                }
                if (this.mSmsGridView.getItemCount() <= 0) {
                    switchThemeUI(2);
                } else {
                    switchThemeUI(0);
                }
            }
            this.mSmsThemeBuffer.clear();
        }
    }

    private void postFetchSmsThemeData() {
        RemoteInteractor.getInstance(this.mContext).cancelRequest(this.mOldSmsThemeListUrl);
        RemoteInteractor.getInstance(this.mContext).postGetJsonObjectRequest(this.mSmsThemeListUrl, true, true);
    }

    private void postGetSmsThemeDataCache() {
        RemoteInteractor.getInstance(this.mContext).cancelRequest(this.mSmsThemeListUrl);
        RemoteInteractor.getInstance(this.mContext).postGetCacheJson(this.mSmsThemeListUrl);
    }

    private void showTip(int i) {
        Toast.makeText(this.mContext, i, 0).show();
    }

    private void showTip(String str) {
        Toast.makeText(this.mContext, str, 0).show();
    }

    private void switchThemeUI(int i) {
        switchThemeUI(i, false);
    }

    /* access modifiers changed from: private */
    public void switchThemeUI(int i, boolean z) {
        if (this.mSmsGridView != null && this.mRefreshLayout != null) {
            if (i == 0) {
                cancelDelayShowRefresh();
                this.mRefreshLayout.setVisibility(0);
                this.mRefreshLayout.setRefreshing(false);
                this.mSmsThemeNoData.setVisibility(8);
            } else if (1 == i) {
                this.mRefreshLayout.setVisibility(0);
                if (z && this.mRefreshLayout.isRefreshing()) {
                    this.mRefreshLayout.setRefreshing(false);
                }
                this.mRefreshLayout.setRefreshing(true);
                this.mSmsThemeNoData.setVisibility(8);
            } else {
                cancelDelayShowRefresh();
                this.mRefreshLayout.setVisibility(8);
                this.mRefreshLayout.setRefreshing(false);
                this.mSmsThemeNoData.setVisibility(0);
            }
        }
    }

    @Override // com.keyboard.common.remotemodule.core.network.RemoteInteractor.RemoteResponseListener
    public void onCacheResponse(String str, Object obj) {
        JSONObject jSONObject;
        if (str != null && str.equals(this.mSmsThemeListUrl)) {
            try {
                jSONObject = (JSONObject) obj;
            } catch (Exception e) {
                e.printStackTrace();
                jSONObject = null;
            }
            onGetSmsThemeResponse(jSONObject, true);
        }
    }

    @Override // com.sms.common.thememodule.view.TabContainer
    public void onCreate() {
        initData();
    }

    @Override // com.sms.common.thememodule.view.TabContainer
    public void onDestroy() {
        RemoteInteractor.getInstance(this.mContext).removeListener(this);
        if (this.mSmsGridView != null) {
            int childCount = this.mSmsGridView.getChildCount();
            for (int i = 0; i < childCount; i++) {
                View childAt = this.mSmsGridView.getChildAt(i);
                if (childAt != null) {
                    ImageView imageView = (ImageView) childAt.findViewById(R.id.sms_theme_poster);
                    ImageLoaderWrapper.cancelLoadTask(imageView);
                    imageView.setImageDrawable(null);
                }
            }
            this.mSmsGridView.destroy();
        }
        if (this.mSmsThemeBuffer != null) {
            MemoryCache memoryCache = ImageLoaderWrapper.getMemoryCache();
            if (memoryCache != null) {
                Iterator<SmsThemeInfo> it = this.mSmsThemeBuffer.iterator();
                while (it.hasNext()) {
                    SmsThemeInfo next = it.next();
                    if (!(next == null || next.mSmallPreview == null)) {
                        memoryCache.remove(next.mSmallPreview);
                    }
                }
            }
            this.mSmsThemeBuffer.clear();
        }
    }

    @Override // com.keyboard.common.remotemodule.core.network.RemoteInteractor.RemoteResponseListener
    public void onErrorResponse(String str, VolleyError volleyError) {
        String str2;
        if (str != null && this.mSmsThemeListUrl.equals(str)) {
            if (volleyError == null) {
                str2 = "get more theme error:" + " unkown";
            } else {
                str2 = "get more theme error:" + volleyError.getClass().getSimpleName();
                if (volleyError.networkResponse != null) {
                    str2 = str2 + " error code: " + volleyError.networkResponse.statusCode;
                }
            }
            if (this.mSmsGridView != null) {
                if (this.mCurrentPage > 1) {
                    this.mCurrentPage--;
                }
                showTip(str2);
                if (this.mSmsGridView.getItemCount() <= 0) {
                    switchThemeUI(2);
                } else {
                    switchThemeUI(0);
                }
            }
        }
    }

    @Override // com.sms.common.thememodule.view.SmsThemeGridView.ItemClickListener
    public void onItemClick(SmsThemeInfo smsThemeInfo) {
        String str = smsThemeInfo.mPkg;
        String pkgNameFromInstallSource = SuggestInfoUtils.getPkgNameFromInstallSource(str);
        if (pkgNameFromInstallSource != null) {
            if (SuggestInfoUtils.isApkInstalled(this.mContext, pkgNameFromInstallSource)) {
                Toast.makeText(this.mContext, ZeroClient.CLICK_LABEL_YES, 0).show();
            } else {
                Toast.makeText(this.mContext, ZeroClient.CLICK_LABEL_NO, 0).show();
                SuggestInfoUtils.goToInstallApk(this.mContext, str, this.mPkgName, TAG);
            }
            setCurrentTheme(smsThemeInfo.mPkg);
        }
    }

    @Override // com.sms.common.thememodule.view.TabContainer
    public void onPause() {
        ImageLoaderWrapper.pauseImageLoader();
    }

    @Override // com.keyboard.common.uimodule.swiperefreshlayout.SwipeRefreshLayout.OnRefreshListener
    public void onRefresh(int i) {
        switchThemeUI(1);
        nextPage();
        postFetchSmsThemeData();
    }

    @Override // com.keyboard.common.remotemodule.core.network.RemoteInteractor.RemoteResponseListener
    public void onResponse(String str, Object obj) {
        JSONObject jSONObject;
        if (this.mSmsThemeListUrl.equals(str)) {
            try {
                jSONObject = (JSONObject) obj;
            } catch (Exception e) {
                e.printStackTrace();
                jSONObject = null;
            }
            onGetSmsThemeResponse(jSONObject, false);
        }
    }

    @Override // com.sms.common.thememodule.view.TabContainer
    public void onResume() {
        ImageLoaderWrapper.resumeImageLoader();
    }

    /* access modifiers changed from: protected */
    @Override // com.sms.common.thememodule.view.TabContainer
    public String setAppId(String str) {
        if (str != null) {
            this.mSmsThemeAppId = str;
            nextPage();
            postFetchSmsThemeData();
        }
        return this.mSmsThemeAppId;
    }

    /* access modifiers changed from: protected */
    @Override // com.sms.common.thememodule.view.TabContainer
    public void setBuildInThemeList(ArrayList<SmsThemeInfo> arrayList) {
        if (arrayList != null) {
            this.mOnlineBuildInThemeList = arrayList;
        }
    }

    @Override // com.sms.common.thememodule.view.TabContainer
    public void setCurrentTheme(String str) {
        this.mSmsGridView.setCurrentTheme(str);
        this.mSmsGridView.updateView();
    }

    /* access modifiers changed from: protected */
    @Override // com.sms.common.thememodule.view.TabContainer
    public void setItemClickListener(SmsThemeGridView.ItemClickListener itemClickListener) {
        this.mSmsGridView.setItemClickListener(itemClickListener);
    }

    /* access modifiers changed from: protected */
    @Override // com.sms.common.thememodule.view.TabContainer
    public int setPageItemNum(int i) {
        if (i > 0) {
            this.mPageItemNum = i;
        }
        return this.mPageItemNum;
    }
}
