package com.sms.common.thememodule.view;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;
import com.android.volley.VolleyError;
import com.keyboard.common.remotemodule.core.network.ImageLoaderWrapper;
import com.keyboard.common.remotemodule.core.network.RemoteInteractor;
import com.keyboard.common.remotemodule.core.utils.SuggestInfoUtils;
import com.keyboard.common.remotemodule.core.zero.ZeroClient;
import com.keyboard.common.uimodule.swiperefreshlayout.SwipeRefreshLayout;
import com.nostra13.universalimageloader.cache.memory.MemoryCache;
import com.sms.common.thememodule.R;
import com.sms.common.thememodule.data.SmsThemeInfo;
import com.sms.common.thememodule.view.SmsThemeGridView;
import java.util.ArrayList;
import java.util.Iterator;

public class LocalSmsThemeContainer extends TabContainer implements RemoteInteractor.RemoteResponseListener, SmsThemeGridView.ItemClickListener {
    private static final String DEFAULT_VALUE = "default";
    private static final String KEY_SMS_THEME = "SMS_THEME_APPID";
    private static final int MSG_SHOW_REFRESH = 100;
    private static final long SHOW_REFRESH_DELAY = 500;
    private static final String TAG = OnlineSmsThemeContainer.class.getSimpleName();
    private static final int UI_LOADING = 1;
    private static final int UI_NORMAL = 0;
    private static final int UI_NO_DATA = 2;
    private int mColumnsNum = 0;
    private Context mContext = null;
    private int mCurrentPage = 0;
    private ArrayList<SmsThemeInfo> mLocalBuildInThemeList;
    private String mOldSmsThemeListUrl;
    private int mPageItemNum = 0;
    private String mPkgName = null;
    private SwipeRefreshLayout mRefreshLayout = null;
    private SmsThemeGridView mSmsGridView = null;
    private String mSmsThemeAppId;
    private ArrayList<SmsThemeInfo> mSmsThemeBuffer;
    private String mSmsThemeListUrl;
    private ImageView mSmsThemeNoData = null;
    private Handler mUIHandler = null;

    public LocalSmsThemeContainer(Context context) {
        super(context);
        init(context);
    }

    public LocalSmsThemeContainer(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        init(context);
    }

    public LocalSmsThemeContainer(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        init(context);
    }

    private ArrayList<SmsThemeInfo> getLocalDataList() {
        return null;
    }

    @Override // com.sms.common.thememodule.view.TabContainer
    private void init(Context context) {
        this.mContext = context;
        Resources resources = this.mContext.getResources();
        this.mPkgName = this.mContext.getPackageName();
        this.mColumnsNum = resources.getInteger(R.integer.sms_theme_gridview_colnum);
    }

    private void initData() {
        this.mSmsThemeBuffer = new ArrayList<>();
        Resources resources = getResources();
        Drawable drawable = resources.getDrawable(R.drawable.sms_theme_ic_loading);
        Drawable drawable2 = resources.getDrawable(R.drawable.sms_theme_ic_load_error);
        this.mSmsGridView = (SmsThemeGridView) findViewById(R.id.sms_local_theme_gridview);
        this.mSmsGridView.setNumColumns(this.mColumnsNum);
        this.mSmsGridView.setLoadingRes(drawable, drawable2);
        this.mSmsGridView.setItemClickListener(this);
        this.mSmsThemeNoData = (ImageView) findViewById(R.id.sms_theme_no_data);
    }

    private void showTip(int i) {
        Toast.makeText(this.mContext, i, 0).show();
    }

    private void showTip(String str) {
        Toast.makeText(this.mContext, str, 0).show();
    }

    @Override // com.keyboard.common.remotemodule.core.network.RemoteInteractor.RemoteResponseListener
    public void onCacheResponse(String str, Object obj) {
    }

    @Override // com.sms.common.thememodule.view.TabContainer
    public void onCreate() {
        initData();
    }

    @Override // com.sms.common.thememodule.view.TabContainer
    public void onDestroy() {
        if (this.mSmsGridView != null) {
            int childCount = this.mSmsGridView.getChildCount();
            for (int i = 0; i < childCount; i++) {
                View childAt = this.mSmsGridView.getChildAt(i);
                if (childAt != null) {
                    ImageView imageView = (ImageView) childAt.findViewById(R.id.sms_theme_poster);
                    ImageLoaderWrapper.cancelLoadTask(imageView);
                    imageView.setImageDrawable(null);
                }
            }
            this.mSmsGridView.destroy();
        }
        if (this.mSmsThemeBuffer != null) {
            MemoryCache memoryCache = ImageLoaderWrapper.getMemoryCache();
            if (memoryCache != null) {
                Iterator<SmsThemeInfo> it = this.mSmsThemeBuffer.iterator();
                while (it.hasNext()) {
                    SmsThemeInfo next = it.next();
                    if (!(next == null || next.mSmallPreview == null)) {
                        memoryCache.remove(next.mSmallPreview);
                    }
                }
            }
            this.mSmsThemeBuffer.clear();
        }
    }

    @Override // com.keyboard.common.remotemodule.core.network.RemoteInteractor.RemoteResponseListener
    public void onErrorResponse(String str, VolleyError volleyError) {
    }

    @Override // com.sms.common.thememodule.view.SmsThemeGridView.ItemClickListener
    public void onItemClick(SmsThemeInfo smsThemeInfo) {
        String str = smsThemeInfo.mPkg;
        String pkgNameFromInstallSource = SuggestInfoUtils.getPkgNameFromInstallSource(str);
        if (pkgNameFromInstallSource != null) {
            if (SuggestInfoUtils.isApkInstalled(this.mContext, pkgNameFromInstallSource)) {
                Toast.makeText(this.mContext, ZeroClient.CLICK_LABEL_YES, 0).show();
            } else {
                Toast.makeText(this.mContext, ZeroClient.CLICK_LABEL_NO, 0).show();
                SuggestInfoUtils.goToInstallApk(this.mContext, str, this.mPkgName, TAG);
            }
            setCurrentTheme(smsThemeInfo.mPkg);
        }
    }

    @Override // com.sms.common.thememodule.view.TabContainer
    public void onPause() {
        ImageLoaderWrapper.pauseImageLoader();
    }

    @Override // com.keyboard.common.remotemodule.core.network.RemoteInteractor.RemoteResponseListener
    public void onResponse(String str, Object obj) {
    }

    @Override // com.sms.common.thememodule.view.TabContainer
    public void onResume() {
        ImageLoaderWrapper.resumeImageLoader();
    }

    /* access modifiers changed from: protected */
    @Override // com.sms.common.thememodule.view.TabContainer
    public String setAppId(String str) {
        if (str != null) {
            this.mSmsThemeAppId = str;
        }
        return this.mSmsThemeAppId;
    }

    /* access modifiers changed from: protected */
    @Override // com.sms.common.thememodule.view.TabContainer
    public void setBuildInThemeList(ArrayList<SmsThemeInfo> arrayList) {
        if (arrayList != null) {
            this.mLocalBuildInThemeList = arrayList;
            this.mSmsThemeBuffer.addAll(0, this.mLocalBuildInThemeList);
            this.mSmsGridView.setThemeInfo(this.mSmsThemeBuffer);
        }
    }

    @Override // com.sms.common.thememodule.view.TabContainer
    public void setCurrentTheme(String str) {
        this.mSmsGridView.setCurrentTheme(str);
        this.mSmsGridView.updateView();
    }

    /* access modifiers changed from: protected */
    @Override // com.sms.common.thememodule.view.TabContainer
    public void setItemClickListener(SmsThemeGridView.ItemClickListener itemClickListener) {
        this.mSmsGridView.setItemClickListener(itemClickListener);
    }

    /* access modifiers changed from: protected */
    @Override // com.sms.common.thememodule.view.TabContainer
    public int setPageItemNum(int i) {
        if (i > 0) {
            this.mPageItemNum = i;
        }
        return this.mPageItemNum;
    }
}
