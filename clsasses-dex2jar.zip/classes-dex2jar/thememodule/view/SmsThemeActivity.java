package com.sms.common.thememodule.view;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.android.common.inbuymodule.UpdateVersion;
import com.keyboard.common.remotemodule.core.network.ImageLoaderWrapper;
import com.nostra13.universalimageloader.core.display.FadeInBitmapDisplayer;
import com.sms.common.thememodule.R;
import com.sms.common.thememodule.data.SmsThemeInfo;
import com.sms.common.thememodule.view.SlidingTabLayout;
import com.sms.common.thememodule.view.SmsThemeGridView;
import com.sms.common.thememodule.view.TabContainer;
import java.util.ArrayList;
import java.util.Iterator;

public abstract class SmsThemeActivity extends Activity implements TabContainer.TabContainerCallback, ViewPager.OnPageChangeListener, SlidingTabLayout.TabColorizer, SmsThemeGridView.ItemClickListener {
    public static final String DEFAULT_DISK_CACHE_PATH = "/.remote/smstheme/";
    public static final int DEFAULT_DISK_CACHE_SIZE = 104857600;
    public static final int DEFAULT_FADE_DURATION = 500;
    public static final int DEFAULT_MEMORY_CACHE_SIZE = 15728640;
    private static final String THEME_URL = "https://play.google.com/store/search?q=pub:CrazyEmojiTheme";
    public static final Bitmap.Config UIL_IMG_CONFIG = Bitmap.Config.RGB_565;
    public static final int UIL_MAX_CACHE_H = 512;
    public static final int UIL_MAX_CACHE_W = 512;
    private ContentAdapter mContentAdapter = null;
    /* access modifiers changed from: private */
    public ArrayList<ContentData> mContentList = null;
    private ViewPager mContentPager = null;
    private SlidingTabLayout mTabLayout = null;
    private int mTabSelectedColor = 0;
    private int mTabUnSelectedColor = 0;

    private class ContentAdapter extends PagerAdapter {
        public ContentAdapter() {
        }

        @Override // android.support.v4.view.PagerAdapter
        public void destroyItem(ViewGroup viewGroup, int i, Object obj) {
            viewGroup.removeView((TabContainer) obj);
        }

        @Override // android.support.v4.view.PagerAdapter
        public int getCount() {
            if (SmsThemeActivity.this.mContentList == null) {
                return 0;
            }
            return SmsThemeActivity.this.mContentList.size();
        }

        @Override // android.support.v4.view.PagerAdapter
        public CharSequence getPageTitle(int i) {
            return SmsThemeActivity.this.mContentList == null ? "" : ((ContentData) SmsThemeActivity.this.mContentList.get(i)).mTitle;
        }

        @Override // android.support.v4.view.PagerAdapter
        public Object instantiateItem(ViewGroup viewGroup, int i) {
            if (SmsThemeActivity.this.mContentList == null || i < 0 || i >= SmsThemeActivity.this.mContentList.size()) {
                return null;
            }
            ContentData contentData = (ContentData) SmsThemeActivity.this.mContentList.get(i);
            viewGroup.addView(contentData.mContainer);
            return contentData.mContainer;
        }

        @Override // android.support.v4.view.PagerAdapter
        public boolean isViewFromObject(View view, Object obj) {
            return view.equals(obj);
        }
    }

    private class ContentData {
        TabContainer mContainer;
        String mTitle;

        private ContentData() {
        }
    }

    private void initContent() {
        this.mContentPager = (ViewPager) findViewById(R.id.sms_theme_view_pager);
        this.mContentList = new ArrayList<>();
        LayoutInflater from = LayoutInflater.from(this);
        ContentData contentData = new ContentData();
        contentData.mContainer = (TabContainer) from.inflate(R.layout.sms_theme_online_container, (ViewGroup) null);
        contentData.mTitle = "Online";
        contentData.mContainer.setCallback(this);
        contentData.mContainer.setBuildInThemeList(getOnlineBuildInThemeList());
        contentData.mContainer.setAppId(getAppId());
        contentData.mContainer.setPageItemNum(getPageItemNum());
        contentData.mContainer.setItemClickListener(this);
        this.mContentList.add(contentData);
        ContentData contentData2 = new ContentData();
        contentData2.mContainer = (TabContainer) from.inflate(R.layout.sms_theme_local_container, (ViewGroup) null);
        contentData2.mTitle = "Local";
        contentData2.mContainer.setCallback(this);
        contentData2.mContainer.setBuildInThemeList(getLocalBuildInThemeList());
        contentData2.mContainer.setPageItemNum(getPageItemNum());
        contentData2.mContainer.setItemClickListener(this);
        this.mContentList.add(contentData2);
        this.mContentAdapter = new ContentAdapter();
        this.mContentPager.setAdapter(this.mContentAdapter);
        this.mTabLayout = (SlidingTabLayout) findViewById(R.id.tab_layout);
        this.mTabLayout.setDistributeEvenly(true);
        this.mTabLayout.setCustomTabView(R.layout.sms_theme_tab_view, R.id.tab_title);
        this.mTabLayout.setCustomTabColorizer(this);
        this.mTabLayout.setViewPager(this.mContentPager);
        this.mTabLayout.setOnPageChangeListener(this);
        updateTabTitle(0);
    }

    private void initData() {
        Resources resources = getResources();
        this.mTabSelectedColor = resources.getColor(R.color.sms_theme_tab_color_selected);
        this.mTabUnSelectedColor = resources.getColor(R.color.sms_theme_tab_color_unselected);
        this.mContentList = new ArrayList<>();
        ImageLoaderWrapper.init(this, 15728640, 512, 512, 104857600, DEFAULT_DISK_CACHE_PATH, UIL_IMG_CONFIG, new FadeInBitmapDisplayer(500), null, null, null);
    }

    private void installCloudTheme(Context context) {
        String onlineKeyValue = UpdateVersion.getOnlineKeyValue(context, "online_theme_url");
        if (onlineKeyValue == null || onlineKeyValue.length() <= 0) {
            UpdateVersion.rateDirectBrowser(context, THEME_URL);
        } else {
            UpdateVersion.rateDirectBrowser(context, onlineKeyValue);
        }
    }

    private void updateTabTitle(int i) {
        if (this.mTabLayout != null) {
            try {
                ViewGroup viewGroup = (ViewGroup) this.mTabLayout.getTabStrip();
                for (int i2 = 0; i2 < viewGroup.getChildCount(); i2++) {
                    TextView textView = (TextView) viewGroup.getChildAt(i2);
                    if (i == i2) {
                        textView.setTextColor(this.mTabSelectedColor);
                    } else {
                        textView.setTextColor(this.mTabUnSelectedColor);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /* access modifiers changed from: protected */
    public abstract void clickItem(SmsThemeInfo smsThemeInfo);

    /* access modifiers changed from: protected */
    public abstract String getAdsId();

    /* access modifiers changed from: protected */
    public abstract String getAppId();

    @Override // com.sms.common.thememodule.view.SlidingTabLayout.TabColorizer
    public int getIndicatorColor(int i) {
        return this.mTabSelectedColor;
    }

    /* access modifiers changed from: protected */
    public abstract ArrayList<SmsThemeInfo> getLocalBuildInThemeList();

    /* access modifiers changed from: protected */
    public abstract ArrayList<SmsThemeInfo> getOnlineBuildInThemeList();

    /* access modifiers changed from: protected */
    public abstract int getPageItemNum();

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: ClspMth{android.content.Intent.putExtra(java.lang.String, boolean):android.content.Intent}
     arg types: [java.lang.String, int]
     candidates:
      ClspMth{android.content.Intent.putExtra(java.lang.String, int):android.content.Intent}
      ClspMth{android.content.Intent.putExtra(java.lang.String, java.lang.String[]):android.content.Intent}
      ClspMth{android.content.Intent.putExtra(java.lang.String, int[]):android.content.Intent}
      ClspMth{android.content.Intent.putExtra(java.lang.String, double):android.content.Intent}
      ClspMth{android.content.Intent.putExtra(java.lang.String, char):android.content.Intent}
      ClspMth{android.content.Intent.putExtra(java.lang.String, boolean[]):android.content.Intent}
      ClspMth{android.content.Intent.putExtra(java.lang.String, byte):android.content.Intent}
      ClspMth{android.content.Intent.putExtra(java.lang.String, android.os.Bundle):android.content.Intent}
      ClspMth{android.content.Intent.putExtra(java.lang.String, float):android.content.Intent}
      ClspMth{android.content.Intent.putExtra(java.lang.String, java.lang.CharSequence[]):android.content.Intent}
      ClspMth{android.content.Intent.putExtra(java.lang.String, java.lang.CharSequence):android.content.Intent}
      ClspMth{android.content.Intent.putExtra(java.lang.String, long[]):android.content.Intent}
      ClspMth{android.content.Intent.putExtra(java.lang.String, long):android.content.Intent}
      ClspMth{android.content.Intent.putExtra(java.lang.String, short):android.content.Intent}
      ClspMth{android.content.Intent.putExtra(java.lang.String, android.os.Parcelable[]):android.content.Intent}
      ClspMth{android.content.Intent.putExtra(java.lang.String, java.io.Serializable):android.content.Intent}
      ClspMth{android.content.Intent.putExtra(java.lang.String, double[]):android.content.Intent}
      ClspMth{android.content.Intent.putExtra(java.lang.String, android.os.Parcelable):android.content.Intent}
      ClspMth{android.content.Intent.putExtra(java.lang.String, float[]):android.content.Intent}
      ClspMth{android.content.Intent.putExtra(java.lang.String, byte[]):android.content.Intent}
      ClspMth{android.content.Intent.putExtra(java.lang.String, java.lang.String):android.content.Intent}
      ClspMth{android.content.Intent.putExtra(java.lang.String, short[]):android.content.Intent}
      ClspMth{android.content.Intent.putExtra(java.lang.String, char[]):android.content.Intent}
      ClspMth{android.content.Intent.putExtra(java.lang.String, boolean):android.content.Intent} */
    public void onCreate(Bundle bundle) {
        Intent intent = getIntent();
        if (intent == null) {
            intent = new Intent();
        }
        intent.putExtra("buystatus", false);
        intent.putExtra("adsid", getAdsId());
        intent.putExtra("position", "first");
        setIntent(intent);
        super.onCreate(bundle);
        if (Build.VERSION.SDK_INT > 14) {
            getActionBar().setIcon(R.drawable.action_icon_none);
        }
        setContentView(R.layout.sms_theme_tab_main_layout);
        initData();
        initContent();
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_theme, menu);
        return super.onCreateOptionsMenu(menu);
    }

    /* access modifiers changed from: protected */
    public void onDestroy() {
        super.onDestroy();
        if (this.mContentPager != null) {
            this.mContentAdapter = null;
            this.mContentPager.setAdapter(null);
            this.mContentPager = null;
        }
        if (this.mContentList != null) {
            Iterator<ContentData> it = this.mContentList.iterator();
            while (it.hasNext()) {
                ContentData next = it.next();
                if (!(next == null || next.mContainer == null)) {
                    next.mContainer.onDestroy();
                    next.mContainer = null;
                }
            }
            this.mContentList.clear();
            this.mContentList = null;
        }
        this.mTabLayout = null;
        ImageLoaderWrapper.release();
    }

    @Override // com.sms.common.thememodule.view.SmsThemeGridView.ItemClickListener
    public void onItemClick(SmsThemeInfo smsThemeInfo) {
        clickItem(smsThemeInfo);
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        installCloudTheme(this);
        return true;
    }

    @Override // android.support.v4.view.ViewPager.OnPageChangeListener
    public void onPageScrollStateChanged(int i) {
    }

    @Override // android.support.v4.view.ViewPager.OnPageChangeListener
    public void onPageScrolled(int i, float f, int i2) {
    }

    @Override // android.support.v4.view.ViewPager.OnPageChangeListener
    public void onPageSelected(int i) {
        if (this.mContentList != null) {
            int i2 = 0;
            while (true) {
                int i3 = i2;
                if (i3 < this.mContentList.size()) {
                    ContentData contentData = this.mContentList.get(i3);
                    if (!(contentData == null || contentData.mContainer == null)) {
                        if (i3 == i) {
                            contentData.mContainer.onScrollIn();
                        } else {
                            contentData.mContainer.onScrollOut();
                        }
                    }
                    i2 = i3 + 1;
                } else {
                    updateTabTitle(i);
                    return;
                }
            }
        }
    }

    /* access modifiers changed from: protected */
    public void onPause() {
        super.onPause();
        if (this.mContentList != null) {
            Iterator<ContentData> it = this.mContentList.iterator();
            while (it.hasNext()) {
                ContentData next = it.next();
                if (!(next == null || next.mContainer == null)) {
                    next.mContainer.onPause();
                }
            }
        }
    }

    /* access modifiers changed from: protected */
    public void onRestart() {
        super.onRestart();
        if (this.mContentList != null) {
            Iterator<ContentData> it = this.mContentList.iterator();
            while (it.hasNext()) {
                ContentData next = it.next();
                if (!(next == null || next.mContainer == null)) {
                    next.mContainer.onRestart();
                }
            }
        }
    }

    /* access modifiers changed from: protected */
    public void onResume() {
        super.onResume();
        ImageLoaderWrapper.resumeImageLoader();
        if (this.mContentList != null) {
            Iterator<ContentData> it = this.mContentList.iterator();
            while (it.hasNext()) {
                ContentData next = it.next();
                if (!(next == null || next.mContainer == null)) {
                    next.mContainer.onResume();
                }
            }
        }
    }

    /* access modifiers changed from: protected */
    public void onStop() {
        super.onStop();
        if (this.mContentList != null) {
            Iterator<ContentData> it = this.mContentList.iterator();
            while (it.hasNext()) {
                ContentData next = it.next();
                if (!(next == null || next.mContainer == null)) {
                    next.mContainer.onStop();
                }
            }
        }
    }

    @Override // com.sms.common.thememodule.view.TabContainer.TabContainerCallback
    public void onThemeChange(String str) {
        if (this.mContentList != null) {
            Iterator<ContentData> it = this.mContentList.iterator();
            while (it.hasNext()) {
                ContentData next = it.next();
                if (!(next == null || next.mContainer == null)) {
                    next.mContainer.setCurrentTheme(str);
                }
            }
        }
    }

    public void setCurrentTheme(String str) {
        int i = 0;
        while (true) {
            int i2 = i;
            if (i2 < this.mContentList.size()) {
                if (str != null) {
                    this.mContentList.get(i2).mContainer.setCurrentTheme(str);
                }
                i = i2 + 1;
            } else {
                return;
            }
        }
    }
}
