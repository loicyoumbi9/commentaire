package com.sms.common.thememodule.view;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.FrameLayout;
import com.sms.common.thememodule.data.SmsThemeInfo;
import com.sms.common.thememodule.view.SmsThemeGridView;
import java.util.ArrayList;

public abstract class TabContainer extends FrameLayout {
    protected TabContainerCallback mCallback = null;

    interface TabContainerCallback {
        void onThemeChange(String str);
    }

    public TabContainer(Context context) {
        super(context);
        init(context);
    }

    public TabContainer(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        init(context);
    }

    public TabContainer(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        init(context);
    }

    private void init(Context context) {
    }

    public void onCreate() {
    }

    public void onDestroy() {
    }

    /* access modifiers changed from: protected */
    public void onFinishInflate() {
        super.onFinishInflate();
        onCreate();
    }

    public void onPause() {
    }

    public void onRestart() {
    }

    public void onResume() {
    }

    public void onScrollIn() {
    }

    public void onScrollOut() {
    }

    public void onStop() {
    }

    /* access modifiers changed from: protected */
    public abstract String setAppId(String str);

    /* access modifiers changed from: protected */
    public abstract void setBuildInThemeList(ArrayList<SmsThemeInfo> arrayList);

    public void setCallback(TabContainerCallback tabContainerCallback) {
        this.mCallback = tabContainerCallback;
    }

    /* access modifiers changed from: protected */
    public abstract void setCurrentTheme(String str);

    /* access modifiers changed from: protected */
    public abstract void setItemClickListener(SmsThemeGridView.ItemClickListener itemClickListener);

    /* access modifiers changed from: protected */
    public abstract int setPageItemNum(int i);

    public void themeInstalled(String str) {
    }

    public void themeUninstall(String str) {
    }
}
