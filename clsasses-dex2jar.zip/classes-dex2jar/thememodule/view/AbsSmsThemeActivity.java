package com.sms.common.thememodule.view;

import android.app.Activity;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;
import com.android.volley.VolleyError;
import com.keyboard.common.remotemodule.core.network.ImageLoaderWrapper;
import com.keyboard.common.remotemodule.core.network.RemoteInteractor;
import com.keyboard.common.remotemodule.core.network.RemoteUrlFactory;
import com.keyboard.common.uimodule.swiperefreshlayout.SwipeRefreshLayout;
import com.nostra13.universalimageloader.cache.memory.MemoryCache;
import com.sms.common.thememodule.R;
import com.sms.common.thememodule.data.SmsRemoteDecoder;
import com.sms.common.thememodule.data.SmsThemeInfo;
import com.sms.common.thememodule.view.SmsThemeGridView;
import java.util.ArrayList;
import java.util.Iterator;
import org.json.JSONObject;

public abstract class AbsSmsThemeActivity extends Activity implements RemoteInteractor.RemoteResponseListener, SwipeRefreshLayout.OnRefreshListener, SmsThemeGridView.ItemClickListener {
    private static final int MSG_SHOW_REFRESH = 100;
    private static final long SHOW_REFRESH_DELAY = 500;
    private static final String TAG = AbsSmsThemeActivity.class.getSimpleName();
    private static final int UI_LOADING = 1;
    private static final int UI_NORMAL = 0;
    private static final int UI_NO_DATA = 2;
    private int mCurrentPage = 0;
    private String mOldSmsThemeListUrl;
    private int mPageItemNum = 0;
    private SwipeRefreshLayout mRefreshLayout = null;
    protected SmsThemeGridView mSmsGridView;
    private String mSmsThemeAppId;
    private ArrayList<SmsThemeInfo> mSmsThemeBuffer;
    private String mSmsThemeListUrl;
    private ImageView mSmsThemeNoData = null;
    private Handler mUIHandler = null;

    private void cancelDelayShowRefresh() {
        if (this.mUIHandler != null) {
            this.mUIHandler.removeMessages(100);
        }
    }

    private void delayShowRefresh() {
        if (this.mUIHandler != null) {
            this.mUIHandler.removeMessages(100);
            this.mUIHandler.sendEmptyMessageDelayed(100, SHOW_REFRESH_DELAY);
        }
    }

    private void initData() {
        Resources resources = getResources();
        this.mPageItemNum = getPageItemNum();
        this.mSmsThemeAppId = getAppId();
        this.mSmsThemeBuffer = new ArrayList<>();
        Drawable drawable = resources.getDrawable(R.drawable.sms_theme_ic_loading);
        Drawable drawable2 = resources.getDrawable(R.drawable.sms_theme_ic_load_error);
        this.mSmsGridView = (SmsThemeGridView) findViewById(R.id.sms_theme_gridview);
        this.mSmsGridView.setLoadingRes(drawable, drawable2);
        this.mSmsGridView.setItemClickListener(this);
        this.mRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.sms_theme_refresh_layout);
        this.mRefreshLayout.setColorScheme(R.color.sms_theme_activity_refresh_color1, R.color.sms_theme_activity_refresh_color2, R.color.sms_theme_activity_refresh_color3, R.color.sms_theme_activity_refresh_color4);
        this.mRefreshLayout.setRefreshMode(1);
        this.mRefreshLayout.setOnRefreshListener(this);
        this.mSmsThemeNoData = (ImageView) findViewById(R.id.sms_theme_no_data);
        RemoteInteractor.getInstance(this).addListener(this);
        initHandler();
    }

    private void initHandler() {
        this.mUIHandler = new Handler(Looper.getMainLooper(), new Handler.Callback() {
            /* class com.sms.common.thememodule.view.AbsSmsThemeActivity.AnonymousClass1 */

            public boolean handleMessage(Message message) {
                switch (message.what) {
                    case 100:
                        AbsSmsThemeActivity.this.switchThemeUI(1, true);
                        return true;
                    default:
                        return false;
                }
            }
        });
    }

    private void nextPage() {
        this.mOldSmsThemeListUrl = RemoteUrlFactory.assembleGetThemeListUrl(this.mSmsThemeAppId, this.mCurrentPage, this.mPageItemNum);
        this.mCurrentPage++;
        this.mSmsThemeListUrl = RemoteUrlFactory.assembleGetThemeListUrl(this.mSmsThemeAppId, this.mCurrentPage, this.mPageItemNum);
    }

    private void onGetSmsThemeResponse(JSONObject jSONObject, boolean z) {
        if (this.mSmsGridView != null) {
            this.mSmsThemeBuffer.clear();
            SmsRemoteDecoder.decodeSmsThemeRaw(this.mSmsThemeBuffer, jSONObject);
            if (!(this.mSmsThemeBuffer == null || getLocalDataList() == null)) {
                for (int i = 0; i < this.mSmsThemeBuffer.size(); i++) {
                    for (int i2 = 0; i2 < getLocalDataList().size(); i2++) {
                        if (getLocalDataList().get(i2).mPkg.equals(this.mSmsThemeBuffer.get(i).mPkg)) {
                            this.mSmsThemeBuffer.remove(i);
                        }
                    }
                }
            }
            if (z) {
                if (getLocalDataList() != null) {
                    this.mSmsThemeBuffer.addAll(0, getLocalDataList());
                }
                this.mSmsGridView.setThemeInfo(this.mSmsThemeBuffer);
                postFetchSmsThemeData();
                delayShowRefresh();
            } else {
                if (this.mSmsThemeBuffer.isEmpty()) {
                    if (this.mCurrentPage > 1) {
                        this.mCurrentPage--;
                    }
                    showTip(R.string.no_more_sms_theme);
                } else if (1 == this.mCurrentPage) {
                    RemoteInteractor.getInstance(this).postCacheJson(this.mSmsThemeListUrl, jSONObject);
                    if (getLocalDataList() != null) {
                        this.mSmsThemeBuffer.addAll(0, getLocalDataList());
                    }
                    this.mSmsGridView.setThemeInfo(this.mSmsThemeBuffer);
                } else {
                    this.mSmsGridView.addThemeInfo(this.mSmsThemeBuffer);
                }
                if (this.mSmsGridView.getItemCount() <= 0) {
                    switchThemeUI(2);
                } else {
                    switchThemeUI(0);
                }
            }
            this.mSmsThemeBuffer.clear();
        }
    }

    private void postFetchSmsThemeData() {
        RemoteInteractor.getInstance(this).cancelRequest(this.mOldSmsThemeListUrl);
        RemoteInteractor.getInstance(this).postGetJsonObjectRequest(this.mSmsThemeListUrl, true, true);
    }

    private void postGetSmsThemeDataCache() {
        RemoteInteractor.getInstance(this).cancelRequest(this.mSmsThemeListUrl);
        RemoteInteractor.getInstance(this).postGetCacheJson(this.mSmsThemeListUrl);
    }

    private void showTip(int i) {
        Toast.makeText(this, i, 0).show();
    }

    private void showTip(String str) {
        Toast.makeText(this, str, 0).show();
    }

    private void switchThemeUI(int i) {
        switchThemeUI(i, false);
    }

    /* access modifiers changed from: private */
    public void switchThemeUI(int i, boolean z) {
        if (this.mSmsGridView != null && this.mRefreshLayout != null) {
            if (i == 0) {
                cancelDelayShowRefresh();
                this.mRefreshLayout.setVisibility(0);
                this.mRefreshLayout.setRefreshing(false);
                this.mSmsThemeNoData.setVisibility(8);
            } else if (1 == i) {
                this.mRefreshLayout.setVisibility(0);
                if (z && this.mRefreshLayout.isRefreshing()) {
                    this.mRefreshLayout.setRefreshing(false);
                }
                this.mRefreshLayout.setRefreshing(true);
                this.mSmsThemeNoData.setVisibility(8);
            } else {
                cancelDelayShowRefresh();
                this.mRefreshLayout.setVisibility(8);
                this.mRefreshLayout.setRefreshing(false);
                this.mSmsThemeNoData.setVisibility(0);
            }
        }
    }

    /* access modifiers changed from: protected */
    public abstract void clickItem(SmsThemeInfo smsThemeInfo);

    /* access modifiers changed from: protected */
    public abstract String getAppId();

    /* access modifiers changed from: protected */
    public abstract ArrayList<SmsThemeInfo> getLocalDataList();

    /* access modifiers changed from: protected */
    public abstract int getPageItemNum();

    @Override // com.keyboard.common.remotemodule.core.network.RemoteInteractor.RemoteResponseListener
    public void onCacheResponse(String str, Object obj) {
        JSONObject jSONObject;
        if (str != null && str.equals(this.mSmsThemeListUrl)) {
            try {
                jSONObject = (JSONObject) obj;
            } catch (Exception e) {
                e.printStackTrace();
                jSONObject = null;
            }
            onGetSmsThemeResponse(jSONObject, true);
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.sms_theme_layout);
        initData();
        nextPage();
        postGetSmsThemeDataCache();
    }

    public void onDestroy() {
        super.onDestroy();
        RemoteInteractor.getInstance(this).removeListener(this);
        if (this.mSmsGridView != null) {
            int childCount = this.mSmsGridView.getChildCount();
            for (int i = 0; i < childCount; i++) {
                View childAt = this.mSmsGridView.getChildAt(i);
                if (childAt != null) {
                    ImageView imageView = (ImageView) childAt.findViewById(R.id.sms_theme_poster);
                    ImageLoaderWrapper.cancelLoadTask(imageView);
                    imageView.setImageDrawable(null);
                }
            }
            this.mSmsGridView.destroy();
        }
        if (this.mSmsThemeBuffer != null) {
            MemoryCache memoryCache = ImageLoaderWrapper.getMemoryCache();
            if (memoryCache != null) {
                Iterator<SmsThemeInfo> it = this.mSmsThemeBuffer.iterator();
                while (it.hasNext()) {
                    SmsThemeInfo next = it.next();
                    if (!(next == null || next.mSmallPreview == null)) {
                        memoryCache.remove(next.mSmallPreview);
                    }
                }
            }
            this.mSmsThemeBuffer.clear();
        }
    }

    @Override // com.keyboard.common.remotemodule.core.network.RemoteInteractor.RemoteResponseListener
    public void onErrorResponse(String str, VolleyError volleyError) {
        String str2;
        if (str != null && this.mSmsThemeListUrl.equals(str)) {
            if (volleyError == null) {
                str2 = "get more theme error:" + " unkown";
            } else {
                str2 = "get more theme error:" + volleyError.getClass().getSimpleName();
                if (volleyError.networkResponse != null) {
                    str2 = str2 + " error code: " + volleyError.networkResponse.statusCode;
                }
            }
            if (this.mSmsGridView != null) {
                if (this.mCurrentPage > 1) {
                    this.mCurrentPage--;
                }
                showTip(str2);
                if (this.mSmsGridView.getItemCount() <= 0) {
                    switchThemeUI(2);
                } else {
                    switchThemeUI(0);
                }
            }
        }
    }

    @Override // com.sms.common.thememodule.view.SmsThemeGridView.ItemClickListener
    public void onItemClick(SmsThemeInfo smsThemeInfo) {
        clickItem(smsThemeInfo);
    }

    public void onPause() {
        super.onResume();
        ImageLoaderWrapper.pauseImageLoader();
    }

    @Override // com.keyboard.common.uimodule.swiperefreshlayout.SwipeRefreshLayout.OnRefreshListener
    public void onRefresh(int i) {
        switchThemeUI(1);
        nextPage();
        postFetchSmsThemeData();
    }

    @Override // com.keyboard.common.remotemodule.core.network.RemoteInteractor.RemoteResponseListener
    public void onResponse(String str, Object obj) {
        JSONObject jSONObject;
        if (this.mSmsThemeListUrl.equals(str)) {
            try {
                jSONObject = (JSONObject) obj;
            } catch (Exception e) {
                e.printStackTrace();
                jSONObject = null;
            }
            onGetSmsThemeResponse(jSONObject, false);
        }
    }

    public void onResume() {
        super.onResume();
        ImageLoaderWrapper.resumeImageLoader();
    }

    public void setCurrentTheme(String str) {
        this.mSmsGridView.setCurrentTheme(str);
        this.mSmsGridView.updateView();
    }
}
