package u.aly;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class ds extends du {
    protected InputStream a = null;
    protected OutputStream b = null;

    protected ds() {
    }

    public ds(InputStream inputStream) {
        this.a = inputStream;
    }

    public ds(InputStream inputStream, OutputStream outputStream) {
        this.a = inputStream;
        this.b = outputStream;
    }

    public ds(OutputStream outputStream) {
        this.b = outputStream;
    }

    @Override // u.aly.du
    public int a(byte[] bArr, int i, int i2) throws dv {
        if (this.a == null) {
            throw new dv(1, "Cannot read from null inputStream");
        }
        try {
            int read = this.a.read(bArr, i, i2);
            if (read >= 0) {
                return read;
            }
            throw new dv(4);
        } catch (IOException e) {
            throw new dv(0, e);
        }
    }

    @Override // u.aly.du
    public boolean a() {
        return true;
    }

    @Override // u.aly.du
    public void b() throws dv {
    }

    @Override // u.aly.du
    public void b(byte[] bArr, int i, int i2) throws dv {
        if (this.b == null) {
            throw new dv(1, "Cannot write to null outputStream");
        }
        try {
            this.b.write(bArr, i, i2);
        } catch (IOException e) {
            throw new dv(0, e);
        }
    }

    @Override // u.aly.du
    public void c() {
        if (this.a != null) {
            try {
                this.a.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            this.a = null;
        }
        if (this.b != null) {
            try {
                this.b.close();
            } catch (IOException e2) {
                e2.printStackTrace();
            }
            this.b = null;
        }
    }

    @Override // u.aly.du
    public void d() throws dv {
        if (this.b == null) {
            throw new dv(1, "Cannot flush null outputStream");
        }
        try {
            this.b.flush();
        } catch (IOException e) {
            throw new dv(0, e);
        }
    }
}
