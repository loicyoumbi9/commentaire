package u.aly;

public final class dd {
    public final byte a;
    public final byte b;
    public final int c;

    public dd() {
        this((byte) 0, (byte) 0, 0);
    }

    public dd(byte b2, byte b3, int i) {
        this.a = b2;
        this.b = b3;
        this.c = i;
    }
}
